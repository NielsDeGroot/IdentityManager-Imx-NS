import { __awaiter } from 'tslib';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Input, ViewChild, Inject, NgModule } from '@angular/core';
import * as i4$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i4 from '@elemental-ui/core';
import { EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i1 from 'qer';
import { RequestableEntitlementType } from 'qer';
import * as i1$1 from 'qbm';
import { BaseCdr, CdrModule, DataSourceToolbarModule, DataTableModule } from 'qbm';
import * as i5 from '@angular/material/button';
import { DisplayColumns, XOrigin } from 'imx-qbm-dbts';
import { V2Client, TypedClient } from 'imx-api-aad';
import * as i3$1 from '@angular/material/card';
import * as i1$2 from '@angular/forms';
import { UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i2 from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function canReadInAzure(groups) {
    return groups.find(item => item === 'AAD_4_NAMESPACEADMIN_AZUREAD') != null;
}

class AadPermissionsService {
    constructor(userService) {
        this.userService = userService;
    }
    canReadInAzure() {
        return __awaiter(this, void 0, void 0, function* () {
            return canReadInAzure((yield this.userService.getGroups()).map(group => group.Name));
        });
    }
}
AadPermissionsService.ɵfac = function AadPermissionsService_Factory(t) { return new (t || AadPermissionsService)(i0.ɵɵinject(i1.UserModelService)); };
AadPermissionsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AadPermissionsService, factory: AadPermissionsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AadPermissionsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1.UserModelService }]; }, null);
})();

class AadExtensionService {
    constructor(permissions, appConfig) {
        this.permissions = permissions;
        this.appConfig = appConfig;
    }
    canReadInAzure() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.permissions.canReadInAzure();
        });
    }
    getReportForSubSku(uidSubSku) {
        return `${this.appConfig.BaseUrl}/portal/targetsystem/aadsubsku/${uidSubSku}/licenceoverview`;
    }
}
AadExtensionService.ɵfac = function AadExtensionService_Factory(t) { return new (t || AadExtensionService)(i0.ɵɵinject(AadPermissionsService), i0.ɵɵinject(i1$1.AppConfigService)); };
AadExtensionService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AadExtensionService, factory: AadExtensionService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AadExtensionService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: AadPermissionsService }, { type: i1$1.AppConfigService }]; }, null);
})();

function LicenceOverviewButtonComponent_button_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "button", 1)(1, "span", 2);
        i0.ɵɵtext(2, "#LDS#Download licence overview");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("euiDownload", ctx_r0.licenceOverview);
    }
}
class LicenceOverviewButtonComponent {
    constructor(aadService, permissions) {
        this.aadService = aadService;
        this.permissions = permissions;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const url = this.referrer.type === 'AADSubSku'
                && (yield this.permissions.canReadInAzure()) ?
                this.aadService.getReportForSubSku(this.referrer.uidGroup) : '';
            this.licenceOverview = url != null && url !== '' ? Object.assign(Object.assign({}, this.referrer.defaultDownloadOptions), { url }) : undefined;
        });
    }
}
LicenceOverviewButtonComponent.ɵfac = function LicenceOverviewButtonComponent_Factory(t) { return new (t || LicenceOverviewButtonComponent)(i0.ɵɵdirectiveInject(AadExtensionService), i0.ɵɵdirectiveInject(AadPermissionsService)); };
LicenceOverviewButtonComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LicenceOverviewButtonComponent, selectors: [["ng-component"]], inputs: { referrer: "referrer" }, decls: 1, vars: 1, consts: [["class", "imx-licence-button", "mat-stroked-button", "", "color", "primary", "data-imx-identifier", "licence-overview-button-download-license overview", 3, "euiDownload", 4, "ngIf"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "licence-overview-button-download-license overview", 1, "imx-licence-button", 3, "euiDownload"], ["translate", ""]], template: function LicenceOverviewButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, LicenceOverviewButtonComponent_button_0_Template, 3, 1, "button", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.licenceOverview);
        }
    }, dependencies: [i3.NgIf, i4.EuiDownloadDirective, i5.MatButton, i4$1.TranslateDirective], styles: [".imx-licence-button[_ngcontent-%COMP%]{margin-left:10px;margin-right:10px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LicenceOverviewButtonComponent, [{
            type: Component,
            args: [{ template: "<button class=\"imx-licence-button\" *ngIf=\"licenceOverview\" mat-stroked-button color=\"primary\" [euiDownload]=\"licenceOverview\"\r\n  data-imx-identifier=\"licence-overview-button-download-license overview\">\r\n  <span translate>#LDS#Download licence overview</span>\r\n</button>", styles: [".imx-licence-button{margin-left:10px;margin-right:10px}\n"] }]
        }], function () { return [{ type: AadExtensionService }, { type: AadPermissionsService }]; }, { referrer: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing AAD API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
ApiService.ɵfac = function ApiService_Factory(t) { return new (t || ApiService)(i0.ɵɵinject(i1$1.AppConfigService), i0.ɵɵinject(i1$1.ClassloggerService), i0.ɵɵinject(i1$1.ImxTranslationProviderService)); };
ApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApiService, factory: ApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1$1.AppConfigService }, { type: i1$1.ClassloggerService }, { type: i1$1.ImxTranslationProviderService }]; }, null);
})();

class AzureAdService {
    constructor(aadApiClient, busyService) {
        this.aadApiClient = aadApiClient;
        this.busyService = busyService;
    }
    get aadUserSchema() {
        return this.aadApiClient.typedClient.PortalTargetsystemAaduserSubsku.GetSchema();
    }
    get aadUserDeniedPlansSchema() {
        return this.aadApiClient.typedClient.PortalTargetsystemAaduserDeniedserviceplans.GetSchema();
    }
    get aadGroupSubSchema() {
        return this.aadApiClient.typedClient.PortalTargetsystemAadgroupSubsku.GetSchema();
    }
    get aadGroupDeniedPlansSchema() {
        return this.aadApiClient.typedClient.PortalTargetsystemAadgroupDeniedserviceplans.GetSchema();
    }
    getAadUserSubscriptions(uidAadUser, navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.aadApiClient.typedClient.PortalTargetsystemAaduserSubsku.Get(uidAadUser, navigationState);
        });
    }
    getAadUserDeniedPlans(uidAadUser, navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.aadApiClient.typedClient.PortalTargetsystemAaduserDeniedserviceplans.Get(uidAadUser, navigationState);
        });
    }
    getAadGroupDeniedPlans(uidAadGroup, navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.aadApiClient.typedClient.PortalTargetsystemAadgroupDeniedserviceplans.Get(uidAadGroup, navigationState);
        });
    }
    getAadGroupSubscriptions(uidAadGroup, navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.aadApiClient.typedClient.PortalTargetsystemAadgroupSubsku.Get(uidAadGroup, navigationState);
        });
    }
    generateAadUserSubscriptionEntity(uidAaduser) {
        return this.aadApiClient.typedClient.PortalTargetsystemAaduserSubsku.createEntity({
            Columns: {
                UID_AADUser: {
                    Value: uidAaduser
                }
            }
        });
    }
    generateAadUserDeniedPlanEntity(uidAaduser) {
        return this.aadApiClient.typedClient.PortalTargetsystemAaduserDeniedserviceplans.createEntity({
            Columns: {
                UID_AADUser: {
                    Value: uidAaduser
                }
            }
        });
    }
    createAadUserSubscription(uidAadUser, aadUserSubscription) {
        return this.aadApiClient.typedClient.PortalTargetsystemAaduserSubsku.Post(uidAadUser, aadUserSubscription);
    }
    createAadUserDeniedPlan(uidAadUser, aadUserDeniedPlan) {
        return this.aadApiClient.typedClient.PortalTargetsystemAaduserDeniedserviceplans.Post(uidAadUser, aadUserDeniedPlan);
    }
    removeAadUserSubscriptions(uidAadUser, userSubscriptions) {
        return __awaiter(this, void 0, void 0, function* () {
            const promises = [];
            userSubscriptions.forEach((userSub) => {
                const key = userSub.GetEntity().GetKeys().join();
                promises.push(this.aadApiClient.client.portal_targetsystem_aaduser_subsku_delete(uidAadUser, key));
            });
            return Promise.all(promises);
        });
    }
    removeAadUserDeniedPlans(uidAadUser, userDeniedPlans) {
        return __awaiter(this, void 0, void 0, function* () {
            const promises = [];
            userDeniedPlans.forEach((deniedPlan) => {
                const deniedPlanValue = deniedPlan.UID_AADDeniedServicePlan.value;
                promises.push(this.aadApiClient.client.portal_targetsystem_aaduser_deniedserviceplans_delete(uidAadUser, deniedPlanValue));
            });
            return Promise.all(promises);
        });
    }
    handleOpenLoader() {
        if (!this.busyIndicator) {
            this.busyIndicator = this.busyService.show();
        }
    }
    handleCloseLoader() {
        if (this.busyIndicator) {
            setTimeout(() => {
                this.busyService.hide(this.busyIndicator);
                this.busyIndicator = undefined;
            });
        }
    }
}
AzureAdService.ɵfac = function AzureAdService_Factory(t) { return new (t || AzureAdService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i4.EuiLoadingService)); };
AzureAdService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AzureAdService, factory: AzureAdService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AzureAdService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: ApiService }, { type: i4.EuiLoadingService }]; }, null);
})();

const _c0$3 = ["dataTable"];
const _c1$3 = function () { return ["search", "filter"]; };
const _c2$3 = function () { return ["namespace"]; };
class AadGroupSubscriptionsComponent {
    constructor(logger, aadService, settings, dataProvider) {
        this.logger = logger;
        this.aadService = aadService;
        this.filterOptions = [];
        this.DisplayColumns = DisplayColumns;
        this.displayedColumns = [];
        this.navigationState = { PageSize: settings.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaAadGroupSub = this.aadService.aadGroupSubSchema;
        this.referrer = dataProvider.data;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.displayedColumns = [
                this.entitySchemaAadGroupSub.Columns.UID_AADSubSku,
                this.entitySchemaAadGroupSub.Columns.XOrigin
            ];
            yield this.navigate();
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.navigate();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Searching for: ${keywords}`);
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.navigate();
        });
    }
    navigate() {
        return __awaiter(this, void 0, void 0, function* () {
            this.aadService.handleOpenLoader();
            try {
                const data = yield this.aadService.getAadGroupSubscriptions(this.referrer.objectuid, this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: data,
                    entitySchema: this.entitySchemaAadGroupSub,
                    navigationState: this.navigationState,
                    filters: this.filterOptions,
                };
                this.logger.debug(this, `Head at ${data.Data.length + this.navigationState.StartIndex} of ${data.totalCount} item(s)`);
            }
            finally {
                this.aadService.handleCloseLoader();
            }
        });
    }
}
AadGroupSubscriptionsComponent.ɵfac = function AadGroupSubscriptionsComponent_Factory(t) { return new (t || AadGroupSubscriptionsComponent)(i0.ɵɵdirectiveInject(i1$1.ClassloggerService), i0.ɵɵdirectiveInject(AzureAdService), i0.ɵɵdirectiveInject(i1$1.SettingsService), i0.ɵɵdirectiveInject(i1$1.DynamicTabDataProviderDirective)); };
AadGroupSubscriptionsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AadGroupSubscriptionsComponent, selectors: [["imx-aad-group-subscriptions"]], viewQuery: function AadGroupSubscriptionsComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$3, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTable = _t.first);
        }
    }, decls: 12, vars: 13, consts: [[1, "imx-content"], ["translate", "", 1, "mat-headline"], [1, "imx-content-card"], ["data-imx-identifier", "aad-group-subscriptions-toolbar", 3, "settings", "options", "hiddenFilters", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "aad-group-subscriptions-tabledata-table", 3, "dst", "selectable"], ["dataTable", ""], [3, "entityColumn"], ["data-imx-identifier", "aad-group-subscriptions-paginator", 3, "dst"]], template: function AadGroupSubscriptionsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1);
            i0.ɵɵtext(2, "#LDS#Heading Azure Active Directory Subscriptions");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card", 2)(4, "imx-data-source-toolbar", 3, 4);
            i0.ɵɵlistener("navigationStateChanged", function AadGroupSubscriptionsComponent_Template_imx_data_source_toolbar_navigationStateChanged_4_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function AadGroupSubscriptionsComponent_Template_imx_data_source_toolbar_search_4_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "imx-data-table", 5, 6);
            i0.ɵɵelement(9, "imx-data-table-column", 7)(10, "imx-data-table-column", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(11, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(5);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(11, _c1$3))("hiddenFilters", i0.ɵɵpureFunction0(12, _c2$3))("searchBoxText", i0.ɵɵpipeBind1(6, 9, "#LDS#Search"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0)("selectable", false);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAadGroupSub == null ? null : ctx.entitySchemaAadGroupSub.Columns.UID_AADSubSku);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAadGroupSub == null ? null : ctx.entitySchemaAadGroupSub.Columns.XOrigin);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i3$1.MatCard, i4$1.TranslateDirective, i1$1.DataSourceToolbarComponent, i1$1.DataSourcePaginatorComponent, i1$1.DataTableComponent, i1$1.DataTableColumnComponent, i4$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100%}.imx-content-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.imx-content[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;margin-bottom:-16px}.imx-card[_ngcontent-%COMP%]{margin:0 0 -16px}.imx-card[_ngcontent-%COMP%]   .governance-sidesheet-action-buttons[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}@media screen and (max-width: 480px){.imx-button-bar[_ngcontent-%COMP%]{flex-direction:column;display:block;text-align:center}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{width:100%;margin-bottom:5px}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:last-of-type{margin-bottom:0}.imx-button-bar[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:0}}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AadGroupSubscriptionsComponent, [{
            type: Component,
            args: [{ selector: 'imx-aad-group-subscriptions', template: "<div class=\"imx-content\">\r\n  <h2 class=\"mat-headline\" translate>#LDS#Heading Azure Active Directory Subscriptions</h2>\r\n  <mat-card class=\"imx-content-card\">\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      [settings]=\"dstSettings\"\r\n      [options]=\"['search', 'filter']\"\r\n      [hiddenFilters]=\"['namespace']\"\r\n      [searchBoxText]=\"'#LDS#Search' | translate\"\r\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n      data-imx-identifier=\"aad-group-subscriptions-toolbar\"\r\n      (search)=\"onSearch($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n\r\n    <imx-data-table #dataTable [dst]=\"dst\" detailViewVisible=\"false\" [selectable]=\"false\" mode=\"manual\" data-imx-identifier=\"aad-group-subscriptions-tabledata-table\">\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAadGroupSub?.Columns.UID_AADSubSku\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAadGroupSub?.Columns.XOrigin\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n\r\n    <imx-data-source-paginator data-imx-identifier=\"aad-group-subscriptions-paginator\" [dst]=\"dst\"></imx-data-source-paginator>\r\n  </mat-card>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;height:100%}.imx-content-card{display:flex;flex-direction:column;overflow:hidden}.imx-content{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;margin-bottom:-16px}.imx-card{margin:0 0 -16px}.imx-card .governance-sidesheet-action-buttons .justify-start eui-icon{font-size:14px;margin-right:4px}@media screen and (max-width: 480px){.imx-button-bar{flex-direction:column;display:block;text-align:center}.imx-button-bar button{width:100%;margin-bottom:5px}.imx-button-bar button:last-of-type{margin-bottom:0}.imx-button-bar .justify-start{margin-right:0}}\n"] }]
        }], function () { return [{ type: i1$1.ClassloggerService }, { type: AzureAdService }, { type: i1$1.SettingsService }, { type: i1$1.DynamicTabDataProviderDirective }]; }, { dataTable: [{
                type: ViewChild,
                args: ['dataTable', { static: false }]
            }] });
})();

const _c0$2 = ["dataTable"];
const _c1$2 = function () { return ["search", "filter"]; };
const _c2$2 = function () { return ["namespace"]; };
class AadGroupDeniedPlansComponent {
    constructor(logger, aadService, settings, dataProvider) {
        this.logger = logger;
        this.aadService = aadService;
        this.filterOptions = [];
        this.DisplayColumns = DisplayColumns;
        this.displayedColumns = [];
        this.navigationState = { PageSize: settings.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaAadGroupDeniedPlan = this.aadService.aadGroupDeniedPlansSchema;
        this.referrer = dataProvider.data;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.displayedColumns = [
                this.entitySchemaAadGroupDeniedPlan.Columns.UID_AADDeniedServicePlan,
                this.entitySchemaAadGroupDeniedPlan.Columns.XOrigin
            ];
            yield this.navigate();
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.navigate();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Searching for: ${keywords}`);
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.navigate();
        });
    }
    navigate() {
        return __awaiter(this, void 0, void 0, function* () {
            this.aadService.handleOpenLoader();
            try {
                const data = yield this.aadService.getAadGroupDeniedPlans(this.referrer.objectuid, this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: data,
                    entitySchema: this.entitySchemaAadGroupDeniedPlan,
                    navigationState: this.navigationState,
                    filters: this.filterOptions,
                };
                this.logger.debug(this, `Head at ${data.Data.length + this.navigationState.StartIndex} of ${data.totalCount} item(s)`);
            }
            finally {
                this.aadService.handleCloseLoader();
            }
        });
    }
}
AadGroupDeniedPlansComponent.ɵfac = function AadGroupDeniedPlansComponent_Factory(t) { return new (t || AadGroupDeniedPlansComponent)(i0.ɵɵdirectiveInject(i1$1.ClassloggerService), i0.ɵɵdirectiveInject(AzureAdService), i0.ɵɵdirectiveInject(i1$1.SettingsService), i0.ɵɵdirectiveInject(i1$1.DynamicTabDataProviderDirective)); };
AadGroupDeniedPlansComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AadGroupDeniedPlansComponent, selectors: [["imx-aad-group-denied-plans"]], viewQuery: function AadGroupDeniedPlansComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$2, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTable = _t.first);
        }
    }, decls: 12, vars: 13, consts: [[1, "imx-content"], ["translate", "", 1, "mat-headline"], [1, "imx-content-card"], ["data-imx-identifier", "aad-group-disabled-plans-toolbar", 3, "settings", "options", "hiddenFilters", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "aad-group-disabled-plans-tabledata-table", 3, "dst", "selectable"], ["dataTable", ""], [3, "entityColumn"], ["data-imx-identifier", "aad-group-disabled-plans-paginator", 3, "dst"]], template: function AadGroupDeniedPlansComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1);
            i0.ɵɵtext(2, "#LDS#Heading Disabled Azure Active Directory Service Plans");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card", 2)(4, "imx-data-source-toolbar", 3, 4);
            i0.ɵɵlistener("navigationStateChanged", function AadGroupDeniedPlansComponent_Template_imx_data_source_toolbar_navigationStateChanged_4_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function AadGroupDeniedPlansComponent_Template_imx_data_source_toolbar_search_4_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "imx-data-table", 5, 6);
            i0.ɵɵelement(9, "imx-data-table-column", 7)(10, "imx-data-table-column", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(11, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(5);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(11, _c1$2))("hiddenFilters", i0.ɵɵpureFunction0(12, _c2$2))("searchBoxText", i0.ɵɵpipeBind1(6, 9, "#LDS#Search"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0)("selectable", false);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAadGroupDeniedPlan == null ? null : ctx.entitySchemaAadGroupDeniedPlan.Columns.UID_AADDeniedServicePlan);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAadGroupDeniedPlan == null ? null : ctx.entitySchemaAadGroupDeniedPlan.Columns.XOrigin);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i3$1.MatCard, i4$1.TranslateDirective, i1$1.DataSourceToolbarComponent, i1$1.DataSourcePaginatorComponent, i1$1.DataTableComponent, i1$1.DataTableColumnComponent, i4$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100%}.imx-content-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.imx-content[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;margin-bottom:-16px}.imx-card[_ngcontent-%COMP%]{margin:0 0 -16px}.imx-card[_ngcontent-%COMP%]   .governance-sidesheet-action-buttons[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}@media screen and (max-width: 480px){.imx-button-bar[_ngcontent-%COMP%]{flex-direction:column;display:block;text-align:center}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{width:100%;margin-bottom:5px}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:last-of-type{margin-bottom:0}.imx-button-bar[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:0}}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AadGroupDeniedPlansComponent, [{
            type: Component,
            args: [{ selector: 'imx-aad-group-denied-plans', template: "<div class=\"imx-content\">\r\n  <h2 class=\"mat-headline\" translate>#LDS#Heading Disabled Azure Active Directory Service Plans</h2>\r\n  <mat-card class=\"imx-content-card\">\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      [settings]=\"dstSettings\"\r\n      [options]=\"['search', 'filter']\"\r\n      [hiddenFilters]=\"['namespace']\"\r\n      [searchBoxText]=\"'#LDS#Search' | translate\"\r\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n      data-imx-identifier=\"aad-group-disabled-plans-toolbar\"\r\n      (search)=\"onSearch($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n\r\n    <imx-data-table #dataTable [dst]=\"dst\" detailViewVisible=\"false\" [selectable]=\"false\" mode=\"manual\" data-imx-identifier=\"aad-group-disabled-plans-tabledata-table\">\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAadGroupDeniedPlan?.Columns.UID_AADDeniedServicePlan\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAadGroupDeniedPlan?.Columns.XOrigin\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n\r\n    <imx-data-source-paginator data-imx-identifier=\"aad-group-disabled-plans-paginator\" [dst]=\"dst\"></imx-data-source-paginator>\r\n  </mat-card>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;height:100%}.imx-content-card{display:flex;flex-direction:column;overflow:hidden}.imx-content{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;margin-bottom:-16px}.imx-card{margin:0 0 -16px}.imx-card .governance-sidesheet-action-buttons .justify-start eui-icon{font-size:14px;margin-right:4px}@media screen and (max-width: 480px){.imx-button-bar{flex-direction:column;display:block;text-align:center}.imx-button-bar button{width:100%;margin-bottom:5px}.imx-button-bar button:last-of-type{margin-bottom:0}.imx-button-bar .justify-start{margin-right:0}}\n"] }]
        }], function () { return [{ type: i1$1.ClassloggerService }, { type: AzureAdService }, { type: i1$1.SettingsService }, { type: i1$1.DynamicTabDataProviderDirective }]; }, { dataTable: [{
                type: ViewChild,
                args: ['dataTable', { static: false }]
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function AadUserCreateDialogComponent_imx_cdr_editor_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r3 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
        i0.ɵɵlistener("controlCreated", function AadUserCreateDialogComponent_imx_cdr_editor_6_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.formArray.push($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r1 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r1);
    }
}
class AadUserCreateDialogComponent {
    constructor(formBuilder, dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.cdrList = [];
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.detailsFormGroup.get('formArray');
    }
    ngOnInit() {
        this.setup();
    }
    create() {
        this.dialogRef.close(this.data);
    }
    setup() {
        this.cdrList = [
            new BaseCdr(this.data.property.Column)
        ];
    }
}
AadUserCreateDialogComponent.ɵfac = function AadUserCreateDialogComponent_Factory(t) { return new (t || AadUserCreateDialogComponent)(i0.ɵɵdirectiveInject(i1$2.UntypedFormBuilder), i0.ɵɵdirectiveInject(i2.MatDialogRef), i0.ɵɵdirectiveInject(MAT_DIALOG_DATA)); };
AadUserCreateDialogComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AadUserCreateDialogComponent, selectors: [["imx-aad-user-create-dialog"]], decls: 14, vars: 6, consts: [["mat-dialog-content", ""], [1, "aad-user-create-dialog"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["mat-dialog-actions", "", "align", "end"], ["mat-button", "", "mat-dialog-close", "", "cdkFocusInitial", "", "data-imx-identifier", "aad-user-create-dialog-cancel"], ["translate", ""], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "aad-user-create-dialog-add", 3, "disabled", "click"], [3, "cdr", "controlCreated"]], template: function AadUserCreateDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "h2");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "form", 2);
            i0.ɵɵtemplate(6, AadUserCreateDialogComponent_imx_cdr_editor_6_Template, 1, 1, "imx-cdr-editor", 3);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(7, "div", 4)(8, "button", 5)(9, "span", 6);
            i0.ɵɵtext(10, "#LDS#Cancel");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(11, "button", 7);
            i0.ɵɵlistener("click", function AadUserCreateDialogComponent_Template_button_click_11_listener() { return ctx.create(); });
            i0.ɵɵelementStart(12, "span", 6);
            i0.ɵɵtext(13, "#LDS#Add");
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 4, ctx.data.title));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.detailsFormGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("disabled", ctx.detailsFormGroup.pristine || ctx.detailsFormGroup.invalid);
        }
    }, dependencies: [i3.NgForOf, i1$2.ɵNgNoValidate, i1$2.NgControlStatusGroup, i1$2.FormGroupDirective, i5.MatButton, i2.MatDialogClose, i2.MatDialogContent, i2.MatDialogActions, i1$1.CdrEditorComponent, i4$1.TranslateDirective, i4$1.TranslatePipe], styles: [".aad-user-create-dialog[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin-bottom:10px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AadUserCreateDialogComponent, [{
            type: Component,
            args: [{ selector: 'imx-aad-user-create-dialog', template: "<div mat-dialog-content>\r\n  <div class=\"aad-user-create-dialog\">\r\n    <h2>{{ data.title | translate }}</h2>\r\n    <form [formGroup]=\"detailsFormGroup\">\r\n      <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"></imx-cdr-editor>\r\n    </form>\r\n  </div>\r\n</div>\r\n<div mat-dialog-actions align=\"end\">\r\n  <button mat-button mat-dialog-close cdkFocusInitial data-imx-identifier=\"aad-user-create-dialog-cancel\">\r\n    <span translate>#LDS#Cancel</span>\r\n  </button>\r\n  <button mat-flat-button color=\"primary\" (click)=\"create()\" [disabled]=\"detailsFormGroup.pristine || detailsFormGroup.invalid\" data-imx-identifier=\"aad-user-create-dialog-add\">\r\n    <span translate>#LDS#Add</span>\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.aad-user-create-dialog h2{margin-bottom:10px}\n"] }]
        }], function () {
        return [{ type: i1$2.UntypedFormBuilder }, { type: i2.MatDialogRef }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [MAT_DIALOG_DATA]
                    }] }];
    }, null);
})();

const _c0$1 = ["dataTable"];
const _c1$1 = function () { return ["search", "filter"]; };
const _c2$1 = function () { return ["namespace"]; };
class AadUserSubscriptionsComponent {
    constructor(dialog, logger, aadService, settings, dataProvider) {
        this.dialog = dialog;
        this.logger = logger;
        this.aadService = aadService;
        this.filterOptions = [];
        this.DisplayColumns = DisplayColumns;
        this.selectedUserSubs = [];
        this.itemStatus = {
            enabled: (item) => {
                return item.XOrigin.value === XOrigin.Direct;
            }
        };
        this.displayedColumns = [];
        this.navigationState = { PageSize: settings.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaAadUser = this.aadService.aadUserSchema;
        this.referrer = dataProvider.data;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.displayedColumns = [
                this.entitySchemaAadUser.Columns.ObjectKeyAADSubSku,
                this.entitySchemaAadUser.Columns.XOrigin
            ];
            yield this.navigate();
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.navigate();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Searching for: ${keywords}`);
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.navigate();
        });
    }
    onUserSubSelected(selected) {
        this.logger.debug(this, `Selected aad user subscriptions changed`);
        this.logger.trace(`New aad user subscription selections`, selected);
        this.selectedUserSubs = selected;
    }
    removeUserSubscriptions() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.aadService.handleOpenLoader();
                yield this.aadService.removeAadUserSubscriptions(this.getUserKey(), this.selectedUserSubs);
                yield this.navigate();
                this.dataTable.clearSelection();
            }
            finally {
                this.aadService.handleCloseLoader();
            }
        });
    }
    showCreateModal() {
        return __awaiter(this, void 0, void 0, function* () {
            const aadSub = this.aadService.generateAadUserSubscriptionEntity(this.getUserKey());
            const dialogRef = this.dialog.open(AadUserCreateDialogComponent, {
                width: '600px',
                data: {
                    property: aadSub.ObjectKeyAADSubSku,
                    title: '#LDS#Heading Add Subscription'
                }
            });
            dialogRef.afterClosed().subscribe((result) => __awaiter(this, void 0, void 0, function* () {
                if (result) {
                    try {
                        this.aadService.handleOpenLoader();
                        yield this.aadService.createAadUserSubscription(this.getUserKey(), aadSub);
                        yield this.navigate();
                    }
                    finally {
                        this.aadService.handleCloseLoader();
                    }
                }
            }));
        });
    }
    navigate() {
        return __awaiter(this, void 0, void 0, function* () {
            this.aadService.handleOpenLoader();
            try {
                const data = yield this.aadService.getAadUserSubscriptions(this.getUserKey(), this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: data,
                    entitySchema: this.entitySchemaAadUser,
                    navigationState: this.navigationState,
                    filters: this.filterOptions,
                };
                this.logger.debug(this, `Head at ${data.Data.length + this.navigationState.StartIndex} of ${data.totalCount} item(s)`);
            }
            finally {
                this.aadService.handleCloseLoader();
            }
        });
    }
    getUserKey() {
        return this.referrer.objectuid;
    }
}
AadUserSubscriptionsComponent.ɵfac = function AadUserSubscriptionsComponent_Factory(t) { return new (t || AadUserSubscriptionsComponent)(i0.ɵɵdirectiveInject(i2.MatDialog), i0.ɵɵdirectiveInject(i1$1.ClassloggerService), i0.ɵɵdirectiveInject(AzureAdService), i0.ɵɵdirectiveInject(i1$1.SettingsService), i0.ɵɵdirectiveInject(i1$1.DynamicTabDataProviderDirective)); };
AadUserSubscriptionsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AadUserSubscriptionsComponent, selectors: [["imx-aad-user-subscriptions"]], viewQuery: function AadUserSubscriptionsComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$1, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTable = _t.first);
        }
    }, decls: 21, vars: 15, consts: [[1, "imx-content"], ["translate", "", 1, "mat-headline"], [1, "imx-content-card"], ["data-imx-identifier", "aad-user-subscriptions-toolbar", 3, "settings", "options", "hiddenFilters", "searchBoxText", "itemStatus", "navigationStateChanged", "search"], ["dst", ""], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "aad-user-subscriptions-tabledata-table", 3, "dst", "selectable", "selectionChanged"], ["dataTable", ""], [3, "entityColumn"], ["data-imx-identifier", "aad-user-subscriptions-paginator", 3, "dst"], [1, "governance-sidesheet-action-buttons-container", "imx-card"], [1, "governance-sidesheet-action-buttons"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "delete-aad-user-subscription", 1, "justify-start", 3, "disabled", "click"], ["icon", "delete"], ["translate", ""], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "add-aad-user-subscription", 3, "click"]], template: function AadUserSubscriptionsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1);
            i0.ɵɵtext(2, "#LDS#Heading Azure Active Directory Subscriptions");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card", 2)(4, "imx-data-source-toolbar", 3, 4);
            i0.ɵɵlistener("navigationStateChanged", function AadUserSubscriptionsComponent_Template_imx_data_source_toolbar_navigationStateChanged_4_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function AadUserSubscriptionsComponent_Template_imx_data_source_toolbar_search_4_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "imx-data-table", 5, 6);
            i0.ɵɵlistener("selectionChanged", function AadUserSubscriptionsComponent_Template_imx_data_table_selectionChanged_7_listener($event) { return ctx.onUserSubSelected($event); });
            i0.ɵɵelement(9, "imx-data-table-column", 7)(10, "imx-data-table-column", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(11, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(12, "mat-card", 9)(13, "div", 10)(14, "button", 11);
            i0.ɵɵlistener("click", function AadUserSubscriptionsComponent_Template_button_click_14_listener() { return ctx.removeUserSubscriptions(); });
            i0.ɵɵelement(15, "eui-icon", 12);
            i0.ɵɵelementStart(16, "span", 13);
            i0.ɵɵtext(17, "#LDS#Remove");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(18, "button", 14);
            i0.ɵɵlistener("click", function AadUserSubscriptionsComponent_Template_button_click_18_listener() { return ctx.showCreateModal(); });
            i0.ɵɵelementStart(19, "span", 13);
            i0.ɵɵtext(20, "#LDS#Add subscription");
            i0.ɵɵelementEnd()()()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(5);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(13, _c1$1))("hiddenFilters", i0.ɵɵpureFunction0(14, _c2$1))("searchBoxText", i0.ɵɵpipeBind1(6, 11, "#LDS#Search"))("itemStatus", ctx.itemStatus);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0)("selectable", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAadUser == null ? null : ctx.entitySchemaAadUser.Columns.ObjectKeyAADSubSku);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAadUser == null ? null : ctx.entitySchemaAadUser.Columns.XOrigin);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("disabled", ctx.selectedUserSubs.length === 0);
        }
    }, dependencies: [i4.EuiIconComponent, i5.MatButton, i3$1.MatCard, i4$1.TranslateDirective, i1$1.DataSourceToolbarComponent, i1$1.DataSourcePaginatorComponent, i1$1.DataTableComponent, i1$1.DataTableColumnComponent, i4$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100%}.imx-content-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.imx-content[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;margin-bottom:-16px}.imx-card[_ngcontent-%COMP%]{margin:0 0 -16px}.imx-card[_ngcontent-%COMP%]   .governance-sidesheet-action-buttons[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}@media screen and (max-width: 480px){.imx-button-bar[_ngcontent-%COMP%]{flex-direction:column;display:block;text-align:center}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{width:100%;margin-bottom:5px}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:last-of-type{margin-bottom:0}.imx-button-bar[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:0}}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AadUserSubscriptionsComponent, [{
            type: Component,
            args: [{ selector: 'imx-aad-user-subscriptions', template: "<div class=\"imx-content\">\r\n  <h2 class=\"mat-headline\" translate>#LDS#Heading Azure Active Directory Subscriptions</h2>\r\n  <mat-card class=\"imx-content-card\">\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      [settings]=\"dstSettings\"\r\n      [options]=\"['search', 'filter']\"\r\n      [hiddenFilters]=\"['namespace']\"\r\n      [searchBoxText]=\"'#LDS#Search' | translate\"\r\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n      data-imx-identifier=\"aad-user-subscriptions-toolbar\"\r\n      [itemStatus]=\"itemStatus\"\r\n      (search)=\"onSearch($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n    <imx-data-table\r\n      #dataTable\r\n      [dst]=\"dst\"\r\n      detailViewVisible=\"false\"\r\n      [selectable]=\"true\"\r\n      (selectionChanged)=\"onUserSubSelected($event)\"\r\n      mode=\"manual\"\r\n      data-imx-identifier=\"aad-user-subscriptions-tabledata-table\"\r\n    >\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAadUser?.Columns.ObjectKeyAADSubSku\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAadUser?.Columns.XOrigin\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n    <imx-data-source-paginator data-imx-identifier=\"aad-user-subscriptions-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\r\n  </mat-card>\r\n</div>\r\n<mat-card class=\"governance-sidesheet-action-buttons-container imx-card\">\r\n  <div class=\"governance-sidesheet-action-buttons\">\r\n    <button\r\n      class=\"justify-start\"\r\n      mat-stroked-button\r\n      color=\"warn\"\r\n      [disabled]=\"selectedUserSubs.length === 0\"\r\n      data-imx-identifier=\"delete-aad-user-subscription\"\r\n      (click)=\"removeUserSubscriptions()\"\r\n    >\r\n      <eui-icon icon=\"delete\"></eui-icon>\r\n      <span translate>#LDS#Remove</span>\r\n    </button>\r\n\r\n    <button mat-raised-button color=\"primary\" (click)=\"showCreateModal()\" data-imx-identifier=\"add-aad-user-subscription\">\r\n      <span translate>#LDS#Add subscription</span>\r\n    </button>\r\n  </div>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;height:100%}.imx-content-card{display:flex;flex-direction:column;overflow:hidden}.imx-content{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;margin-bottom:-16px}.imx-card{margin:0 0 -16px}.imx-card .governance-sidesheet-action-buttons .justify-start eui-icon{font-size:14px;margin-right:4px}@media screen and (max-width: 480px){.imx-button-bar{flex-direction:column;display:block;text-align:center}.imx-button-bar button{width:100%;margin-bottom:5px}.imx-button-bar button:last-of-type{margin-bottom:0}.imx-button-bar .justify-start{margin-right:0}}\n"] }]
        }], function () { return [{ type: i2.MatDialog }, { type: i1$1.ClassloggerService }, { type: AzureAdService }, { type: i1$1.SettingsService }, { type: i1$1.DynamicTabDataProviderDirective }]; }, { dataTable: [{
                type: ViewChild,
                args: ['dataTable', { static: false }]
            }] });
})();

const _c0 = ["dataTable"];
const _c1 = function () { return ["search", "filter"]; };
const _c2 = function () { return ["namespace"]; };
class AadUserDeniedPlansComponent {
    constructor(dialog, logger, aadService, settings, dataProvider) {
        this.dialog = dialog;
        this.logger = logger;
        this.aadService = aadService;
        this.filterOptions = [];
        this.DisplayColumns = DisplayColumns;
        this.selectedUserDeniedPlans = [];
        this.displayedColumns = [];
        this.navigationState = { PageSize: settings.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaAadUserDeniedPlan = this.aadService.aadUserDeniedPlansSchema;
        this.referrer = dataProvider.data;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.displayedColumns = [
                this.entitySchemaAadUserDeniedPlan.Columns.UID_AADDeniedServicePlan,
                this.entitySchemaAadUserDeniedPlan.Columns.XOrigin,
            ];
            yield this.navigate();
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.navigate();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Searching for: ${keywords}`);
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.navigate();
        });
    }
    onDeniedPlanSelected(selected) {
        this.logger.debug(this, `Selected aad user disabled plans changed`);
        this.logger.trace(`New aad user disabled plan selections`, selected);
        this.selectedUserDeniedPlans = selected;
    }
    showCreateModal() {
        return __awaiter(this, void 0, void 0, function* () {
            const aadDeniedPlan = this.aadService.generateAadUserDeniedPlanEntity(this.getUserKey());
            const dialogRef = this.dialog.open(AadUserCreateDialogComponent, {
                width: '600px',
                data: {
                    property: aadDeniedPlan.UID_AADDeniedServicePlan,
                    title: '#LDS#Heading Assign Disabled Service Plan'
                }
            });
            dialogRef.afterClosed().subscribe((result) => __awaiter(this, void 0, void 0, function* () {
                if (result) {
                    try {
                        this.aadService.handleOpenLoader();
                        yield this.aadService.createAadUserDeniedPlan(this.getUserKey(), aadDeniedPlan);
                        yield this.navigate();
                    }
                    finally {
                        this.aadService.handleCloseLoader();
                    }
                }
            }));
        });
    }
    removeUserDeniedPlans() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.aadService.handleOpenLoader();
                yield this.aadService.removeAadUserDeniedPlans(this.getUserKey(), this.selectedUserDeniedPlans);
                yield this.navigate();
                this.dataTable.clearSelection();
            }
            finally {
                this.aadService.handleCloseLoader();
            }
        });
    }
    navigate() {
        return __awaiter(this, void 0, void 0, function* () {
            this.aadService.handleOpenLoader();
            try {
                const data = yield this.aadService.getAadUserDeniedPlans(this.getUserKey(), this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: data,
                    entitySchema: this.entitySchemaAadUserDeniedPlan,
                    navigationState: this.navigationState,
                    filters: this.filterOptions,
                };
                this.logger.debug(this, `Head at ${data.Data.length + this.navigationState.StartIndex} of ${data.totalCount} item(s)`);
            }
            finally {
                this.aadService.handleCloseLoader();
            }
        });
    }
    getUserKey() {
        return this.referrer.objectuid;
    }
}
AadUserDeniedPlansComponent.ɵfac = function AadUserDeniedPlansComponent_Factory(t) { return new (t || AadUserDeniedPlansComponent)(i0.ɵɵdirectiveInject(i2.MatDialog), i0.ɵɵdirectiveInject(i1$1.ClassloggerService), i0.ɵɵdirectiveInject(AzureAdService), i0.ɵɵdirectiveInject(i1$1.SettingsService), i0.ɵɵdirectiveInject(i1$1.DynamicTabDataProviderDirective)); };
AadUserDeniedPlansComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AadUserDeniedPlansComponent, selectors: [["imx-aad-user-denied-plans"]], viewQuery: function AadUserDeniedPlansComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTable = _t.first);
        }
    }, inputs: { referrer: "referrer" }, decls: 21, vars: 14, consts: [[1, "imx-content"], ["translate", "", 1, "mat-headline"], [1, "imx-content-card"], ["data-imx-identifier", "aad-user-disabled-plans-toolbar", 3, "settings", "options", "hiddenFilters", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "aad-user-disabled-plans-tabledata-table", 3, "dst", "selectable", "selectionChanged"], ["dataTable", ""], [3, "entityColumn"], ["data-imx-identifier", "aad-user-disabled-plans-paginator", 3, "dst"], [1, "governance-sidesheet-action-buttons-container", "imx-card"], [1, "governance-sidesheet-action-buttons"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "delete-aad-user-disabled-plans", 1, "justify-start", 3, "disabled", "click"], ["icon", "delete"], ["translate", ""], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "add-aad-user-disabled-plans", 3, "click"]], template: function AadUserDeniedPlansComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1);
            i0.ɵɵtext(2, "#LDS#Heading Disabled Azure Active Directory Service Plans");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card", 2)(4, "imx-data-source-toolbar", 3, 4);
            i0.ɵɵlistener("navigationStateChanged", function AadUserDeniedPlansComponent_Template_imx_data_source_toolbar_navigationStateChanged_4_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function AadUserDeniedPlansComponent_Template_imx_data_source_toolbar_search_4_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "imx-data-table", 5, 6);
            i0.ɵɵlistener("selectionChanged", function AadUserDeniedPlansComponent_Template_imx_data_table_selectionChanged_7_listener($event) { return ctx.onDeniedPlanSelected($event); });
            i0.ɵɵelement(9, "imx-data-table-column", 7)(10, "imx-data-table-column", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(11, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(12, "mat-card", 9)(13, "div", 10)(14, "button", 11);
            i0.ɵɵlistener("click", function AadUserDeniedPlansComponent_Template_button_click_14_listener() { return ctx.removeUserDeniedPlans(); });
            i0.ɵɵelement(15, "eui-icon", 12);
            i0.ɵɵelementStart(16, "span", 13);
            i0.ɵɵtext(17, "#LDS#Remove");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(18, "button", 14);
            i0.ɵɵlistener("click", function AadUserDeniedPlansComponent_Template_button_click_18_listener() { return ctx.showCreateModal(); });
            i0.ɵɵelementStart(19, "span", 13);
            i0.ɵɵtext(20, "#LDS#Assign disabled service plan");
            i0.ɵɵelementEnd()()()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(5);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(12, _c1))("hiddenFilters", i0.ɵɵpureFunction0(13, _c2))("searchBoxText", i0.ɵɵpipeBind1(6, 10, "#LDS#Search"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0)("selectable", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAadUserDeniedPlan == null ? null : ctx.entitySchemaAadUserDeniedPlan.Columns.UID_AADDeniedServicePlan);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAadUserDeniedPlan == null ? null : ctx.entitySchemaAadUserDeniedPlan.Columns.XOrigin);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("disabled", ctx.selectedUserDeniedPlans.length === 0);
        }
    }, dependencies: [i4.EuiIconComponent, i5.MatButton, i3$1.MatCard, i4$1.TranslateDirective, i1$1.DataSourceToolbarComponent, i1$1.DataSourcePaginatorComponent, i1$1.DataTableComponent, i1$1.DataTableColumnComponent, i4$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100%}.imx-content-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.imx-content[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;margin-bottom:-16px}.imx-card[_ngcontent-%COMP%]{margin:0 0 -16px}.imx-card[_ngcontent-%COMP%]   .governance-sidesheet-action-buttons[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}@media screen and (max-width: 480px){.imx-button-bar[_ngcontent-%COMP%]{flex-direction:column;display:block;text-align:center}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{width:100%;margin-bottom:5px}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:last-of-type{margin-bottom:0}.imx-button-bar[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:0}}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AadUserDeniedPlansComponent, [{
            type: Component,
            args: [{ selector: 'imx-aad-user-denied-plans', template: "<div class=\"imx-content\">\r\n  <h2 class=\"mat-headline\" translate>#LDS#Heading Disabled Azure Active Directory Service Plans</h2>\r\n  <mat-card class=\"imx-content-card\">\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      [settings]=\"dstSettings\"\r\n      [options]=\"['search', 'filter']\"\r\n      [hiddenFilters]=\"['namespace']\"\r\n      [searchBoxText]=\"'#LDS#Search' | translate\"\r\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n      data-imx-identifier=\"aad-user-disabled-plans-toolbar\"\r\n      (search)=\"onSearch($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n\r\n    <imx-data-table\r\n      #dataTable\r\n      [dst]=\"dst\"\r\n      detailViewVisible=\"false\"\r\n      [selectable]=\"true\"\r\n      (selectionChanged)=\"onDeniedPlanSelected($event)\"\r\n      mode=\"manual\"\r\n      data-imx-identifier=\"aad-user-disabled-plans-tabledata-table\"\r\n    >\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAadUserDeniedPlan?.Columns.UID_AADDeniedServicePlan\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAadUserDeniedPlan?.Columns.XOrigin\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n\r\n    <imx-data-source-paginator data-imx-identifier=\"aad-user-disabled-plans-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\r\n  </mat-card>\r\n</div>\r\n<mat-card class=\"governance-sidesheet-action-buttons-container imx-card\">\r\n  <div class=\"governance-sidesheet-action-buttons\">\r\n    <button\r\n      class=\"justify-start\"\r\n      mat-stroked-button\r\n      color=\"warn\"\r\n      [disabled]=\"selectedUserDeniedPlans.length === 0\"\r\n      data-imx-identifier=\"delete-aad-user-disabled-plans\"\r\n      (click)=\"removeUserDeniedPlans()\"\r\n    >\r\n      <eui-icon icon=\"delete\"></eui-icon>\r\n      <span translate>#LDS#Remove</span>\r\n    </button>\r\n\r\n    <button mat-raised-button color=\"primary\" (click)=\"showCreateModal()\" data-imx-identifier=\"add-aad-user-disabled-plans\">\r\n      <span translate>#LDS#Assign disabled service plan</span>\r\n    </button>\r\n  </div>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;height:100%}.imx-content-card{display:flex;flex-direction:column;overflow:hidden}.imx-content{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto;margin-bottom:-16px}.imx-card{margin:0 0 -16px}.imx-card .governance-sidesheet-action-buttons .justify-start eui-icon{font-size:14px;margin-right:4px}@media screen and (max-width: 480px){.imx-button-bar{flex-direction:column;display:block;text-align:center}.imx-button-bar button{width:100%;margin-bottom:5px}.imx-button-bar button:last-of-type{margin-bottom:0}.imx-button-bar .justify-start{margin-right:0}}\n"] }]
        }], function () { return [{ type: i2.MatDialog }, { type: i1$1.ClassloggerService }, { type: AzureAdService }, { type: i1$1.SettingsService }, { type: i1$1.DynamicTabDataProviderDirective }]; }, { referrer: [{
                type: Input
            }], dataTable: [{
                type: ViewChild,
                args: ['dataTable', { static: false }]
            }] });
})();

class InitService {
    constructor(extService, permission) {
        this.extService = extService;
        this.permission = permission;
    }
    onInit() {
        this.extService.register('buttonBarExtensionComponent', { instance: LicenceOverviewButtonComponent });
        this.extService.register('groupSidesheet', {
            instance: AadGroupSubscriptionsComponent, inputData: {
                id: 'subscriptions',
                label: '#LDS#Heading Azure Active Directory Subscriptions',
                checkVisibility: (ref) => __awaiter(this, void 0, void 0, function* () { return this.isAadAccount(ref) && (this.permission.canReadInAzure()); })
            },
            sortOrder: 10
        });
        this.extService.register('groupSidesheet', {
            instance: AadGroupDeniedPlansComponent, inputData: {
                id: 'deniedPlans',
                label: '#LDS#Heading Disabled Azure Active Directory Service Plans',
                checkVisibility: (ref) => __awaiter(this, void 0, void 0, function* () { return this.isAadAccount(ref) && (this.permission.canReadInAzure()); })
            },
            sortOrder: 20
        });
        this.extService.register('accountSidesheet', {
            instance: AadUserSubscriptionsComponent, inputData: {
                id: 'subscriptions',
                label: '#LDS#Heading Azure Active Directory Subscriptions',
                checkVisibility: (ref) => __awaiter(this, void 0, void 0, function* () { return this.isAadAccount(ref) && (this.permission.canReadInAzure()); })
            },
            sortOrder: 10
        });
        this.extService.register('accountSidesheet', {
            instance: AadUserDeniedPlansComponent,
            inputData: {
                id: 'deniedPlans',
                label: '#LDS#Heading Disabled Azure Active Directory Service Plans',
                checkVisibility: (ref) => __awaiter(this, void 0, void 0, function* () { return this.isAadAccount(ref) && (this.permission.canReadInAzure()); })
            },
            sortOrder: 20
        });
    }
    isAadAccount(referrer) {
        let isAad = false;
        isAad = referrer ? referrer.objecttable === 'AADGroup' : false;
        return isAad;
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i1$1.ExtService), i0.ɵɵinject(AadPermissionsService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i1$1.ExtService }, { type: AadPermissionsService }]; }, null);
})();

class AadConfigModule {
    constructor(logger, initService, aadApiService, dynamicMethodService, entlTypeService) {
        this.logger = logger;
        this.initService = initService;
        this.aadApiService = aadApiService;
        this.dynamicMethodService = dynamicMethodService;
        this.entlTypeService = entlTypeService;
        this.logger.info(this, '🔥 AAD loaded');
        this.initService.onInit();
        this.entlTypeService.Register(() => __awaiter(this, void 0, void 0, function* () {
            return [
                new RequestableEntitlementType("AADDeniedServicePlan", this.aadApiService.apiClient, "UID_AADDeniedServicePlan", this.dynamicMethodService)
            ];
        }));
        this.logger.info(this, '▶️ AAD initialized');
    }
}
AadConfigModule.ɵfac = function AadConfigModule_Factory(t) { return new (t || AadConfigModule)(i0.ɵɵinject(i1$1.ClassloggerService), i0.ɵɵinject(InitService), i0.ɵɵinject(ApiService), i0.ɵɵinject(i1$1.DynamicMethodService), i0.ɵɵinject(i1.RequestableEntitlementTypeService)); };
AadConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: AadConfigModule });
AadConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        TranslateModule,
        EuiCoreModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AadConfigModule, [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        CommonModule,
                        TranslateModule,
                        EuiCoreModule
                    ]
                }]
        }], function () { return [{ type: i1$1.ClassloggerService }, { type: InitService }, { type: ApiService }, { type: i1$1.DynamicMethodService }, { type: i1.RequestableEntitlementTypeService }]; }, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(AadConfigModule, { imports: [CommonModule,
            TranslateModule,
            EuiCoreModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AzureAdModule {
}
AzureAdModule.ɵfac = function AzureAdModule_Factory(t) { return new (t || AzureAdModule)(); };
AzureAdModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: AzureAdModule });
AzureAdModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        AzureAdService,
        AadPermissionsService
    ], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        RouterModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AzureAdModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        AadUserSubscriptionsComponent,
                        AadUserCreateDialogComponent,
                        AadUserDeniedPlansComponent,
                        AadGroupSubscriptionsComponent,
                        AadGroupDeniedPlansComponent,
                        LicenceOverviewButtonComponent
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        CdrModule,
                        RouterModule,
                        TranslateModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                    ],
                    providers: [
                        AzureAdService,
                        AadPermissionsService
                    ],
                    exports: [
                        AadUserSubscriptionsComponent,
                        AadUserDeniedPlansComponent,
                        AadGroupSubscriptionsComponent,
                        AadGroupDeniedPlansComponent,
                        LicenceOverviewButtonComponent
                    ],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(AzureAdModule, { declarations: [AadUserSubscriptionsComponent,
            AadUserCreateDialogComponent,
            AadUserDeniedPlansComponent,
            AadGroupSubscriptionsComponent,
            AadGroupDeniedPlansComponent,
            LicenceOverviewButtonComponent], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            CdrModule,
            RouterModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule], exports: [AadUserSubscriptionsComponent,
            AadUserDeniedPlansComponent,
            AadGroupSubscriptionsComponent,
            AadGroupDeniedPlansComponent,
            LicenceOverviewButtonComponent] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of cpl
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AadConfigModule, AadGroupDeniedPlansComponent, AadGroupSubscriptionsComponent, AadPermissionsService, AadUserDeniedPlansComponent, AadUserSubscriptionsComponent, ApiService, AzureAdModule, LicenceOverviewButtonComponent };
//# sourceMappingURL=aad.mjs.map
