import { ClassloggerService, DynamicMethodService } from 'qbm';
import { RequestableEntitlementTypeService } from 'qer';
import { ApiService } from './api.service';
import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@ngx-translate/core";
import * as i3 from "@elemental-ui/core";
export declare class AadConfigModule {
    private readonly logger;
    private readonly initService;
    private readonly aadApiService;
    private readonly dynamicMethodService;
    private readonly entlTypeService;
    constructor(logger: ClassloggerService, initService: InitService, aadApiService: ApiService, dynamicMethodService: DynamicMethodService, entlTypeService: RequestableEntitlementTypeService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AadConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AadConfigModule, never, [typeof i1.CommonModule, typeof i2.TranslateModule, typeof i3.EuiCoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AadConfigModule>;
}
