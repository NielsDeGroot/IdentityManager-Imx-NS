import { AppConfigService } from 'qbm';
import { AadPermissionsService } from '../admin/aad-permissions.service';
import * as i0 from "@angular/core";
export declare class AadExtensionService {
    private readonly permissions;
    private appConfig;
    constructor(permissions: AadPermissionsService, appConfig: AppConfigService);
    canReadInAzure(): Promise<boolean>;
    getReportForSubSku(uidSubSku: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AadExtensionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AadExtensionService>;
}
