import { OnInit } from '@angular/core';
import { EuiDownloadOptions } from '@elemental-ui/core';
import { AadPermissionsService } from '../../admin/aad-permissions.service';
import { AadExtensionService } from '../aad-extension.service';
import * as i0 from "@angular/core";
export declare class LicenceOverviewButtonComponent implements OnInit {
    aadService: AadExtensionService;
    private permissions;
    licenceOverview: EuiDownloadOptions;
    referrer: {
        type: string;
        uidGroup: string;
        defaultDownloadOptions: EuiDownloadOptions;
    };
    constructor(aadService: AadExtensionService, permissions: AadPermissionsService);
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LicenceOverviewButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LicenceOverviewButtonComponent, "ng-component", never, { "referrer": "referrer"; }, {}, never, never, false>;
}
