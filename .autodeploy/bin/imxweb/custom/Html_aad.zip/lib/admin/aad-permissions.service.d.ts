import { UserModelService } from 'qer';
import * as i0 from "@angular/core";
export declare class AadPermissionsService {
    private readonly userService;
    constructor(userService: UserModelService);
    canReadInAzure(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AadPermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AadPermissionsService>;
}
