export declare function canReadInAzure(groups: string[]): boolean;
