import { OnInit } from '@angular/core';
import { PortalTargetsystemAadgroupSubsku } from 'imx-api-aad';
import { CollectionLoadParameters, DisplayColumns, EntitySchema } from 'imx-qbm-dbts';
import { ClassloggerService, DataSourceToolbarFilter, DataSourceToolbarSettings, DataTableComponent, DynamicTabDataProviderDirective, SettingsService } from 'qbm';
import { AzureAdService } from '../azure-ad.service';
import * as i0 from "@angular/core";
export declare class AadGroupSubscriptionsComponent implements OnInit {
    private readonly logger;
    private readonly aadService;
    dataTable: DataTableComponent<PortalTargetsystemAadgroupSubsku>;
    dstSettings: DataSourceToolbarSettings;
    navigationState: CollectionLoadParameters;
    filterOptions: DataSourceToolbarFilter[];
    readonly entitySchemaAadGroupSub: EntitySchema;
    readonly DisplayColumns: typeof DisplayColumns;
    private displayedColumns;
    private referrer;
    constructor(logger: ClassloggerService, aadService: AzureAdService, settings: SettingsService, dataProvider: DynamicTabDataProviderDirective);
    ngOnInit(): Promise<void>;
    onNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    onSearch(keywords: string): Promise<void>;
    private navigate;
    static ɵfac: i0.ɵɵFactoryDeclaration<AadGroupSubscriptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AadGroupSubscriptionsComponent, "imx-aad-group-subscriptions", never, {}, {}, never, never, false>;
}
