import { OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { IWriteValue } from 'imx-qbm-dbts';
import { ColumnDependentReference } from 'qbm';
import * as i0 from "@angular/core";
export interface AadUserCreateDialogData {
    property: IWriteValue<string>;
    title: string;
}
export declare class AadUserCreateDialogComponent implements OnInit {
    dialogRef: MatDialogRef<AadUserCreateDialogComponent>;
    data: AadUserCreateDialogData;
    readonly detailsFormGroup: UntypedFormGroup;
    cdrList: ColumnDependentReference[];
    constructor(formBuilder: UntypedFormBuilder, dialogRef: MatDialogRef<AadUserCreateDialogComponent>, data: AadUserCreateDialogData);
    get formArray(): UntypedFormArray;
    ngOnInit(): void;
    create(): void;
    private setup;
    static ɵfac: i0.ɵɵFactoryDeclaration<AadUserCreateDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AadUserCreateDialogComponent, "imx-aad-user-create-dialog", never, {}, {}, never, never, false>;
}
