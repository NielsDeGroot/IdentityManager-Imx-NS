import { OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PortalTargetsystemAaduserDeniedserviceplans } from 'imx-api-aad';
import { CollectionLoadParameters, DisplayColumns, EntitySchema } from 'imx-qbm-dbts';
import { ClassloggerService, DataSourceToolbarFilter, DataSourceToolbarSettings, DataTableComponent, DynamicTabDataProviderDirective, SettingsService } from 'qbm';
import { AzureAdService } from '../azure-ad.service';
import * as i0 from "@angular/core";
export declare class AadUserDeniedPlansComponent implements OnInit {
    private dialog;
    private readonly logger;
    private readonly aadService;
    referrer: {
        objecttable: string;
        objectuid: string;
    };
    dataTable: DataTableComponent<PortalTargetsystemAaduserDeniedserviceplans>;
    dstSettings: DataSourceToolbarSettings;
    navigationState: CollectionLoadParameters;
    filterOptions: DataSourceToolbarFilter[];
    readonly entitySchemaAadUserDeniedPlan: EntitySchema;
    readonly DisplayColumns: typeof DisplayColumns;
    selectedUserDeniedPlans: PortalTargetsystemAaduserDeniedserviceplans[];
    private displayedColumns;
    constructor(dialog: MatDialog, logger: ClassloggerService, aadService: AzureAdService, settings: SettingsService, dataProvider: DynamicTabDataProviderDirective);
    ngOnInit(): Promise<void>;
    onNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    onSearch(keywords: string): Promise<void>;
    onDeniedPlanSelected(selected: PortalTargetsystemAaduserDeniedserviceplans[]): void;
    showCreateModal(): Promise<void>;
    removeUserDeniedPlans(): Promise<void>;
    private navigate;
    private getUserKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<AadUserDeniedPlansComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AadUserDeniedPlansComponent, "imx-aad-user-denied-plans", never, { "referrer": "referrer"; }, {}, never, never, false>;
}
