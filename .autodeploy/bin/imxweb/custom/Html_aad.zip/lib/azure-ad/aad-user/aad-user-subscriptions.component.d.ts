import { OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PortalTargetsystemAaduserSubsku } from 'imx-api-aad';
import { CollectionLoadParameters, DisplayColumns, EntitySchema } from 'imx-qbm-dbts';
import { ClassloggerService, DataSourceToolbarFilter, DataSourceToolbarSettings, DataTableComponent, DynamicTabDataProviderDirective, SettingsService } from 'qbm';
import { AzureAdService } from '../azure-ad.service';
import * as i0 from "@angular/core";
export declare class AadUserSubscriptionsComponent implements OnInit {
    private dialog;
    private readonly logger;
    private readonly aadService;
    dataTable: DataTableComponent<PortalTargetsystemAaduserSubsku>;
    dstSettings: DataSourceToolbarSettings;
    navigationState: CollectionLoadParameters;
    filterOptions: DataSourceToolbarFilter[];
    readonly entitySchemaAadUser: EntitySchema;
    readonly DisplayColumns: typeof DisplayColumns;
    selectedUserSubs: PortalTargetsystemAaduserSubsku[];
    readonly itemStatus: {
        enabled: (item: PortalTargetsystemAaduserSubsku) => boolean;
    };
    private displayedColumns;
    private referrer;
    constructor(dialog: MatDialog, logger: ClassloggerService, aadService: AzureAdService, settings: SettingsService, dataProvider: DynamicTabDataProviderDirective);
    ngOnInit(): Promise<void>;
    onNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    onSearch(keywords: string): Promise<void>;
    onUserSubSelected(selected: PortalTargetsystemAaduserSubsku[]): void;
    removeUserSubscriptions(): Promise<void>;
    showCreateModal(): Promise<void>;
    private navigate;
    private getUserKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<AadUserSubscriptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AadUserSubscriptionsComponent, "imx-aad-user-subscriptions", never, {}, {}, never, never, false>;
}
