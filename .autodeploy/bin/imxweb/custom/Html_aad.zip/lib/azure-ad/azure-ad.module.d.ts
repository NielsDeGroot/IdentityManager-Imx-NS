import * as i0 from "@angular/core";
import * as i1 from "./aad-user/aad-user-subscriptions.component";
import * as i2 from "./aad-user/aad-user-create-dialog.component";
import * as i3 from "./aad-user/aad-user-denied-plans.component";
import * as i4 from "./aad-group/aad-group-subscriptions.component";
import * as i5 from "./aad-group/aad-group-denied-plans.component";
import * as i6 from "../aad-extension/licence-overview-button/licence-overview-button.component";
import * as i7 from "@angular/common";
import * as i8 from "@angular/forms";
import * as i9 from "@elemental-ui/core";
import * as i10 from "qbm";
import * as i11 from "@angular/router";
import * as i12 from "@ngx-translate/core";
export declare class AzureAdModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AzureAdModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AzureAdModule, [typeof i1.AadUserSubscriptionsComponent, typeof i2.AadUserCreateDialogComponent, typeof i3.AadUserDeniedPlansComponent, typeof i4.AadGroupSubscriptionsComponent, typeof i5.AadGroupDeniedPlansComponent, typeof i6.LicenceOverviewButtonComponent], [typeof i7.CommonModule, typeof i8.FormsModule, typeof i8.ReactiveFormsModule, typeof i9.EuiCoreModule, typeof i9.EuiMaterialModule, typeof i10.CdrModule, typeof i11.RouterModule, typeof i12.TranslateModule, typeof i10.DataSourceToolbarModule, typeof i10.DataTableModule], [typeof i1.AadUserSubscriptionsComponent, typeof i3.AadUserDeniedPlansComponent, typeof i4.AadGroupSubscriptionsComponent, typeof i5.AadGroupDeniedPlansComponent, typeof i6.LicenceOverviewButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AzureAdModule>;
}
