import { EuiLoadingService } from '@elemental-ui/core';
import { PortalTargetsystemAadgroupDeniedserviceplans, PortalTargetsystemAadgroupSubsku, PortalTargetsystemAaduserDeniedserviceplans, PortalTargetsystemAaduserSubsku } from 'imx-api-aad';
import { CollectionLoadParameters, EntitySchema, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class AzureAdService {
    private readonly aadApiClient;
    private readonly busyService;
    private busyIndicator;
    constructor(aadApiClient: ApiService, busyService: EuiLoadingService);
    get aadUserSchema(): EntitySchema;
    get aadUserDeniedPlansSchema(): EntitySchema;
    get aadGroupSubSchema(): EntitySchema;
    get aadGroupDeniedPlansSchema(): EntitySchema;
    getAadUserSubscriptions(uidAadUser: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemAaduserSubsku>>;
    getAadUserDeniedPlans(uidAadUser: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemAaduserDeniedserviceplans>>;
    getAadGroupDeniedPlans(uidAadGroup: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemAadgroupDeniedserviceplans>>;
    getAadGroupSubscriptions(uidAadGroup: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemAadgroupSubsku>>;
    generateAadUserSubscriptionEntity(uidAaduser: string): PortalTargetsystemAaduserSubsku;
    generateAadUserDeniedPlanEntity(uidAaduser: string): PortalTargetsystemAaduserDeniedserviceplans;
    createAadUserSubscription(uidAadUser: string, aadUserSubscription: PortalTargetsystemAaduserSubsku): Promise<TypedEntityCollectionData<PortalTargetsystemAaduserSubsku>>;
    createAadUserDeniedPlan(uidAadUser: string, aadUserDeniedPlan: PortalTargetsystemAaduserDeniedserviceplans): Promise<TypedEntityCollectionData<PortalTargetsystemAaduserDeniedserviceplans>>;
    removeAadUserSubscriptions(uidAadUser: string, userSubscriptions: PortalTargetsystemAaduserSubsku[]): Promise<any>;
    removeAadUserDeniedPlans(uidAadUser: string, userDeniedPlans: PortalTargetsystemAaduserDeniedserviceplans[]): Promise<any>;
    handleOpenLoader(): void;
    handleCloseLoader(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AzureAdService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AzureAdService>;
}
