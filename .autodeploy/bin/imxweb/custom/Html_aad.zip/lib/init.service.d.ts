import { ExtService } from 'qbm';
import { AadPermissionsService } from './admin/aad-permissions.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly extService;
    private permission;
    constructor(extService: ExtService, permission: AadPermissionsService);
    onInit(): void;
    private isAadAccount;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
