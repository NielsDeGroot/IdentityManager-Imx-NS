import * as i5 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Input, Inject, EventEmitter, Output, ViewChild, NgModule, SecurityContext } from '@angular/core';
import * as i3 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i3$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i1$1 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiTheme, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i2 from 'qbm';
import { EntityColumnContainer, BaseCdr, BusyService, HELPER_ALERT_KEY_PREFIX, CdrFactoryService, YAxisInformation, SeriesInformation, LineChartOptions, XAxisInformation, TranslationEditorComponent, TreeDatabase, HyperViewModule, BusyIndicatorModule, DisableControlModule, QbmModule, DataSourceToolbarModule, DataTableModule, LdsReplaceModule, CdrModule, ClassloggerModule, DataTilesModule, SqlWizardModule, InfoModalDialogModule, SelectModule, DateModule, DataTreeModule, DataTreeWrapperModule, FkAdvancedPickerModule, EntityModule, ImageModule, HelpContextualModule, RouteGuardService, HELP_CONTEXTUAL } from 'qbm';
import * as i1 from 'qer';
import { ServiceItemsEditFormComponent, additionalColumnsForServiceItemsKey, UserModule, ServiceItemTagsModule, TilesModule } from 'qer';
import * as i7 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import 'imx-api-qer';
import { Subject, BehaviorSubject } from 'rxjs';
import * as i13$2 from 'imx-api-aob';
import { V2Client, TypedClient, PortalApplicationNew, PortalApplication } from 'imx-api-aob';
import * as i8 from '@angular/forms';
import { UntypedFormControl, UntypedFormGroup, Validators, FormGroup, FormArray, ReactiveFormsModule, FormsModule } from '@angular/forms';
import * as i6 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i1$2 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i5$1 from '@angular/cdk/platform';
import { CompareOperator, FilterType, DisplayColumns, DbObjectKey, TypedEntity, ValType, DisplayPattern, TypedEntityBuilder, isExpressionInvalid } from 'imx-qbm-dbts';
import moment from 'moment-timezone';
import * as i11 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import * as i12 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i13 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i14 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i11$1 from '@angular/cdk/scrolling';
import { ScrollingModule } from '@angular/cdk/scrolling';
import * as i9 from '@angular/material/list';
import * as i6$1 from '@angular/material/core';
import * as i10 from '@angular/material/select';
import _ from 'lodash';
import * as i6$2 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i12$1 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i13$1 from '@angular/material/menu';
import { MatMenuTrigger, MatMenuModule } from '@angular/material/menu';
import * as i4 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i11$2 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i8$1 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i5$2 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';
import * as i9$1 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatBadgeModule } from '@angular/material/badge';
import { PortalModule } from '@angular/cdk/portal';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTableModule } from '@angular/material/table';
import { pie } from 'billboard.js';
import * as i2$1 from '@angular/platform-browser';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isAobApplicationOwner(features) {
    return features.find(item => item === 'Portal_UI_ApplicationOwner') != null;
}
function isAobApplicationAdmin(features) {
    return features.find(item => item === 'Portal_UI_ApplicationAdmin') != null;
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobPermissionsService {
    constructor(userService) {
        this.userService = userService;
    }
    async isAobApplicationOwner() {
        return isAobApplicationOwner((await this.userService.getFeatures()).Features);
    }
    async isAobApplicationAdmin() {
        return isAobApplicationAdmin((await this.userService.getFeatures()).Features);
    }
}
AobPermissionsService.ɵfac = function AobPermissionsService_Factory(t) { return new (t || AobPermissionsService)(i0.ɵɵinject(i1.UserModelService)); };
AobPermissionsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobPermissionsService, factory: AobPermissionsService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobPermissionsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i1.UserModelService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function KpiTileComponent_imx_icon_tile_0_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 3);
    i0.ɵɵlistener("click", function KpiTileComponent_imx_icon_tile_0_ng_template_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r3 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r3.goToGlobalKpi()); });
    i0.ɵɵelementStart(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(4, "eui-icon", 4);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵattribute("data-imx-identifier", "kpi-tile-button-view");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#View KPI overview"));
} }
function KpiTileComponent_imx_icon_tile_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "imx-icon-tile", 1);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵtemplate(3, KpiTileComponent_imx_icon_tile_0_ng_template_3_Template, 5, 4, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("caption", i0.ɵɵpipeBind1(1, 3, "#LDS#Heading Application KPI Overview"))("subtitle", i0.ɵɵpipeBind1(2, 5, "#LDS#Get an overview of the KPIs for your applications."))("identifier", "global-kpi");
} }
class KpiTileComponent {
    constructor(router, aobPermissionService) {
        this.router = router;
        this.aobPermissionService = aobPermissionService;
    }
    async ngOnInit() {
        this.isAobOwner = await this.aobPermissionService.isAobApplicationAdmin();
    }
    goToGlobalKpi() {
        this.router.navigate(['applications/kpi']);
    }
}
KpiTileComponent.ɵfac = function KpiTileComponent_Factory(t) { return new (t || KpiTileComponent)(i0.ɵɵdirectiveInject(i3.Router), i0.ɵɵdirectiveInject(AobPermissionsService)); };
KpiTileComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: KpiTileComponent, selectors: [["imx-kpi-tile"]], decls: 1, vars: 1, consts: [["data-imx-identifier", "kpi-tile", 3, "caption", "subtitle", "identifier", 4, "ngIf"], ["data-imx-identifier", "kpi-tile", 3, "caption", "subtitle", "identifier"], ["ActionTemplate", ""], ["mat-button", "", "color", "primary", 3, "click"], ["size", "m", "icon", "forward"]], template: function KpiTileComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, KpiTileComponent_imx_icon_tile_0_Template, 5, 7, "imx-icon-tile", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.isAobOwner);
    } }, dependencies: [i5.NgIf, i7.MatButton, i1$1.EuiIconComponent, i1.IconTileComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]   .mat-button[_ngcontent-%COMP%]{text-transform:uppercase}[_nghost-%COMP%]   .mat-button[_ngcontent-%COMP%]     eui-icon{margin-left:15px}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KpiTileComponent, [{
        type: Component,
        args: [{ selector: 'imx-kpi-tile', template: "<imx-icon-tile data-imx-identifier=\"kpi-tile\"\r\n*ngIf=\"isAobOwner\"\r\n[caption]=\"'#LDS#Heading Application KPI Overview' | translate\" \r\n[subtitle]=\"'#LDS#Get an overview of the KPIs for your applications.' |translate\"\r\n[identifier]=\"'global-kpi'\">\r\n<ng-template #ActionTemplate>\r\n  <button mat-button color=\"primary\" [attr.data-imx-identifier]=\"'kpi-tile-button-view'\"\r\n    (click)=\"goToGlobalKpi()\">\r\n    <span>{{'#LDS#View KPI overview'| translate}}</span>\r\n    <eui-icon size=\"m\" icon=\"forward\"></eui-icon>\r\n  </button>\r\n</ng-template>\r\n</imx-icon-tile>", styles: [":host .mat-button{text-transform:uppercase}:host .mat-button ::ng-deep eui-icon{margin-left:15px}\n"] }]
    }], function () { return [{ type: i3.Router }, { type: AobPermissionsService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function LockInfoAlertComponent_eui_alert_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 1)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵproperty("colored", true);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#You cannot edit all properties, because the service item is assigned to an application and therefore some properties are locked."), " ");
} }
class LockInfoAlertComponent {
    constructor() {
        this.isLocked = false;
    }
    ngOnInit() {
        this.isLocked = this.serviceItem?.GetEntity()?.GetColumn('LockInfo')?.GetValue();
    }
}
LockInfoAlertComponent.ɵfac = function LockInfoAlertComponent_Factory(t) { return new (t || LockInfoAlertComponent)(); };
LockInfoAlertComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LockInfoAlertComponent, selectors: [["imx-lock-info-alert"]], inputs: { serviceItem: "serviceItem" }, decls: 1, vars: 1, consts: [["class", "imx-helper-alert", "type", "info", "condensed", "true", 3, "colored", 4, "ngIf"], ["type", "info", "condensed", "true", 1, "imx-helper-alert", 3, "colored"]], template: function LockInfoAlertComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, LockInfoAlertComponent_eui_alert_0_Template, 4, 4, "eui-alert", 0);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.isLocked);
    } }, dependencies: [i5.NgIf, i1$1.EuiAlertComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .imx-helper-alert[_ngcontent-%COMP%]{margin-bottom:20px;width:100%}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LockInfoAlertComponent, [{
        type: Component,
        args: [{ selector: 'imx-lock-info-alert', template: "<eui-alert class=\"imx-helper-alert\" *ngIf=\"isLocked\" type=\"info\" condensed=\"true\" [colored]=\"true\">\r\n  <span>\r\n    {{'#LDS#You cannot edit all properties, because the service item is assigned to an application and therefore some properties are locked.' | translate }}\r\n  </span>\r\n</eui-alert>", styles: [":host{display:flex;flex-direction:column}:host .imx-helper-alert{margin-bottom:20px;width:100%}\n"] }]
    }], null, { serviceItem: [{
            type: Input
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class LockInfoAlertExtension {
    constructor() {
        this.instance = LockInfoAlertComponent;
    }
}
LockInfoAlertExtension.id = ServiceItemsEditFormComponent.alertExtId;

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobService {
    constructor(router, extService, menuService) {
        this.router = router;
        this.extService = extService;
        this.menuService = menuService;
        this.setupMenu();
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register(additionalColumnsForServiceItemsKey, {
            inputData: {
                columnName: 'UID_AOBApplication'
            }
        });
        this.extService.register('Dashboard-MediumTiles', {
            instance: KpiTileComponent
        });
        this.extService.register(LockInfoAlertExtension.id, new LockInfoAlertExtension());
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach(route => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features) => {
            const items = [];
            if (isAobApplicationAdmin(features) || isAobApplicationOwner(features)) {
                items.push({
                    id: 'AOB_Data_Applications',
                    title: '#LDS#Applications',
                    navigationCommands: { commands: ['/applications', { outlets: { primary: ['navigation'], content: ['detail'] } }] },
                    sorting: '40-20',
                });
            }
            if (items.length === 0) {
                return null;
            }
            return {
                id: 'ROOT_Data',
                title: '#LDS#Data administration',
                sorting: '40',
                items
            };
        });
    }
}
AobService.ɵfac = function AobService_Factory(t) { return new (t || AobService)(i0.ɵɵinject(i3.Router), i0.ɵɵinject(i2.ExtService), i0.ɵɵinject(i2.MenuService)); };
AobService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobService, factory: AobService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i3.Router }, { type: i2.ExtService }, { type: i2.MenuService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing AOB API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
AobApiService.ɵfac = function AobApiService_Factory(t) { return new (t || AobApiService)(i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ImxTranslationProviderService)); };
AobApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobApiService, factory: AobApiService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i2.AppConfigService }, { type: i2.ClassloggerService }, { type: i2.ImxTranslationProviderService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ImageSelectorDialogComponent_mat_card_9_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 13);
    i0.ɵɵlistener("click", function ImageSelectorDialogComponent_mat_card_9_Template_mat_card_click_0_listener() { const restoredCtx = i0.ɵɵrestoreView(_r7); const name_r5 = restoredCtx.$implicit; const ctx_r6 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r6.selectIcon(name_r5)); });
    i0.ɵɵelement(1, "eui-icon", 14);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const name_r5 = ctx.$implicit;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("selected", ctx_r0.iconIsSelected(name_r5));
    i0.ɵɵadvance(1);
    i0.ɵɵpropertyInterpolate("icon", name_r5);
} }
function ImageSelectorDialogComponent_mat_card_13_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 15);
    i0.ɵɵlistener("click", function ImageSelectorDialogComponent_mat_card_13_Template_mat_card_click_0_listener() { i0.ɵɵrestoreView(_r9); i0.ɵɵnextContext(); const _r3 = i0.ɵɵreference(19); return i0.ɵɵresetView(_r3.click()); });
    i0.ɵɵelement(1, "eui-icon", 16);
    i0.ɵɵelementEnd();
} }
function ImageSelectorDialogComponent_mat_card_14_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 17);
    i0.ɵɵlistener("click", function ImageSelectorDialogComponent_mat_card_14_Template_mat_card_click_0_listener() { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r10.selectImage()); });
    i0.ɵɵelement(1, "img", 18);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("selected", ctx_r2.imageIsSelected);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("src", ctx_r2.imageHandler.addBase64Prefix(ctx_r2.imageUrl), i0.ɵɵsanitizeUrl);
} }
function ImageSelectorDialogComponent_div_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 19);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Please select an image in PNG or JPEG format."));
} }
/**
 * A dialog to select an icon from a predefined list or upload an own one.
 */
class ImageSelectorDialogComponent {
    constructor(dialogRef, imageHandler, logger, data, fileSelector) {
        this.dialogRef = dialogRef;
        this.imageHandler = imageHandler;
        this.logger = logger;
        this.fileSelector = fileSelector;
        this.fileFormatError = false;
        this.iconNames = [];
        this.subscriptions = [];
        this.subscriptions.push(this.fileSelector.fileFormatError.subscribe(() => this.fileFormatError = true), this.fileSelector.fileSelected.subscribe(imageUrl => this.selectImage(imageUrl)));
        this.title = data.title;
        this.icons = data.icons;
        Object.keys(data.icons).forEach(iconName => this.iconNames.push(iconName));
        if (data.imageUrl) {
            this.logger.debug(this, 'show and select actual assigned icon');
            this.selectImage(data.imageUrl);
        }
        else {
            this.logger.debug(this, 'initially select the default icon');
            this.selectIcon(data.defaultIcon);
        }
    }
    get imageIsSelected() { return this.selectedIconName == null; }
    ngOnDestroy() {
        this.subscriptions.forEach(s => s.unsubscribe());
    }
    onSave() {
        this.dialogRef.close({ file: this.getIconUrl() });
    }
    iconIsSelected(name) {
        return name === this.selectedIconName;
    }
    selectImage(newImageUrl) {
        if (newImageUrl) {
            this.imageUrl = newImageUrl;
        }
        this.selectedIconName = undefined;
    }
    selectIcon(name) {
        this.selectedIconName = name;
    }
    emitFiles(files) {
        this.fileSelector.emitFiles(files, 'image/png');
    }
    resetFileFormatErrorState() {
        this.fileFormatError = false;
    }
    getIconUrl() {
        if (this.selectedIconName) {
            return this.icons[this.selectedIconName];
        }
        return this.imageUrl;
    }
}
ImageSelectorDialogComponent.ɵfac = function ImageSelectorDialogComponent_Factory(t) { return new (t || ImageSelectorDialogComponent)(i0.ɵɵdirectiveInject(i1$2.MatDialogRef), i0.ɵɵdirectiveInject(i2.Base64ImageService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(MAT_DIALOG_DATA), i0.ɵɵdirectiveInject(i2.FileSelectorService)); };
ImageSelectorDialogComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ImageSelectorDialogComponent, selectors: [["imx-image-selector-dialog"]], decls: 28, vars: 22, consts: [["mat-dialog-title", ""], ["mat-dialog-content", ""], [1, "imx-image-selector-list"], ["data-imx-identifier", "selector-icon-select", 3, "selected", "click", 4, "ngFor", "ngForOf"], ["class", "imx-default-preview-image", "data-imx-identifier", "selector-image-open-upload", 3, "click", 4, "ngIf"], ["class", "imx-default-preview-image", 3, "selected", "click", 4, "ngIf"], ["type", "button", "mat-raised-button", "", "color", "warn", "data-imx-identifier", "selector-image-open-upload-button", 3, "click"], ["type", "file", "multiple", "false", "accept", "image/png, image/jpeg", 1, "imx-hidden-element", 3, "click", "change"], ["file", ""], ["class", "imx-error-message", 4, "ngIf"], ["mat-dialog-actions", "", "align", "end"], ["mat-stroked-button", "", "type", "button", "mat-dialog-close", "", "data-imx-identifier", "selector-dialog-button-cancel"], ["mat-raised-button", "", "type", "button", "color", "primary", "data-imx-identifier", "selector-dialog-button-save", 3, "click"], ["data-imx-identifier", "selector-icon-select", 3, "click"], ["size", "xl", 3, "icon"], ["data-imx-identifier", "selector-image-open-upload", 1, "imx-default-preview-image", 3, "click"], ["size", "xl", "icon", "image"], [1, "imx-default-preview-image", 3, "click"], ["height", "48", "data-imx-identifier", "selector-image-select", 1, "imx-preview-image", 3, "src"], [1, "imx-error-message"]], template: function ImageSelectorDialogComponent_Template(rf, ctx) { if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div")(1, "h2", 0);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "div", 1)(5, "span");
        i0.ɵɵtext(6);
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(8, "div", 2);
        i0.ɵɵtemplate(9, ImageSelectorDialogComponent_mat_card_9_Template, 2, 3, "mat-card", 3);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(10, "span");
        i0.ɵɵtext(11);
        i0.ɵɵpipe(12, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(13, ImageSelectorDialogComponent_mat_card_13_Template, 2, 0, "mat-card", 4);
        i0.ɵɵtemplate(14, ImageSelectorDialogComponent_mat_card_14_Template, 2, 3, "mat-card", 5);
        i0.ɵɵelementStart(15, "button", 6);
        i0.ɵɵlistener("click", function ImageSelectorDialogComponent_Template_button_click_15_listener() { i0.ɵɵrestoreView(_r12); const _r3 = i0.ɵɵreference(19); return i0.ɵɵresetView(_r3.click()); });
        i0.ɵɵtext(16);
        i0.ɵɵpipe(17, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(18, "input", 7, 8);
        i0.ɵɵlistener("click", function ImageSelectorDialogComponent_Template_input_click_18_listener() { return ctx.resetFileFormatErrorState(); })("change", function ImageSelectorDialogComponent_Template_input_change_18_listener($event) { return ctx.emitFiles($event.target.files); });
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(20, ImageSelectorDialogComponent_div_20_Template, 3, 3, "div", 9);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(21, "div", 10)(22, "button", 11);
        i0.ɵɵtext(23);
        i0.ɵɵpipe(24, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(25, "button", 12);
        i0.ɵɵlistener("click", function ImageSelectorDialogComponent_Template_button_click_25_listener() { return ctx.onSave(); });
        i0.ɵɵtext(26);
        i0.ɵɵpipe(27, "translate");
        i0.ɵɵelementEnd()()();
    } if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 10, ctx.title));
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(7, 12, "#LDS#Select an Icon"));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngForOf", ctx.iconNames);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(12, 14, "#LDS#WC_Or"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", !ctx.imageUrl);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.imageUrl);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(17, 16, "#LDS#Select image"), " ");
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("ngIf", ctx.fileFormatError);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(24, 18, "#LDS#Cancel"), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(27, 20, "#LDS#Save"), " ");
    } }, dependencies: [i5.NgForOf, i5.NgIf, i1$1.EuiIconComponent, i7.MatButton, i6.MatCard, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogContent, i1$2.MatDialogActions, i3$1.TranslatePipe], styles: [".mat-dialog-title[_ngcontent-%COMP%]{font-weight:600;font-size:24px}.mat-dialog-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center}.mat-dialog-content[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:20px}.mat-dialog-content[_ngcontent-%COMP%] > .mat-raised-button[_ngcontent-%COMP%]{background-color:#e36a00;margin-bottom:30px;margin-top:20px}.mat-dialog-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end}.mat-dialog-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-bottom:10px;margin-left:10px}.imx-hidden-element[_ngcontent-%COMP%]{display:none}.imx-image-selector-list[_ngcontent-%COMP%]{flex-direction:row;display:flex}.imx-default-preview-image[_ngcontent-%COMP%]{box-shadow:none}.eui-icon[_ngcontent-%COMP%]{color:#919799;-webkit-user-select:none;user-select:none}.mat-card[_ngcontent-%COMP%]{box-shadow:none;border:3px solid transparent;cursor:pointer}.mat-card.selected[_ngcontent-%COMP%]{border:3px solid #0a96d1}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ImageSelectorDialogComponent, [{
        type: Component,
        args: [{ selector: 'imx-image-selector-dialog', template: "<div>\r\n  <h2 mat-dialog-title>{{ title | translate }}</h2>\r\n  <div mat-dialog-content>\r\n    <span>{{ '#LDS#Select an Icon' | translate }}</span>\r\n    <div class=\"imx-image-selector-list\">\r\n      <mat-card *ngFor=\"let name of iconNames\" (click)=\"selectIcon(name)\" [class.selected]=\"iconIsSelected(name)\" data-imx-identifier=\"selector-icon-select\">\r\n        <eui-icon size=\"xl\" icon=\"{{ name }}\"></eui-icon>\r\n      </mat-card>\r\n    </div>\r\n    <span>{{ '#LDS#WC_Or' | translate }}</span>\r\n    <mat-card *ngIf=\"!imageUrl\" class=\"imx-default-preview-image\" (click)=\"file.click()\" data-imx-identifier=\"selector-image-open-upload\">\r\n      <eui-icon size=\"xl\" icon=\"image\"></eui-icon>\r\n    </mat-card>\r\n    <mat-card class=\"imx-default-preview-image\" *ngIf=\"imageUrl\" (click)=\"selectImage()\" [class.selected]=\"imageIsSelected\">\r\n      <img [src]=\"imageHandler.addBase64Prefix(imageUrl)\" height=\"48\" class=\"imx-preview-image\" data-imx-identifier=\"selector-image-select\" />\r\n    </mat-card>\r\n    <button type=\"button\" mat-raised-button color=\"warn\" data-imx-identifier=\"selector-image-open-upload-button\" (click)=\"file.click()\">\r\n      {{ '#LDS#Select image' | translate }}\r\n    </button>\r\n    <!-- NS20260708 Added support for JPEG   -->\r\n    <input class=\"imx-hidden-element\" #file type=\"file\" multiple=\"false\" accept=\"image/png, image/jpeg\" (click)=\"resetFileFormatErrorState()\" (change)=\"emitFiles($event.target.files)\" />\r\n    <div *ngIf=\"fileFormatError\" class=\"imx-error-message\">{{ '#LDS#Please select an image in PNG or JPEG format.' | translate }}</div>\r\n  </div>\r\n  <div mat-dialog-actions align=\"end\">\r\n    <button mat-stroked-button type=\"button\" mat-dialog-close data-imx-identifier=\"selector-dialog-button-cancel\">\r\n      {{ '#LDS#Cancel' | translate }}\r\n    </button>\r\n    <button mat-raised-button type=\"button\" color=\"primary\" (click)=\"onSave()\" data-imx-identifier=\"selector-dialog-button-save\">\r\n      {{ '#LDS#Save' | translate }}\r\n    </button>\r\n  </div>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.mat-dialog-title{font-weight:600;font-size:24px}.mat-dialog-content{display:flex;flex-direction:column;align-items:center}.mat-dialog-content>span{font-size:20px}.mat-dialog-content>.mat-raised-button{background-color:#e36a00;margin-bottom:30px;margin-top:20px}.mat-dialog-actions{display:flex;justify-content:flex-end}.mat-dialog-actions button{margin-bottom:10px;margin-left:10px}.imx-hidden-element{display:none}.imx-image-selector-list{flex-direction:row;display:flex}.imx-default-preview-image{box-shadow:none}.eui-icon{color:#919799;-webkit-user-select:none;user-select:none}.mat-card{box-shadow:none;border:3px solid transparent;cursor:pointer}.mat-card.selected{border:3px solid #0a96d1}\n"] }]
    }], function () { return [{ type: i1$2.MatDialogRef }, { type: i2.Base64ImageService }, { type: i2.ClassloggerService }, { type: undefined, decorators: [{
                type: Inject,
                args: [MAT_DIALOG_DATA]
            }] }, { type: i2.FileSelectorService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationImageSelectComponent {
    constructor(dialog, imageProvider) {
        this.dialog = dialog;
        this.imageProvider = imageProvider;
        this.control = new UntypedFormControl();
        this.columnContainer = new EntityColumnContainer();
        this.controlCreated = new EventEmitter();
        this.icons = {
            // tslint:disable-next-line:max-line-length
            application: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAlCAYAAAAA7LqSAAAAAXNSR0IArs4c6QAAAeJJREFUWAntWbFKA0EQde/CYSGk0SqIiEhEVNBW/YLkD4SQIsc1/oCVtZWlJLlK0C/w6ivE1kIiIiJcKgtttNKId74Jd7JcYrMwa052YZm5eTs782Z2mz0xhRGGYSmKohnSizaazeabECIWnU5nD8kfJ0kyVzQSlC9I9DFdCwSOdJNA4HfkcD+ucMC+YO+Nw1IbYXGGI/cFzEMLhkpm1CSfEHje87wVy7L25ZhEEFgV2DrsdRkj3bbtHcLgt5kSHi6BT4WIaB1I4ALJvFBQJHQK8VNd6JfAHgmDDLD2mfR0PLRarSvSXde9gbhO7UOhnQiqV2+327MUPY7jBoScwy6wJcIga1gr39tl3/e3Cet2uxsQW6RnQ8AhyT50yfQI9RGvmo9JRwYE7mBfG4MBSm5hX8WUCxCV8ot1fCOZacQZIUGxgdkQIyRSTPyG5YmcYOEBORVgnCHHWpZnnsgHLtlrBk6yxJX4lPOTz5lsL5xuiExay0xHTEeYKmCOFlNhlbc1HVEuHZOj6QhTYZW3NR1RLh2To+kIU2GVtzUdUS4dk6PpCFNhlbc1HVEuHZPjv+nInzyZMjQloo7Ir+EMMbRsGRORQEsoxiB4+A5KjuM0BoMBPe8vMsZi2xr/WHrlcvn8Gxm0iGtOIek+AAAAAElFTkSuQmCC',
            // tslint:disable-next-line:max-line-length
            box: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAABqklEQVRoQ+1YPUvDQBh+riSiBJRubo7FWXD1B7h3L4gHyWQGF62DH4tDnBo4Ebp39we4Cs7i6OZWFIJiQk4OtFiqJL3cBYnvrXnf573ng9wlDA1ZrCE8QET+mpPkCDliSQGKliVhtWHJEW3pLDU20xEhxApjbCvP83VLwhmBbbVa91LKG8758xfgxJHRaLQwHo9PAOwbmWYf5Lzdbve73e67GjUhEkXRkud5FwC4/T0YmSCSJNkLw/CViBjRszoIOVJdQ7MI5IhZPauj/ezIcDhcTNP0QEq5WX2GfQTG2K3rume9Xu9t6vVrf7TdCc28a9nVzC76r44IIfoAju2Onxv9iHOu7oMzi4jMraWZhloceQSwm6bpXZk9u667AeASwFqZ+s+aWohMHVBFm9P8bKiFyHWWZTtBEDwVkVDPB4PBquM4VwC2y9TX6Yia9QBARazMUpHqlCn8VlOLI3PuSauciNCBqBWc4iaKFkWrOCVaFRQtipZWcIqbKFoUreKUaFX842jFcdxxHOdUSrmspZ3hJsbYS5Zlh77vq0+FmUX/tQwLXhmuMY58ANUk7zNkl1kaAAAAAElFTkSuQmCC',
            // tslint:disable-next-line:max-line-length
            openfolder: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAC80lEQVRoQ+2Zz2sTQRTHv28zadUiklp602tP4lH/AoUePElErYdQs1uSWmi9qNBa6UUKpoptdJtDD9KDVUEPRdSbJ68qiKIX9VoTtBRt2cyTDSQQJbNhmgnTkr0F9v34zHf2fWc3hF1y0S7hQAfENiU7inQUMbQCna1laGG109YpsrCwcEgIcZqZu3QzEtFWEASPs9nsd90cOnE1kJWVla5SqXQTwLhOon9i5hKJxJVkMrnVglxNpaiB5HK5vT09PXMAvKYi1Tf5Gxsb4xMTE79bkKupFKZAngK4J6U0oogQoiylfOd53s8qpSmQplZxmzfNJhKJyer23ckgddtXBfKVmR8BWNvmypkK/9bb2/skUhEiGnRd97mpLlqdt5Ei7wEkPc/72OqCpvI1AnlbLpfPZDKZT2Hh6elpp7+//4CU0jHViG7eeDweuK77KxKEmalQKIwx823dYobj1gFcigTxfX8fgDsALhpuSDs9M+cjQebn5w8KIZaJ6KR2JfOBU5Eg+Xx+IBaLPQRw1Hw/ehWIaCgSpFAoHJdSvgSwX6+M+ShmPhEJsri4eIqZn5lvR7vCuuM40SC+74fH+px2GfOBFatQKtLX1/elWCzOENFV8/3oVWDmF0EQnFeCxGKx8C3P6tEL4IEQIqsEkVKu2T56Qw/p7u6+rAQJxbZ99AKY8jxvRgkSj8cTto/e0ENc111WggghBiwfvQg9ZGRk5FXUwz5o+eiteEg6nX7TEISZzwEYsnn0Aqi9bjQEkVKmHMfJWH7qrXjI6OjoDxVIlogmLT/1VjxkeHh4XbW1rhPRDZtPvVUPSaVSf1Qgd4ko/PJo7am36iGh3zUEAbAK4JreCag9UVUPUYIQ0QdmPtuelvSqVD1EBfIZQBHAMb0SbYmqeYgKpC2dbLNI3Ser2jOytLS0Z3Nz8xYRhd6xE67Vcrl8IZPJlOoUCX/4vn8EwBiAw5aTFInofjqdfk1E/B+I5c0r2+v8q2ubeh1FOooYWoG/nVypz2zv/LMAAAAASUVORK5CYII=',
            // tslint:disable-next-line:max-line-length
            server: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAACM0lEQVRoQ+2ZMWvbUBDH717jOMWQYA8eswfSvdDQD1ACHQJa4sWLJAcSqAvdWkS7FeJCCrakxYuzCDIEQj5AaSB7Ct0zerBJwLSu23elpTG1ooCe7GfLL8+bhd7d/f7/QzpOCIr8UBEO0CBpc1I7kmpHPM97BAB7ALCatkJD9VwCwIFlWRc314et1Ww2l/r9/j4i7qQc4m95RFTPZrMvy+Xy9z//hyC1Wu1hLpf7AADWPIAAgNfr9V5Uq9VvIiA7nPOvYUDG2BoA1GcELg7COd+oVCpn4YIbjcYTxthnDTKeAuKOAIAarTWecNJOJ3JEWjVjBI4GCYJgsdPpbM3By/CG/bJQKBwZhvFj5PE7hjKpOKrm0Og4DisWiyucc5YKme8ogjHG2+32leM4/NasFQTBg263WwWA92mG+K+2V/l8vmYYxi+RESWNbOKPXyI6R8TrMA0RLSPi4xlRioPoWUuuVffYEbnCJo4u7kjiVHIPKg5CROj7/vJgMFiQK+RkomcymZ+maV4jIumhcTKaTjbKyPSrF3STFTdWNL2g0wu6WI2S6CbxF6Iy069e0CXqmNiHxFsrdujp3hhvQccYe0pEzyJqaxHRF5k1I+I6AJTCORDxlHP+6d/1eAs6z/NeA8DbiGAl0zQPZYL4vr9NRK2IHG8sy3oXlfvOBZ0yIK7r7iLiZsTmpG7b9rFMR1zXfR71LZOITmzb/ijkiMxCZcRWc/crQ6lpxdSOTEvpuHmUceQ3am+oQn9k2zIAAAAASUVORK5CYII=',
            // tslint:disable-next-line:max-line-length
            hdd: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAETklEQVRoQ+2ZTWhjVRTH/+e91kZSnSaLSgdk3MksdDcKulDQcasDQ1BnHJAmvYkfwWZRdKD6tDhKF4lUSt5LUgaGGUfCDKPoShwYEcWPhagL6U4XnWAXDWObmkjfO3JLMoSQvps2uamG3uW795x7fvece+659xEGpNGAcOAA5L/myQOP/C89UigUwq7rvgbg4T4DfG+a5gfRaHRNNW9HoeU4zjSAtEqZpv6UECKj0t0pyCyAd1TKNPW/KYSYU+nWBfIVgBsAfvQ8ryKNMAwjCOAYgMcBPKYyrKm/7yBrzJxh5vPxePwmEXE7Y5mZbNs+TEQvEpEM2bACqn8gRHTZdd2ziUTi912sNLLZ7H2maZ5j5ud85PoGYlUqlflUKvX3biAaY9Pp9J3BYHAGgLWDvH4QIjpbrVbTyWSytheIhszCwsJIIBBIMfO5Nnr0ghDRhWq1+moymfyrG4gmmLsDgcCHzHymRZ9WkN8Mw3g2Fov90guIho58Pv+g53kfAzjar6w1FwqF3o5EIm4vQYrFolkul98CIM+tRtPmkZLnec8kEokfegnR0JXNZh8yDOMTABP1b3pAiOgKM0eFELdUIJZlGePj44fkuNXV1VuWZXkqGcdxDhFRgZlPagVh5vfC4fCsKqwKhcKRra2tDBGdkAYx87WhoaHpaDT6hx+MDK+1tbU5InpDKwiAuBDC8TNGptORkZF5AMmWcQu1Wm1Gla4dxxEAbK0gRHR6amrqkh+I9Ibruh8BeKRl3LemaT6v8koulzvFzBf3HWRpaemw67qXmFkWiLcbEd0wTfPU5OTkTb+F6AsIAOX9oJ5GUwBkeDW3mVAolFbtr5b7j56sBSATCoVej0Qi//itqqyhRkdHp5hZVrggoszGxkZOVZMVi8U7yuXy+wC25QBoA/kSwBkhREmVSvfS7ziOPD8uAHhSN8g6M5+Ix+PX92KoSsa27SeI6BqAu3SDSP1OpVKZVoWJyujW/npJL+/nMv02mrbQkhOsAzgphPhit8b6jXcc5ykAV5q8oXWPbNtCRN+4rnt6p1uhZVlDExMTwVKptN5JaZLP5496nne+zZOTVo80YD4lIhGLxf5sXul6iMjU+wqAZXm4maZ5dWVlZbkdVD6fv4eZHWZ+uo3H9IPISdvVUIuLi/cODw9fZuZHWwz7FcBFwzA+a0C11mT7BlKfeFm+e9VqtauyjvI5EJvtlFDy2eg4gPt99k5/PNJsADN/bRhGplqtXh8bG3M3NzfnieilLhOCVhDpAcfzvJ8MwzgC4OX649ttm5n5OyKSj3MPABjvAkYbyM8AXhBCyNDYborN2gXDtqgeEGaeFUK82/qSaNv2cSLq6blSXwE9IDvdR3K53DFm/rzLMGrnPT0gA+MRAIOxR5rODd+s1e0Ob5LXE1o9NLBTVT0FGYxfbwPzM7TTGNjPcR39Q9xPAzud+wCk05Xq17gDj/RrpTud51+Swm1RKPvqDgAAAABJRU5ErkJggg=='
        };
        this.defaultIcon = this.icons.application;
    }
    ngOnChanges(changes) {
        if (changes.column && this.column) {
            const cdr = new class {
                constructor(column) {
                    this.column = column;
                    this.isReadOnly = () => !this.column.GetMetadata().CanEdit();
                }
                get hint() {
                    return !this.column.GetValue()?.length ?
                        '#LDS#If you do not select an icon, the default icon will be used.' : '';
                }
            }(this.column);
            this.columnContainer.init(cdr);
            this.updateControlValue();
        }
    }
    ngAfterViewInit() {
        this.controlCreated.emit(this.control);
    }
    async openEditDialog() {
        const imageSelectorDialogParams = {
            autoFocus: false,
            data: {
                title: '#LDS#Edit Application Icon',
                icons: this.icons,
                imageUrl: this.control.value,
                defaultIcon: 'application'
            }
        };
        const result = await this.dialog.open(ImageSelectorDialogComponent, imageSelectorDialogParams).afterClosed().toPromise();
        if (result) {
            await this.column.PutValue(this.imageProvider.getImageData(result.file));
            this.updateControlValue();
            this.control.markAsDirty();
        }
    }
    updateControlValue() {
        const value = this.column.GetValue();
        this.control.setValue(value?.length ? value : this.defaultIcon, { emitEvent: false });
    }
}
ApplicationImageSelectComponent.ɵfac = function ApplicationImageSelectComponent_Factory(t) { return new (t || ApplicationImageSelectComponent)(i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(i2.Base64ImageService)); };
ApplicationImageSelectComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationImageSelectComponent, selectors: [["imx-application-image-select"]], inputs: { column: "column" }, outputs: { controlCreated: "controlCreated" }, features: [i0.ɵɵNgOnChangesFeature], decls: 1, vars: 3, consts: [[3, "valueWrapper", "control", "hideRemoveButton", "change"]], template: function ApplicationImageSelectComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-image-select", 0);
        i0.ɵɵlistener("change", function ApplicationImageSelectComponent_Template_imx_image_select_change_0_listener() { return ctx.openEditDialog(); });
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        i0.ɵɵproperty("valueWrapper", ctx.columnContainer)("control", ctx.control)("hideRemoveButton", true);
    } }, dependencies: [i2.ImageSelectComponent] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationImageSelectComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-image-select', template: "<imx-image-select\r\n  [valueWrapper]=\"columnContainer\"\r\n  [control]=\"control\"\r\n  (change)=\"openEditDialog()\"\r\n  [hideRemoveButton]=\"true\">\r\n</imx-image-select>\r\n" }]
    }], function () { return [{ type: i1$2.MatDialog }, { type: i2.Base64ImageService }]; }, { column: [{
            type: Input
        }], controlCreated: [{
            type: Output
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ApplicationCreateComponent_imx_cdr_editor_5_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_5_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.form.addControl(ctx_r5.name.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r0.name);
} }
function ApplicationCreateComponent_imx_cdr_editor_6_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_6_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r7 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r7.form.addControl(ctx_r7.description.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r1.description);
} }
function ApplicationCreateComponent_imx_cdr_editor_7_Template(rf, ctx) { if (rf & 1) {
    const _r10 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 9);
    i0.ɵɵlistener("valueChange", function ApplicationCreateComponent_imx_cdr_editor_7_Template_imx_cdr_editor_valueChange_0_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r9 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r9.updateName($event)); })("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_7_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r11 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r11.form.addControl(ctx_r11.serviceCategory.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r2.serviceCategory);
} }
function ApplicationCreateComponent_imx_cdr_editor_8_Template(rf, ctx) { if (rf & 1) {
    const _r13 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_8_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r13); const ctx_r12 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r12.form.addControl(ctx_r12.manager.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r3.manager);
} }
function ApplicationCreateComponent_imx_cdr_editor_9_Template(rf, ctx) { if (rf & 1) {
    const _r15 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
    i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_imx_cdr_editor_9_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r15); const ctx_r14 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r14.form.addControl(ctx_r14.owner.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r4.owner);
} }
class ApplicationCreateComponent {
    constructor(data, sidesheetRef, translateService, confirmation) {
        this.sidesheetRef = sidesheetRef;
        this.translateService = translateService;
        this.form = new UntypedFormGroup({});
        this.subscriptions = [];
        this.imageColumn = data.application.JPegPhoto.Column;
        this.nameColumn = data.application.Ident_AOBApplication.Column;
        this.name = new BaseCdr(this.nameColumn);
        this.description = new BaseCdr(data.application.Description.Column);
        this.serviceCategory = new class {
            constructor(property, translateService) {
                this.property = property;
                this.translateService = translateService;
                this.column = this.property.Column;
                this.isReadOnly = () => !this.property.GetMetadata().CanEdit();
            }
            get hint() {
                return this.property.value?.length > 0 ? '' :
                    this.translateService.instant('#LDS#If you do not select a service category, a service category with the same name as the application is created and assigned.');
            }
        }(data.application.UID_AccProductGroup, this.translateService);
        this.manager = new BaseCdr(data.application.UID_PersonHead.Column);
        this.owner = new BaseCdr(data.application.UID_AERoleOwner.Column);
        this.subscriptions.push(sidesheetRef.closeClicked().subscribe(async () => {
            if ((data.application.GetEntity().GetDiffData()?.Data?.length > 0 || !this.form.pristine) &&
                !(await confirmation.confirmLeaveWithUnsavedChanges())) {
                return;
            }
            sidesheetRef.close(false);
        }));
    }
    ngOnDestroy() {
        this.subscriptions.forEach(s => s.unsubscribe());
    }
    async updateName(value) {
        const name = this.name.column.GetValue();
        if (name == null || name.length === 0) {
            await this.name.column.PutValue(value?.DisplayValue);
            this.name = new BaseCdr(this.nameColumn);
        }
    }
    async save() {
        this.sidesheetRef.close(true);
    }
}
ApplicationCreateComponent.ɵfac = function ApplicationCreateComponent_Factory(t) { return new (t || ApplicationCreateComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
ApplicationCreateComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationCreateComponent, selectors: [["imx-application-create"]], decls: 14, vars: 8, consts: [["eui-sidesheet-content", "", 1, "imx-content"], ["translate", ""], ["id", "form", 1, "imx-form", 3, "formGroup"], [1, "imx-select", 3, "column", "controlCreated"], ["class", "imx-select", 3, "cdr", "controlCreated", 4, "ngIf"], ["class", "imx-select", 3, "cdr", "valueChange", "controlCreated", 4, "ngIf"], ["eui-sidesheet-actions", "", 1, "imx-button-bar"], ["data-imx-identifier", "createApp-save", "mat-raised-button", "", "color", "primary", "type", "button", "form", "form", 3, "disabled", "click"], [1, "imx-select", 3, "cdr", "controlCreated"], [1, "imx-select", 3, "cdr", "valueChange", "controlCreated"]], template: function ApplicationCreateComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 0)(1, "p", 1);
        i0.ɵɵtext(2, "#LDS#Add an icon, name and description to the application and assign a manager to it.");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "form", 2)(4, "imx-application-image-select", 3);
        i0.ɵɵlistener("controlCreated", function ApplicationCreateComponent_Template_imx_application_image_select_controlCreated_4_listener($event) { return ctx.form.addControl(ctx.imageColumn.ColumnName, $event); });
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(5, ApplicationCreateComponent_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 4);
        i0.ɵɵtemplate(6, ApplicationCreateComponent_imx_cdr_editor_6_Template, 1, 1, "imx-cdr-editor", 4);
        i0.ɵɵtemplate(7, ApplicationCreateComponent_imx_cdr_editor_7_Template, 1, 1, "imx-cdr-editor", 5);
        i0.ɵɵtemplate(8, ApplicationCreateComponent_imx_cdr_editor_8_Template, 1, 1, "imx-cdr-editor", 4);
        i0.ɵɵtemplate(9, ApplicationCreateComponent_imx_cdr_editor_9_Template, 1, 1, "imx-cdr-editor", 4);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(10, "mat-card", 6)(11, "button", 7);
        i0.ɵɵlistener("click", function ApplicationCreateComponent_Template_button_click_11_listener() { return ctx.save(); });
        i0.ɵɵelementStart(12, "span", 1);
        i0.ɵɵtext(13, "#LDS#Save");
        i0.ɵɵelementEnd()()();
    } if (rf & 2) {
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("formGroup", ctx.form);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("column", ctx.imageColumn);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.name);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.description);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.serviceCategory);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.manager);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.owner);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", !ctx.form.dirty || ctx.form.invalid);
    } }, dependencies: [i5.NgIf, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i7.MatButton, i6.MatCard, i8.ɵNgNoValidate, i8.NgControlStatusGroup, i2.CdrEditorComponent, i8.FormGroupDirective, i3$1.TranslateDirective, ApplicationImageSelectComponent], styles: ["[_nghost-%COMP%]{overflow-y:auto;display:flex;flex-direction:column;height:100%;background-color:#f9fbfc}.imx-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;margin:30px;overflow-y:auto;flex:1 1 auto;max-height:calc(100% - 60px)}.imx-button-bar[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;margin-bottom:0;padding:16px 32px;border-top:1px solid rgba(0,0,0,.12);background-color:#fff}.imx-button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-left:10px}.imx-button-bar[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}.eui-dark-theme   [_nghost-%COMP%]{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]{background-color:#444647}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]{background-color:#16191a}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationCreateComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-create', template: "<mat-card eui-sidesheet-content class=\"imx-content\">\r\n  <p translate>#LDS#Add an icon, name and description to the application and assign a manager to it.</p>\r\n\r\n  <form class=\"imx-form\" id=\"form\" [formGroup]=\"form\">\r\n    <imx-application-image-select class=\"imx-select\"\r\n      [column]=\"imageColumn\"\r\n      (controlCreated)=\"form.addControl(imageColumn.ColumnName, $event)\">\r\n    </imx-application-image-select>\r\n    <imx-cdr-editor class=\"imx-select\" *ngIf=\"name\" [cdr]=\"name\"\r\n      (controlCreated)=\"form.addControl(name.column.ColumnName, $event)\">\r\n    </imx-cdr-editor>\r\n    <imx-cdr-editor class=\"imx-select\" *ngIf=\"description\" [cdr]=\"description\"\r\n      (controlCreated)=\"form.addControl(description.column.ColumnName, $event)\">\r\n    </imx-cdr-editor>\r\n    <imx-cdr-editor class=\"imx-select\" *ngIf=\"serviceCategory\" [cdr]=\"serviceCategory\" (valueChange)=\"updateName($event)\"\r\n      (controlCreated)=\"form.addControl(serviceCategory.column.ColumnName, $event)\">\r\n    </imx-cdr-editor>\r\n    <imx-cdr-editor class=\"imx-select\" *ngIf=\"manager\" [cdr]=\"manager\"\r\n      (controlCreated)=\"form.addControl(manager.column.ColumnName, $event)\">\r\n    </imx-cdr-editor>\r\n    <imx-cdr-editor class=\"imx-select\" *ngIf=\"owner\" [cdr]=\"owner\"\r\n      (controlCreated)=\"form.addControl(owner.column.ColumnName, $event)\">\r\n    </imx-cdr-editor>\r\n  </form>\r\n</mat-card>\r\n\r\n<mat-card eui-sidesheet-actions class=\"imx-button-bar\">\r\n  <button data-imx-identifier=\"createApp-save\" mat-raised-button color=\"primary\" type=\"button\"\r\n    (click)=\"save()\" form=\"form\" [disabled]=\"!form.dirty || form.invalid\">\r\n    <span translate>#LDS#Save</span>\r\n  </button>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{overflow-y:auto;display:flex;flex-direction:column;height:100%;background-color:#f9fbfc}.imx-content{display:flex;flex-direction:column;margin:30px;overflow-y:auto;flex:1 1 auto;max-height:calc(100% - 60px)}.imx-button-bar{display:flex;justify-content:flex-end;margin-bottom:0;padding:16px 32px;border-top:1px solid rgba(0,0,0,.12);background-color:#fff}.imx-button-bar button{margin-left:10px}.imx-button-bar .justify-start{margin-right:auto}.eui-dark-theme :host{background-color:#2f3233}.eui-dark-theme :host .imx-button-bar{background-color:#444647}.eui-contrast-theme :host{background-color:#000}.eui-contrast-theme :host .imx-button-bar{background-color:#16191a}\n"] }]
    }], function () { return [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1$1.EuiSidesheetRef }, { type: i3$1.TranslateService }, { type: i2.ConfirmationService }]; }, null); })();

/**
 * This service provides methods for handling with {@link PortalApplication[]|applications}.
 * {@link ApplicationCardComponent|ApplicationCardComponent}.
 */
class ApplicationsService {
    constructor(aobClient, logger, errorHandler, apiProvider, translateService, sidesheet, snackbar, busyService) {
        this.aobClient = aobClient;
        this.logger = logger;
        this.errorHandler = errorHandler;
        this.apiProvider = apiProvider;
        this.translateService = translateService;
        this.sidesheet = sidesheet;
        this.snackbar = snackbar;
        this.busyService = busyService;
        this.onApplicationCreated = new Subject();
        this.onApplicationDeleted = new Subject();
        this.applicationRefresh = new BehaviorSubject(false);
        this.abortController = new AbortController();
        this.translateService.get('#LDS#Published').subscribe((trans) => (this.publishedText = trans));
        this.translateService.get('#LDS#KPI issues').subscribe((trans) => (this.kpiErrorsText = trans));
        this.translateService.get('#LDS#New').subscribe((trans) => (this.newBadgeText = trans));
    }
    get applicationSchema() {
        return this.aobClient.typedClient.PortalApplication.GetSchema();
    }
    get theme() {
        const bodyClasses = document.body.classList;
        return bodyClasses.contains(EuiTheme.LIGHT)
            ? EuiTheme.LIGHT
            : bodyClasses.contains(EuiTheme.DARK)
                ? EuiTheme.DARK
                : bodyClasses.contains(EuiTheme.CONTRAST)
                    ? EuiTheme.CONTRAST
                    : '';
    }
    /**
     * Encapsules the aob/applications GET endpoint and delivers a list of {@link PortalApplication[]|applications}.
     */
    async get(parameters = {}) {
        if (this.aobClient.typedClient == null) {
            return new Promise((resolve) => resolve(null));
        }
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalApplication.Get(parameters, { signal: this.abortController.signal }));
    }
    async reload(uidApplication) {
        return await this.apiProvider.request(async () => (await this.aobClient.typedClient.PortalApplicationInteractive.Get_byid(uidApplication)).Data[0]);
    }
    createNew() {
        return this.aobClient.typedClient.PortalApplicationNew.createEntity();
    }
    async tryCommit(application, reload) {
        try {
            await application.GetEntity().Commit(reload);
            if (application.AuthenticationRoot.value) {
                application.AuthenticationRootHelper.value = application.AuthenticationRoot.value;
            }
            this.logger.debug(this, 'storedapp:', application);
            return true;
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        return false;
    }
    /**
     * Publishs the given {@link PortalApplication[]|applications} by setting IsInactive to false or an ActivationDate to the given date.
     */
    async publish(application, publishData) {
        if (!publishData.publishFuture) {
            await application.IsInActive.Column.PutValue(publishData.publishFuture);
        }
        else {
            await application.ActivationDate.Column.PutValue(publishData.date);
        }
        this.logger.debug(this, 'Commit change: publish application...', application.ActivationDate.value);
        return this.tryCommit(application, true);
    }
    /**
     * Unpublishs the given {@link PortalApplication[]|applications} by setting IsInactive to true and ActivationDate to the default.
     */
    async unpublish(application) {
        await application.IsInActive.Column.PutValue(true);
        await application.ActivationDate.Column.PutValue(null);
        this.logger.debug(this, 'Commit change: unpublish application...');
        return this.tryCommit(application, true);
    }
    /**
     * Shows a badge on the given {@link PortalApplication[]|applications},
     * if the application is published or has kpi issues.
     */
    getApplicationBadges(application) {
        this.updateBadges(this.theme);
        if (application instanceof PortalApplicationNew) {
            this.logger.trace(this, 'Add a new badge to the badgelist.');
            return [this.badgeNew];
        }
        const badges = [];
        if (this.hasKpiIssues(application)) {
            this.logger.trace(this, 'Add a kpi error badge to the badgelist.');
            badges.push(this.badgeKpiErrors);
        }
        if (this.isPublished(application)) {
            this.logger.trace(this, 'Add a published badge to the badgelist.');
            badges.push(this.badgePublished);
        }
        if (this.createdToday(application)) {
            this.logger.trace(this, 'Add a new badge to the badgelist.');
            badges.push(this.badgeNew);
        }
        if (badges.length === 0) {
            this.logger.trace(this, 'Add no badge.');
        }
        return badges;
    }
    async createApplication() {
        const application = this.createNew();
        const result = await this.sidesheet
            .open(ApplicationCreateComponent, {
            title: await this.translateService.get('#LDS#Heading Create Application').toPromise(),
            padding: '0px',
            width: 'max(600px, 60%)',
            disableClose: true,
            testId: 'create-aob-application',
            data: {
                application,
            },
        })
            .afterClosed()
            .toPromise();
        if (result) {
            let overlayRef;
            setTimeout(() => (overlayRef = this.busyService.show()));
            try {
                await application.GetEntity().Commit(true);
                this.onApplicationCreated.next(application.UID_AOBApplication.value);
                this.snackbar.open({ key: '#LDS#The application has been successfully created.' });
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
        }
        else {
            this.snackbar.open({ key: '#LDS#The creation of the application has been canceled.' });
        }
    }
    async deleteApplication(uid) {
        await this.aobClient.client.portal_application_delete(uid);
        this.onApplicationDeleted.next(uid);
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
    isPublished(application) {
        if (application.IsInActive == null) {
            return false;
        }
        return !application.IsInActive.value;
    }
    hasKpiIssues(application) {
        if (application.HasKpiIssues == null) {
            return false;
        }
        return application.HasKpiIssues.value;
    }
    createdToday(app) {
        return (app != null && app.XDateInserted != null && new Date(app.XDateInserted.value).toLocaleDateString() === new Date().toLocaleDateString());
    }
    /**
     * Updates the badges, that are used on the application tiles, according to the used theme
     *
     * @param theme Currently used EuiTheme
     */
    updateBadges(theme) {
        //ToDo Bug422573 find a better solution for theming
        const published = {};
        published[EuiTheme.LIGHT] = '#0a96d1';
        published[EuiTheme.DARK] = '#016b91';
        published[EuiTheme.CONTRAST] = '#016b91';
        const newb = {};
        newb[EuiTheme.LIGHT] = '#4ba803';
        newb[EuiTheme.DARK] = '#327301';
        newb[EuiTheme.CONTRAST] = '#327301';
        const kpi = {};
        kpi[EuiTheme.LIGHT] = '#e36a00';
        kpi[EuiTheme.DARK] = '#900';
        kpi[EuiTheme.CONTRAST] = '#900';
        this.badgePublished = {
            content: this.publishedText,
            color: published[theme] ?? '#618f3e',
            textColor: '#ffffff',
        };
        this.badgeKpiErrors = {
            content: this.kpiErrorsText,
            color: kpi[theme] ?? '#f4770b',
            textColor: '#ffffff',
        };
        this.badgeNew = {
            content: this.newBadgeText,
            color: newb[theme] ?? '#02556d',
            textColor: theme === EuiTheme.LIGHT ? '#ffffff' : '#000000',
        };
    }
}
ApplicationsService.ɵfac = function ApplicationsService_Factory(t) { return new (t || ApplicationsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i0.ErrorHandler), i0.ɵɵinject(i2.ApiClientService), i0.ɵɵinject(i3$1.TranslateService), i0.ɵɵinject(i1$1.EuiSidesheetService), i0.ɵɵinject(i2.SnackBarService), i0.ɵɵinject(i1$1.EuiLoadingService)); };
ApplicationsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApplicationsService, factory: ApplicationsService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: AobApiService }, { type: i2.ClassloggerService }, { type: i0.ErrorHandler }, { type: i2.ApiClientService }, { type: i3$1.TranslateService }, { type: i1$1.EuiSidesheetService }, { type: i2.SnackBarService }, { type: i1$1.EuiLoadingService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationHyperviewService {
    constructor(apiClient, apiProvider) {
        this.apiClient = apiClient;
        this.apiProvider = apiProvider;
    }
    async get(uidApplication) {
        return this.apiProvider.request(() => this.apiClient.client.portal_hyperview_get('AOBApplication', uidApplication));
    }
}
ApplicationHyperviewService.ɵfac = function ApplicationHyperviewService_Factory(t) { return new (t || ApplicationHyperviewService)(i0.ɵɵinject(i1.QerApiService), i0.ɵɵinject(i2.ApiClientService)); };
ApplicationHyperviewService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApplicationHyperviewService, factory: ApplicationHyperviewService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationHyperviewService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i1.QerApiService }, { type: i2.ApiClientService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ApplicationHyperviewComponent_imx_busy_indicator_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-busy-indicator");
} }
function ApplicationHyperviewComponent_imx_hyperview_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-hyperview", 2);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("shapes", ctx_r1.shapes)("fontSize", "small");
} }
class ApplicationHyperviewComponent {
    constructor(classlogger, hyperviewprovider) {
        this.classlogger = classlogger;
        this.hyperviewprovider = hyperviewprovider;
        this.busyService = new BusyService();
        this.isLoading = false;
        this.busyService.busyStateChanged.subscribe((elem) => (this.isLoading = elem));
    }
    async ngOnChanges() {
        const isBusy = this.busyService.beginBusy();
        try {
            this.shapes = await this.hyperviewprovider.get(this.uidApplication);
            if (this.shapes) {
                this.classlogger.debug(this, 'hyperview loaded');
                this.classlogger.trace(this, this.shapes);
            }
            else {
                this.classlogger.error(this, 'ShapeData[] is undefined');
            }
        }
        finally {
            isBusy.endBusy();
        }
    }
}
ApplicationHyperviewComponent.ɵfac = function ApplicationHyperviewComponent_Factory(t) { return new (t || ApplicationHyperviewComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ApplicationHyperviewService)); };
ApplicationHyperviewComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationHyperviewComponent, selectors: [["imx-application-hyperview"]], inputs: { uidApplication: "uidApplication" }, features: [i0.ɵɵNgOnChangesFeature], decls: 2, vars: 2, consts: [[4, "ngIf"], [3, "shapes", "fontSize", 4, "ngIf"], [3, "shapes", "fontSize"]], template: function ApplicationHyperviewComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, ApplicationHyperviewComponent_imx_busy_indicator_0_Template, 1, 0, "imx-busy-indicator", 0);
        i0.ɵɵtemplate(1, ApplicationHyperviewComponent_imx_hyperview_1_Template, 1, 2, "imx-hyperview", 1);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.isLoading);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx.isLoading);
    } }, dependencies: [i5.NgIf, i2.HyperviewComponent, i2.BusyIndicatorComponent], styles: ["[_nghost-%COMP%]{background-color:transparent;display:flex;flex-direction:column}[_nghost-%COMP%]   imx-busy-service[_ngcontent-%COMP%]{justify-self:center;align-self:center}.eui-dark-theme   [_nghost-%COMP%]{background-color:transparent}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationHyperviewComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-hyperview', template: "<imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\r\n<imx-hyperview [shapes]=\"shapes\" [fontSize]=\"'small'\" *ngIf=\"!isLoading\"></imx-hyperview>\r\n\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{background-color:transparent;display:flex;flex-direction:column}:host imx-busy-service{justify-self:center;align-self:center}.eui-dark-theme :host{background-color:transparent}.eui-contrast-theme :host{background-color:#000}\n"] }]
    }], function () { return [{ type: i2.ClassloggerService }, { type: ApplicationHyperviewService }]; }, { uidApplication: [{
            type: Input
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementFilter {
    notPublished(entitlement) {
        return entitlement.IsInActive && entitlement.IsInActive.value && !entitlement.ActivationDate.value;
    }
    willPublish(entitlement) {
        return entitlement.IsInActive && entitlement.IsInActive.value && entitlement.ActivationDate.value != null;
    }
    published(entitlement) {
        return !entitlement.IsInActive.value;
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
var EntitlementsType;
(function (EntitlementsType) {
    EntitlementsType[EntitlementsType["UnsGroup"] = 0] = "UnsGroup";
    EntitlementsType[EntitlementsType["Eset"] = 1] = "Eset";
    EntitlementsType[EntitlementsType["Qerresource"] = 2] = "Qerresource";
    EntitlementsType[EntitlementsType["Rpsreport"] = 3] = "Rpsreport";
    EntitlementsType[EntitlementsType["Tsbaccountdef"] = 4] = "Tsbaccountdef";
})(EntitlementsType || (EntitlementsType = {}));

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementsService {
    constructor(aobClient, apiProvider, logger, errorHandler, translate) {
        this.aobClient = aobClient;
        this.apiProvider = apiProvider;
        this.logger = logger;
        this.errorHandler = errorHandler;
        this.filter = new EntitlementFilter();
        translate.get('#LDS#Published').subscribe((value) => this.badgePublished = {
            content: value,
            color: '#618f3e'
        });
        translate.get('#LDS#Will be published').subscribe((value) => this.badgeWillPublish = {
            content: value,
            color: '#f4770b'
        });
    }
    get entitlementSchema() {
        return this.aobClient.typedClient.PortalEntitlement.GetSchema();
    }
    async get(parameters = {}) {
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlement.Get(parameters));
    }
    async getInteractive(uid) {
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementInteractive.Get_byid(uid));
    }
    async addElementsToRole(entitlementSystemRoleInput) {
        return this.apiProvider.request(() => this.aobClient.client.portal_entitlement_systemrole_post(entitlementSystemRoleInput));
    }
    candidateSchema(type) {
        switch (type) {
            case EntitlementsType.Eset:
                return this.aobClient.typedClient.PortalEntitlementcandidatesEset.GetSchema();
            case EntitlementsType.Qerresource:
                return this.aobClient.typedClient.PortalEntitlementcandidatesQerresource.GetSchema();
            case EntitlementsType.Rpsreport:
                return this.aobClient.typedClient.PortalEntitlementcandidatesRpsreport.GetSchema();
            case EntitlementsType.Tsbaccountdef:
                return this.aobClient.typedClient.PortalEntitlementcandidatesTsbaccountdef.GetSchema();
            case EntitlementsType.UnsGroup:
                return this.aobClient.typedClient.PortalEntitlementcandidatesUnsgroup.GetSchema();
            default:
                throw new Error(`Type ${0} not supported`);
        }
    }
    async getCandidates(type, parameters = {}) {
        switch (type) {
            case EntitlementsType.Eset:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesEset.Get(parameters));
            case EntitlementsType.Qerresource:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesQerresource.Get(parameters));
            case EntitlementsType.Rpsreport:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesRpsreport.Get(parameters));
            case EntitlementsType.Tsbaccountdef:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesTsbaccountdef.Get(parameters));
            case EntitlementsType.UnsGroup:
                return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementcandidatesUnsgroup.Get(parameters));
            default:
                throw new Error(`Type ${0} not supported`);
        }
    }
    async getDataModel(type) {
        if (type === EntitlementsType.UnsGroup) {
            return this.aobClient.client.portal_entitlementcandidates_UNSGroup_datamodel_get(undefined);
        }
        return undefined;
    }
    async getEntitlementsForApplication(application, collectionLoadParameters = {}) {
        const filter = [...collectionLoadParameters.filter ?? [],
            {
                ColumnName: 'UID_AOBApplication',
                Type: FilterType.Compare,
                CompareOp: CompareOperator.Equal,
                Value1: application.UID_AOBApplication.value
            }];
        return this.get({
            ...collectionLoadParameters,
            ...{
                filter
            }
        });
    }
    async reload(entitlement) {
        const collection = await this.getInteractive(entitlement.UID_AOBEntitlement.value);
        return collection && collection.Data && collection.Data.length > 0 ? collection.Data[0] : undefined;
    }
    async assign(application, candidates) {
        let assignCount = 0;
        for (const candidate of candidates) {
            this.logger.debug(this, 'try to assign a new entitlement to application', application.UID_AOBApplication);
            const entitlement = await this.createNew(candidate, application.UID_AOBApplication);
            this.logger.info(this, 'try to assign a new entitlement to application', application.UID_AOBApplication);
            if (await this.tryCommit(entitlement)) {
                this.logger.info(this, 'The entitlement was assigned to application', application.UID_AOBApplication);
                assignCount++;
            }
        }
        return assignCount;
    }
    async unassign(entitlements) {
        return this.apiProvider.request(async () => {
            let result = null;
            for (const entitlement of entitlements) {
                result = await this.aobClient.client.portal_entitlement_delete(entitlement.UID_AOBEntitlement.value);
            }
            return result;
        });
    }
    async publish(entitlements, publishData) {
        let publishCount = 0;
        for (const entitlement of entitlements) {
            const interactive = (await this.aobClient.typedClient.PortalEntitlementInteractive.Get_byid(entitlement.GetEntity().GetKeys()[0])).Data[0];
            if (!publishData.publishFuture) {
                await interactive.IsInActive.Column.PutValue(publishData.publishFuture);
            }
            else {
                await interactive.ActivationDate.Column.PutValue(publishData.date);
            }
            this.logger.debug(this, 'Commit change: publish entitlement...');
            if (await this.tryCommit(interactive)) {
                publishCount++;
            }
        }
        return publishCount;
    }
    async unpublish(entitlements) {
        let unpublishCount = 0;
        for (const entitlement of entitlements) {
            const interactive = (await this.aobClient.typedClient.PortalEntitlementInteractive.Get_byid(entitlement.GetEntity().GetKeys()[0])).Data[0];
            await interactive.IsInActive.Column.PutValue(true);
            await interactive.ActivationDate.Column.PutValue(null);
            this.logger.debug(this, 'Commit change: unpublish entitlement...');
            if (await this.tryCommit(interactive)) {
                unpublishCount++;
            }
        }
        return unpublishCount;
    }
    async tryCommit(entitlement, reload) {
        try {
            await entitlement.GetEntity().Commit(reload);
            return true;
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        return false;
    }
    getEntitlementBadges(entitlement) {
        if (this.filter.published(entitlement)) {
            return [this.badgePublished];
        }
        if (this.filter.willPublish(entitlement)) {
            return [this.badgeWillPublish];
        }
        return [];
    }
    async getEntitlementsFilterTree(options) {
        return this.aobClient.client.portal_entitlementcandidates_UNSGroup_filtertree_get(options);
    }
    async createNew(element, uidAobApplication) {
        const entitlement = (await this.aobClient.typedClient.PortalEntitlementInteractive.Get()).Data[0];
        entitlement.ObjectKeyElement.value = element.GetEntity().GetColumn('XObjectKey').GetValue(),
            entitlement.UID_AOBApplication.value = uidAobApplication.value;
        return entitlement;
    }
}
EntitlementsService.ɵfac = function EntitlementsService_Factory(t) { return new (t || EntitlementsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ApiClientService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i0.ErrorHandler), i0.ɵɵinject(i3$1.TranslateService)); };
EntitlementsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EntitlementsService, factory: EntitlementsService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: AobApiService }, { type: i2.ApiClientService }, { type: i2.ClassloggerService }, { type: i0.ErrorHandler }, { type: i3$1.TranslateService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * The list of all possible actions on the {@link PortalEntitlement|PortalEntitlements} for an {@link PortalApplication|PortalApplication}.
 */
var LifecycleAction;
(function (LifecycleAction) {
    LifecycleAction[LifecycleAction["Publish"] = 0] = "Publish";
    LifecycleAction[LifecycleAction["Unpublish"] = 1] = "Unpublish";
    LifecycleAction[LifecycleAction["Unassign"] = 2] = "Unassign";
})(LifecycleAction || (LifecycleAction = {}));

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function LifecycleActionComponent_ng_template_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "div", 15);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r6 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r6 == null ? null : data_r6.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r6 == null ? null : data_r6.Description.Column.GetDisplayValue());
} }
function LifecycleActionComponent_span_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#*If you unassign an application entitlement from this application, it is removed from this application. The application entitlement can still be reassigned as required."));
} }
function LifecycleActionComponent_div_11_mat_card_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card");
    i0.ɵɵelement(1, "eui-icon", 27);
    i0.ɵɵelementStart(2, "mat-card-title");
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const shop_r13 = ctx.$implicit;
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(shop_r13.GetEntity().GetDisplay());
} }
function LifecycleActionComponent_div_11_span_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r8 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, ctx_r8.data.type === "AobEntitlement" ? "#LDS#Application entitlements cannot be published. No shop is assigned to the application. Please assign at least one shop to the application." : "#LDS#No shop is assigned to the application. Without a shop, the assigned application entitlements cannot be requested. Please assign at least one shop to the application."), " ");
} }
function LifecycleActionComponent_div_11_span_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1("*", i0.ɵɵpipeBind1(2, 1, "#LDS#IT Shops are set at the application level."), "");
} }
function LifecycleActionComponent_div_11_span_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r10 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, ctx_r10.isApplication() ? "#LDS#The application will be published immediately. The exact time may vary." : "#LDS#The application entitlement will be published immediately. The exact time may vary."), "");
} }
function LifecycleActionComponent_div_11_mat_form_field_21_mat_error_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Please specify a date that lies in the future."), " ");
} }
function LifecycleActionComponent_div_11_mat_form_field_21_mat_error_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Please enter a valid date or select a date from the calendar."), " ");
} }
function LifecycleActionComponent_div_11_mat_form_field_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-form-field");
    i0.ɵɵelement(1, "input", 29);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelement(3, "mat-datepicker-toggle", 30)(4, "mat-datepicker", null, 31);
    i0.ɵɵtemplate(6, LifecycleActionComponent_div_11_mat_form_field_21_mat_error_6_Template, 3, 3, "mat-error", 26);
    i0.ɵɵtemplate(7, LifecycleActionComponent_div_11_mat_form_field_21_mat_error_7_Template, 3, 3, "mat-error", 26);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const _r14 = i0.ɵɵreference(5);
    const ctx_r11 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵpropertyInterpolate("placeholder", i0.ɵɵpipeBind1(2, 6, "#LDS#Date"));
    i0.ɵɵproperty("min", ctx_r11.minDate)("matDatepicker", _r14);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("for", _r14);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r11.datepickerFormControl.hasError("noFutureDateSelected"));
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r11.datepickerFormControl.hasError("invalidDate"));
} }
function LifecycleActionComponent_div_11_span_22_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "ldsReplace");
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r12 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind3(2, 1, i0.ɵɵpipeBind1(3, 5, ctx_r12.isApplication() ? "#LDS#The application will be published on {0} at {1} (your local time)." : "#LDS#The application entitlement will be published on {0} at {1} (your local time) if the application is published."), ctx_r12.dateString, ctx_r12.timeString));
} }
function LifecycleActionComponent_div_11_Template(rf, ctx) { if (rf & 1) {
    const _r18 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 17)(1, "div", 18)(2, "h5");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, LifecycleActionComponent_div_11_mat_card_5_Template, 4, 1, "mat-card", 19);
    i0.ɵɵtemplate(6, LifecycleActionComponent_div_11_span_6_Template, 3, 3, "span", 20);
    i0.ɵɵtemplate(7, LifecycleActionComponent_div_11_span_7_Template, 3, 3, "span", 8);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "div", 21)(9, "form", 22);
    i0.ɵɵlistener("ngSubmit", function LifecycleActionComponent_div_11_Template_form_ngSubmit_9_listener() { i0.ɵɵrestoreView(_r18); const ctx_r17 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r17.submitData()); });
    i0.ɵɵelementStart(10, "h5");
    i0.ɵɵtext(11);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "mat-radio-group", 23)(14, "mat-radio-button", 24);
    i0.ɵɵtext(15);
    i0.ɵɵpipe(16, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(17, "mat-radio-button", 25);
    i0.ɵɵtext(18);
    i0.ɵɵpipe(19, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵtemplate(20, LifecycleActionComponent_div_11_span_20_Template, 3, 3, "span", 8);
    i0.ɵɵtemplate(21, LifecycleActionComponent_div_11_mat_form_field_21_Template, 8, 8, "mat-form-field", 26);
    i0.ɵɵtemplate(22, LifecycleActionComponent_div_11_span_22_Template, 4, 7, "span", 8);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 11, "#LDS#Shops") + (ctx_r3.data.type === "AobEntitlement" ? "*" : ""));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r3.data.shops);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r3.data.shops.length == 0);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r3.data.type === "AobEntitlement");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("formGroup", ctx_r3.publishDateForm);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(12, 13, "#LDS#Publication Date"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(16, 15, "#LDS#Now"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(19, 17, "#LDS#Later"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", !ctx_r3.publishFuture);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r3.publishFuture);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r3.publishFuture && ctx_r3.datepickerFormControl.value);
} }
function LifecycleActionComponent_button_16_Template(rf, ctx) { if (rf & 1) {
    const _r20 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 32);
    i0.ɵɵlistener("click", function LifecycleActionComponent_button_16_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r20); const ctx_r19 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r19.submitData()); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r4.actionButtonText, " ");
} }
function LifecycleActionComponent_button_17_Template(rf, ctx) { if (rf & 1) {
    const _r22 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 33);
    i0.ɵɵlistener("click", function LifecycleActionComponent_button_17_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r22); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.submitDataIe()); });
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r5 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r5.publishDateForm.invalid || ctx_r5.data.shops.length < 1 && ctx_r5.data.type === "AobEntitlement");
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r5.actionButtonText, " ");
} }
/**
 * A component that represents a dialog for submitting an {@link LifecycleAction|action} on the
 * given {@link PortalApplication|PortalApplication} or {@link PortalEntitlement|PortalEntitlements}.
 *
 */
class LifecycleActionComponent {
    constructor(dialogRef, data, logger, ldsReplace, translateService, metadataProvider, aobApiService, platform) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.logger = logger;
        this.ldsReplace = ldsReplace;
        this.translateService = translateService;
        this.metadataProvider = metadataProvider;
        this.aobApiService = aobApiService;
        this.platform = platform;
        this.DisplayColumns = DisplayColumns; // Enables use of this static class in Angular Templates.
        this.whenToPublish = 'now';
        /**
         * @ignore
         * List of subscriptions.
         */
        this.subscriptions = [];
        this.browserCulture = this.translateService.currentLang;
        this.initCaptions();
        const curDate = new Date();
        curDate.setHours(24, 0, 0, 0);
        // set date to tomorrow
        this.minDate = moment(curDate);
        this.datepickerFormControl = new UntypedFormControl(this.minDate, this.validateDate(this.minDate, () => this.publishFuture));
        this.publishDateForm = new UntypedFormGroup({
            datepickerFormControl: this.datepickerFormControl,
            whenToPublish: new UntypedFormControl('now'),
        });
        this.subscriptions.push(this.publishDateForm.get('whenToPublish').valueChanges
            .subscribe((when) => {
            this.whenToPublish = when;
            this.publishFuture = this.whenToPublish === 'future';
        }));
        this.publishFuture = false;
        this.dataSource = {
            Data: data.elements,
            totalCount: data.elements.length
        };
    }
    get dateString() {
        return this.datepickerFormControl.value.toDate().toLocaleDateString(this.browserCulture);
    }
    get timeString() {
        return this.datepickerFormControl.value.toDate().toLocaleTimeString(this.browserCulture);
    }
    /**
     * @ignore Used internally.
     */
    async ngOnInit() {
        this.entitySchema = this.isApplication()
            ? this.aobApiService.typedClient.PortalApplication.GetSchema()
            : this.aobApiService.typedClient.PortalEntitlement.GetSchema();
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchema.Columns.UID_AERoleOwner
        ];
        this.dstSettings = {
            dataSource: this.dataSource,
            entitySchema: this.entitySchema,
            displayedColumns: this.displayedColumns,
            navigationState: {
                StartIndex: 0
            }
        };
        await this.metadataProvider
            .GetTableMetadata(this.entitySchema.TypeName)
            .then((metadata) => (this.tableDisplay = metadata.DisplaySingular));
    }
    /**
     * @ignore Used internally.
     * Unsubscribes all listeners.
     */
    ngOnDestroy() {
        this.subscriptions.forEach(subscription => subscription.unsubscribe());
    }
    /**
     * Closes the {@link MatDialog|dialog} and returns the publish-data (in the publish-mode) or true (for all modes).
     */
    submitData() {
        this.logger.debug(this, `Close the ${this.data.action} dialog for ${this.data.elements.length} ${this.data.type}(s).`);
        const result = this.data.action === LifecycleAction.Publish
            ? { publishFuture: this.publishFuture, date: this.datepickerFormControl.value.toDate() }
            : true;
        this.dialogRef.close(result);
    }
    submitDataIe() {
        if (!this.platform.TRIDENT) {
            return;
        }
        this.submitData();
    }
    /** Returns true, if the dialog is used for unassigning items. */
    isUnassign() {
        return this.data.action === LifecycleAction.Unassign;
    }
    /** Returns true, if the dialog is used for publishing items. */
    isPublish() {
        return this.data.action === LifecycleAction.Publish;
    }
    /** Returns true, if the dialog is used for unpublishing items. */
    isUnpublish() {
        return this.data.action === LifecycleAction.Unpublish;
    }
    /** Returns true, if the dialog is used for {@link PortalApplication|PortalApplication}. */
    isApplication() {
        return this.data.type === 'AobApplication';
    }
    /** Returns true, if the dialog is used for {@link PortalEntitlement|PortalEntitlements}. */
    isEntitlement() {
        return this.data.type === 'AobEntitlement';
    }
    initCaptions() {
        this.logger.debug(this, `Init captions for the ${this.data.action.toString()}-mode depending on the application count.`);
        const multipleEntitlements = this.data != null && this.data.elements != null && this.data.elements.length > 1;
        let dialogTitle = multipleEntitlements ? '#LDS#Heading Unassign {0} Application Entitlements' : '#LDS#Heading Unassign Application Entitlement';
        let buttonText = multipleEntitlements ? '#LDS#Unassign' : '#LDS#Unassign';
        if (this.data.type === 'AobApplication') {
            dialogTitle = multipleEntitlements ? '#LDS#Heading Delete {0} Applications' : '#LDS#Heading Delete Application';
            buttonText = multipleEntitlements ? '#LDS#Delete' : '#LDS#Delete';
        }
        if (this.isPublish()) {
            if (this.data.type === 'AobApplication') {
                dialogTitle = multipleEntitlements ? '#LDS#Heading Publish {0} Applications' : '#LDS#Heading Publish Application';
                buttonText = multipleEntitlements ? '#LDS#Publish' : '#LDS#Publish';
            }
            else {
                dialogTitle = multipleEntitlements ? '#LDS#Heading Publish {0} Application Entitlements' : '#LDS#Heading Publish Application Entitlement';
                buttonText = multipleEntitlements ? '#LDS#Publish' : '#LDS#Publish';
            }
        }
        else if (this.isUnpublish()) {
            if (this.data.type === 'AobApplication') {
                dialogTitle = multipleEntitlements ? '#LDS#Heading Unpublish {0} Applications' : '#LDS#Heading Unpublish Application';
                buttonText = multipleEntitlements ? '#LDS#Unpublish' : '#LDS#Unpublish';
            }
            else {
                dialogTitle = multipleEntitlements ? '#LDS#Heading Unpublish {0} Application Entitlements' : '#LDS#Heading Unpublish Application Entitlement';
                buttonText = multipleEntitlements ? '#LDS#Unpublish' : '#LDS#Unpublish';
            }
        }
        this.translateService.get(dialogTitle)
            .subscribe((trans) => this.dialogTitle = this.ldsReplace.transform(trans, this.data.elements.length));
        this.translateService.get(buttonText).
            subscribe((trans) => this.actionButtonText = trans);
    }
    validateDate(minDate, publishFuture) {
        return (control) => {
            if (!publishFuture()) {
                return null;
            }
            if (!control.value || control.value.length > 0) {
                return { invalidDate: true };
            }
            if (control.value < minDate) {
                return { noFutureDateSelected: true };
            }
            else {
                return null;
            }
        };
    }
}
LifecycleActionComponent.ɵfac = function LifecycleActionComponent_Factory(t) { return new (t || LifecycleActionComponent)(i0.ɵɵdirectiveInject(i1$2.MatDialogRef), i0.ɵɵdirectiveInject(MAT_DIALOG_DATA), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i2.LdsReplacePipe), i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(AobApiService), i0.ɵɵdirectiveInject(i5$1.Platform)); };
LifecycleActionComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: LifecycleActionComponent, selectors: [["imx-entitlements-action"]], decls: 18, vars: 13, consts: [["mat-dialog-title", ""], ["mat-dialog-content", ""], ["imxtable", ""], [3, "settings"], ["dataSourceToolbar", ""], ["mode", "manual", "detailViewVisible", "false", 3, "dst"], [3, "entityColumn", "columnLabel"], [3, "entityColumn"], ["class", "mat-small", 4, "ngIf"], ["class", "imx-entitlements-publish-settings", 4, "ngIf"], ["mat-dialog-actions", "", "align", "end"], ["mat-stroked-button", "", "mat-dialog-close", ""], ["mat-raised-button", "", "color", "warn", "cdkFocusInitial", "", 3, "click", 4, "ngIf"], ["mat-raised-button", "", "color", "primary", "form", "publishDateForm", "cdkFocusInitial", "", 3, "disabled", "click", 4, "ngIf"], ["imxTitle", ""], ["imxSubtitle", ""], [1, "mat-small"], [1, "imx-entitlements-publish-settings"], [1, "imx-entitlements-publish-itshops"], [4, "ngFor", "ngForOf"], ["class", "mat-error", 4, "ngIf"], [1, "imx-entitlements-publish-date"], ["id", "publishDateForm", 1, "imx-form", 3, "formGroup", "ngSubmit"], ["aria-label", "Publish date", "formControlName", "whenToPublish"], ["value", "now"], ["value", "future"], [4, "ngIf"], ["mat-card-avatar", "", "size", "16px", "icon", "library"], [1, "mat-error"], ["matInput", "", "required", "", "formControlName", "datepickerFormControl", 3, "min", "matDatepicker", "placeholder"], ["matSuffix", "", 3, "for"], ["datepicker", ""], ["mat-raised-button", "", "color", "warn", "cdkFocusInitial", "", 3, "click"], ["mat-raised-button", "", "color", "primary", "form", "publishDateForm", "cdkFocusInitial", "", 3, "disabled", "click"]], template: function LifecycleActionComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "h2", 0);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(2, "div", 1)(3, "div", 2);
        i0.ɵɵelement(4, "imx-data-source-toolbar", 3, 4);
        i0.ɵɵelementStart(6, "imx-data-table", 5)(7, "imx-data-table-column", 6);
        i0.ɵɵtemplate(8, LifecycleActionComponent_ng_template_8_Template, 4, 2, "ng-template");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(9, "imx-data-table-column", 7);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(10, LifecycleActionComponent_span_10_Template, 3, 3, "span", 8);
        i0.ɵɵtemplate(11, LifecycleActionComponent_div_11_Template, 23, 19, "div", 9);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(12, "div", 10)(13, "button", 11);
        i0.ɵɵtext(14);
        i0.ɵɵpipe(15, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(16, LifecycleActionComponent_button_16_Template, 2, 1, "button", 12);
        i0.ɵɵtemplate(17, LifecycleActionComponent_button_17_Template, 2, 2, "button", 13);
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        const _r0 = i0.ɵɵreference(5);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(ctx.dialogTitle);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("settings", ctx.dstSettings);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r0);
        i0.ɵɵadvance(1);
        i0.ɵɵpropertyInterpolate("columnLabel", ctx.tableDisplay);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns["UID_AERoleOwner"]);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.isEntitlement() && ctx.isUnassign());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.isPublish());
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(15, 11, "#LDS#Cancel"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", !ctx.isPublish());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.isPublish());
    } }, dependencies: [i5.NgForOf, i5.NgIf, i2.DataSourceToolbarComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i1$1.EuiIconComponent, i8.ɵNgNoValidate, i8.DefaultValueAccessor, i8.NgControlStatus, i8.NgControlStatusGroup, i8.RequiredValidator, i7.MatButton, i6.MatCard, i6.MatCardTitle, i6.MatCardAvatar, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogContent, i1$2.MatDialogActions, i11.MatDatepicker, i11.MatDatepickerInput, i11.MatDatepickerToggle, i12.MatError, i12.MatFormField, i12.MatSuffix, i13.MatInput, i14.MatRadioGroup, i14.MatRadioButton, i8.FormGroupDirective, i8.FormControlName, i2.LdsReplacePipe, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:inherit}imx-data-source-toolbar[_ngcontent-%COMP%]{display:none}.mat-table[_ngcontent-%COMP%]{box-shadow:none}.mat-table[_ngcontent-%COMP%]   .mat-cell[_ngcontent-%COMP%]{max-width:20vw}.mat-card-avatar[_ngcontent-%COMP%]{background-color:#aab0b3;color:#fff;padding:5px;height:25px;width:25px;-webkit-user-select:none;user-select:none}.mat-dialog-content[_ngcontent-%COMP%]{overflow:hidden;flex:1;display:flex;flex-direction:column;height:inherit}.mat-column-__Display[_ngcontent-%COMP%]{max-width:500px}div[imxTitle][_ngcontent-%COMP%]{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}div[imxSubtitle][_ngcontent-%COMP%]{font-size:smaller;opacity:.7;color:#919799}div[imxtable][_ngcontent-%COMP%]{overflow:auto;flex-grow:1;flex-shrink:0}div[imxActionsLabel][_ngcontent-%COMP%]{max-height:50px;margin:30px 0}.imx-entitlements-publish-settings[_ngcontent-%COMP%]{display:flex;margin-top:20px;overflow:auto}.mat-dialog-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end}.mat-dialog-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-left:10px;margin-top:10px}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]{display:flex;flex-direction:column;padding-bottom:20px;overflow:auto;width:380px;margin-right:20px}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{margin-bottom:25px}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{display:flex;align-items:center;height:50px;width:300px;margin-bottom:15px}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   .mat-card-title[_ngcontent-%COMP%]{font-size:16px;margin-left:10px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   .mat-small[_ngcontent-%COMP%]{font-size:10px;color:#919799}.imx-entitlements-publish-itshops[_ngcontent-%COMP%]   .mat-error[_ngcontent-%COMP%]{font-size:12px;margin-right:15px}.imx-entitlements-publish-date[_ngcontent-%COMP%]{display:flex;flex-direction:column;padding-bottom:20px;width:400px}.imx-entitlements-publish-date[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{margin-bottom:25px}.imx-entitlements-publish-date[_ngcontent-%COMP%]   .mat-radio-button[_ngcontent-%COMP%]{margin-right:60px}.imx-entitlements-publish-date[_ngcontent-%COMP%]   .mat-form-field[_ngcontent-%COMP%]{width:159px;margin-top:30px}.imx-entitlements-publish-date[_ngcontent-%COMP%]   .mat-small[_ngcontent-%COMP%]{display:block;font-size:14px;font-style:italic;color:#444647}.eui-dark-theme   [_nghost-%COMP%]   .mat-card-avatar[_ngcontent-%COMP%]{background-color:#616566;color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .mat-card-avatar[_ngcontent-%COMP%]{background-color:#2f3233;color:#000}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LifecycleActionComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlements-action', template: "<h2 mat-dialog-title>{{ dialogTitle }}</h2>\r\n<div mat-dialog-content>\r\n  <div imxtable>\r\n    <imx-data-source-toolbar #dataSourceToolbar [settings]=\"dstSettings\"> </imx-data-source-toolbar>\r\n    <imx-data-table [dst]=\"dataSourceToolbar\" mode=\"manual\" detailViewVisible=\"false\">\r\n      <imx-data-table-column [entityColumn]=\"entitySchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\" columnLabel=\"{{ tableDisplay }}\">\r\n        <ng-template let-data>\r\n          <div imxTitle>{{ data?.GetEntity().GetDisplay() }}</div>\r\n          <div imxSubtitle>{{ data?.Description.Column.GetDisplayValue() }}</div>\r\n        </ng-template>\r\n      </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema?.Columns['UID_AERoleOwner']\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n  </div>\r\n  <span *ngIf=\"isEntitlement() && isUnassign()\" class=\"mat-small\">{{\r\n    '#LDS#*If you unassign an application entitlement from this application, it is removed from this application. The application entitlement can still be reassigned as required.'\r\n      | translate\r\n  }}</span>\r\n  <div *ngIf=\"isPublish()\" class=\"imx-entitlements-publish-settings\">\r\n    <div class=\"imx-entitlements-publish-itshops\">\r\n      <h5>{{ ('#LDS#Shops' | translate) + (data.type === 'AobEntitlement' ? '*' : '') }}</h5>\r\n      <mat-card *ngFor=\"let shop of data.shops\">\r\n        <eui-icon mat-card-avatar size=\"16px\" icon=\"library\"></eui-icon>\r\n        <mat-card-title>{{ shop.GetEntity().GetDisplay() }}</mat-card-title>\r\n      </mat-card>\r\n      <span *ngIf=\"data.shops.length == 0\" class=\"mat-error\">\r\n        {{\r\n          (data.type === 'AobEntitlement'\r\n            ? '#LDS#Application entitlements cannot be published. No shop is assigned to the application. Please assign at least one shop to the application.'\r\n            : '#LDS#No shop is assigned to the application. Without a shop, the assigned application entitlements cannot be requested. Please assign at least one shop to the application.'\r\n          ) | translate\r\n        }}\r\n      </span>\r\n      <span *ngIf=\"data.type === 'AobEntitlement'\" class=\"mat-small\">*{{ '#LDS#IT Shops are set at the application level.' | translate }}</span>\r\n    </div>\r\n    <div class=\"imx-entitlements-publish-date\">\r\n      <form class=\"imx-form\" id=\"publishDateForm\" [formGroup]=\"publishDateForm\" (ngSubmit)=\"submitData()\">\r\n        <h5>{{ '#LDS#Publication Date' | translate }}</h5>\r\n        <mat-radio-group aria-label=\"Publish date\" formControlName=\"whenToPublish\">\r\n          <mat-radio-button value=\"now\">{{ '#LDS#Now' | translate }}</mat-radio-button>\r\n          <mat-radio-button value=\"future\">{{ '#LDS#Later' | translate }}</mat-radio-button>\r\n        </mat-radio-group>\r\n        <span *ngIf=\"!publishFuture\" class=\"mat-small\">\r\n          {{\r\n            (isApplication()\r\n              ? '#LDS#The application will be published immediately. The exact time may vary.'\r\n              : '#LDS#The application entitlement will be published immediately. The exact time may vary.'\r\n            ) | translate\r\n          }}</span\r\n        >\r\n        <mat-form-field *ngIf=\"publishFuture\">\r\n          <input matInput [min]=\"minDate\" [matDatepicker]=\"datepicker\" required placeholder=\"{{ '#LDS#Date' | translate }}\" formControlName=\"datepickerFormControl\" />\r\n          <mat-datepicker-toggle matSuffix [for]=\"datepicker\"></mat-datepicker-toggle>\r\n          <mat-datepicker #datepicker></mat-datepicker>\r\n          <mat-error *ngIf=\"datepickerFormControl.hasError('noFutureDateSelected')\">\r\n            {{ '#LDS#Please specify a date that lies in the future.' | translate }}\r\n          </mat-error>\r\n          <mat-error *ngIf=\"datepickerFormControl.hasError('invalidDate')\">\r\n            {{ '#LDS#Please enter a valid date or select a date from the calendar.' | translate }}\r\n          </mat-error>\r\n        </mat-form-field>\r\n        <!-- TODO 225775: Add Timepicker -->\r\n        <span *ngIf=\"publishFuture && this.datepickerFormControl.value\" class=\"mat-small\">{{\r\n          (isApplication()\r\n            ? '#LDS#The application will be published on {0} at {1} (your local time).'\r\n            : '#LDS#The application entitlement will be published on {0} at {1} (your local time) if the application is published.'\r\n          )\r\n            | translate\r\n            | ldsReplace : dateString : timeString\r\n        }}</span>\r\n      </form>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div mat-dialog-actions align=\"end\">\r\n  <button mat-stroked-button mat-dialog-close>{{ '#LDS#Cancel' | translate }}</button>\r\n  <button mat-raised-button color=\"warn\" *ngIf=\"!isPublish()\" (click)=\"submitData()\" cdkFocusInitial>\r\n    {{ actionButtonText }}\r\n  </button>\r\n  <button\r\n    mat-raised-button\r\n    color=\"primary\"\r\n    (click)=\"submitDataIe()\"\r\n    form=\"publishDateForm\"\r\n    *ngIf=\"isPublish()\"\r\n    cdkFocusInitial\r\n    [disabled]=\"publishDateForm.invalid || (data.shops.length < 1 && data.type === 'AobEntitlement')\"\r\n  >\r\n    {{ actionButtonText }}\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;height:inherit}imx-data-source-toolbar{display:none}.mat-table{box-shadow:none}.mat-table .mat-cell{max-width:20vw}.mat-card-avatar{background-color:#aab0b3;color:#fff;padding:5px;height:25px;width:25px;-webkit-user-select:none;user-select:none}.mat-dialog-content{overflow:hidden;flex:1;display:flex;flex-direction:column;height:inherit}.mat-column-__Display{max-width:500px}div[imxTitle]{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}div[imxSubtitle]{font-size:smaller;opacity:.7;color:#919799}div[imxtable]{overflow:auto;flex-grow:1;flex-shrink:0}div[imxActionsLabel]{max-height:50px;margin:30px 0}.imx-entitlements-publish-settings{display:flex;margin-top:20px;overflow:auto}.mat-dialog-actions{display:flex;justify-content:flex-end}.mat-dialog-actions button{margin-left:10px;margin-top:10px}.imx-entitlements-publish-itshops{display:flex;flex-direction:column;padding-bottom:20px;overflow:auto;width:380px;margin-right:20px}.imx-entitlements-publish-itshops h5{margin-bottom:25px}.imx-entitlements-publish-itshops .mat-card{display:flex;align-items:center;height:50px;width:300px;margin-bottom:15px}.imx-entitlements-publish-itshops .mat-card-title{font-size:16px;margin-left:10px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.imx-entitlements-publish-itshops .mat-small{font-size:10px;color:#919799}.imx-entitlements-publish-itshops .mat-error{font-size:12px;margin-right:15px}.imx-entitlements-publish-date{display:flex;flex-direction:column;padding-bottom:20px;width:400px}.imx-entitlements-publish-date h5{margin-bottom:25px}.imx-entitlements-publish-date .mat-radio-button{margin-right:60px}.imx-entitlements-publish-date .mat-form-field{width:159px;margin-top:30px}.imx-entitlements-publish-date .mat-small{display:block;font-size:14px;font-style:italic;color:#444647}.eui-dark-theme :host .mat-card-avatar{background-color:#616566;color:#2f3233}.eui-contrast-theme :host .mat-card-avatar{background-color:#2f3233;color:#000}\n"] }]
    }], function () { return [{ type: i1$2.MatDialogRef }, { type: undefined, decorators: [{
                type: Inject,
                args: [MAT_DIALOG_DATA]
            }] }, { type: i2.ClassloggerService }, { type: i2.LdsReplacePipe }, { type: i3$1.TranslateService }, { type: i2.MetadataService }, { type: AobApiService }, { type: i5$1.Platform }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SystemRoleConfigService {
    constructor(aobClient) {
        this.aobClient = aobClient;
    }
    get roleSchema() {
        return this.aobClient.typedClient.PortalEntitlementcandidatesEset.GetSchema();
    }
    async getExistingRoles(application, parameters) {
        return this.aobClient.typedClient.PortalEntitlementSystemrole.Get(application, parameters);
    }
}
SystemRoleConfigService.ɵfac = function SystemRoleConfigService_Factory(t) { return new (t || SystemRoleConfigService)(i0.ɵɵinject(AobApiService)); };
SystemRoleConfigService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: SystemRoleConfigService, factory: SystemRoleConfigService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SystemRoleConfigService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: AobApiService }]; }, null); })();

const _c0$c = ["viewport"];
function SystemRoleConfigComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 9);
    i0.ɵɵlistener("dismissed", function SystemRoleConfigComponent_eui_alert_1_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r6 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r6.onHelperDismissed()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r0.LdsAddOrCreate), " ");
} }
function SystemRoleConfigComponent_mat_radio_group_3_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-radio-group", 10);
    i0.ɵɵlistener("ngModelChange", function SystemRoleConfigComponent_mat_radio_group_3_Template_mat_radio_group_ngModelChange_0_listener($event) { i0.ɵɵrestoreView(_r9); const ctx_r8 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r8.type = $event); })("change", function SystemRoleConfigComponent_mat_radio_group_3_Template_mat_radio_group_change_0_listener($event) { i0.ɵɵrestoreView(_r9); const ctx_r10 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r10.typeChanged($event)); });
    i0.ɵɵelementStart(1, "mat-radio-button", 11);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-radio-button", 12);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngModel", ctx_r1.type);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("value", "new");
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 5, "#LDS#Create new system role"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("value", "existing");
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 7, "#LDS#Add to existing system role"), " ");
} }
function SystemRoleConfigComponent_form_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "form", 13)(1, "mat-form-field", 14)(2, "mat-label", 15);
    i0.ɵɵtext(3, "#LDS#Name");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(4, "input", 16);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("formGroup", ctx_r2.form);
} }
function SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_mat_list_option_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-list-option", 23)(1, "div", 24)(2, "div", 25);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const candidate_r15 = ctx.$implicit;
    i0.ɵɵproperty("value", candidate_r15);
    i0.ɵɵattribute("data-imx-identifier", "multi-select-formcontrol-list" + candidate_r15.GetEntity().GetKeys()[0]);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(candidate_r15.GetEntity().GetDisplay());
} }
function SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_Template(rf, ctx) { if (rf & 1) {
    const _r18 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "cdk-virtual-scroll-viewport", 19, 20)(2, "mat-selection-list", 21);
    i0.ɵɵlistener("selectionChange", function SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_Template_mat_selection_list_selectionChange_2_listener($event) { i0.ɵɵrestoreView(_r18); const ctx_r17 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r17.updateSelected($event)); });
    i0.ɵɵtemplate(3, SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_mat_list_option_3_Template, 4, 3, "mat-list-option", 22);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r11 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("itemSize", 50);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("multiple", false);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("cdkVirtualForOf", ctx_r11.candidates);
} }
function SystemRoleConfigComponent_ng_container_5_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 26);
    i0.ɵɵelement(1, "eui-icon", 27);
    i0.ɵɵelementStart(2, "p", 15);
    i0.ɵɵtext(3, "#LDS#There are currently no system roles.");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("icon", "table");
} }
function SystemRoleConfigComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, SystemRoleConfigComponent_ng_container_5_cdk_virtual_scroll_viewport_1_Template, 4, 3, "cdk-virtual-scroll-viewport", 17);
    i0.ɵɵtemplate(2, SystemRoleConfigComponent_ng_container_5_div_2_Template, 4, 1, "div", 18);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", (ctx_r3.candidates == null ? null : ctx_r3.candidates.length) > 0);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r3.candidates == null || ctx_r3.candidates.length === 0);
} }
function SystemRoleConfigComponent_button_7_Template(rf, ctx) { if (rf & 1) {
    const _r20 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 28);
    i0.ɵɵlistener("click", function SystemRoleConfigComponent_button_7_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r20); const ctx_r19 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r19.close(true)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r4.form.invalid || !ctx_r4.form.dirty);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Create new system role"), " ");
} }
function SystemRoleConfigComponent_button_8_Template(rf, ctx) { if (rf & 1) {
    const _r22 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 29);
    i0.ɵɵlistener("click", function SystemRoleConfigComponent_button_8_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r22); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.close(false)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r5 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", ctx_r5.selectedRole == null);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Add to system role"), " ");
} }
class SystemRoleConfigComponent {
    constructor(data, sidesheetRef, busyService, addToExistingProvider, settingsService, changeDetectorRef) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.busyService = busyService;
        this.addToExistingProvider = addToExistingProvider;
        this.settingsService = settingsService;
        this.changeDetectorRef = changeDetectorRef;
        this.type = 'new';
        this.showHelperAlert = true;
        this.subscriptions = [];
        this.LdsAddOrCreate = '#LDS#Here you can merge the application entitlements into a new system role or add the application entitlements to an existing system role. The system role will then be assigned to the application as an application entitlement.';
        this.form = new UntypedFormGroup({ name: new UntypedFormControl(undefined, Validators.required) });
    }
    async ngAfterViewInit() {
        this.parameters = { PageSize: this.settingsService.DefaultPageSize, StartIndex: 0 };
        if (this.viewport) {
            this.subscriptions.push(this.viewport.renderedRangeStream.subscribe(async (range) => {
                if (range.end === (this.settingsService.DefaultPageSize + this.parameters.StartIndex)) {
                    this.parameters.StartIndex += this.settingsService.DefaultPageSize;
                    const tmpCandidates = Object.assign([], this.candidates);
                    await this.loadData(this.parameters);
                    this.candidates.unshift(...tmpCandidates);
                    this.changeDetectorRef.detectChanges();
                }
            }));
        }
    }
    ngOnDestroy() {
        this.subscriptions.forEach(s => s.unsubscribe());
    }
    async typeChanged(evt) {
        if (evt.value === 'existing') {
            if (this.viewport) {
                this.subscriptions.push(this.viewport.renderedRangeStream.subscribe(async (range) => {
                    if (range.end === (this.settingsService.DefaultPageSize + this.parameters.StartIndex)) {
                        this.parameters.StartIndex += this.settingsService.DefaultPageSize;
                        const tmpCandidates = Object.assign([], this.candidates);
                        await this.loadData(this.parameters);
                        this.candidates.unshift(...tmpCandidates);
                        this.changeDetectorRef.detectChanges();
                    }
                }));
            }
            this.selectedRole = null;
            await this.loadData({ ...this.parameters, ...{ StartIndex: 0 } });
        }
    }
    async updateSelected(selection) {
        this.selectedRole = selection.options[0].value.GetEntity().GetKeys()[0];
    }
    onHelperDismissed() {
        this.showHelperAlert = false;
    }
    close(createNew) {
        if (createNew) {
            this.sidesheetRef.close({ NameNewEset: this.form.get('name').value });
        }
        else {
            this.sidesheetRef.close({ UidEset: this.selectedRole });
        }
    }
    async loadData(newState) {
        let overlayRef;
        setTimeout(() => overlayRef = this.busyService.show());
        try {
            this.candidates = (await this.addToExistingProvider.getExistingRoles(this.data.uid, newState))
                .Data;
        }
        finally {
            setTimeout(() => this.busyService.hide(overlayRef));
        }
    }
}
SystemRoleConfigComponent.ɵfac = function SystemRoleConfigComponent_Factory(t) { return new (t || SystemRoleConfigComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(SystemRoleConfigService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef)); };
SystemRoleConfigComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SystemRoleConfigComponent, selectors: [["ng-component"]], viewQuery: function SystemRoleConfigComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0$c, 5);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.viewport = _t.first);
    } }, decls: 9, vars: 6, consts: [["eui-sidesheet-content", ""], ["class", "imx-helper-alert", "type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "imx-content-card"], [3, "ngModel", "ngModelChange", "change", 4, "ngIf"], [3, "formGroup", 4, "ngIf"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "system-role-config-create-new-system-role-button", 3, "disabled", "click", 4, "ngIf"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "system-role-config-add-to-existing-system-role-button", 3, "disabled", "click", 4, "ngIf"], ["type", "info", 1, "imx-helper-alert", 3, "condensed", "colored", "dismissable", "dismissed"], [3, "ngModel", "ngModelChange", "change"], ["data-imx-identifier", "add-to-role-new", 3, "value"], ["data-imx-identifier", "add-to-role-existing", 3, "value"], [3, "formGroup"], ["appearance", "outline"], ["translate", ""], ["matInput", "", "formControlName", "name", "data-imx-identifier", "system-role-config-new-system-role-input"], ["minBufferPx", "300", "maxBufferPx", "800", "class", "imx-viewport", 3, "itemSize", 4, "ngIf"], ["class", "imx-no-results", 4, "ngIf"], ["minBufferPx", "300", "maxBufferPx", "800", 1, "imx-viewport", 3, "itemSize"], ["viewport", ""], [3, "multiple", "selectionChange"], ["class", "imx-candidate-option", 3, "value", 4, "cdkVirtualFor", "cdkVirtualForOf"], [1, "imx-candidate-option", 3, "value"], [1, "imx-candidate-content"], [1, "imx-candidate-display"], [1, "imx-no-results"], [3, "icon"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "system-role-config-create-new-system-role-button", 3, "disabled", "click"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "system-role-config-add-to-existing-system-role-button", 3, "disabled", "click"]], template: function SystemRoleConfigComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0);
        i0.ɵɵtemplate(1, SystemRoleConfigComponent_eui_alert_1_Template, 3, 6, "eui-alert", 1);
        i0.ɵɵelementStart(2, "mat-card", 2);
        i0.ɵɵtemplate(3, SystemRoleConfigComponent_mat_radio_group_3_Template, 7, 9, "mat-radio-group", 3);
        i0.ɵɵtemplate(4, SystemRoleConfigComponent_form_4_Template, 5, 1, "form", 4);
        i0.ɵɵtemplate(5, SystemRoleConfigComponent_ng_container_5_Template, 3, 2, "ng-container", 5);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(6, "div", 6);
        i0.ɵɵtemplate(7, SystemRoleConfigComponent_button_7_Template, 3, 4, "button", 7);
        i0.ɵɵtemplate(8, SystemRoleConfigComponent_button_8_Template, 3, 4, "button", 8);
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.showHelperAlert && !ctx.data.createOnly);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", !ctx.data.createOnly);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.type === "new");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.type === "existing");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.type === "new");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.type !== "new");
    } }, dependencies: [i5.NgIf, i1$1.EuiAlertComponent, i1$1.EuiIconComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i7.MatButton, i6.MatCard, i12.MatFormField, i12.MatLabel, i13.MatInput, i9.MatSelectionList, i9.MatListOption, i14.MatRadioGroup, i14.MatRadioButton, i11$1.CdkFixedSizeVirtualScroll, i11$1.CdkVirtualForOf, i11$1.CdkVirtualScrollViewport, i8.ɵNgNoValidate, i8.DefaultValueAccessor, i8.NgControlStatus, i8.NgControlStatusGroup, i8.NgModel, i8.FormGroupDirective, i8.FormControlName, i3$1.TranslateDirective, i3$1.TranslatePipe], styles: [".imx-viewport[_ngcontent-%COMP%]{height:300px;width:100%;overflow-x:hidden}.imx-helper-alert[_ngcontent-%COMP%]{margin:10px 0 20px auto;width:100%}.mat-radio-button[_ngcontent-%COMP%]{margin-right:20px}.mat-radio-group[_ngcontent-%COMP%]{padding:10px 10px 30px;display:flex;flex-direction:row}.eui-sidesheet-content[_ngcontent-%COMP%]{height:inherit;overflow:hidden;display:flex;flex-direction:column}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-content-card[_ngcontent-%COMP%]{flex:1 1 auto}.imx-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0}.imx-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px;color:#c4cacc8c}.imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px;color:#919799}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SystemRoleConfigComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\r\n  <eui-alert *ngIf=\"showHelperAlert && !data.createOnly\" class=\"imx-helper-alert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\"\r\n    [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\r\n    {{ LdsAddOrCreate | translate }}\r\n  </eui-alert>\r\n  <mat-card class=\"imx-content-card\">\r\n\r\n    <mat-radio-group [(ngModel)]=\"type\" (change)=\"typeChanged($event)\" *ngIf=\"!data.createOnly\">\r\n      <mat-radio-button [value]=\"'new'\" data-imx-identifier=\"add-to-role-new\">\r\n        {{'#LDS#Create new system role' | translate}}\r\n      </mat-radio-button>\r\n      <mat-radio-button [value]=\"'existing'\" data-imx-identifier=\"add-to-role-existing\">\r\n        {{'#LDS#Add to existing system role' | translate}}\r\n      </mat-radio-button>\r\n    </mat-radio-group>\r\n    <form [formGroup]=\"form\" *ngIf=\"type === 'new'\">\r\n      <mat-form-field appearance=\"outline\">\r\n        <mat-label translate>#LDS#Name</mat-label>\r\n        <input matInput formControlName=\"name\" data-imx-identifier=\"system-role-config-new-system-role-input\">\r\n      </mat-form-field>\r\n    </form>\r\n    <ng-container *ngIf=\"type === 'existing' \">\r\n      <cdk-virtual-scroll-viewport *ngIf=\"candidates?.length > 0\" #viewport [itemSize]=\"50\" minBufferPx=\"300\"\r\n        maxBufferPx=\"800\" class=\"imx-viewport\">\r\n        <mat-selection-list [multiple]=\"false\" (selectionChange)=\"updateSelected($event)\">\r\n          <mat-list-option *cdkVirtualFor=\"let candidate of candidates; index as i\" [value]=\"candidate\"\r\n            class=\"imx-candidate-option\"\r\n            [attr.data-imx-identifier]=\"'multi-select-formcontrol-list' + candidate.GetEntity().GetKeys()[0]\">\r\n            <div class=\"imx-candidate-content\">\r\n              <div class=\"imx-candidate-display\">{{ candidate.GetEntity().GetDisplay() }}</div>\r\n            </div>\r\n          </mat-list-option>\r\n        </mat-selection-list>\r\n      </cdk-virtual-scroll-viewport>\r\n      <div class=\"imx-no-results\" *ngIf=\"candidates == null || candidates.length === 0\">\r\n        <eui-icon [icon]=\"'table'\"></eui-icon>\r\n        <p translate>#LDS#There are currently no system roles.</p>\r\n      </div>\r\n    </ng-container>\r\n\r\n  </mat-card>\r\n</div>\r\n\r\n<div eui-sidesheet-actions >\r\n  <button *ngIf=\"type === 'new'\" mat-raised-button color=\"primary\" [disabled]=\"form.invalid || !form.dirty\"\r\n    (click)=\"close(true)\" data-imx-identifier=\"system-role-config-create-new-system-role-button\">\r\n    {{'#LDS#Create new system role' | translate}}\r\n  </button>\r\n  <button [disabled]=\"selectedRole == null\" *ngIf=\"type !== 'new'\" mat-raised-button color=\"primary\"\r\n    (click)=\"close(false)\" data-imx-identifier=\"system-role-config-add-to-existing-system-role-button\">\r\n    {{'#LDS#Add to system role' | translate}}\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.imx-viewport{height:300px;width:100%;overflow-x:hidden}.imx-helper-alert{margin:10px 0 20px auto;width:100%}.mat-radio-button{margin-right:20px}.mat-radio-group{padding:10px 10px 30px;display:flex;flex-direction:row}.eui-sidesheet-content{height:inherit;overflow:hidden;display:flex;flex-direction:column}.eui-sidesheet-content .imx-content-card{flex:1 1 auto}.imx-no-results{text-align:center;margin:20px 0}.imx-no-results .eui-icon{font-size:100px;color:#c4cacc8c}.imx-no-results p{margin:0;font-size:18px;color:#919799}\n"] }]
    }], function () { return [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1$1.EuiSidesheetRef }, { type: i1$1.EuiLoadingService }, { type: SystemRoleConfigService }, { type: i2.SettingsService }, { type: i0.ChangeDetectorRef }]; }, { viewport: [{
            type: ViewChild,
            args: ['viewport']
        }] }); })();

function EntitlementsAddComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "eui-alert", 15);
    i0.ɵɵlistener("dismissed", function EntitlementsAddComponent_eui_alert_1_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.onHelperDismissed()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r0.LdsInfoAlert), " ");
} }
function EntitlementsAddComponent_mat_option_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-option", 16);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const entitlementSourceType_r7 = ctx.$implicit;
    i0.ɵɵproperty("value", entitlementSourceType_r7.entitlementsType);
    i0.ɵɵattribute("data-imx-identifier", "imx-entitlments-add-type-select" + entitlementSourceType_r7.entitlementsType);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", entitlementSourceType_r7.display, " ");
} }
function EntitlementsAddComponent_ng_container_10_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelement(1, "imx-data-table-column", 21);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r9 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("entityColumn", ctx_r9.entitySchema == null ? null : ctx_r9.entitySchema.Columns[ctx_r9.DisplayColumns.DISPLAY_PROPERTYNAME]);
} }
function EntitlementsAddComponent_ng_container_10_ng_container_5_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "div", 22);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r12 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r12 == null ? null : data_r12.GetEntity().GetDisplay());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r12 == null ? null : data_r12.Description.Column.GetDisplayValue());
} }
function EntitlementsAddComponent_ng_container_10_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "imx-data-table-column", 21);
    i0.ɵɵtemplate(2, EntitlementsAddComponent_ng_container_10_ng_container_5_ng_template_2_Template, 4, 2, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(3, "imx-data-table-column", 21)(4, "imx-data-table-column", 21)(5, "imx-data-table-column", 21);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r10 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("entityColumn", ctx_r10.entitySchema == null ? null : ctx_r10.entitySchema.Columns[ctx_r10.DisplayColumns.DISPLAY_PROPERTYNAME]);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("entityColumn", ctx_r10.entitySchema == null ? null : ctx_r10.entitySchema.Columns["CanonicalName"]);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("entityColumn", ctx_r10.entitySchema == null ? null : ctx_r10.entitySchema.Columns["Description"]);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("entityColumn", ctx_r10.entitySchema == null ? null : ctx_r10.entitySchema.Columns["UID_UNSRoot"]);
} }
const _c0$b = function () { return ["search", "filter", "filterTree"]; };
function EntitlementsAddComponent_ng_container_10_Template(rf, ctx) { if (rf & 1) {
    const _r14 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "imx-data-source-toolbar", 17, 18);
    i0.ɵɵlistener("navigationStateChanged", function EntitlementsAddComponent_ng_container_10_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { i0.ɵɵrestoreView(_r14); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.onNavigationStateChanged($event)); })("search", function EntitlementsAddComponent_ng_container_10_Template_imx_data_source_toolbar_search_1_listener($event) { i0.ɵɵrestoreView(_r14); const ctx_r15 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r15.onSearch($event)); })("filterTreeSelectionChanged", function EntitlementsAddComponent_ng_container_10_Template_imx_data_source_toolbar_filterTreeSelectionChanged_1_listener($event) { i0.ɵɵrestoreView(_r14); const ctx_r16 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r16.onFilterByTree($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "imx-data-table", 19);
    i0.ɵɵlistener("selectionChanged", function EntitlementsAddComponent_ng_container_10_Template_imx_data_table_selectionChanged_3_listener($event) { i0.ɵɵrestoreView(_r14); const ctx_r17 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r17.onSelectionChanged($event)); })("highlightedEntityChanged", function EntitlementsAddComponent_ng_container_10_Template_imx_data_table_highlightedEntityChanged_3_listener($event) { i0.ɵɵrestoreView(_r14); const ctx_r18 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r18.onHighlightedEntityChanged($event)); });
    i0.ɵɵtemplate(4, EntitlementsAddComponent_ng_container_10_ng_container_4_Template, 2, 1, "ng-container", 8);
    i0.ɵɵtemplate(5, EntitlementsAddComponent_ng_container_10_ng_container_5_Template, 6, 4, "ng-container", 8);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(6, "imx-data-source-paginator", 20);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const _r8 = i0.ɵɵreference(2);
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("settings", ctx_r2.settings)("options", i0.ɵɵpureFunction0(8, _c0$b));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("dst", _r8)("selectable", true)("detailViewVisible", false);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r2.selectedSourceType !== ctx_r2.EntitlementsType.UnsGroup);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r2.selectedSourceType === ctx_r2.EntitlementsType.UnsGroup);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("dst", _r8);
} }
function EntitlementsAddComponent_button_18_Template(rf, ctx) { if (rf & 1) {
    const _r20 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 23);
    i0.ɵɵlistener("click", function EntitlementsAddComponent_button_18_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r20); const ctx_r19 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r19.onCreateRole()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Create new system role"), " ");
} }
function EntitlementsAddComponent_button_19_Template(rf, ctx) { if (rf & 1) {
    const _r22 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 24);
    i0.ɵɵlistener("click", function EntitlementsAddComponent_button_19_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r22); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.onAddToRole()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵproperty("disabled", !ctx_r4.selections || (ctx_r4.selections == null ? null : ctx_r4.selections.length) === 0);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Merge into system role"), " ");
} }
const helperAlertKey = `${HELPER_ALERT_KEY_PREFIX}_addNewEntitlements`;
/**
 * A component that represents a sidesheet for adding application entitlements to an {@link PortalApplication}.
 */
class EntitlementsAddComponent {
    constructor(sidesheetRef, data, logger, entitlementsProvider, busyService, storageService, metaData, sidesheet, translateService) {
        this.sidesheetRef = sidesheetRef;
        this.data = data;
        this.logger = logger;
        this.entitlementsProvider = entitlementsProvider;
        this.busyService = busyService;
        this.storageService = storageService;
        this.metaData = metaData;
        this.sidesheet = sidesheet;
        this.translateService = translateService;
        this.EntitlementsType = EntitlementsType; // Enables use of this Enum in Angular Templates.
        this.DisplayColumns = DisplayColumns; // Enables use of this static class in Angular Templates.
        this.displayedColumns = [];
        this.selectedSourceType = EntitlementsType.UnsGroup;
        this.entitlementSourceTypes = [];
        this.LdsInfoAlert = '#LDS#Here you can assign application entitlements to the application. Once assigned, you can publish these application entitlements so that they can be requested.';
        this.selectedSourceType = data.defaultType;
        this.isSystemRolesEnabled = data.isSystemRolesEnabled;
        this.browserCulture = translateService.currentLang;
    }
    get showHelperAlert() {
        return !this.storageService.isHelperAlertDismissed(helperAlertKey);
    }
    async ngOnInit() {
        await this.metaData.updateNonExisting(['ESet', 'UNSGroup', 'QERResource', 'RPSReport', 'TSBAccountDef']);
        this.entitlementSourceTypes = [
            { entitlementsType: EntitlementsType.UnsGroup, display: this.metaData.tables.UNSGroup.Display },
            { entitlementsType: EntitlementsType.Qerresource, display: this.metaData.tables.QERResource.Display },
            { entitlementsType: EntitlementsType.Rpsreport, display: this.metaData.tables.RPSReport.Display },
            { entitlementsType: EntitlementsType.Tsbaccountdef, display: this.metaData.tables.TSBAccountDef.Display },
        ];
        if (this.isSystemRolesEnabled) {
            this.entitlementSourceTypes.unshift({ entitlementsType: EntitlementsType.Eset, display: this.metaData.tables.ESet.Display });
        }
        await this.useSource(this.selectedSourceType);
    }
    onHelperDismissed() {
        this.storageService.storeHelperAlertDismissal(helperAlertKey);
    }
    /**
     * Call to toggle the view and show entitlements candidates or roles candidates.
     */
    async toggleView(arg) {
        this.selectedSourceType = arg.value;
        this.logger.debug(this, `Switching view to ${this.selectedSourceType}.`);
        await this.useSource(this.selectedSourceType);
    }
    onOk() {
        this.logger.debug(this, 'Close the sidesheet for assigning application entitlements');
        this.logger.trace(this, this.selections);
        this.sidesheetRef.close({ selection: this.selections });
    }
    async onCreateRole() {
        const entitlementSystemRoleInput = await this.sidesheet
            .open(SystemRoleConfigComponent, {
            // TODO: make LDS Heading
            title: await this.translateService.get('#LDS#Create new system role').toPromise(),
            padding: '0px',
            width: 'max(500px, 50%)',
            testId: 'create-role-sidesheet',
            data: { uid: this.data.uidApplication, createOnly: true },
        })
            .afterClosed()
            .toPromise();
        if (!entitlementSystemRoleInput) {
            this.logger.debug(this, 'role dialog canceled');
            return;
        }
        entitlementSystemRoleInput.UidApplication = this.data.uidApplication;
        entitlementSystemRoleInput.ObjectKeyEntitlements = [];
        this.sidesheetRef.close({ role: entitlementSystemRoleInput });
    }
    async onAddToRole() {
        const entitlementSystemRoleInput = await this.sidesheet
            .open(SystemRoleConfigComponent, {
            title: await this.translateService.get('#LDS#Heading Merge Application Entitlements into System Role').toPromise(),
            padding: '0px',
            width: 'max(500px, 50%)',
            testId: 'add-to-existing-role-sidesheet',
            data: { uid: this.data.uidApplication, createOnly: false },
        })
            .afterClosed()
            .toPromise();
        if (!entitlementSystemRoleInput) {
            this.logger.debug(this, 'role dialog canceled');
            return;
        }
        const keys = this.selections
            .map((elem) => CdrFactoryService.tryGetColumn(elem.GetEntity(), 'XObjectKey')?.GetValue())
            .filter((elem) => elem != null);
        if (keys.length < this.selections.length) {
            this.logger.error(this, 'Attempt to assign entitlement(s) failed');
        }
        entitlementSystemRoleInput.UidApplication = this.data.uidApplication;
        entitlementSystemRoleInput.ObjectKeyEntitlements = keys;
        this.sidesheetRef.close({ role: entitlementSystemRoleInput });
    }
    onSelectionChanged(selection) {
        this.selections = selection;
    }
    onHighlightedEntityChanged(entity) {
        this.highlightedEntity = entity;
    }
    onNavigationStateChanged(newState) {
        this.navigationState = newState;
        this.updateCandidates();
    }
    onSearch(keywords) {
        this.logger.debug(this, `Searching for: ${keywords}`);
        this.navigationState.StartIndex = 0;
        this.navigationState.search = keywords;
        this.updateCandidates();
    }
    async onFilterByTree(filters) {
        this.navigationState.filter = filters;
        this.updateCandidates();
    }
    async useSource(type) {
        this.selectedSourceType = type;
        this.entitySchema = this.entitlementsProvider.candidateSchema(type);
        let overlayRef;
        setTimeout(() => (overlayRef = this.busyService.show()));
        try {
            this.filters = (await this.entitlementsProvider.getDataModel(type))?.Filters;
        }
        finally {
            setTimeout(() => this.busyService.hide(overlayRef));
        }
        this.displayedColumns = this.getDisplayedColumnsForEntitlement(this.entitySchema, type);
        this.navigationState = { StartIndex: 0, PageSize: 25 };
        this.highlightedEntity = null;
        this.updateCandidates();
    }
    async updateCandidates() {
        let overlayRef;
        setTimeout(() => (overlayRef = this.busyService.show()));
        try {
            this.logger.debug(this, 'Get candidates from the server...');
            const data = await this.entitlementsProvider.getCandidates(this.selectedSourceType, this.navigationState);
            this.settings = {
                dataSource: data,
                displayedColumns: this.displayedColumns,
                entitySchema: this.entitySchema,
                navigationState: this.navigationState,
                filters: this.filters,
                filterTree: this.selectedSourceType === EntitlementsType.UnsGroup
                    ? {
                        filterMethode: async (parentkey) => {
                            return this.entitlementsProvider.getEntitlementsFilterTree({
                                parentkey,
                            });
                        },
                        multiSelect: false,
                    }
                    : undefined,
            };
            if (data == null) {
                this.logger.error(this, 'TypedEntityCollectionData<TypedEntity> is undefined');
            }
        }
        finally {
            setTimeout(() => this.busyService.hide(overlayRef));
        }
    }
    getDisplayedColumnsForEntitlement(entitySchema, type) {
        if (!entitySchema) {
            return [];
        }
        switch (type) {
            case EntitlementsType.UnsGroup:
                return [
                    entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
                    entitySchema.Columns.CanonicalName,
                    entitySchema.Columns.UID_UNSRoot,
                ];
            default:
                return [entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]];
        }
    }
}
EntitlementsAddComponent.ɵfac = function EntitlementsAddComponent_Factory(t) { return new (t || EntitlementsAddComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(EntitlementsService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.StorageService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$1.TranslateService)); };
EntitlementsAddComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementsAddComponent, selectors: [["imx-entitlements-add"]], decls: 23, vars: 17, consts: [["eui-sidesheet-content", ""], ["class", "imx-helper-alert", "type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "imx-sidesheet-content"], [1, "imx-type-selection"], ["appearance", "outline", 1, "flex-field"], [1, "imx-info-text-light"], ["data-imx-identifier", "imx-entitlments-add-type-select", 3, "ngModel", "ngModelChange", "selectionChange"], [3, "value", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["eui-sidesheet-actions", ""], [1, "imx-selected-entitlements"], ["color", "orange", "data-imx-identifier", "imx-entitlements-add-selected-items-badge", 1, "imx-badge"], ["mat-raised-button", "", "data-imx-identifier", "imx-entitlements-create-role-button", 3, "click", 4, "ngIf"], ["mat-raised-button", "", "data-imx-identifier", "imx-entitlements-add-to-role-button", 3, "disabled", "click", 4, "ngIf"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "imx-entitlements-add-assig-button", 3, "disabled", "click"], ["type", "info", 1, "imx-helper-alert", 3, "condensed", "colored", "dismissable", "dismissed"], [3, "value"], [3, "settings", "options", "navigationStateChanged", "search", "filterTreeSelectionChanged"], ["dst", ""], ["mode", "manual", 3, "dst", "selectable", "detailViewVisible", "selectionChanged", "highlightedEntityChanged"], [3, "dst"], [3, "entityColumn"], ["subtitle", ""], ["mat-raised-button", "", "data-imx-identifier", "imx-entitlements-create-role-button", 3, "click"], ["mat-raised-button", "", "data-imx-identifier", "imx-entitlements-add-to-role-button", 3, "disabled", "click"]], template: function EntitlementsAddComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0);
        i0.ɵɵtemplate(1, EntitlementsAddComponent_eui_alert_1_Template, 3, 6, "eui-alert", 1);
        i0.ɵɵelementStart(2, "mat-card", 2)(3, "div", 3)(4, "mat-form-field", 4)(5, "mat-label", 5);
        i0.ɵɵtext(6);
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(8, "mat-select", 6);
        i0.ɵɵlistener("ngModelChange", function EntitlementsAddComponent_Template_mat_select_ngModelChange_8_listener($event) { return ctx.selectedSourceType = $event; })("selectionChange", function EntitlementsAddComponent_Template_mat_select_selectionChange_8_listener($event) { return ctx.toggleView($event); });
        i0.ɵɵtemplate(9, EntitlementsAddComponent_mat_option_9_Template, 2, 3, "mat-option", 7);
        i0.ɵɵelementEnd()()();
        i0.ɵɵtemplate(10, EntitlementsAddComponent_ng_container_10_Template, 7, 9, "ng-container", 8);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(11, "div", 9)(12, "p", 10)(13, "eui-badge", 11);
        i0.ɵɵtext(14);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(15, "span");
        i0.ɵɵtext(16);
        i0.ɵɵpipe(17, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(18, EntitlementsAddComponent_button_18_Template, 3, 3, "button", 12);
        i0.ɵɵtemplate(19, EntitlementsAddComponent_button_19_Template, 3, 4, "button", 13);
        i0.ɵɵelementStart(20, "button", 14);
        i0.ɵɵlistener("click", function EntitlementsAddComponent_Template_button_click_20_listener() { return ctx.onOk(); });
        i0.ɵɵtext(21);
        i0.ɵɵpipe(22, "translate");
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.showHelperAlert);
        i0.ɵɵadvance(5);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(7, 11, "#LDS#Application entitlement type"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngModel", ctx.selectedSourceType);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx.entitlementSourceTypes);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.settings == null ? null : ctx.settings.dataSource);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate1(" ", (ctx.selections == null ? null : ctx.selections.length) || 0, "");
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(17, 13, "#LDS#Selected application entitlements"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.isSystemRolesEnabled);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.isSystemRolesEnabled);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("disabled", (ctx.selections == null ? null : ctx.selections.length) === 0);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(22, 15, "#LDS#Assign"), " ");
    } }, dependencies: [i5.NgForOf, i5.NgIf, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i1$1.EuiAlertComponent, i1$1.EuiBadgeComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i6$1.MatOption, i7.MatButton, i6.MatCard, i12.MatFormField, i12.MatLabel, i10.MatSelect, i8.NgControlStatus, i8.NgModel, i3$1.TranslatePipe], styles: [".imx-helper-alert[_ngcontent-%COMP%]{margin:10px 0 20px auto;width:100%}.imx-selected-entitlements[_ngcontent-%COMP%]{margin:0;line-height:36px;flex:auto}.imx-selected-entitlements[_ngcontent-%COMP%]     .imx-badge.eui-badge .eui-badge-content{font-size:14px;line-height:14px}.imx-badge[_ngcontent-%COMP%]{background-color:inherit}.eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-sidesheet-content[_ngcontent-%COMP%]{flex:1 1 auto;height:inherit;overflow:hidden;display:flex;flex-direction:column}.eui-sidesheet-actions[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{align-self:center}.eui-sidesheet-actions[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:not(:last-child){margin-right:10px}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementsAddComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlements-add', template: "<div eui-sidesheet-content>\r\n  <eui-alert *ngIf=\"showHelperAlert\" class=\"imx-helper-alert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\"\r\n    [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\r\n    {{LdsInfoAlert | translate}}\r\n  </eui-alert>\r\n  <mat-card class=\"imx-sidesheet-content\">\r\n    <div class=\"imx-type-selection\">\r\n      <mat-form-field appearance=\"outline\" class=\"flex-field\">\r\n        <mat-label class=\"imx-info-text-light\">{{'#LDS#Application entitlement type' | translate }}</mat-label>\r\n        <mat-select [(ngModel)]=\"selectedSourceType\" (selectionChange)=\"toggleView($event)\"\r\n          data-imx-identifier=\"imx-entitlments-add-type-select\">\r\n          <mat-option *ngFor=\"let entitlementSourceType of entitlementSourceTypes\"\r\n            [value]=\"entitlementSourceType.entitlementsType\"\r\n            [attr.data-imx-identifier]=\"'imx-entitlments-add-type-select' + entitlementSourceType.entitlementsType\">\r\n            {{entitlementSourceType.display}}\r\n          </mat-option>\r\n        </mat-select>\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <ng-container *ngIf=\"settings?.dataSource\">\r\n      <imx-data-source-toolbar\r\n        #dst\r\n        [settings]=\"settings\"\r\n        (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n        [options]=\"['search', 'filter', 'filterTree']\"\r\n        (search)=\"onSearch($event)\"\r\n        (filterTreeSelectionChanged)=\"onFilterByTree($event)\"\r\n      >\r\n      </imx-data-source-toolbar>\r\n      <imx-data-table [dst]=\"dst\" [selectable]=\"true\" (selectionChanged)=\"onSelectionChanged($event)\"\r\n        (highlightedEntityChanged)=\"onHighlightedEntityChanged($event)\" [detailViewVisible]=\"false\" mode=\"manual\">\r\n        <ng-container *ngIf=\"selectedSourceType !== EntitlementsType.UnsGroup\">\r\n          <imx-data-table-column [entityColumn]=\"entitySchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\"></imx-data-table-column>\r\n        </ng-container>\r\n        <ng-container *ngIf=\"selectedSourceType === EntitlementsType.UnsGroup\">\r\n          <imx-data-table-column [entityColumn]=\"entitySchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n            <ng-template let-data>\r\n              <div>{{ data?.GetEntity().GetDisplay() }}</div>\r\n              <div subtitle>{{ data?.Description.Column.GetDisplayValue()}}</div>\r\n            </ng-template>\r\n          </imx-data-table-column>\r\n          <imx-data-table-column [entityColumn]=\"entitySchema?.Columns['CanonicalName']\">\r\n          </imx-data-table-column>\r\n          <imx-data-table-column [entityColumn]=\"entitySchema?.Columns['Description']\">\r\n          </imx-data-table-column>\r\n          <imx-data-table-column [entityColumn]=\"entitySchema?.Columns['UID_UNSRoot']\">\r\n          </imx-data-table-column>\r\n        </ng-container>\r\n      </imx-data-table>\r\n      <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n    </ng-container>\r\n  </mat-card>\r\n</div>\r\n<div eui-sidesheet-actions >\r\n  <p class=\"imx-selected-entitlements\">\r\n    <eui-badge class=\"imx-badge\" color=\"orange\" data-imx-identifier=\"imx-entitlements-add-selected-items-badge\">\r\n      {{selections?.length || 0}}</eui-badge>\r\n    <span>{{'#LDS#Selected application entitlements' | translate }}</span>\r\n  </p>\r\n  <button *ngIf=\"isSystemRolesEnabled\"\r\n    mat-raised-button (click)=\"onCreateRole()\"\r\n    data-imx-identifier=\"imx-entitlements-create-role-button\">\r\n    {{ '#LDS#Create new system role' | translate }}\r\n  </button>\r\n  <button *ngIf=\"isSystemRolesEnabled\"\r\n    mat-raised-button (click)=\"onAddToRole()\" [disabled]=\"!selections || selections?.length === 0\"\r\n    data-imx-identifier=\"imx-entitlements-add-to-role-button\">\r\n    {{ '#LDS#Merge into system role' | translate }}\r\n  </button>\r\n  <button mat-raised-button (click)=\"onOk()\" [disabled]=\"selections?.length === 0\" color=\"primary\"\r\n    data-imx-identifier=\"imx-entitlements-add-assig-button\">\r\n    {{ '#LDS#Assign' | translate }}\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.imx-helper-alert{margin:10px 0 20px auto;width:100%}.imx-selected-entitlements{margin:0;line-height:36px;flex:auto}.imx-selected-entitlements ::ng-deep .imx-badge.eui-badge .eui-badge-content{font-size:14px;line-height:14px}.imx-badge{background-color:inherit}.eui-sidesheet-content{display:flex;flex-direction:column}.eui-sidesheet-content .imx-sidesheet-content{flex:1 1 auto;height:inherit;overflow:hidden;display:flex;flex-direction:column}.eui-sidesheet-actions>*{align-self:center}.eui-sidesheet-actions>*:not(:last-child){margin-right:10px}\n"] }]
    }], function () { return [{ type: i1$1.EuiSidesheetRef }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i2.ClassloggerService }, { type: EntitlementsService }, { type: i1$1.EuiLoadingService }, { type: i2.StorageService }, { type: i2.MetadataService }, { type: i1$1.EuiSidesheetService }, { type: i3$1.TranslateService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ShopsService {
    constructor(aobClient, logger, apiProvider) {
        this.aobClient = aobClient;
        this.logger = logger;
        this.apiProvider = apiProvider;
    }
    get display() {
        return this.aobClient.typedClient.PortalShops.GetSchema().Display;
    }
    async get(parameters = { ParentKey: '' }) {
        this.logger.debug(this, 'get');
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalShops.Get(parameters));
    }
    async getApplicationInShop(application, parameters = {}) {
        this.logger.debug(this, 'getApplicationInShop');
        if (application) {
            return this.apiProvider.request(() => this.aobClient.typedClient.PortalApplicationinshop.Get(application, parameters));
        }
    }
    async getFirstAndCount(uidApplication) {
        const shops = await this.getApplicationInShop(uidApplication, { PageSize: 1 });
        return {
            first: shops.Data.length === 0 ? undefined : shops.Data[0],
            count: shops.totalCount
        };
    }
    async updateApplicationInShops(application, changeSet) {
        this.logger.debug(this, 'updateApplicationInShops');
        const applicationInShop = await this.getApplicationInShop(application.UID_AOBApplication.value);
        return applicationInShop &&
            await this.addShops(application, changeSet.add.filter(shop => !ShopsService.isAssigned(shop, applicationInShop.Data))) &&
            this.removeShops(application, changeSet.remove.filter(shop => ShopsService.isAssigned(shop, applicationInShop.Data)));
    }
    async addShops(application, shops) {
        let count = 0;
        await this.apiProvider.request(async () => {
            for (const shop of shops) {
                await this.aobClient.client.
                    portal_applicationinshop_put(application.UID_AOBApplication.value, shop.UID_ITShopOrg.value, []);
                count++;
            }
        });
        return count === shops.length;
    }
    async removeShops(application, shops) {
        let count = 0;
        await this.apiProvider.request(async () => {
            for (const shop of shops) {
                await this.aobClient.client
                    .portal_applicationinshop_delete(application.UID_AOBApplication.value, shop.UID_ITShopOrg.value, '');
                count++;
            }
        });
        return count === shops.length;
    }
    static isAssigned(shop, shopsAssigned) {
        return shopsAssigned && shopsAssigned.find(shopAssigned => shopAssigned.UID_ITShopOrg.value === shop.UID_ITShopOrg.value) != null;
    }
}
ShopsService.ɵfac = function ShopsService_Factory(t) { return new (t || ShopsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ApiClientService)); };
ShopsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ShopsService, factory: ShopsService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ShopsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: AobApiService }, { type: i2.ClassloggerService }, { type: i2.ApiClientService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ServiceItemsService {
    constructor(aobClient, apiProvider) {
        this.aobClient = aobClient;
        this.apiProvider = apiProvider;
    }
    async get(entitlement, parameters = {}) {
        return this.apiProvider.request(() => this.aobClient.typedClient.PortalEntitlementServiceitem.Get({
            ...{ uid_aobentitlement: entitlement.UID_AOBEntitlement.value },
            ...parameters
        }));
    }
}
ServiceItemsService.ɵfac = function ServiceItemsService_Factory(t) { return new (t || ServiceItemsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ApiClientService)); };
ServiceItemsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ServiceItemsService, factory: ServiceItemsService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ServiceItemsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: AobApiService }, { type: i2.ApiClientService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EntitlementEditComponent_imx_cdr_editor_3_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 7);
    i0.ɵɵlistener("controlCreated", function EntitlementEditComponent_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r5); const cdr_r3 = restoredCtx.$implicit; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.form.addControl(cdr_r3.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r3);
} }
function EntitlementEditComponent_ng_container_4_imx_service_item_tags_1_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-service-item-tags", 9);
    i0.ɵɵlistener("controlCreated", function EntitlementEditComponent_ng_container_4_imx_service_item_tags_1_Template_imx_service_item_tags_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r9); const ctx_r8 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r8.form.addControl("tags", $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r6 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("selection", ctx_r6.productTagsSelected)("loading", ctx_r6.loadingTags);
} }
function EntitlementEditComponent_ng_container_4_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    const _r12 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 7);
    i0.ɵɵlistener("controlCreated", function EntitlementEditComponent_ng_container_4_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r12); const cdr_r10 = restoredCtx.$implicit; const ctx_r11 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r11.form.addControl(cdr_r10.column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r10 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r10);
} }
function EntitlementEditComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, EntitlementEditComponent_ng_container_4_imx_service_item_tags_1_Template, 1, 2, "imx-service-item-tags", 8);
    i0.ɵɵtemplate(2, EntitlementEditComponent_ng_container_4_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 2);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r1.productTagsSelected);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngForOf", ctx_r1.cdrListServiceItem);
} }
function EntitlementEditComponent_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r14 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 10);
    i0.ɵɵlistener("click", function EntitlementEditComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r14); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.manageEntitlement()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Edit"));
} }
/**
 * A component that provides a form for viewing and editing entitlements/roles.
 */
class EntitlementEditComponent {
    constructor(tagProvider, logger, router, errorHandler, cdrFactoryService, busyService) {
        this.tagProvider = tagProvider;
        this.logger = logger;
        this.router = router;
        this.errorHandler = errorHandler;
        this.cdrFactoryService = cdrFactoryService;
        this.busyService = busyService;
        this.form = new UntypedFormGroup({});
        this.productTagsInitial = [];
        this.cdrList = [];
        this.cdrListServiceItem = [];
        this.controlCreated = new EventEmitter();
        this.saved = new EventEmitter();
    }
    ngOnInit() {
        this.controlCreated.emit(this.form);
        const entitlementColumns = [
            'Ident_AOBEntitlement',
            'Description',
            'ObjectKeyAdditionalApprover'
        ];
        this.cdrList = this.cdrFactoryService.buildCdrFromColumnList(this.entitlement.GetEntity(), entitlementColumns);
        if (this.serviceItem) {
            const serviceIemColumns = [
                'UID_OrgRuler',
                'UID_PWODecisionMethod',
                'UID_QERTermsOfUse',
                'UID_AccProductParamCategory',
                'UID_AccProductGroup',
                'ProductURL',
                'IsApproveRequiresMfa'
            ];
            this.cdrListServiceItem = this.cdrFactoryService.buildCdrFromColumnList(this.serviceItem.GetEntity(), serviceIemColumns);
        }
    }
    async ngOnChanges(changes) {
        if (changes.entitlement || changes.serviceItem) {
            if (changes.entitlement && this.entitlement) {
                if (this.entitlement.UID_AccProduct.value !== '') {
                    await this.initTags(this.entitlement);
                }
            }
            this.form.markAsPristine();
        }
    }
    /**
     * Saves all changes of specified  {@link PortalEntitlement|entitlement}.
     * @param entitlement The {@link PortalEntitlement|entitlement} to be saved.
     */
    async save() {
        this.logger.trace(this, 'Save clicked for entitlement', this.entitlement);
        const success = await this.tryCommit([this.entitlement, this.serviceItem]);
        this.saved.emit(success);
    }
    async initTags(entitlement) {
        this.loadingTags = true;
        this.productTagsInitial = (await this.tagProvider.getTags(entitlement.UID_AccProduct.value))
            .Data.map(elem => elem.Ident_DialogTag.value);
        this.productTagsSelected = this.productTagsInitial.slice();
        this.loadingTags = false;
    }
    async tryCommit(typedEntities) {
        let success = false;
        let overlayRef;
        setTimeout(() => overlayRef = this.busyService.show());
        try {
            for (const typedEntity of typedEntities) {
                if (typedEntity) {
                    await typedEntity.GetEntity().Commit(true);
                }
            }
            if (this.entitlement.UID_AccProduct.value !== '') {
                await this.saveTags();
                this.productTagsInitial = this.productTagsSelected.slice();
            }
            this.form.markAsPristine();
            success = true;
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            setTimeout(() => this.busyService.hide(overlayRef));
        }
        return success;
    }
    async saveTags() {
        const changeSet = this.getTagsChangeSet();
        return this.tagProvider.updateTags(this.entitlement.UID_AccProduct.value, changeSet.add, changeSet.remove);
    }
    getTagsChangeSet() {
        this.logger.trace(this, 'save tags initial', this.productTagsInitial);
        this.logger.trace(this, 'save tags selected', this.productTagsSelected);
        return {
            add: this.productTagsSelected.filter(elem => this.productTagsInitial.indexOf(elem) < 0),
            remove: this.productTagsInitial.filter(elem => this.productTagsSelected.indexOf(elem) < 0)
        };
    }
    get isEditableEntitlement() {
        // TODO: only if IsOwnerOrAdmin is set
        return DbObjectKey.FromXml(this.entitlement.ObjectKeyElement.value).TableName == "ESet";
    }
    manageEntitlement() {
        this.saved.emit(false);
        this.router.navigate(['/myresponsibilities/ESet']);
    }
}
EntitlementEditComponent.ɵfac = function EntitlementEditComponent_Factory(t) { return new (t || EntitlementEditComponent)(i0.ɵɵdirectiveInject(i1.ServiceItemTagsService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i3.Router), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i2.CdrFactoryService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService)); };
EntitlementEditComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementEditComponent, selectors: [["imx-entitlement-edit"]], inputs: { entitlement: "entitlement", serviceItem: "serviceItem" }, outputs: { controlCreated: "controlCreated", saved: "saved" }, features: [i0.ɵɵNgOnChangesFeature], decls: 10, vars: 8, consts: [["eui-sidesheet-content", ""], ["id", "entitlementForm", 1, "imx-form", 3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-raised-button", "", "data-imx-identifier", "entitlement-edit-details-button", "type", "button", "color", "primary", 3, "click", 4, "ngIf"], ["mat-raised-button", "", "data-imx-identifier", "entitlement-edit-button-save", "type", "button", "color", "primary", 3, "disabled", "click"], [3, "cdr", "controlCreated"], [3, "selection", "loading", "controlCreated", 4, "ngIf"], [3, "selection", "loading", "controlCreated"], ["mat-raised-button", "", "data-imx-identifier", "entitlement-edit-details-button", "type", "button", "color", "primary", 3, "click"]], template: function EntitlementEditComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "form", 1);
        i0.ɵɵtemplate(3, EntitlementEditComponent_imx_cdr_editor_3_Template, 1, 1, "imx-cdr-editor", 2);
        i0.ɵɵtemplate(4, EntitlementEditComponent_ng_container_4_Template, 3, 2, "ng-container", 3);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(5, "div", 4);
        i0.ɵɵtemplate(6, EntitlementEditComponent_button_6_Template, 3, 3, "button", 5);
        i0.ɵɵelementStart(7, "button", 6);
        i0.ɵɵlistener("click", function EntitlementEditComponent_Template_button_click_7_listener() { return ctx.save(); });
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("formGroup", ctx.form);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx.cdrList);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.serviceItem);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.isEditableEntitlement);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("disabled", !ctx.form.dirty);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(9, 6, "#LDS#Save"));
    } }, dependencies: [i2.CdrEditorComponent, i5.NgForOf, i5.NgIf, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i8.ɵNgNoValidate, i8.NgControlStatusGroup, i7.MatButton, i6.MatCard, i8.FormGroupDirective, i1.ServiceItemTagsComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100%}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementEditComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlement-edit', template: "<div eui-sidesheet-content>\r\n  <mat-card>\r\n    <form class=\"imx-form\" id=\"entitlementForm\" [formGroup]=\"form\">\r\n      <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"form.addControl(cdr.column.ColumnName, $event)\">\r\n      </imx-cdr-editor>\r\n      <ng-container *ngIf=\"serviceItem\">\r\n        <imx-service-item-tags *ngIf=\"productTagsSelected\"\r\n          [selection]=\"productTagsSelected\"\r\n          [loading]=\"loadingTags\"\r\n          (controlCreated)=\"form.addControl('tags', $event)\">\r\n        </imx-service-item-tags>\r\n        <imx-cdr-editor *ngFor=\"let cdr of cdrListServiceItem\" [cdr]=\"cdr\" (controlCreated)=\"form.addControl(cdr.column.ColumnName, $event)\">\r\n        </imx-cdr-editor>\r\n      </ng-container>\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n<div eui-sidesheet-actions>\r\n  <button mat-raised-button data-imx-identifier=\"entitlement-edit-details-button\" *ngIf=\"isEditableEntitlement\"\r\n    type=\"button\" (click)=\"manageEntitlement()\" color=\"primary\">{{ '#LDS#Edit' | translate }}</button>\r\n  <button mat-raised-button data-imx-identifier=\"entitlement-edit-button-save\"\r\n    [disabled]=\"!form.dirty\" type=\"button\" (click)=\"save()\" color=\"primary\">{{ '#LDS#Save' | translate }}</button>\r\n</div>\r\n", styles: [":host{display:flex;flex-direction:column;height:100%}:host .eui-sidesheet-content{display:flex;flex-direction:column;overflow:auto}\n"] }]
    }], function () { return [{ type: i1.ServiceItemTagsService }, { type: i2.ClassloggerService }, { type: i3.Router }, { type: i0.ErrorHandler }, { type: i2.CdrFactoryService }, { type: i1$1.EuiLoadingService }]; }, { entitlement: [{
            type: Input
        }], serviceItem: [{
            type: Input
        }], controlCreated: [{
            type: Output
        }], saved: [{
            type: Output
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementDetailComponent {
    constructor(data, sidesheetRef, snackbar, confirmation) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.snackbar = snackbar;
        this.form = new UntypedFormGroup({});
        this.subscriptions = [];
        this.subscriptions.push(this.sidesheetRef.closeClicked().subscribe(async () => {
            const entitlementHasChanges = this.entityHasChanges(this.data.entitlement);
            const serviceItemHasChanges = this.entityHasChanges(this.data.serviceItem);
            const hasChanges = entitlementHasChanges || serviceItemHasChanges || !this.form.pristine;
            if (hasChanges && !(await confirmation.confirmLeaveWithUnsavedChanges())) {
                return;
            }
            if (entitlementHasChanges) {
                await this.data.entitlement.GetEntity().DiscardChanges();
            }
            if (serviceItemHasChanges) {
                await this.data.serviceItem.GetEntity().DiscardChanges();
            }
            if (hasChanges) {
                this.snackbar.open({ key: '#LDS#The changes were discarded.' });
            }
            this.sidesheetRef.close(false);
        }));
    }
    ngOnDestroy() {
        this.subscriptions.forEach(s => s.unsubscribe());
    }
    afterSave(success) {
        if (success) {
            this.snackbar.open({ key: '#LDS#The application entitlement has been successfully saved.' });
        }
        this.sidesheetRef.close(true);
    }
    entityHasChanges(entity) {
        return entity != null && entity.GetEntity().GetDiffData()?.Data?.length > 0;
    }
}
EntitlementDetailComponent.ɵfac = function EntitlementDetailComponent_Factory(t) { return new (t || EntitlementDetailComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
EntitlementDetailComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementDetailComponent, selectors: [["imx-entitlement-detail"]], decls: 1, vars: 2, consts: [[3, "entitlement", "serviceItem", "controlCreated", "saved"]], template: function EntitlementDetailComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-entitlement-edit", 0);
        i0.ɵɵlistener("controlCreated", function EntitlementDetailComponent_Template_imx_entitlement_edit_controlCreated_0_listener($event) { return ctx.form.addControl("entitlementedit", $event); })("saved", function EntitlementDetailComponent_Template_imx_entitlement_edit_saved_0_listener($event) { return ctx.afterSave($event); });
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        i0.ɵɵproperty("entitlement", ctx.data == null ? null : ctx.data.entitlement)("serviceItem", ctx.data == null ? null : ctx.data.serviceItem);
    } }, dependencies: [EntitlementEditComponent] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementDetailComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlement-detail', template: "<imx-entitlement-edit\r\n  [entitlement]=\"data?.entitlement\"\r\n  [serviceItem]=\"data?.serviceItem\"\r\n  (controlCreated)=\"form.addControl('entitlementedit', $event)\"\r\n  (saved)=\"afterSave($event)\">\r\n</imx-entitlement-edit>\r\n" }]
    }], function () { return [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1$1.EuiSidesheetRef }, { type: i2.SnackBarService }, { type: i2.ConfirmationService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementEditAutoAddService {
    constructor(api) {
        this.api = api;
    }
    async getFilterProperties(table) {
        return (await this.api.client.portal_application_sqlwizard_tables_columns_get(table)).Properties;
    }
    async getCandidates(parentTable, options) {
        return this.api.client.portal_application_sqlwizard_candidates_get(parentTable, options);
    }
    async showEntitlementsToMap(state) {
        return this.api.client.portal_application_interactive_entitlementstoadd_get(state.EntityId, { keys: state.Keys, state: state.State });
    }
    async mapEntitlementsToApplication(uidApplication) {
        return this.api.client.portal_application_map_post(uidApplication);
    }
}
EntitlementEditAutoAddService.ɵfac = function EntitlementEditAutoAddService_Factory(t) { return new (t || EntitlementEditAutoAddService)(i0.ɵɵinject(AobApiService)); };
EntitlementEditAutoAddService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EntitlementEditAutoAddService, factory: EntitlementEditAutoAddService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementEditAutoAddService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], function () { return [{ type: AobApiService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementToAddTyped extends TypedEntity {
    constructor() {
        super(...arguments);
        this.IsAssignedToMe = this.GetEntityValue('IsAssignedToMe');
        this.IsAssignedToOther = this.GetEntityValue('IsAssignedToOther');
        this.DisplayName = this.GetEntityValue('DisplayName');
        this.CanonicalName = this.GetEntityValue('CanonicalName');
        this.UID_AOBApplicationConflicted = this.GetEntityValue('UID_AOBApplicationConflicted');
    }
    static GetEntitySchema() {
        const ret = {};
        ret.IsAssignedToMe = {
            Type: ValType.Bool,
            ColumnName: 'IsAssignedToMe'
        };
        ret.IsAssignedToOther = {
            Type: ValType.Bool,
            ColumnName: 'IsAssignedToOther'
        };
        ret.DisplayName = {
            Type: ValType.String,
            ColumnName: 'DisplayName'
        };
        ret.CanonicalName = {
            Type: ValType.String,
            ColumnName: 'CanonicalName'
        };
        ret.UID_AOBApplicationConflicted = {
            Type: ValType.String,
            ColumnName: 'UID_AOBApplicationConflicted'
        };
        return {
            TypeName: 'EntitlementToAddTyped',
            DisplayPattern: new DisplayPattern('%DisplayName%'),
            Columns: ret
        };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementToAddDataWrapperService {
    constructor() {
        this.entitySchema = EntitlementToAddTyped.GetEntitySchema();
        this.builder = new TypedEntityBuilder(EntitlementToAddTyped);
    }
    buildTypedEntities(data) {
        const entities = data.Data.map((element, index) => this.buildEntityData(element, `${index}`));
        return this.builder.buildReadWriteEntities({
            TotalCount: entities.length,
            Entities: entities.sort((a, b) => this.compareElement(a, b))
        }, this.entitySchema);
    }
    buildEntityData(data, key) {
        const ret = {};
        ret.IsAssignedToMe = { Value: data.IsAssignedToMe, IsReadOnly: true };
        ret.IsAssignedToOther = { Value: data.IsAssignedToOther, IsReadOnly: true };
        ret.DisplayName = { Value: data.DisplayName, IsReadOnly: true };
        ret.CanonicalName = { Value: data.CanonicalName, IsReadOnly: true };
        ret.UID_AOBApplicationConflicted =
            {
                Value: data.UID_AOBApplicationConflicted,
                IsReadOnly: true,
                DisplayValue: data.DisplayApplicationConflicted
            };
        return { Columns: ret, Keys: [key] };
    }
    compareElement(a, b) {
        const val1 = `${(a.Columns.IsAssignedToMe.Value ? 1 : a.Columns.IsAssignedToOther.Value ? 0 : 2)} ${a.Columns.DisplayName.Value}`;
        const val2 = `${(b.Columns.IsAssignedToMe.Value ? 1 : b.Columns.IsAssignedToOther.Value ? 0 : 2)} ${b.Columns.DisplayName.Value}`;
        return val1.localeCompare(val2);
    }
}
EntitlementToAddDataWrapperService.ɵfac = function EntitlementToAddDataWrapperService_Factory(t) { return new (t || EntitlementToAddDataWrapperService)(); };
EntitlementToAddDataWrapperService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EntitlementToAddDataWrapperService, factory: EntitlementToAddDataWrapperService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementToAddDataWrapperService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], null, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function MappedEntitlementsPreviewComponent_eui_alert_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 12)(1, "div")(2, "span", 13);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(4, "div")(5, "span", 13);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("colored", true)("dismissable", true);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r0.alertText);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r0.speedupText);
} }
function MappedEntitlementsPreviewComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 14)(1, "div")(2, "span", 15);
    i0.ɵɵtext(3, "#LDS#Matching application entitlements");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span");
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "span", 15);
    i0.ɵɵtext(7, "#LDS#Application entitlements to add");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "span");
    i0.ɵɵtext(9);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(10, "span", 15);
    i0.ɵɵtext(11, "#LDS#Application entitlements already assigned to this application");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "span");
    i0.ɵɵtext(13);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "span", 15);
    i0.ɵɵtext(15, "#LDS#Application entitlements assigned to another application");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "span");
    i0.ɵɵtext(17);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(ctx_r1.getCount(""));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r1.getCount("add"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r1.getCount("assigned"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(ctx_r1.getCount("conflicted"));
} }
function MappedEntitlementsPreviewComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "div", 16);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const entity_r6 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(entity_r6.DisplayName.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(entity_r6.CanonicalName.Column.GetDisplayValue());
} }
function MappedEntitlementsPreviewComponent_ng_template_13_eui_badge_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 18);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const entity_r7 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("color", entity_r7.IsAssignedToMe.value ? "green" : "orange");
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, entity_r7.IsAssignedToMe.value ? "#LDS#Already assigned to this application" : "#LDS#Assigned to other application"), " ");
} }
function MappedEntitlementsPreviewComponent_ng_template_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, MappedEntitlementsPreviewComponent_ng_template_13_eui_badge_0_Template, 3, 4, "eui-badge", 17);
} if (rf & 2) {
    const entity_r7 = ctx.$implicit;
    i0.ɵɵproperty("ngIf", entity_r7.IsAssignedToMe.value || entity_r7.IsAssignedToOther.value);
} }
function MappedEntitlementsPreviewComponent_div_17_Template(rf, ctx) { if (rf & 1) {
    const _r12 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 19)(1, "mat-slide-toggle", 20, 21);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "button", 22);
    i0.ɵɵlistener("click", function MappedEntitlementsPreviewComponent_div_17_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r12); const _r10 = i0.ɵɵreference(2); const ctx_r11 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r11.apply(_r10.checked)); });
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "#LDS#Assign application entitlements after saving"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 4, "#LDS#Save automatic assignment"), " ");
} }
const _c0$a = function () { return []; };
class MappedEntitlementsPreviewComponent {
    constructor(data, sidesheetRef) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.DisplayColumns = DisplayColumns;
        this.navigationState = { StartIndex: 0, PageSize: 20 };
        this.alertText = '#LDS#Here you can get an overview of application entitlements that will be added to this application by the conditions. Application entitlements that are already assigned to an application will be skipped.';
        this.speedupText = '#LDS#In addition, you can specify whether the application entitlements should be assigned immediately after the conditions are saved. However, you can also have the application entitlements added later.';
    }
    apply(map) {
        this.sidesheetRef.close({ save: true, map });
    }
    getCount(type) {
        switch (type) {
            case 'conflicted':
                return this.data.entitlementToAdd.Data.filter((elem) => elem.IsAssignedToOther.value).length;
            case 'add':
                return this.data.entitlementToAdd.Data.filter((elem) => !elem.IsAssignedToMe.value && !elem.IsAssignedToOther.value).length;
            case 'assigned':
                return this.data.entitlementToAdd.Data.filter((elem) => elem.IsAssignedToMe.value).length;
        }
        return this.data.entitlementToAdd.totalCount;
    }
    navigate(source) {
        this.entitySchema = EntitlementToAddTyped.GetEntitySchema();
        this.navigationState = { ...this.navigationState, ...source };
        const data = this.data.entitlementToAdd.Data.slice(this.navigationState.StartIndex, this.navigationState.StartIndex + this.navigationState.PageSize);
        const displayedColumns = [
            this.entitySchema.Columns.DisplayName,
            this.entitySchema.Columns.IsAssignedToMe,
            this.entitySchema.Columns.UID_AOBApplicationConflicted,
        ];
        this.settings = {
            displayedColumns: displayedColumns,
            dataSource: {
                Data: data,
                totalCount: this.data.entitlementToAdd.totalCount,
            },
            entitySchema: this.entitySchema,
            navigationState: this.navigationState,
        };
    }
    async ngOnInit() {
        this.navigate({});
    }
}
MappedEntitlementsPreviewComponent.ɵfac = function MappedEntitlementsPreviewComponent_Factory(t) { return new (t || MappedEntitlementsPreviewComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef)); };
MappedEntitlementsPreviewComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MappedEntitlementsPreviewComponent, selectors: [["ng-component"]], decls: 18, vars: 21, consts: [["eui-sidesheet-content", ""], ["class", "imx-info-text", "type", "info", "condensed", "true", 3, "colored", "dismissable", 4, "ngIf"], [1, "imx-content-card"], ["class", "imx-info-grid", 4, "ngIf"], [3, "settings", "options", "navigationStateChanged"], ["dst", ""], [1, "imx-table-container"], ["mode", "manual", "data-imx-identifier", "mapped-entitlements-preview-datatable", 3, "dst", "detailViewVisible", "noDataText"], [3, "entityColumn", "columnLabel"], ["columnLabel", "", 3, "entityColumn"], ["data-imx-identifier", "mapped-entitlements-preview-paginator", 3, "dst"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["type", "info", "condensed", "true", 1, "imx-info-text", 3, "colored", "dismissable"], ["translate", ""], [1, "imx-info-grid"], ["bold", "", "translate", ""], ["subtitle", ""], [3, "color", 4, "ngIf"], [3, "color"], ["eui-sidesheet-actions", ""], ["checked", "true", "data-imx-identifier", "mapped-entitlements-preview-slider-with-mapping", 1, "justify-start"], ["mappedslider", ""], ["mat-raised-button", "", "data-imx-identifier", "mapped-entitlements-preview-button-save", "color", "primary", 3, "click"]], template: function MappedEntitlementsPreviewComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0);
        i0.ɵɵtemplate(1, MappedEntitlementsPreviewComponent_eui_alert_1_Template, 7, 4, "eui-alert", 1);
        i0.ɵɵelementStart(2, "mat-card", 2);
        i0.ɵɵtemplate(3, MappedEntitlementsPreviewComponent_div_3_Template, 18, 4, "div", 3);
        i0.ɵɵelementStart(4, "imx-data-source-toolbar", 4, 5);
        i0.ɵɵlistener("navigationStateChanged", function MappedEntitlementsPreviewComponent_Template_imx_data_source_toolbar_navigationStateChanged_4_listener($event) { return ctx.navigate($event); });
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(6, "div", 6)(7, "imx-data-table", 7);
        i0.ɵɵpipe(8, "translate");
        i0.ɵɵelementStart(9, "imx-data-table-column", 8);
        i0.ɵɵpipe(10, "translate");
        i0.ɵɵtemplate(11, MappedEntitlementsPreviewComponent_ng_template_11_Template, 4, 2, "ng-template");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(12, "imx-data-table-column", 9);
        i0.ɵɵtemplate(13, MappedEntitlementsPreviewComponent_ng_template_13_Template, 1, 1, "ng-template");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(14, "imx-data-table-column", 8);
        i0.ɵɵpipe(15, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(16, "imx-data-source-paginator", 10);
        i0.ɵɵelementEnd()()();
        i0.ɵɵtemplate(17, MappedEntitlementsPreviewComponent_div_17_Template, 8, 6, "div", 11);
    } if (rf & 2) {
        const _r2 = i0.ɵɵreference(5);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.data.withSave);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.data.entitlementToAdd.totalCount > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("settings", ctx.settings)("options", i0.ɵɵpureFunction0(20, _c0$a));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("dst", _r2)("detailViewVisible", false)("noDataText", i0.ɵɵpipeBind1(8, 14, "#LDS#There are no matching application entitlements."));
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(10, 16, "#LDS#Application entitlement"));
        i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns.DisplayName);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns.IsAssignedToMe);
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(15, 18, "#LDS#Already assigned to following application"));
        i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns.UID_AOBApplicationConflicted);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.data.withSave);
    } }, dependencies: [i5.NgIf, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i1$1.EuiAlertComponent, i1$1.EuiBadgeComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i7.MatButton, i6.MatCard, i6$2.MatSlideToggle, i3$1.TranslateDirective, i3$1.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{height:inherit;overflow:hidden;display:flex;flex-direction:column}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-content-card[_ngcontent-%COMP%]{flex:1 1 auto;overflow:hidden}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-content-card[_ngcontent-%COMP%]   .imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:calc(100% - 80px);flex:1 1 auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto;display:flex;flex-direction:column;justify-content:center;height:auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}.imx-info-text[_ngcontent-%COMP%]{margin-bottom:15px}span[bold][_ngcontent-%COMP%]{font-weight:600}.imx-info-grid[_ngcontent-%COMP%]{display:flex;flex-direction:row}.imx-info-grid[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:first-child{display:grid;column-gap:15px;grid-template-columns:auto auto}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MappedEntitlementsPreviewComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\r\n  <eui-alert class=\"imx-info-text\" *ngIf=\"data.withSave\" type=\"info\" condensed=\"true\" [colored]=\"true\"\r\n    [dismissable]=\"true\">\r\n    <div>\r\n      <span translate>{{alertText}}</span>\r\n    </div>\r\n    <div>\r\n      <span translate>{{speedupText}}</span>\r\n    </div>\r\n  </eui-alert>\r\n  <mat-card class=\"imx-content-card\">\r\n    <div *ngIf=\"data.entitlementToAdd.totalCount > 0\" class=\"imx-info-grid\">\r\n      <div>\r\n        <span bold translate>#LDS#Matching application entitlements</span>\r\n        <span>{{getCount('')}}</span>\r\n        <span bold translate>#LDS#Application entitlements to add</span>\r\n        <span>{{getCount('add')}}</span>\r\n        <span bold translate>#LDS#Application entitlements already assigned to this application</span>\r\n        <span>{{getCount('assigned')}}</span>\r\n        <span bold translate>#LDS#Application entitlements assigned to another application</span>\r\n        <span>{{getCount('conflicted')}}</span>\r\n      </div>\r\n    </div>\r\n    <imx-data-source-toolbar #dst [settings]=\"settings\" (navigationStateChanged)=\"navigate($event)\" [options]=\"[]\"> \r\n    </imx-data-source-toolbar>\r\n\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-table [dst]=\"dst\" mode=\"manual\" [detailViewVisible]=\"false\" \r\n      [noDataText]=\"'#LDS#There are no matching application entitlements.' | translate\"\r\n        data-imx-identifier=\"mapped-entitlements-preview-datatable\">\r\n        <imx-data-table-column [entityColumn]=\"entitySchema?.Columns.DisplayName\"\r\n          columnLabel=\"{{'#LDS#Application entitlement' | translate }}\">\r\n          <ng-template let-entity>\r\n            <div>{{ entity.DisplayName.Column.GetDisplayValue() }}</div>\r\n            <div subtitle>{{ entity.CanonicalName.Column.GetDisplayValue()}}</div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchema?.Columns.IsAssignedToMe\" columnLabel=\"\">\r\n          <ng-template let-entity>\r\n            <eui-badge *ngIf=\"entity.IsAssignedToMe.value || entity.IsAssignedToOther.value\"\r\n              [color]=\"entity.IsAssignedToMe.value ? 'green' : 'orange'\">\r\n              {{(entity.IsAssignedToMe.value ? '#LDS#Already assigned to this application' :'#LDS#Assigned to other application') |\r\n              translate}}\r\n            </eui-badge>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n\r\n        <imx-data-table-column [entityColumn]=\"entitySchema?.Columns.UID_AOBApplicationConflicted\"\r\n          columnLabel=\"{{'#LDS#Already assigned to following application' | translate }}\">\r\n        </imx-data-table-column>\r\n      </imx-data-table>\r\n    <imx-data-source-paginator [dst]=\"dst\" data-imx-identifier=\"mapped-entitlements-preview-paginator\"> </imx-data-source-paginator>\r\n\r\n    </div>\r\n  </mat-card>\r\n</div>\r\n<div eui-sidesheet-actions  *ngIf=\"data.withSave\">\r\n  <mat-slide-toggle class=\"justify-start\" #mappedslider checked=\"true\"\r\n    data-imx-identifier=\"mapped-entitlements-preview-slider-with-mapping\">\r\n    {{'#LDS#Assign application entitlements after saving' |translate}}\r\n  </mat-slide-toggle>\r\n  <button mat-raised-button data-imx-identifier=\"mapped-entitlements-preview-button-save\" color=\"primary\"\r\n    (click)=\"apply(mappedslider.checked)\">\r\n    {{'#LDS#Save automatic assignment' |translate}}\r\n  </button>\r\n</div>\r\n", styles: [".eui-sidesheet-content{height:inherit;overflow:hidden;display:flex;flex-direction:column}.eui-sidesheet-content .imx-content-card{flex:1 1 auto;overflow:hidden}.eui-sidesheet-content .imx-content-card .imx-table-container{display:flex;flex-direction:column;overflow:hidden;height:calc(100% - 80px);flex:1 1 auto}.eui-sidesheet-actions .justify-start{margin-right:auto;display:flex;flex-direction:column;justify-content:center;height:auto}.eui-sidesheet-actions button:not(:last-of-type):not(.justify-start){margin-right:10px}.imx-info-text{margin-bottom:15px}span[bold]{font-weight:600}.imx-info-grid{display:flex;flex-direction:row}.imx-info-grid :first-child{display:grid;column-gap:15px;grid-template-columns:auto auto}\n"] }]
    }], function () { return [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1$1.EuiSidesheetRef }]; }, null); })();

function EntitlementEditAutoAddComponent_imx_sqlwizard_2_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-sqlwizard", 6);
    i0.ɵɵlistener("change", function EntitlementEditAutoAddComponent_imx_sqlwizard_2_Template_imx_sqlwizard_change_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.checkChanges()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("tableName", "UNSGroup")("apiService", ctx_r0.svc)("expression", ctx_r0.sqlExpression == null ? null : ctx_r0.sqlExpression.Expression)("allowEmptyExpression", true);
} }
class EntitlementEditAutoAddComponent {
    constructor(data, svc, sidesheetRef, entitlementToAddWrapperService, busyService, snackbar, sidesheet, translateService, confirm) {
        this.data = data;
        this.svc = svc;
        this.sidesheetRef = sidesheetRef;
        this.entitlementToAddWrapperService = entitlementToAddWrapperService;
        this.busyService = busyService;
        this.snackbar = snackbar;
        this.sidesheet = sidesheet;
        this.translateService = translateService;
        this.subscriptions = [];
        this.reload = false;
        this.exprHasntChanged = true;
        this.subscriptions.push(sidesheetRef.closeClicked().subscribe(async () => {
            if (this.exprHasntChanged || (await confirm.confirmLeaveWithUnsavedChanges()))
                sidesheetRef.close(this.reload);
        }));
        this.sqlExpression = _.cloneDeep(data.sqlExpression);
    }
    checkChanges() {
        this.exprHasntChanged = _.isEqual(this.data.sqlExpression, this.sqlExpression);
    }
    get controlsInvalid() {
        return this.exprHasntChanged || (!this.sqlExpression.IsUnsupported && this.isConditionInvalid());
    }
    ngOnDestroy() {
        this.subscriptions.forEach((elem) => elem.unsubscribe());
    }
    async showResults(withSave) {
        let overlay;
        setTimeout(() => {
            overlay = this.busyService.show();
        });
        let elements;
        try {
            await this.setExtendedData(this.sqlExpression.Expression);
            elements = await this.svc.showEntitlementsToMap(this.data.application.InteractiveEntityStateData);
        }
        finally {
            setTimeout(() => {
                this.busyService.hide(overlay);
            });
        }
        if (!elements) {
            return;
        }
        const entitlementToAdd = this.entitlementToAddWrapperService.buildTypedEntities(elements);
        const saveChanges = await this.sidesheet.open(MappedEntitlementsPreviewComponent, {
            title: await this.translateService.get('#LDS#Heading View Matching Application Entitlements').toPromise(),
            subTitle: this.data.application.GetEntity().GetDisplay(),
            padding: '0px',
            width: 'max(550px, 55%)',
            testId: 'mapped-entitlements-preview-sidesheet',
            data: {
                entitlementToAdd,
                withSave,
            },
        })
            .afterClosed()
            .toPromise();
        this.reload = true;
        if (withSave && saveChanges?.save) {
            setTimeout(() => {
                overlay = this.busyService.show();
            });
            try {
                await this.data.application.GetEntity().Commit(false);
                if (saveChanges.map) {
                    this.svc.mapEntitlementsToApplication(this.data.application.UID_AOBApplication.value);
                }
            }
            finally {
                setTimeout(() => {
                    this.busyService.hide(overlay);
                });
            }
            this.sidesheetRef.close(true);
            this.snackbar.open({
                key: saveChanges.map
                    ? '#LDS#The conditions for automatically added application entitlements have been changed. The application entitlements are added now. This may take some time.'
                    : '#LDS#The conditions for automatically added application entitlements have been changed.',
            });
        }
        else {
            // reset the extended data if you do not save the data
            setTimeout(() => {
                overlay = this.busyService.show();
            });
            try {
                await this.setExtendedData(this.data.sqlExpression.Expression);
            }
            finally {
                setTimeout(() => {
                    this.busyService.hide(overlay);
                });
            }
        }
    }
    isConditionInvalid() {
        // check if the sqlWizard has a valid expression
        return (this.exprHasntChanged ||
            this.sqlExpression?.Expression?.Expressions.length === 0 ||
            isExpressionInvalid(this.sqlExpression) ||
            !this.hasValuesSet(this.sqlExpression.Expression));
    }
    hasValuesSet(sqlExpression, checkCurrent = false) {
        const current = !checkCurrent || sqlExpression.Value != null;
        if (sqlExpression.Expressions?.length > 0) {
            return current && sqlExpression.Expressions.every((elem) => this.hasValuesSet(elem, true));
        }
        return current;
    }
    async setExtendedData(sqlExpression) {
        return this.data.application.setExtendedData({
            ...this.data.application.extendedData,
            ...{
                SqlExpression: { Filters: [sqlExpression] },
            },
        });
    }
}
EntitlementEditAutoAddComponent.ɵfac = function EntitlementEditAutoAddComponent_Factory(t) { return new (t || EntitlementEditAutoAddComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(EntitlementEditAutoAddService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(EntitlementToAddDataWrapperService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
EntitlementEditAutoAddComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementEditAutoAddComponent, selectors: [["ng-component"]], decls: 10, vars: 8, consts: [["eui-sidesheet-content", ""], [1, "imx-content-card"], [3, "tableName", "apiService", "expression", "allowEmptyExpression", "change", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "entitlement-edit-auto-add-button-test-condition", 1, "justify-start", 3, "click"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "entitlement-edit-auto-add-button-save-condition", 3, "disabled", "click"], [3, "tableName", "apiService", "expression", "allowEmptyExpression", "change"]], template: function EntitlementEditAutoAddComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "mat-card", 1);
        i0.ɵɵtemplate(2, EntitlementEditAutoAddComponent_imx_sqlwizard_2_Template, 1, 4, "imx-sqlwizard", 2);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(3, "div", 3)(4, "button", 4);
        i0.ɵɵlistener("click", function EntitlementEditAutoAddComponent_Template_button_click_4_listener() { return ctx.showResults(false); });
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "button", 5);
        i0.ɵɵlistener("click", function EntitlementEditAutoAddComponent_Template_button_click_7_listener() { return ctx.showResults(true); });
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", !(ctx.sqlExpression == null ? null : ctx.sqlExpression.IsUnsupported));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 4, "#LDS#Test automatic assignment"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", ctx.controlsInvalid);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 6, "#LDS#Save automatic assignment"), "");
    } }, dependencies: [i5.NgIf, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i7.MatButton, i6.MatCard, i2.SqlWizardComponent, i3$1.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{height:inherit;overflow:hidden;display:flex;flex-direction:column}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-content-card[_ngcontent-%COMP%]{flex:1 1 auto;overflow:auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto;display:flex;flex-direction:column;justify-content:center}.eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementEditAutoAddComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\r\n<mat-card class=\"imx-content-card\">\r\n  <imx-sqlwizard *ngIf=\"!sqlExpression?.IsUnsupported\" [tableName]=\"'UNSGroup'\"  (change)=\"checkChanges()\" [apiService]=\"svc\" [expression]=\"sqlExpression?.Expression\" [allowEmptyExpression]=\"true\">\r\n  </imx-sqlwizard>\r\n</mat-card>\r\n</div>\r\n<div eui-sidesheet-actions >\r\n  <button class=\"justify-start\" mat-stroked-button data-imx-identifier=\"entitlement-edit-auto-add-button-test-condition\" (click)=\"showResults(false)\">\r\n    {{'#LDS#Test automatic assignment' |translate}}\r\n  </button>\r\n  <button [disabled]=\"controlsInvalid\" mat-raised-button color=\"primary\" (click)=\"showResults(true)\" data-imx-identifier=\"entitlement-edit-auto-add-button-save-condition\">\r\n    {{'#LDS#Save automatic assignment' |translate}}</button>\r\n</div>\r\n", styles: [".eui-sidesheet-content{height:inherit;overflow:hidden;display:flex;flex-direction:column}.eui-sidesheet-content .imx-content-card{flex:1 1 auto;overflow:auto}.eui-sidesheet-actions .justify-start{margin-right:auto;display:flex;flex-direction:column;justify-content:center}.eui-sidesheet-actions button:not(:last-of-type):not(.justify-start){margin-right:10px}\n"] }]
    }], function () { return [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: EntitlementEditAutoAddService }, { type: i1$1.EuiSidesheetRef }, { type: EntitlementToAddDataWrapperService }, { type: i1$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i1$1.EuiSidesheetService }, { type: i3$1.TranslateService }, { type: i2.ConfirmationService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function UserComponent_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(ctx_r0.primaryValue);
} }
class UserComponent {
    constructor(translateService, logger) {
        this.translateService = translateService;
        this.logger = logger;
        this.size = 'default';
    }
    ngOnChanges() {
        if (!this.noUserText || this.noUserText.length < 1) {
            this.logger.debug(this, 'Show default noUserText because no other was specified.');
            this.noUserText = '#LDS#(not assigned)';
        }
        if (!this.hasValidUser()) {
            this.logger.debug(this, 'Show noUserText because of an empty value.');
            this.translateService.get(this.noUserText).subscribe((trans) => this.secondaryValue = trans);
            this.primaryValue = '';
        }
        else {
            this.primaryValue = this.uid.Column.GetDisplayValue();
            this.secondaryValue = this.role;
        }
    }
    hasValidUser() {
        this.hasUser = this.uid != null && this.uid.value != null && this.uid.value.length > 0;
        return this.hasUser;
    }
}
UserComponent.ɵfac = function UserComponent_Factory(t) { return new (t || UserComponent)(i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i2.ClassloggerService)); };
UserComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: UserComponent, selectors: [["imx-user"]], inputs: { uid: "uid", role: "role", noUserText: "noUserText", size: "size" }, features: [i0.ɵɵNgOnChangesFeature], decls: 7, vars: 7, consts: [[1, "imx-user-icon"], [1, "imx-user-properties"], [4, "ngIf"]], template: function UserComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div")(1, "mat-icon", 0);
        i0.ɵɵtext(2, "person");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "div", 1);
        i0.ɵɵtemplate(4, UserComponent_span_4_Template, 2, 1, "span", 2);
        i0.ɵɵelementStart(5, "span");
        i0.ɵɵtext(6);
        i0.ɵɵelementEnd()()();
    } if (rf & 2) {
        i0.ɵɵclassMapInterpolate1("imx-user ", ctx.size, "");
        i0.ɵɵclassProp("noUser", !ctx.hasUser);
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("ngIf", ctx.hasUser);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(ctx.secondaryValue);
    } }, dependencies: [i5.NgIf, i4.MatIcon], styles: [".imx-user[_ngcontent-%COMP%]{display:flex;align-items:center;justify-items:center;margin:5px;min-height:40px}.imx-user-icon[_ngcontent-%COMP%]{color:#fff;background-color:#c4cacc;border-radius:50%;text-align:center;vertical-align:middle;line-height:30px;width:30px;height:30px;margin-right:5px;flex-shrink:0}.imx-user-properties[_ngcontent-%COMP%]{margin-left:5px;display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-weight:600;font-size:12px;overflow:hidden;text-overflow:ellipsis}.imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:last-child{font-size:10px;color:#aab0b3}.imx-user.large[_ngcontent-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{font-size:30px;height:30px;width:30px}.imx-user.large[_ngcontent-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:16px}.imx-user.large[_ngcontent-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:last-child{font-size:12px}.imx-user.noUser[_ngcontent-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{color:#e36a00;background-color:#f7e4d0}.imx-user.noUser[_ngcontent-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:12px}.imx-user.large.noUser[_ngcontent-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:14px}.eui-dark-theme   [_nghost-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{color:#2f3233;background-color:#616566}.eui-dark-theme   [_nghost-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:last-child{color:#616566}.eui-contrast-theme   [_nghost-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{color:#000;background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:last-child{color:#2f3233}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UserComponent, [{
        type: Component,
        args: [{ selector: 'imx-user', template: "<div class=\"imx-user {{size}}\" [class.noUser]=\"!hasUser\">\r\n  <mat-icon class='imx-user-icon'>person</mat-icon>\r\n  <div class=\"imx-user-properties\">\r\n    <span *ngIf=\"hasUser\">{{ primaryValue }}</span>\r\n    <span>{{ secondaryValue }}</span>\r\n  </div>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.imx-user{display:flex;align-items:center;justify-items:center;margin:5px;min-height:40px}.imx-user-icon{color:#fff;background-color:#c4cacc;border-radius:50%;text-align:center;vertical-align:middle;line-height:30px;width:30px;height:30px;margin-right:5px;flex-shrink:0}.imx-user-properties{margin-left:5px;display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-user-properties>span{font-weight:600;font-size:12px;overflow:hidden;text-overflow:ellipsis}.imx-user-properties>span:last-child{font-size:10px;color:#aab0b3}.imx-user.large .imx-user-icon{font-size:30px;height:30px;width:30px}.imx-user.large .imx-user-properties>span{font-size:16px}.imx-user.large .imx-user-properties>span:last-child{font-size:12px}.imx-user.noUser .imx-user-icon{color:#e36a00;background-color:#f7e4d0}.imx-user.noUser .imx-user-properties>span{font-size:12px}.imx-user.large.noUser .imx-user-properties>span{font-size:14px}.eui-dark-theme :host .imx-user-icon{color:#2f3233;background-color:#616566}.eui-dark-theme :host .imx-user-properties>span:last-child{color:#616566}.eui-contrast-theme :host .imx-user-icon{color:#000;background-color:#2f3233}.eui-contrast-theme :host .imx-user-properties>span:last-child{color:#2f3233}\n"] }]
    }], function () { return [{ type: i3$1.TranslateService }, { type: i2.ClassloggerService }]; }, { uid: [{
            type: Input
        }], role: [{
            type: Input
        }], noUserText: [{
            type: Input
        }], size: [{
            type: Input
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$9 = ["table"];
const _c1$5 = ["tiles"];
function EntitlementsComponent_ng_container_1_ng_template_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "div", 17);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r16 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r16.Ident_AOBEntitlement.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r16.Description.Column.GetDisplayValue());
} }
function EntitlementsComponent_ng_container_1_ng_template_10_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 21)(1, "eui-badge");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, "#LDS#Automatic"));
} }
function EntitlementsComponent_ng_container_1_ng_template_10_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵelement(1, "imx-info-badge", 22);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵnextContext(3);
    const _r7 = i0.ɵɵreference(9);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("badgeText", i0.ɵɵpipeBind1(2, 3, "#LDS#Wrong service category"))("templateRef", _r7)("title", i0.ɵɵpipeBind1(3, 5, "#LDS#Heading Wrong Service Category"));
} }
function EntitlementsComponent_ng_container_1_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 18);
    i0.ɵɵtemplate(1, EntitlementsComponent_ng_container_1_ng_template_10_div_1_Template, 4, 3, "div", 19);
    i0.ɵɵtemplate(2, EntitlementsComponent_ng_container_1_ng_template_10_div_2_Template, 4, 7, "div", 20);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r17 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", data_r17.IsDynamic.value);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", data_r17.IsOutlierAssignment.value);
} }
function EntitlementsComponent_ng_container_1_ng_template_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r20 = ctx.$implicit;
    const ctx_r13 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", ctx_r13.getType(data_r20), " ");
} }
function EntitlementsComponent_ng_container_1_ng_template_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtext(0);
} if (rf & 2) {
    const data_r21 = ctx.$implicit;
    i0.ɵɵtextInterpolate1(" ", data_r21.XDateInserted.Column.GetDisplayValue(), " ");
} }
function EntitlementsComponent_ng_container_1_ng_template_20_div_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Not published"));
} }
function EntitlementsComponent_ng_container_1_ng_template_20_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div");
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r22 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Will be published"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(data_r22.ActivationDate.Column.GetDisplayValue());
} }
function EntitlementsComponent_ng_container_1_ng_template_20_div_2_div_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 17);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#(not yet requestable)"));
} }
function EntitlementsComponent_ng_container_1_ng_template_20_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, EntitlementsComponent_ng_container_1_ng_template_20_div_2_div_4_Template, 3, 3, "div", 23);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r25 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Published"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r25.application.IsInActive.value);
} }
function EntitlementsComponent_ng_container_1_ng_template_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, EntitlementsComponent_ng_container_1_ng_template_20_div_0_Template, 3, 3, "div", 20);
    i0.ɵɵtemplate(1, EntitlementsComponent_ng_container_1_ng_template_20_div_1_Template, 6, 4, "div", 20);
    i0.ɵɵtemplate(2, EntitlementsComponent_ng_container_1_ng_template_20_div_2_Template, 5, 4, "div", 20);
} if (rf & 2) {
    const data_r22 = ctx.$implicit;
    const ctx_r15 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("ngIf", ctx_r15.filter.notPublished(data_r22));
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r15.filter.willPublish(data_r22));
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r15.filter.published(data_r22));
} }
const _c2$2 = function () { return ["custom"]; };
function EntitlementsComponent_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    const _r29 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "imx-data-source-toolbar", 6, 7);
    i0.ɵɵlistener("navigationStateChanged", function EntitlementsComponent_ng_container_1_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { i0.ɵɵrestoreView(_r29); const ctx_r28 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r28.getData(false, $event)); })("groupingChanged", function EntitlementsComponent_ng_container_1_Template_imx_data_source_toolbar_groupingChanged_1_listener($event) { i0.ɵɵrestoreView(_r29); const ctx_r30 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r30.onGroupingChanged($event)); });
    i0.ɵɵelement(3, "imx-data-source-toolbar-custom", 8);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerStart(4);
    i0.ɵɵelementStart(5, "imx-data-table", 9, 10);
    i0.ɵɵlistener("highlightedEntityChanged", function EntitlementsComponent_ng_container_1_Template_imx_data_table_highlightedEntityChanged_5_listener($event) { i0.ɵɵrestoreView(_r29); const ctx_r31 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r31.editEntitlement($event)); })("selectionChanged", function EntitlementsComponent_ng_container_1_Template_imx_data_table_selectionChanged_5_listener($event) { i0.ɵɵrestoreView(_r29); const ctx_r32 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r32.onSelectionChanged($event)); });
    i0.ɵɵelementStart(7, "imx-data-table-column", 11);
    i0.ɵɵtemplate(8, EntitlementsComponent_ng_container_1_ng_template_8_Template, 4, 2, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "imx-data-table-generic-column", 12);
    i0.ɵɵtemplate(10, EntitlementsComponent_ng_container_1_ng_template_10_Template, 3, 2, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "imx-data-table-generic-column", 13);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵtemplate(13, EntitlementsComponent_ng_container_1_ng_template_13_Template, 2, 1, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(14, "imx-data-table-column", 11);
    i0.ɵɵelementStart(15, "imx-data-table-generic-column", 14);
    i0.ɵɵpipe(16, "translate");
    i0.ɵɵtemplate(17, EntitlementsComponent_ng_container_1_ng_template_17_Template, 1, 1, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(18, "imx-data-table-generic-column", 15);
    i0.ɵɵpipe(19, "translate");
    i0.ɵɵtemplate(20, EntitlementsComponent_ng_container_1_ng_template_20_Template, 3, 3, "ng-template");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelement(21, "imx-data-source-paginator", 16);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const _r9 = i0.ɵɵreference(2);
    const ctx_r0 = i0.ɵɵnextContext();
    const _r1 = i0.ɵɵreference(3);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("settings", ctx_r0.dstSettings)("alwaysVisible", true)("options", i0.ɵɵpureFunction0(21, _c2$2))("busyService", ctx_r0.busyService)("itemStatus", ctx_r0.status);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("customContentTemplate", _r1);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("dst", _r9)("selectable", true)("detailViewVisible", false);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("entityColumn", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns["Ident_AOBEntitlement"]);
    i0.ɵɵadvance(4);
    i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(12, 15, "#LDS#Type"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("entityColumn", ctx_r0.entitySchema == null ? null : ctx_r0.entitySchema.Columns["UID_AERoleOwner"]);
    i0.ɵɵadvance(1);
    i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(16, 17, "#LDS#Assigned"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(19, 19, "#LDS#Status"));
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("dst", _r9);
} }
function EntitlementsComponent_ng_template_2_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    const _r36 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "button", 24);
    i0.ɵɵlistener("click", function EntitlementsComponent_ng_template_2_ng_container_0_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r36); const ctx_r35 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r35.publish()); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 25);
    i0.ɵɵlistener("click", function EntitlementsComponent_ng_template_2_ng_container_0_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r36); const ctx_r37 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r37.unpublish()); });
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "button", 26)(8, "span");
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(11, "eui-icon", 27);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "mat-menu", 28, 29)(14, "button", 30);
    i0.ɵɵlistener("click", function EntitlementsComponent_ng_template_2_ng_container_0_Template_button_click_14_listener() { i0.ɵɵrestoreView(_r36); const ctx_r38 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r38.addNewElement()); });
    i0.ɵɵtext(15);
    i0.ɵɵpipe(16, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(17, "mat-divider");
    i0.ɵɵelementStart(18, "button", 31);
    i0.ɵɵlistener("click", function EntitlementsComponent_ng_template_2_ng_container_0_Template_button_click_18_listener() { i0.ɵɵrestoreView(_r36); const ctx_r39 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r39.editConditionForDynamicAssignments()); });
    i0.ɵɵtext(19);
    i0.ɵɵpipe(20, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(21, "button", 32);
    i0.ɵɵlistener("click", function EntitlementsComponent_ng_template_2_ng_container_0_Template_button_click_21_listener() { i0.ɵɵrestoreView(_r36); const ctx_r40 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r40.applyMappingForDynamicAssignments()); });
    i0.ɵɵtext(22);
    i0.ɵɵpipe(23, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(24, "button", 33);
    i0.ɵɵlistener("click", function EntitlementsComponent_ng_template_2_ng_container_0_Template_button_click_24_listener() { i0.ɵɵrestoreView(_r36); const ctx_r41 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r41.unassign()); });
    i0.ɵɵtext(25);
    i0.ɵɵpipe(26, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const _r34 = i0.ɵɵreference(13);
    const ctx_r33 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("disabled", ctx_r33.publishDisabled);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 13, "#LDS#Publish"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r33.unpublishDisabled);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 15, "#LDS#Unpublish"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("matMenuTriggerFor", _r34);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 17, "#LDS#Assign more"));
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(16, 19, "#LDS#Assign manually"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("disabled", !ctx_r33.application.extendedDataRead);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(20, 21, ctx_r33.hasConditionForDynamicAssignment ? "#LDS#Edit automatic assignment" : "#LDS#Assign automatically"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r33.hasConditionForDynamicAssignment);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(23, 23, "#LDS#Check for new automatic assignments"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r33.unassignedDisabled);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(26, 25, "#LDS#Unassign"));
} }
function EntitlementsComponent_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, EntitlementsComponent_ng_template_2_ng_container_0_Template, 27, 27, "ng-container", 20);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngIf", !ctx_r2.isLoading);
} }
function EntitlementsComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    const _r43 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 34);
    i0.ɵɵelement(1, "eui-icon", 35);
    i0.ɵɵelementStart(2, "div", 36)(3, "h2");
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "span");
    i0.ɵɵtext(7);
    i0.ɵɵpipe(8, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(9, "div", 37)(10, "button", 38);
    i0.ɵɵlistener("click", function EntitlementsComponent_ng_template_4_Template_button_click_10_listener() { i0.ɵɵrestoreView(_r43); const ctx_r42 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r42.addNewElement()); });
    i0.ɵɵtext(11);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "button", 39);
    i0.ɵɵlistener("click", function EntitlementsComponent_ng_template_4_Template_button_click_13_listener() { i0.ɵɵrestoreView(_r43); const ctx_r44 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r44.editConditionForDynamicAssignments()); });
    i0.ɵɵtext(14);
    i0.ɵɵpipe(15, "translate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 5, "#LDS#No application entitlements assigned"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 7, "#LDS#Assign application entitlements to this application."), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 9, "#LDS#Assign application entitlements"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r4.application.extendedDataRead);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(15, 11, "#LDS#Create automatic assignment"), " ");
} }
function EntitlementsComponent_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-user", 40);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    const entitlement_r45 = ctx.$implicit;
    i0.ɵɵpropertyInterpolate("role", i0.ɵɵpipeBind1(1, 2, "#LDS#Application entitlement owner"));
    i0.ɵɵproperty("uid", entitlement_r45.UID_AERoleOwner);
} }
function EntitlementsComponent_ng_template_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "p", 41);
} if (rf & 2) {
    i0.ɵɵproperty("translate", "#LDS#This application entitlement is not assigned to the root service category of this application nor to any of its child service categories.");
} }
/**
 * A component for viewing, editing and acting all {@link PortalEntitlement|entitlements} for a given {@link PortalApplication|application}.
 *
 * @see addEntitlements
 * @see addRoles
 * @see publish
 * @see unpublish
 * @see unassign
 */
class EntitlementsComponent {
    constructor(logger, matDialog, entitlementsProvider, euiBusyService, dialog, snackbar, shopsProvider, serviceItemsProvider, platform, translateService, sidesheet, settingsService, systemInfo, metadata, autoAddService) {
        this.logger = logger;
        this.matDialog = matDialog;
        this.entitlementsProvider = entitlementsProvider;
        this.euiBusyService = euiBusyService;
        this.dialog = dialog;
        this.snackbar = snackbar;
        this.shopsProvider = shopsProvider;
        this.serviceItemsProvider = serviceItemsProvider;
        this.platform = platform;
        this.translateService = translateService;
        this.sidesheet = sidesheet;
        this.settingsService = settingsService;
        this.systemInfo = systemInfo;
        this.metadata = metadata;
        this.autoAddService = autoAddService;
        this.reloadRequested = new EventEmitter();
        this.DisplayColumns = DisplayColumns; // Enables use of this static class in Angular Templates.
        this.EntitlementsType = EntitlementsType; // Enables use of this static class in Angular Templates.
        this.selections = [];
        this.publishDisabled = true;
        this.unpublishDisabled = true;
        this.unassignedDisabled = true;
        this.isUsedInDialog = false;
        this.filter = new EntitlementFilter();
        this.busyService = new BusyService();
        this.isLoading = false;
        /**
         * Defines a set of status information methods, that are used to determine the status of each element in the entitlements table
         */
        this.status = {
            getBadges: (entitlement) => this.entitlementsProvider.getEntitlementBadges(entitlement),
            enabled: (_) => {
                return true;
            },
        };
        this.updatedTableNames = [];
        this.entitySchema = entitlementsProvider.entitlementSchema;
        this.displayedColumns = [
            this.entitySchema.Columns.Ident_AOBEntitlement,
            {
                Type: ValType.String,
                ColumnName: 'badges',
                untranslatedDisplay: '#LDS#Badges',
            },
            {
                Type: ValType.String,
                ColumnName: 'type',
                untranslatedDisplay: '#LDS#Type',
            },
            this.entitySchema.Columns.UID_AERoleOwner,
            {
                Type: ValType.Date,
                ColumnName: 'assigned',
                untranslatedDisplay: '#LDS#Assigned',
            },
            {
                Type: ValType.String,
                ColumnName: 'status',
                untranslatedDisplay: '#LDS#Status',
            },
        ];
        this.busyService.busyStateChanged.subscribe((elem) => (this.isLoading = elem));
    }
    /**
     * Checks, if there's a dynamic assignment rule attached to this application
     */
    get hasConditionForDynamicAssignment() {
        return (this.application.extendedDataRead?.SqlExpression?.Expressions?.length &&
            this.application.extendedDataRead?.SqlExpression?.Expressions[0].Expression.Expressions.length > 0);
    }
    async ngOnChanges(changes) {
        if (changes.application?.currentValue?.UID_AOBApplication.value === changes.application?.previousValue?.UID_AOBApplication.value) {
            return;
        }
        const isBusy = this.busyService.beginBusy();
        try {
            this.isSystemRoleEnabled = (await this.systemInfo.get()).PreProps.includes('ESET');
            this.getData(true);
        }
        finally {
            isBusy.endBusy();
        }
    }
    /**
     * checks, if an Entitlement can be edited
     * @param aobEntitlement the entitlement to check
     * @returns true, if the entitlements Ident_AOBEntitlement or Description property can be edited
     */
    canEdit(aobEntitlement) {
        return (aobEntitlement != null &&
            (aobEntitlement.Ident_AOBEntitlement.GetMetadata().CanEdit() || aobEntitlement.Description.GetMetadata().CanEdit()));
    }
    openInfo(event) {
        event.stopPropagation();
    }
    /**
     * Opens a sidesheet to assign new entitlements to the application
     * Afterwards entitlements are added to the application as single entitlements or wrapped into a system role
     */
    async addNewElement() {
        const candidates = await this.sidesheet
            .open(EntitlementsAddComponent, {
            title: await this.translateService.get('#LDS#Heading Assign Application Entitlements').toPromise(),
            padding: '0px',
            width: 'max(600px, 60%)',
            testId: 'entitlements-sidesheet',
            data: {
                defaultType: this.isSystemRoleEnabled ? EntitlementsType.Eset : EntitlementsType.UnsGroup,
                isSystemRolesEnabled: this.isSystemRoleEnabled,
                uidApplication: this.application.GetEntity().GetKeys()[0],
            },
        })
            .afterClosed()
            .toPromise();
        if (!candidates) {
            this.logger.debug(this, 'candidate dialog canceled');
            return;
        }
        if (candidates.role) {
            await this.buildRoleAndAddItToApplication(candidates.role);
        }
        else {
            await this.addDirectEntitlements(candidates.selection);
        }
    }
    /**
     * Applys the dynamic assignment rule, that is defined for the application
     */
    async applyMappingForDynamicAssignments() {
        let overlayRef;
        setTimeout(() => (overlayRef = this.euiBusyService.show()));
        try {
            this.autoAddService.mapEntitlementsToApplication(this.application.UID_AOBApplication.value);
        }
        finally {
            setTimeout(() => this.euiBusyService.hide(overlayRef));
        }
        this.snackbar.open({ key: '#LDS#The application entitlements are added now. This may take some time.' });
    }
    /**
     * Opens a side sheet to create/edit the dynamic assignement rule that belongs to the application
     */
    async editConditionForDynamicAssignments() {
        const sidesheetTitle = this.hasConditionForDynamicAssignment
            ? '#LDS#Heading Edit Automatic Assignment'
            : '#LDS#Heading Create Automatic Assignment';
        const reload = await this.sidesheet
            .open(EntitlementEditAutoAddComponent, {
            title: await this.translateService.get(sidesheetTitle).toPromise(),
            subTitle: this.application.GetEntity().GetDisplay(),
            padding: '0px',
            disableClose: true,
            width: 'max(600px, 60%)',
            testId: 'entitlements-edit-auto-add-sidesheet',
            data: {
                sqlExpression: this.application.extendedDataRead.SqlExpression.Expressions[0],
                application: this.application,
            },
        })
            .afterClosed()
            .toPromise();
        if (!reload) {
            return;
        }
        let overlayRef;
        setTimeout(() => (overlayRef = this.euiBusyService.show()));
        try {
            this.reloadRequested.emit();
        }
        finally {
            setTimeout(() => this.euiBusyService.hide(overlayRef));
        }
    }
    /**
     * Call to publish the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to publish
     */
    async publish(aobEntitlement = null) {
        const shops = await this.shopsProvider.getApplicationInShop(this.application.UID_AOBApplication.value);
        if (shops == null) {
            this.logger.error(this, 'TypedEntityCollectionData<AobApplicationinshop> is undefined');
            return;
        }
        const selectedEntitlements = aobEntitlement != null ? [aobEntitlement] : this.selections;
        const dialogConfig = {
            data: {
                action: LifecycleAction.Publish,
                elements: selectedEntitlements,
                shops: shops.Data,
                type: 'AobEntitlement',
            },
            height: this.platform.TRIDENT ? '550px' : 'auto',
        };
        const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(async (publishData) => {
            if (publishData) {
                const overlay = this.euiBusyService.show();
                try {
                    this.logger.debug(this, `Publishing entitlement(s)/role(s) ${publishData.date && publishData.publishFuture ? `on ${publishData.date}` : 'now'}`);
                    const publishCount = await this.entitlementsProvider.publish(selectedEntitlements, publishData);
                    this.matDialog.closeAll();
                    if (publishCount > 0) {
                        this.logger.debug(this, 'Deselect published entitlement(s)/role(s)');
                        this.clearSelections();
                        let publishMessage = {
                            key: 'Application entitlements published',
                        };
                        if (publishData.publishFuture && publishData.date) {
                            const browserCulture = this.translateService.currentLang;
                            publishMessage = {
                                key: '#LDS#The application entitlement will be published on {0} at {1} (your local time) if the application is published.',
                                parameters: [publishData.date.toLocaleDateString(browserCulture), publishData.date.toLocaleTimeString(browserCulture)],
                            };
                        }
                        this.snackbar.open(publishMessage, '#LDS#Close');
                        await this.getData();
                    }
                    if (publishCount < selectedEntitlements.length) {
                        this.logger.error(this, 'Attempt to publish entitlement(s)/role(s) failed');
                    }
                }
                finally {
                    this.euiBusyService.hide(overlay);
                }
            }
            else {
                this.logger.debug(this, 'dialog Cancel');
            }
        });
    }
    /**
     * Call to unpublish the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to unpublish
     */
    async unpublish(aobEntitlement = null) {
        const selectedEntitlements = aobEntitlement != null ? [aobEntitlement] : this.selections;
        const dialogConfig = {
            data: { action: LifecycleAction.Unpublish, elements: selectedEntitlements, type: 'AobEntitlement' },
            width: '800px',
            height: '500px',
        };
        const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(async (result) => {
            if (result) {
                const overlay = this.euiBusyService.show();
                try {
                    this.logger.debug(this, 'Unpublish entitlement(s)/role(s)...');
                    const unpublishCount = await this.entitlementsProvider.unpublish(selectedEntitlements);
                    this.matDialog.closeAll();
                    if (unpublishCount > 0) {
                        this.logger.debug(this, 'Deselect unpublished entitlement(s)/role(s)');
                        this.clearSelections();
                        this.snackbar.open({ key: '#LDS#Application entitlements unpublished' }, '#LDS#Close');
                        await this.getData();
                    }
                    if (unpublishCount < selectedEntitlements.length) {
                        this.logger.error(this, 'Attempt to unpublish entitlement(s)/role(s) failed');
                    }
                }
                finally {
                    this.euiBusyService.hide(overlay);
                }
            }
            else {
                this.logger.debug(this, 'dialog Cancel');
            }
        });
    }
    /**
     * Call to unassign the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}
     * from the associated {@link PortalApplication|application}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to unassign
     */
    async unassign(aobEntitlement = null) {
        const selectedEntitlements = aobEntitlement != null ? [aobEntitlement] : this.selections;
        const dialogConfig = {
            data: { action: LifecycleAction.Unassign, elements: selectedEntitlements, type: 'AobEntitlement' },
            width: '800px',
            height: '500px',
        };
        const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(async (result) => {
            if (result) {
                this.logger.debug(this, 'Remove entitlement(s) from application');
                if (selectedEntitlements.length > 0) {
                    let overlayRef;
                    setTimeout(() => (overlayRef = this.euiBusyService.show()));
                    try {
                        const unassignResult = await this.entitlementsProvider.unassign(selectedEntitlements);
                        if (unassignResult) {
                            this.clearSelections();
                            await this.getData();
                            this.snackbar.open({ key: '#LDS#Application entitlements unassigned' }, '#LDS#Close');
                        }
                        else {
                            this.logger.error(this, 'Attempt to unassign entitlement(s)/role(s) failed');
                        }
                    }
                    finally {
                        setTimeout(() => this.euiBusyService.hide(overlayRef));
                    }
                }
                this.matDialog.closeAll();
            }
            else {
                this.logger.debug(this, 'dialog Cancel');
            }
        });
    }
    /**
     * Call to get data from server depending on the {@link CollectionLoadParameters}.
     * @param resetNavigationState Indicates wether the navigation state should be reset or not.
     * @param newState Optional argument for loading new date for the given {@link CollectionLoadParameters}.
     */
    async getData(resetNavigationState = false, newState) {
        if (resetNavigationState) {
            this.navigationState = { PageSize: this.settingsService.DefaultPageSize, StartIndex: 0 };
        }
        else if (newState) {
            this.navigationState = newState;
        }
        await this.navigate();
    }
    /**
     * Opens a side sheet to edit entitlement information
     * @param entitlement the entitlement to edit
     */
    async editEntitlement(entitlement) {
        const entitlementWrapper = await this.createEntitlementWrapper(entitlement);
        if (entitlementWrapper?.entitlement == null) {
            this.logger.error(this, 'AobEntitlement is undefined');
            return;
        }
        this.sidesheet.open(EntitlementDetailComponent, {
            title: await this.translateService.get('#LDS#Heading Edit Application Entitlement').toPromise(),
            subTitle: entitlementWrapper.entitlement.GetEntity().GetDisplay(),
            padding: '0',
            width: 'max(600px, 60%)',
            disableClose: true,
            data: entitlementWrapper,
            testId: 'application-entitlement-edit-sidesheet',
        });
    }
    /**
     * Triggered action from the {@link DataTableComponent} or {@link TilesComponent} after the selection have changed.
     */
    onSelectionChanged(selection) {
        this.selections = selection;
        this.unassignedDisabled = true;
        this.publishDisabled = true;
        this.unpublishDisabled = true;
        if (this.selections == null || this.selections.length === 0) {
            return;
        }
        this.unassignedDisabled = selection.some((elem) => elem.IsDynamic.value === true);
        let foundPublished = false;
        let foundUnpublished = false;
        let foundWillBePublished = false;
        let foundReadonly = false;
        this.selections.forEach((item) => {
            if (this.filter.notPublished(item)) {
                foundUnpublished = true;
            }
            if (this.filter.willPublish(item)) {
                foundWillBePublished = true;
            }
            if (this.filter.published(item)) {
                foundPublished = true;
            }
            if (!this.canEdit(item)) {
                foundReadonly = true;
            }
        });
        if ((foundUnpublished || foundWillBePublished) && !foundPublished) {
            this.publishDisabled = foundReadonly;
        }
        if ((foundPublished || foundWillBePublished) && !foundUnpublished) {
            this.unpublishDisabled = foundReadonly;
        }
    }
    /**
     * Triggered action from the {@link DataSourceToolbar|DataSourceToolbar} after the grouping have changed.
     */
    onGroupingChanged(col) {
        this.logger.trace(this, 'grouping changed', col);
    }
    getType(data) {
        if (data?.ObjectKeyElement?.value == null) {
            return '';
        }
        const tableName = DbObjectKey.FromXml(data.ObjectKeyElement.value)?.TableName;
        return tableName != null && this.metadata.tables[tableName] ? this.metadata.tables[tableName]?.DisplaySingular : '';
    }
    async addDirectEntitlements(candidates) {
        let overlayRef;
        setTimeout(() => (overlayRef = this.euiBusyService.show()));
        try {
            const assignedCount = await this.entitlementsProvider.assign(this.application, candidates);
            if (assignedCount > 0) {
                await this.getData();
            }
            if (assignedCount < candidates.length) {
                this.logger.error(this, 'Attempt to assign entitlement(s)/role(s) failed');
            }
        }
        finally {
            setTimeout(() => this.euiBusyService.hide(overlayRef));
        }
    }
    async buildRoleAndAddItToApplication(entitlementSystemRoleInput) {
        let overlayRef;
        setTimeout(() => (overlayRef = this.euiBusyService.show()));
        let success = true;
        try {
            await this.entitlementsProvider.addElementsToRole(entitlementSystemRoleInput);
        }
        catch {
            success = false;
        }
        finally {
            setTimeout(() => this.euiBusyService.hide(overlayRef));
        }
        if (success) {
            this.snackbar.open({ key: '#LDS#The application entitlements have been successfully merged into the system role and added to application.' }, '#LDS#Close');
            await this.getData();
        }
    }
    clearSelections() {
        this.selections = [];
        this.table?.clearSelection();
        this.tiles?.clearSelection();
    }
    async navigate() {
        const isBusy = this.busyService.beginBusy();
        try {
            const data = await this.entitlementsProvider.getEntitlementsForApplication(this.application, this.navigationState);
            await this.updateTableNames(data.Data);
            if (data) {
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: data,
                    entitySchema: this.entitySchema,
                    navigationState: this.navigationState,
                };
            }
            else {
                this.logger.error(this, 'TypedEntityCollectionData<PortalEntitlement> is undefined');
            }
        }
        finally {
            isBusy.endBusy();
        }
    }
    async updateTableNames(objs) {
        const newTableNamesForUpdate = objs
            .map((obj) => DbObjectKey.FromXml(obj.ObjectKeyElement.value).TableName)
            .filter((obj) => !this.updatedTableNames.includes(obj));
        if (newTableNamesForUpdate.length === 0) {
            this.logger.debug(this, 'there are no new table names in this data');
            return;
        }
        this.updatedTableNames.push(...newTableNamesForUpdate);
        this.logger.trace(this, 'following items are added to the list of table names', newTableNamesForUpdate);
        return this.metadata.updateNonExisting([...new Set(newTableNamesForUpdate)]);
    }
    async createEntitlementWrapper(entitlement) {
        let entitlementReloaded;
        let serviceItem;
        let overlayRef;
        setTimeout(() => (overlayRef = this.euiBusyService.show()));
        try {
            entitlementReloaded = await this.entitlementsProvider.reload(entitlement);
            if (entitlementReloaded) {
                serviceItem = (await this.serviceItemsProvider.get(entitlement))?.Data?.[0];
            }
        }
        finally {
            setTimeout(() => this.euiBusyService.hide(overlayRef));
        }
        return {
            entitlement: entitlementReloaded,
            serviceItem,
        };
    }
}
EntitlementsComponent.ɵfac = function EntitlementsComponent_Factory(t) { return new (t || EntitlementsComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(EntitlementsService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(ShopsService), i0.ɵɵdirectiveInject(ServiceItemsService), i0.ɵɵdirectiveInject(i5$1.Platform), i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i2.SystemInfoService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(EntitlementEditAutoAddService)); };
EntitlementsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EntitlementsComponent, selectors: [["imx-entitlements"]], viewQuery: function EntitlementsComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0$9, 5);
        i0.ɵɵviewQuery(_c1$5, 5);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.table = _t.first);
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.tiles = _t.first);
    } }, inputs: { application: "application" }, outputs: { reloadRequested: "reloadRequested" }, features: [i0.ɵɵNgOnChangesFeature], decls: 10, vars: 2, consts: [[1, "imx-entitlements-site"], [4, "ngIf", "ngIfElse"], ["customToolbarTemplate", ""], ["nonExisting", ""], ["cardContentTemplate", ""], ["infoContent", ""], [3, "settings", "alwaysVisible", "options", "busyService", "itemStatus", "navigationStateChanged", "groupingChanged"], ["dst", ""], [3, "customContentTemplate"], ["mode", "manual", 1, "mat-elevation-z2", "imx-aob-data-container", 3, "dst", "selectable", "detailViewVisible", "highlightedEntityChanged", "selectionChanged"], ["table", ""], [3, "entityColumn"], ["columnName", "badges", "columnLabel", ""], ["columnName", "type", 3, "columnLabel"], ["columnName", "assigned", 3, "columnLabel"], ["columnName", "status", 3, "columnLabel"], [1, "mat-elevation-z2", 3, "dst"], ["subtitle", ""], [1, "imx-badge-container"], ["color", "primary", 4, "ngIf"], [4, "ngIf"], ["color", "primary"], ["color", "warn", 3, "badgeText", "templateRef", "title"], ["subtitle", "", 4, "ngIf"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "imx-entitlements-publish", 3, "disabled", "click"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-unpublish", 3, "disabled", "click"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-assign-mode-button", 3, "matMenuTriggerFor"], ["icon", "collapsedown"], ["data-imx-identifier", "entitlements-assign-more-actions-menu"], ["actionsMenu", "matMenu"], ["mat-menu-item", "", "data-imx-identifier", "imx-entitlements-assign-manually", 3, "click"], ["mat-menu-item", "", "data-imx-identifier", "imx-entitlements-updateCondition", 3, "disabled", "click"], ["mat-menu-item", "", "data-imx-identifier", "imx-entitlements-apply-mapping", 3, "disabled", "click"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-unassign", 3, "disabled", "click"], [1, "imx-aob-entitlements-empty"], ["icon", "key", "size", "100px"], [1, "imx-aob-entitlements-empty-description"], [1, "imx-aob-entitlements-empty-actions"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "entitlements-add-unsGroup", 3, "click"], ["mat-stroked-button", "", "data-imx-identifier", "imx-entitlements-assign", 3, "disabled", "click"], [3, "uid", "role"], [3, "translate"]], template: function EntitlementsComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0);
        i0.ɵɵtemplate(1, EntitlementsComponent_ng_container_1_Template, 22, 22, "ng-container", 1);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(2, EntitlementsComponent_ng_template_2_Template, 1, 1, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵtemplate(4, EntitlementsComponent_ng_template_4_Template, 16, 13, "ng-template", null, 3, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵtemplate(6, EntitlementsComponent_ng_template_6_Template, 2, 4, "ng-template", null, 4, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵtemplate(8, EntitlementsComponent_ng_template_8_Template, 1, 1, "ng-template", null, 5, i0.ɵɵtemplateRefExtractor);
    } if (rf & 2) {
        const _r3 = i0.ɵɵreference(5);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.dstSettings && ctx.dstSettings.dataSource && ctx.dstSettings.dataSource.totalCount > 0 || ctx.isLoading)("ngIfElse", _r3);
    } }, dependencies: [i5.NgIf, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataSourceToolbarCustomComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i1$1.EuiBadgeComponent, i1$1.EuiIconComponent, i7.MatButton, i12$1.MatDivider, i13$1.MatMenu, i13$1.MatMenuItem, i13$1.MatMenuTrigger, i3$1.TranslateDirective, UserComponent, i2.InfoBadgeComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%;flex:1 1 auto}.imx-entitlements-site[_ngcontent-%COMP%]{padding:16px 40px;height:100%;display:flex;flex-direction:column;flex:1 1 auto}.imx-badge-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:table-cell}.imx-badge-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%] > .eui-badge[_ngcontent-%COMP%]{margin:0 5px}.imx-badge-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%] > .eui-badge[_ngcontent-%COMP%]     .eui-badge-content{white-space:nowrap}imx-data-source-toolbar-custom[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-right:5px}.imx-aob-entitlements-empty[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;margin-bottom:10px;flex:1 1 auto;justify-content:center}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-weight:600}.imx-aob-entitlements-empty[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{margin-top:30px}.imx-aob-entitlements-empty[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#aab0b3}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   .imx-aob-entitlements-empty-description[_ngcontent-%COMP%]{margin-bottom:10px}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   .imx-aob-entitlements-empty-actions[_ngcontent-%COMP%]{display:flex;flex-direction:column}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   .imx-aob-entitlements-empty-actions[_ngcontent-%COMP%] > .mat-raised-button[_ngcontent-%COMP%]{margin-bottom:15px}.imx-aob-entitlements-empty[_ngcontent-%COMP%]   .imx-aob-entitlements-empty-actions[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:last-child{justify-self:center}.imx-aob-entitlements-header[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;margin:10px 0 8px}.imx-aob-entitlements-header[_ngcontent-%COMP%] > h3[_ngcontent-%COMP%]{font-size:18px;margin-right:10px;font-weight:400;line-height:36px}.imx-aob-entitlements-header[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]{text-transform:uppercase}.imx-aob-entitlements-header[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{line-height:36px;font-size:14px}.imx-mat-card-title[_ngcontent-%COMP%]{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.imx-aob-data-container[_ngcontent-%COMP%]{flex-grow:1;align-content:flex-start}div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}.eui-dark-theme   [_nghost-%COMP%]   .imx-aob-entitlements-empty[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#616566}.eui-contrast-theme   [_nghost-%COMP%]   .imx-aob-entitlements-empty[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#919799}.eui-contrast-theme   [_nghost-%COMP%]   .imx-entitlements-site[_ngcontent-%COMP%]{background-color:#000}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementsComponent, [{
        type: Component,
        args: [{ selector: 'imx-entitlements', template: "<div class=\"imx-entitlements-site\">\r\n  <ng-container *ngIf=\"(dstSettings && dstSettings.dataSource && dstSettings.dataSource.totalCount > 0) || isLoading; else nonExisting\">\r\n    <!-- Datasource Toolbar -->\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      [settings]=\"dstSettings\"\r\n      (navigationStateChanged)=\"getData(false, $event)\"\r\n      (groupingChanged)=\"onGroupingChanged($event)\"\r\n      [alwaysVisible]=\"true\"\r\n      [options]=\"['custom']\"\r\n      [busyService]=\"busyService\"\r\n      [itemStatus]=\"status\"\r\n    >\r\n      <imx-data-source-toolbar-custom [customContentTemplate]=\"customToolbarTemplate\"></imx-data-source-toolbar-custom>\r\n    </imx-data-source-toolbar>\r\n\r\n    <!-- Data Table -->\r\n    <ng-container>\r\n      <imx-data-table\r\n        #table\r\n        [dst]=\"dst\"\r\n        [selectable]=\"true\"\r\n        (highlightedEntityChanged)=\"editEntitlement($event)\"\r\n        (selectionChanged)=\"onSelectionChanged($event)\"\r\n        mode=\"manual\"\r\n        class=\"mat-elevation-z2 imx-aob-data-container\"\r\n        [detailViewVisible]=\"false\"\r\n      >\r\n        <imx-data-table-column [entityColumn]=\"entitySchema?.Columns['Ident_AOBEntitlement']\">\r\n          <ng-template let-data>\r\n            <div>{{ data.Ident_AOBEntitlement.Column.GetDisplayValue() }}</div>\r\n            <div subtitle>{{ data.Description.Column.GetDisplayValue() }}</div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n        <imx-data-table-generic-column columnName=\"badges\" columnLabel=\"\">\r\n          <ng-template let-data>\r\n            <div class=\"imx-badge-container\">\r\n              <div color=\"primary\" *ngIf=\"data.IsDynamic.value\">\r\n                <eui-badge>{{  '#LDS#Automatic' | translate  }}</eui-badge>\r\n              </div>\r\n              <div *ngIf=\"data.IsOutlierAssignment.value\">\r\n                <imx-info-badge color=\"warn\" [badgeText]=\"'#LDS#Wrong service category' | translate\" [templateRef]=\"infoContent\" [title]=\"'#LDS#Heading Wrong Service Category' | translate\"></imx-info-badge>\r\n              </div>\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n        <imx-data-table-generic-column columnName=\"type\" columnLabel=\"{{ '#LDS#Type' | translate }}\">\r\n          <ng-template let-data>\r\n            <div>\r\n              {{ getType(data) }}\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchema?.Columns['UID_AERoleOwner']\"> </imx-data-table-column>\r\n        <imx-data-table-generic-column columnName=\"assigned\" columnLabel=\"{{ '#LDS#Assigned' | translate }}\">\r\n          <ng-template let-data>\r\n            {{ data.XDateInserted.Column.GetDisplayValue() }}\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n        <imx-data-table-generic-column columnName=\"status\" columnLabel=\"{{ '#LDS#Status' | translate }}\">\r\n          <ng-template let-data>\r\n            <div *ngIf=\"filter.notPublished(data)\">{{ '#LDS#Not published' | translate }}</div>\r\n            <div *ngIf=\"filter.willPublish(data)\">\r\n              <div>{{ '#LDS#Will be published' | translate }}</div>\r\n              <div>{{ data.ActivationDate.Column.GetDisplayValue() }}</div>\r\n            </div>\r\n            <div *ngIf=\"filter.published(data)\">\r\n              <div>{{ '#LDS#Published' | translate }}</div>\r\n              <div subtitle *ngIf=\"application.IsInActive.value\">{{ '#LDS#(not yet requestable)' | translate }}</div>\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n      </imx-data-table>\r\n    </ng-container>\r\n    <imx-data-source-paginator class=\"mat-elevation-z2\" [dst]=\"dst\"></imx-data-source-paginator>\r\n  </ng-container>\r\n</div>\r\n\r\n<!-- Custom toolbar template with publish, unpublish and unassign buttons -->\r\n<ng-template #customToolbarTemplate>\r\n  <ng-container *ngIf=\"!isLoading\">\r\n    <button mat-raised-button color=\"primary\" [disabled]=\"publishDisabled\" (click)=\"publish()\" data-imx-identifier=\"imx-entitlements-publish\">\r\n      {{ '#LDS#Publish' | translate }}\r\n    </button>\r\n    <button mat-stroked-button [disabled]=\"unpublishDisabled\" (click)=\"unpublish()\" data-imx-identifier=\"imx-entitlements-unpublish\">{{ '#LDS#Unpublish' | translate }}</button>\r\n    <button mat-stroked-button data-imx-identifier=\"imx-entitlements-assign-mode-button\" [matMenuTriggerFor]=\"actionsMenu\">\r\n      <span>{{ '#LDS#Assign more' | translate }}</span>\r\n      <eui-icon icon=\"collapsedown\"></eui-icon>\r\n    </button>\r\n    <mat-menu data-imx-identifier=\"entitlements-assign-more-actions-menu\" #actionsMenu=\"matMenu\">\r\n      <button mat-menu-item data-imx-identifier=\"imx-entitlements-assign-manually\" (click)=\"addNewElement()\">\r\n        {{ '#LDS#Assign manually' | translate }}\r\n      </button>\r\n      <mat-divider></mat-divider>\r\n      <button mat-menu-item data-imx-identifier=\"imx-entitlements-updateCondition\" [disabled]=\"!application.extendedDataRead\" (click)=\"editConditionForDynamicAssignments()\">\r\n        {{ (hasConditionForDynamicAssignment ? '#LDS#Edit automatic assignment' : '#LDS#Assign automatically') | translate }}\r\n      </button>\r\n      <button mat-menu-item data-imx-identifier=\"imx-entitlements-apply-mapping\" [disabled]=\"!hasConditionForDynamicAssignment\" (click)=\"applyMappingForDynamicAssignments()\">\r\n        {{ '#LDS#Check for new automatic assignments' | translate }}\r\n      </button>\r\n    </mat-menu>\r\n    <button mat-stroked-button [disabled]=\"unassignedDisabled\" (click)=\"unassign()\" data-imx-identifier=\"imx-entitlements-unassign\">{{ '#LDS#Unassign' | translate }}</button>\r\n  </ng-container>\r\n</ng-template>\r\n\r\n<!-- Template for non existing entitlements -->\r\n<ng-template #nonExisting>\r\n  <div class=\"imx-aob-entitlements-empty\">\r\n    <eui-icon icon=\"key\" size=\"100px\"></eui-icon>\r\n    <div class=\"imx-aob-entitlements-empty-description\">\r\n      <h2>\r\n        {{ '#LDS#No application entitlements assigned' | translate }}\r\n      </h2>\r\n      <span>\r\n        {{ '#LDS#Assign application entitlements to this application.' | translate }}\r\n      </span>\r\n    </div>\r\n    <div class=\"imx-aob-entitlements-empty-actions\">\r\n      <button mat-raised-button color=\"primary\" (click)=\"addNewElement()\" data-imx-identifier=\"entitlements-add-unsGroup\">\r\n        {{ '#LDS#Assign application entitlements' | translate }}\r\n      </button>\r\n      <button mat-stroked-button data-imx-identifier=\"imx-entitlements-assign\" [disabled]=\"!application.extendedDataRead\" (click)=\"editConditionForDynamicAssignments()\">\r\n        {{ '#LDS#Create automatic assignment' | translate }}\r\n      </button>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<!-- Tile content template -->\r\n<ng-template #cardContentTemplate let-entitlement>\r\n  <imx-user [uid]=\"entitlement.UID_AERoleOwner\" role=\"{{ '#LDS#Application entitlement owner' | translate }}\"> </imx-user>\r\n</ng-template>\r\n\r\n<ng-template #infoContent>\r\n  <p [translate]=\"'#LDS#This application entitlement is not assigned to the root service category of this application nor to any of its child service categories.'\">\r\n    \r\n  </p>\r\n</ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;height:100%;flex:1 1 auto}.imx-entitlements-site{padding:16px 40px;height:100%;display:flex;flex-direction:column;flex:1 1 auto}.imx-badge-container>div{display:table-cell}.imx-badge-container>div>.eui-badge{margin:0 5px}.imx-badge-container>div>.eui-badge ::ng-deep .eui-badge-content{white-space:nowrap}imx-data-source-toolbar-custom button{margin-right:5px}.imx-aob-entitlements-empty{display:flex;flex-direction:column;align-items:center;margin-bottom:10px;flex:1 1 auto;justify-content:center}.imx-aob-entitlements-empty h2{font-weight:600}.imx-aob-entitlements-empty>div{margin-top:30px}.imx-aob-entitlements-empty>.eui-icon{color:#aab0b3}.imx-aob-entitlements-empty .imx-aob-entitlements-empty-description{margin-bottom:10px}.imx-aob-entitlements-empty .imx-aob-entitlements-empty-actions{display:flex;flex-direction:column}.imx-aob-entitlements-empty .imx-aob-entitlements-empty-actions>.mat-raised-button{margin-bottom:15px}.imx-aob-entitlements-empty .imx-aob-entitlements-empty-actions>:last-child{justify-self:center}.imx-aob-entitlements-header{display:flex;flex-wrap:wrap;margin:10px 0 8px}.imx-aob-entitlements-header>h3{font-size:18px;margin-right:10px;font-weight:400;line-height:36px}.imx-aob-entitlements-header>button{text-transform:uppercase}.imx-aob-entitlements-header>span{line-height:36px;font-size:14px}.imx-mat-card-title{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.imx-aob-data-container{flex-grow:1;align-content:flex-start}div[subtitle]{font-size:smaller;color:#919799}.eui-dark-theme :host .imx-aob-entitlements-empty>.eui-icon{color:#616566}.eui-contrast-theme :host .imx-aob-entitlements-empty>.eui-icon{color:#919799}.eui-contrast-theme :host .imx-entitlements-site{background-color:#000}\n"] }]
    }], function () { return [{ type: i2.ClassloggerService }, { type: i1$2.MatDialog }, { type: EntitlementsService }, { type: i1$1.EuiLoadingService }, { type: i1$2.MatDialog }, { type: i2.SnackBarService }, { type: ShopsService }, { type: ServiceItemsService }, { type: i5$1.Platform }, { type: i3$1.TranslateService }, { type: i1$1.EuiSidesheetService }, { type: i2.SettingsService }, { type: i2.SystemInfoService }, { type: i2.MetadataService }, { type: EntitlementEditAutoAddService }]; }, { application: [{
            type: Input
        }], reloadRequested: [{
            type: Output
        }], table: [{
            type: ViewChild,
            args: ['table']
        }], tiles: [{
            type: ViewChild,
            args: ['tiles']
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class KpiOverviewService {
    constructor(aobClient, apiProvider) {
        this.aobClient = aobClient;
        this.apiProvider = apiProvider;
    }
    async get(uidapplication) {
        return this.apiProvider.request(() => this.aobClient.client.portal_application_kpi_get(uidapplication));
    }
}
KpiOverviewService.ɵfac = function KpiOverviewService_Factory(t) { return new (t || KpiOverviewService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ApiClientService)); };
KpiOverviewService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: KpiOverviewService, factory: KpiOverviewService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KpiOverviewService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: AobApiService }, { type: i2.ApiClientService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$8 = ["chartdialog"];
function KpiOverviewComponent_ng_container_0_imx_busy_indicator_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-busy-indicator");
} }
function KpiOverviewComponent_ng_container_0_div_6_h4_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "h4");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Failed"));
} }
function KpiOverviewComponent_ng_container_0_div_6_li_3_button_9_Template(rf, ctx) { if (rf & 1) {
    const _r15 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 14);
    i0.ɵɵlistener("click", function KpiOverviewComponent_ng_container_0_div_6_li_3_button_9_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r15); const chart_r11 = i0.ɵɵnextContext().$implicit; const ctx_r13 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r13.showDetails(chart_r11, true)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Details"));
} }
function KpiOverviewComponent_ng_container_0_div_6_li_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li")(1, "mat-card")(2, "div", 7);
    i0.ɵɵelement(3, "eui-icon", 8);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-card-content", 9)(5, "div", 10);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(7, "div", 11);
    i0.ɵɵelementStart(8, "mat-card-actions", 12);
    i0.ɵɵtemplate(9, KpiOverviewComponent_ng_container_0_div_6_li_3_button_9_Template, 3, 3, "button", 13);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const chart_r11 = ctx.$implicit;
    const ctx_r8 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(5);
    i0.ɵɵproperty("matTooltip", chart_r11.Display);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(chart_r11.Display);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r8.hasDetails(chart_r11));
} }
function KpiOverviewComponent_ng_container_0_div_6_h4_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "h4");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Passed"));
} }
function KpiOverviewComponent_ng_container_0_div_6_li_6_button_9_Template(rf, ctx) { if (rf & 1) {
    const _r20 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 18);
    i0.ɵɵlistener("click", function KpiOverviewComponent_ng_container_0_div_6_li_6_button_9_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r20); const chart_r16 = i0.ɵɵnextContext().$implicit; const ctx_r18 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r18.showDetails(chart_r16, false)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Details"));
} }
function KpiOverviewComponent_ng_container_0_div_6_li_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li")(1, "mat-card")(2, "div", 15);
    i0.ɵɵelement(3, "eui-icon", 16);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-card-content", 9)(5, "div", 10);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(7, "div", 11);
    i0.ɵɵelementStart(8, "mat-card-actions", 12);
    i0.ɵɵtemplate(9, KpiOverviewComponent_ng_container_0_div_6_li_6_button_9_Template, 3, 3, "button", 17);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const chart_r16 = ctx.$implicit;
    const ctx_r10 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(5);
    i0.ɵɵproperty("matTooltip", chart_r16.Display);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(chart_r16.Display);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r10.hasDetails(chart_r16));
} }
function KpiOverviewComponent_ng_container_0_div_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, KpiOverviewComponent_ng_container_0_div_6_h4_1_Template, 3, 3, "h4", 4);
    i0.ɵɵelementStart(2, "ul", 5);
    i0.ɵɵtemplate(3, KpiOverviewComponent_ng_container_0_div_6_li_3_Template, 10, 3, "li", 6);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, KpiOverviewComponent_ng_container_0_div_6_h4_4_Template, 3, 3, "h4", 4);
    i0.ɵɵelementStart(5, "ul", 5);
    i0.ɵɵtemplate(6, KpiOverviewComponent_ng_container_0_div_6_li_6_Template, 10, 3, "li", 6);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r6 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r6.chartDataFail.length > 0);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r6.chartDataFail);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r6.chartDataPass.length > 0);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r6.chartDataPass);
} }
function KpiOverviewComponent_ng_container_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 3)(2, "h3");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(5, KpiOverviewComponent_ng_container_0_imx_busy_indicator_5_Template, 1, 0, "imx-busy-indicator", 4);
    i0.ɵɵtemplate(6, KpiOverviewComponent_ng_container_0_div_6_Template, 7, 4, "div", 4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#KPIs That Affect This Application"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.isLoading);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.isLoading);
} }
function KpiOverviewComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 19)(1, "div", 20);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 21);
    i0.ɵɵelement(5, "eui-icon", 22);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(6, "div", 23)(7, "h2", 24);
    i0.ɵɵtext(8);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(9, "p", 24);
    i0.ɵɵtext(10);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "div", 25);
    i0.ɵɵelement(12, "eui-billboard", 26);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r21 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngClass", data_r21.failed ? "imx-fail imx-title-text" : "imx-pass imx-title-text");
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 5, data_r21.failed ? "#LDS#Failed" : "#LDS#Passed"));
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate(data_r21.chart.display);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r21.chart.description);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("options", data_r21.chart.options);
} }
function KpiOverviewComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 27);
    i0.ɵɵelement(1, "eui-icon", 28);
    i0.ɵɵelementStart(2, "h2");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 1, "#LDS#There are no KPIs affecting this application."), " ");
} }
/**
 * A component, that displays key Performance Indicators (KPIs) for an application
 *
 * @example
 * <imx-kpi-overview [application]="application"></imx-kpi-overview>
 */
class KpiOverviewComponent {
    constructor(translateService, kpiOverviewProvider, logger, matDialog) {
        this.translateService = translateService;
        this.kpiOverviewProvider = kpiOverviewProvider;
        this.logger = logger;
        this.matDialog = matDialog;
        /**
         * @ignore columns for the mat-table that is shown, if a KPI has only one dataPoint
         */
        this.displayedColumns = ['Date', 'Value', 'Threshold'];
        this.busyService = new BusyService();
        this.isLoading = false;
        translateService.get('#LDS#Error threshold').subscribe((trans) => (this.errorThreshhold = trans));
        this.busyService.busyStateChanged.subscribe((elem) => (this.isLoading = elem));
    }
    /**
     * Displays a busyIndicator and initializes the data, when the OnChanges life cycle hook is called
     */
    async ngOnChanges(changes) {
        if (changes.application?.currentValue?.UID_AOBApplication.value === changes.application?.previousValue?.UID_AOBApplication.value) {
            return;
        }
        const isBusy = this.busyService.beginBusy();
        try {
            const data = await this.kpiOverviewProvider.get(this.application.UID_AOBApplication.value);
            if (data) {
                this.chartDataPass = data.filter((kpi) => kpi.Data.length > 0 && kpi.Data[0].Points[0].Value < kpi.ErrorThreshold);
                this.chartDataFail = data.filter((kpi) => kpi.Data.length > 0 && kpi.Data[0].Points[0].Value >= kpi.ErrorThreshold);
            }
            else {
                this.logger.error(this, 'ChartDto[] is undefined');
            }
        }
        finally {
            isBusy.endBusy();
        }
    }
    /**
     * @ignore Opens a dialog that shows the details of a KPI
     * @param chart the data of a single chart
     */
    showDetails(chart, isFail) {
        if (!this.hasDetails(chart)) {
            return;
        }
        this.matDialog.open(this.chartDialog, { data: { chart: this.getChartData(chart), failed: isFail }, width: '600px', autoFocus: false, panelClass: 'kpi-overview-modal' });
    }
    /**
     * @ignore determines whether a chart has detailed data
     * @param chart the data of a single chart
     */
    hasDetails(chart) {
        return chart.Data != null && chart.Data.length > 0;
    }
    /**
     * @ignore determines whether an application has chart data or not
     * @returns true, if there are failed or passed KPIs else it returns false
     */
    hasKpis() {
        return (this.chartDataFail != null && this.chartDataFail.length > 0) || (this.chartDataPass != null && this.chartDataPass.length > 0);
    }
    /**
     * @ignore get an unified display for a date string
     * @param date a date string as represented in the chart
     * @returns the local date string for a date represented by an other string
     */
    getDateDisplay(date) {
        return new Date(date).toLocaleString(this.translateService.currentLang);
    }
    /**
     * @ignore determines whether a chart has more then one data point
     * @param chart the data of a single chart
     * @returns true, if the chart has multiple points else it return false
     */
    hasMultipleDataPoints(chart) {
        return this.hasDetails(chart) && chart.Data[0].Points.length > 1;
    }
    /**
     * @irgnore Builds an object, that could be passed to the detail dialog
     * @param chart the data of a single chart
     * @returns a dictionary, that can be display on the details dialog
     */
    getChartData(chart) {
        return { display: chart.Display, description: chart.Description, options: this.buildOptions(chart) };
    }
    /**
     * @ignore Build the ChartOptions that can be displayed with billboard.js
     * @param chart the data of a single chart
     * @returns a ChartOptions object, that can be used by billboard.js
     */
    buildOptions(chart) {
        const yAxis = new YAxisInformation(chart.Data.map((serie) => new SeriesInformation(chart.Display, serie.Points.map((point) => point.Value))));
        const browserCulture = this.translateService.currentLang;
        yAxis.tickConfiguration = { format: (d) => d.toLocaleString(browserCulture), values: this.accumulateTicks(chart) };
        const lineChartOptions = new LineChartOptions(new XAxisInformation('date', chart.Data[0].Points.map((point) => new Date(point.Date)), {
            count: 6,
            format: (d) => d.toLocaleDateString(browserCulture),
        }), yAxis);
        lineChartOptions.useCurvedLines = false;
        lineChartOptions.hideLegend = true;
        lineChartOptions.showPoints = !this.hasMultipleDataPoints(chart);
        lineChartOptions.additionalLines = [
            {
                value: chart.ErrorThreshold,
                text: this.errorThreshhold,
            },
        ];
        lineChartOptions.size = {
            height: 400,
            width: 500
        };
        this.logger.debug(this, 'Options', lineChartOptions.options);
        return lineChartOptions.options;
    }
    accumulateTicks(chart) {
        const ret = [];
        const max = Math.max.apply(Math, chart.Data[0].Points.map((o) => o.Value));
        const steps = Math.max(1, Math.trunc(max / 10)) + 1;
        ret.push(0);
        if (max <= 0) {
            return ret;
        }
        for (let index = 1; index <= 10; index++) {
            ret.push(index * steps);
        }
        return ret;
    }
}
KpiOverviewComponent.ɵfac = function KpiOverviewComponent_Factory(t) { return new (t || KpiOverviewComponent)(i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(KpiOverviewService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1$2.MatDialog)); };
KpiOverviewComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: KpiOverviewComponent, selectors: [["imx-kpi-overview"]], viewQuery: function KpiOverviewComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0$8, 7);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.chartDialog = _t.first);
    } }, inputs: { application: "application" }, features: [i0.ɵɵNgOnChangesFeature], decls: 5, vars: 2, consts: [[4, "ngIf", "ngIfElse"], ["chartdialog", ""], ["nonExisting", ""], [1, "imx-kpi-site"], [4, "ngIf"], [1, "imx-kpi-list"], [4, "ngFor", "ngForOf"], ["mat-card-avatar", "", 1, "imx-fail"], ["icon", "ignore", "size", "m"], [1, "imx-kpi-content"], [1, "imx-kpi-text", 3, "matTooltip"], [1, "imx-spacer"], [1, "imx-kpi-tile-actions"], ["mat-stroked-button", "", "data-imx-identifier", "KPI_overview_showFailedShowDetails", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "data-imx-identifier", "KPI_overview_showFailedShowDetails", 3, "click"], ["mat-card-avatar", "", 1, "imx-pass"], ["icon", "check", "size", "m"], ["mat-stroked-button", "", "data-imx-identifier", "KPI_overview_showPassedShowDetails", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "data-imx-identifier", "KPI_overview_showPassedShowDetails", 3, "click"], ["mat-dialog-title", ""], [3, "ngClass"], ["mat-icon-button", "", "data-imx-identifier", "KPI_overview_closeChartDialog", "mat-dialog-close", "", 1, "mat-button", "imx-close-dialog-button"], ["icon", "close", "size", "large"], ["mat-dialog-content", ""], [1, "imx-title-text"], [1, "imx-chart"], [3, "options"], [1, "imx-aob-kpi-empty"], ["icon", "areachart", "size", "100px"]], template: function KpiOverviewComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, KpiOverviewComponent_ng_container_0_Template, 7, 5, "ng-container", 0);
        i0.ɵɵtemplate(1, KpiOverviewComponent_ng_template_1_Template, 13, 7, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵtemplate(3, KpiOverviewComponent_ng_template_3_Template, 5, 3, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
    } if (rf & 2) {
        const _r3 = i0.ɵɵreference(4);
        i0.ɵɵproperty("ngIf", ctx.hasKpis() || ctx.isLoading)("ngIfElse", _r3);
    } }, dependencies: [i5.NgClass, i5.NgForOf, i5.NgIf, i6.MatCard, i6.MatCardContent, i6.MatCardActions, i6.MatCardAvatar, i7.MatButton, i8$1.MatTooltip, i1$1.EuiBillboardComponent, i1$1.EuiIconComponent, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogContent, i2.BusyIndicatorComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column}[_nghost-%COMP%]   .mat-card[_ngcontent-%COMP%] > .mat-card-actions[_ngcontent-%COMP%]:last-child{margin-bottom:0}.imx-kpi-site[_ngcontent-%COMP%]{padding:16px 40px;height:auto;min-height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}li[_ngcontent-%COMP%]{list-style-type:none;margin:0 10px 10px 0}.mat-card[_ngcontent-%COMP%]{padding:5px 10px;width:340px;height:68px;display:flex}h2[_ngcontent-%COMP%]{font-size:20px;margin-bottom:8px}p[_ngcontent-%COMP%]{font-size:14px;margin-top:0}eui-billboard[_ngcontent-%COMP%]{width:500px}h3[_ngcontent-%COMP%]{margin-top:20px;font-size:18px;font-weight:400}h4[_ngcontent-%COMP%]{font-size:16px;font-weight:600;margin:30px 0 15px}.imx-card-clickable[_ngcontent-%COMP%]{cursor:pointer}.imx-kpi-text[_ngcontent-%COMP%]{margin:0;vertical-align:middle;word-break:break-word}.imx-kpi-content[_ngcontent-%COMP%]{flex:1 1 auto;align-self:center;margin-bottom:0;margin-right:5px}.imx-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.imx-kpi-tile-actions[_ngcontent-%COMP%]{display:flex;align-items:center;margin:0 5px 0 0;padding:0}.imx-pass[_ngcontent-%COMP%], .imx-fail[_ngcontent-%COMP%]{text-transform:uppercase;font-size:24px;line-height:38px;font-weight:900;margin:0 20px 0 0;align-self:center}.imx-kpi-list[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap}.imx-kpi-view[_ngcontent-%COMP%]{padding:20px 0 0 20px}.imx-chart[_ngcontent-%COMP%]{display:flex;justify-content:center;flex-direction:column}.mat-dialog-title[_ngcontent-%COMP%]{display:flex;margin:0 0 10px}.imx-title-text[_ngcontent-%COMP%]{text-align:center;margin:0 24px 0 60px;flex:1}.imx-close-dialog-button[_ngcontent-%COMP%]{right:-15px;top:-15px}.imx-aob-kpi-empty[_ngcontent-%COMP%]{display:flex;flex-direction:column;justify-content:center;align-items:center;flex:1 1 auto}.imx-aob-kpi-empty[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-weight:600}.eui-light-theme   [_nghost-%COMP%]   li[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{background-color:#fff}.eui-light-theme   [_nghost-%COMP%]   p[_ngcontent-%COMP%]{color:#16191a}.eui-light-theme   [_nghost-%COMP%]   .imx-pass[_ngcontent-%COMP%]{color:#4ba803}.eui-light-theme   [_nghost-%COMP%]   .imx-fail[_ngcontent-%COMP%]{color:#db2534}  .eui-light-theme .kpi-overview-modal .imx-title-text{color:#2f3233}  .eui-light-theme .kpi-overview-modal .imx-pass{color:#4ba803}  .eui-light-theme .kpi-overview-modal .imx-fail{color:#db2534}.eui-dark-theme   [_nghost-%COMP%]   .imx-kpi-list[_ngcontent-%COMP%] > li[_ngcontent-%COMP%] > .mat-card[_ngcontent-%COMP%]{background-color:#616566}.eui-dark-theme   [_nghost-%COMP%]   .imx-aob-kpi-empty[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#f2f6f7}.eui-dark-theme   [_nghost-%COMP%]   .imx-pass[_ngcontent-%COMP%]{color:#99c478}.eui-dark-theme   [_nghost-%COMP%]   .imx-fail[_ngcontent-%COMP%]{color:#f29d99}  .eui-dark-theme .kpi-overview-modal .imx-title-text{color:#f9fbfc}  .eui-dark-theme .kpi-overview-modal .imx-pass{color:#99c478}  .eui-dark-theme .kpi-overview-modal .imx-fail{color:#f29d99}.eui-contrast-theme   [_nghost-%COMP%]   .imx-kpi-list[_ngcontent-%COMP%] > li[_ngcontent-%COMP%] > .mat-card[_ngcontent-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .imx-aob-kpi-empty[_ngcontent-%COMP%]{background-color:#16191a}.eui-contrast-theme   [_nghost-%COMP%]   .imx-aob-kpi-empty[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-pass[_ngcontent-%COMP%]{color:#cee3bf}.eui-contrast-theme   [_nghost-%COMP%]   .imx-fail[_ngcontent-%COMP%]{color:#f3c8c8}  .eui-contrast-theme .kpi-overview-modal .imx-title-text{color:#dfe4e6}  .eui-contrast-theme .kpi-overview-modal .imx-pass{color:#4ba803}  .eui-contrast-theme .kpi-overview-modal .imx-fail{color:#db2534}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KpiOverviewComponent, [{
        type: Component,
        args: [{ selector: 'imx-kpi-overview', template: "<ng-container *ngIf=\"hasKpis() || isLoading; else nonExisting\">\r\n<div class=\"imx-kpi-site\">\r\n  <h3>\r\n    {{ '#LDS#KPIs That Affect This Application' | translate }}\r\n  </h3>\r\n  <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\r\n  <div *ngIf=\"!isLoading\">\r\n    <h4 *ngIf=\"chartDataFail.length > 0\">{{ '#LDS#Failed' | translate }}</h4>\r\n    <ul class=\"imx-kpi-list\">\r\n      <li *ngFor=\"let chart of chartDataFail\">\r\n        <mat-card>\r\n            <div mat-card-avatar class=\"imx-fail\">\r\n              <eui-icon icon=\"ignore\" size=\"m\"></eui-icon>\r\n            </div>\r\n            <mat-card-content class=\"imx-kpi-content\">\r\n              <div class=\"imx-kpi-text\" [matTooltip]=\"chart.Display\">{{ chart.Display }}</div>\r\n            </mat-card-content>\r\n            <div class=\"imx-spacer\"></div>\r\n            <mat-card-actions class =\"imx-kpi-tile-actions\">\r\n              <button *ngIf=\"hasDetails(chart)\" mat-stroked-button data-imx-identifier=\"KPI_overview_showFailedShowDetails\"\r\n              (click)=\"showDetails(chart, true)\">{{ '#LDS#Details' | translate }}</button>\r\n            </mat-card-actions>\r\n        </mat-card>\r\n      </li>\r\n    </ul>\r\n    <h4 *ngIf=\"chartDataPass.length > 0\">{{ '#LDS#Passed' | translate }}</h4>\r\n    <ul class=\"imx-kpi-list\">\r\n      <li *ngFor=\"let chart of chartDataPass\">\r\n        <mat-card>\r\n            <div mat-card-avatar class=\"imx-pass\">\r\n              <eui-icon icon=\"check\" size=\"m\"></eui-icon>\r\n            </div>\r\n          <mat-card-content class=\"imx-kpi-content\">\r\n            <div class=\"imx-kpi-text\" [matTooltip]=\"chart.Display\">{{ chart.Display }}</div>\r\n          </mat-card-content>\r\n          <div class=\"imx-spacer\"></div>\r\n          <mat-card-actions class =\"imx-kpi-tile-actions\">\r\n            <button *ngIf=\"hasDetails(chart)\" mat-stroked-button data-imx-identifier=\"KPI_overview_showPassedShowDetails\"\r\n            (click)=\"showDetails(chart, false)\">{{ '#LDS#Details' | translate }}</button>\r\n          </mat-card-actions>\r\n        </mat-card>\r\n      </li>\r\n    </ul>\r\n  </div>\r\n</div>\r\n</ng-container>\r\n\r\n<!-- Template for a chart dialog -->\r\n<ng-template #chartdialog let-data>\r\n  <div mat-dialog-title>\r\n    <div [ngClass]=\"data.failed? 'imx-fail imx-title-text':'imx-pass imx-title-text'\">{{ (data.failed ? '#LDS#Failed': '#LDS#Passed') | translate }}</div>\r\n    <button mat-icon-button  class=\"mat-button imx-close-dialog-button\" data-imx-identifier=\"KPI_overview_closeChartDialog\" mat-dialog-close>\r\n      <eui-icon icon=\"close\" size=\"large\"></eui-icon>\r\n    </button>\r\n  </div>\r\n  <div mat-dialog-content>\r\n    <h2 class=\"imx-title-text\">{{ data.chart.display }}</h2>\r\n    <p class=\"imx-title-text\">{{ data.chart.description }}</p>\r\n    <div class=\"imx-chart\">\r\n      <eui-billboard [options]=\"data.chart.options\"></eui-billboard>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<!-- Template for non existing entitlements -->\r\n<ng-template #nonExisting>\r\n  <div class=\"imx-aob-kpi-empty\">\r\n    <eui-icon icon=\"areachart\" size=\"100px\"></eui-icon>\r\n    <h2>\r\n      {{ '#LDS#There are no KPIs affecting this application.' | translate }}\r\n    </h2>\r\n  </div>\r\n</ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{flex:1 1 auto;display:flex;flex-direction:column}:host .mat-card>.mat-card-actions:last-child{margin-bottom:0}.imx-kpi-site{padding:16px 40px;height:auto;min-height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}li{list-style-type:none;margin:0 10px 10px 0}.mat-card{padding:5px 10px;width:340px;height:68px;display:flex}h2{font-size:20px;margin-bottom:8px}p{font-size:14px;margin-top:0}eui-billboard{width:500px}h3{margin-top:20px;font-size:18px;font-weight:400}h4{font-size:16px;font-weight:600;margin:30px 0 15px}.imx-card-clickable{cursor:pointer}.imx-kpi-text{margin:0;vertical-align:middle;word-break:break-word}.imx-kpi-content{flex:1 1 auto;align-self:center;margin-bottom:0;margin-right:5px}.imx-spacer{flex:1 1 auto}.imx-kpi-tile-actions{display:flex;align-items:center;margin:0 5px 0 0;padding:0}.imx-pass,.imx-fail{text-transform:uppercase;font-size:24px;line-height:38px;font-weight:900;margin:0 20px 0 0;align-self:center}.imx-kpi-list{display:flex;flex-wrap:wrap}.imx-kpi-view{padding:20px 0 0 20px}.imx-chart{display:flex;justify-content:center;flex-direction:column}.mat-dialog-title{display:flex;margin:0 0 10px}.imx-title-text{text-align:center;margin:0 24px 0 60px;flex:1}.imx-close-dialog-button{right:-15px;top:-15px}.imx-aob-kpi-empty{display:flex;flex-direction:column;justify-content:center;align-items:center;flex:1 1 auto}.imx-aob-kpi-empty h2{font-weight:600}.eui-light-theme :host li .mat-card{background-color:#fff}.eui-light-theme :host p{color:#16191a}.eui-light-theme :host .imx-pass{color:#4ba803}.eui-light-theme :host .imx-fail{color:#db2534}::ng-deep .eui-light-theme .kpi-overview-modal .imx-title-text{color:#2f3233}::ng-deep .eui-light-theme .kpi-overview-modal .imx-pass{color:#4ba803}::ng-deep .eui-light-theme .kpi-overview-modal .imx-fail{color:#db2534}.eui-dark-theme :host .imx-kpi-list>li>.mat-card{background-color:#616566}.eui-dark-theme :host .imx-aob-kpi-empty>.eui-icon{color:#f2f6f7}.eui-dark-theme :host .imx-pass{color:#99c478}.eui-dark-theme :host .imx-fail{color:#f29d99}::ng-deep .eui-dark-theme .kpi-overview-modal .imx-title-text{color:#f9fbfc}::ng-deep .eui-dark-theme .kpi-overview-modal .imx-pass{color:#99c478}::ng-deep .eui-dark-theme .kpi-overview-modal .imx-fail{color:#f29d99}.eui-contrast-theme :host .imx-kpi-list>li>.mat-card{background-color:#2f3233}.eui-contrast-theme :host .imx-aob-kpi-empty{background-color:#16191a}.eui-contrast-theme :host .imx-aob-kpi-empty>.eui-icon{color:#fff}.eui-contrast-theme :host .imx-pass{color:#cee3bf}.eui-contrast-theme :host .imx-fail{color:#f3c8c8}::ng-deep .eui-contrast-theme .kpi-overview-modal .imx-title-text{color:#dfe4e6}::ng-deep .eui-contrast-theme .kpi-overview-modal .imx-pass{color:#4ba803}::ng-deep .eui-contrast-theme .kpi-overview-modal .imx-fail{color:#db2534}\n"] }]
    }], function () { return [{ type: i3$1.TranslateService }, { type: KpiOverviewService }, { type: i2.ClassloggerService }, { type: i1$2.MatDialog }]; }, { application: [{
            type: Input
        }], chartDialog: [{
            type: ViewChild,
            args: ['chartdialog', { static: true }]
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobAccountContainer extends TypedEntity {
    static GetEntitySchema() {
        const columns = {
            XObjectKey: {
                Type: ValType.String,
                ColumnName: 'XObjectKey'
            }
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        return { Columns: columns };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountsService {
    constructor(aobClient, logger, apiProvider) {
        this.aobClient = aobClient;
        this.logger = logger;
        this.apiProvider = apiProvider;
        this.builder = new TypedEntityBuilder(AobAccountContainer);
        this.appUsesAccounts = {};
    }
    get display() {
        return this.aobClient.typedClient.PortalApplicationusesaccount.GetSchema().Display;
    }
    async updateApplicationUsesAccounts(application, changeSet) {
        const assignResult = await this.assign(application, changeSet.add);
        return assignResult && this.unassign(application, changeSet.remove);
    }
    getCandidateTables() {
        return this.aobClient.typedClient.PortalApplicationusesaccountNew.createEntity()
            .ObjectKeyAccount.GetMetadata().GetFkRelations();
    }
    async getSelectedAccountLength(uidApplication) {
        return (await this.apiProvider.request(() => this.aobClient.typedClient.PortalApplicationusesaccount.Get(uidApplication, { PageSize: -1 }))).totalCount;
    }
    async getAssigned(application, parameters = {}) {
        this.appUsesAccounts = {};
        this.logger.debug(this, 'getting assigned accounts...');
        const appUsesAccountCollection = await this.apiProvider.request(() => this.aobClient.typedClient.PortalApplicationusesaccount.Get(application, parameters));
        return this.accountsWithTableInfo(appUsesAccountCollection, parameters);
    }
    async getFirstAndCount(uidApplication) {
        const elements = await this.apiProvider.request(() => this.aobClient.typedClient.PortalApplicationusesaccount.Get(uidApplication, { PageSize: 1 }));
        const accounts = await this.accountsWithTableInfo(elements, { PageSize: 1 });
        return {
            first: accounts.length === 0 ? undefined : accounts[0],
            count: elements.totalCount
        };
    }
    async accountsWithTableInfo(appUsesAccountCollection, parameters) {
        const accountsAssigned = [];
        const tables = this.getCandidateTables();
        if (appUsesAccountCollection && appUsesAccountCollection.Data && tables) {
            for (const appUsesAccount of appUsesAccountCollection.Data) {
                const tableName = DbObjectKey.FromXml(appUsesAccount.ObjectKeyAccount.value).TableName;
                const table = tables.find(fkr => fkr.TableName === tableName);
                if (table) {
                    const accountCollection = await table.Get({
                        ...parameters,
                        ...{
                            filter: [
                                {
                                    ColumnName: table.ColumnName,
                                    Type: FilterType.Compare,
                                    CompareOp: CompareOperator.Like,
                                    Value1: `%${appUsesAccount.ObjectKeyAccount.value}%`
                                }
                            ],
                            search: undefined
                        }
                    });
                    if (accountCollection?.Entities?.length > 0) {
                        const entity = this.builder.buildReadWriteEntity({
                            entitySchema: AobAccountContainer.GetEntitySchema(),
                            entityData: accountCollection.Entities[0]
                        });
                        this.appUsesAccounts[entity.GetEntity().GetKeys().join()] = appUsesAccount;
                        accountsAssigned.push(entity);
                    }
                }
            }
        }
        return accountsAssigned;
    }
    async assign(application, accounts) {
        let count = 0;
        await this.apiProvider.request(async () => {
            for (const account of accounts) {
                this.logger.debug(this, 'assigning account to application...');
                const assignedAccount = this.aobClient.typedClient.PortalApplicationusesaccountNew.createEntity();
                assignedAccount.UID_AOBApplication.value = application.UID_AOBApplication.value;
                assignedAccount.ObjectKeyAccount.value = account.GetEntity().GetColumn('XObjectKey').GetValue();
                await assignedAccount.GetEntity().Commit();
                count++;
            }
        });
        return count === accounts.length;
    }
    async unassign(application, accounts) {
        let count = 0;
        await this.apiProvider.request(async () => {
            for (const account of accounts) {
                this.logger.debug(this, 'unassigning account from application...');
                await this.aobClient.client.portal_applicationusesaccount_delete(application.UID_AOBApplication.value, this.appUsesAccounts[account.GetEntity().GetKeys().join()].UID_AOBAppUsesAccount.value);
                count++;
            }
        });
        return count === accounts.length;
    }
    async searchCandidates(table, keyword, parameters = {}) {
        this.logger.debug(this, 'searching accounts...');
        return table.Get({
            ...parameters,
            ...{
                filter: [
                    {
                        ColumnName: table.ColumnName,
                        Type: FilterType.Compare,
                        CompareOp: CompareOperator.Like,
                        Value1: `%${keyword}%`
                    }
                ],
                search: undefined
            }
        });
    }
}
AccountsService.ɵfac = function AccountsService_Factory(t) { return new (t || AccountsService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ApiClientService)); };
AccountsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AccountsService, factory: AccountsService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: AobApiService }, { type: i2.ClassloggerService }, { type: i2.ApiClientService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SelectionContainer {
    constructor(getKey) {
        this.getKey = getKey;
        this.selected = [];
        this.assigned = [];
    }
    init(assigned) {
        this.assigned = assigned;
        this.selected = assigned.slice();
    }
    getChangeSet() {
        return {
            add: this.selected.filter(item => this.assigned.find(itemAssigned => this.equals(item, itemAssigned)) == null),
            remove: this.selected == null || this.selected.length === 0 ?
                this.assigned :
                this.assigned.filter(itemAssigned => this.selected.find(item => this.equals(item, itemAssigned)) == null)
        };
    }
    equals(item1, item2) {
        return this.getKey(item1) === this.getKey(item2);
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function AuthenticationRootComponent_imx_entity_column_editor_0_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-entity-column-editor", 3);
    i0.ɵɵlistener("controlCreated", function AuthenticationRootComponent_imx_entity_column_editor_0_Template_imx_entity_column_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.form.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("column", ctx_r0.application.IsAuthenticationIntegrated.Column);
} }
function AuthenticationRootComponent_mat_error_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-error");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "ldsReplace");
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(2, 1, i0.ɵɵpipeBind1(3, 4, "#LDS#Please specify a value for {0}."), ctx_r1.application.AuthenticationRoot.GetMetadata().GetDisplay()), "\n");
} }
function AuthenticationRootComponent_imx_cdr_editor_2_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 4);
    i0.ɵɵlistener("controlCreated", function AuthenticationRootComponent_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.form.addControl("authenticationRoot", $event)); })("valueChange", function AuthenticationRootComponent_imx_cdr_editor_2_Template_imx_cdr_editor_valueChange_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r7 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r7.form.updateValueAndValidity()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("cdr", ctx_r2.authenticationRootWrapper);
} }
class AuthenticationRootComponent {
    constructor() {
        this.form = new UntypedFormGroup({}, __ => {
            if (this.application == null) {
                return null;
            }
            const isAuthenticationIntegrated = this.application.IsAuthenticationIntegrated.value;
            const authenticationRootValue = this.application.AuthenticationRootHelper.value;
            return !authenticationRootValue?.length && isAuthenticationIntegrated ? { relationInvalid: true } : null;
        });
        this.controlCreated = new EventEmitter();
    }
    async ngOnInit() {
        const authenticationRootHelper = this.application.AuthenticationRootHelper;
        if (!authenticationRootHelper.value?.length) {
            await authenticationRootHelper.Column.PutValueStruct({
                DataValue: this.application.AuthenticationRoot.value,
                DisplayValue: this.application.AuthenticationRoot.Column.GetDisplayValue()
            });
        }
        this.authenticationRootWrapper = new BaseCdr(authenticationRootHelper.Column);
        this.controlCreated.emit(this.form);
    }
}
AuthenticationRootComponent.ɵfac = function AuthenticationRootComponent_Factory(t) { return new (t || AuthenticationRootComponent)(); };
AuthenticationRootComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AuthenticationRootComponent, selectors: [["imx-authentication-root"]], inputs: { application: "application" }, outputs: { controlCreated: "controlCreated" }, decls: 3, vars: 3, consts: [[3, "column", "controlCreated", 4, "ngIf"], [4, "ngIf"], [3, "cdr", "controlCreated", "valueChange", 4, "ngIf"], [3, "column", "controlCreated"], [3, "cdr", "controlCreated", "valueChange"]], template: function AuthenticationRootComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, AuthenticationRootComponent_imx_entity_column_editor_0_Template, 1, 1, "imx-entity-column-editor", 0);
        i0.ɵɵtemplate(1, AuthenticationRootComponent_mat_error_1_Template, 4, 6, "mat-error", 1);
        i0.ɵɵtemplate(2, AuthenticationRootComponent_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 2);
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.application);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.form == null ? null : ctx.form.errors == null ? null : ctx.form.errors.relationInvalid);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.authenticationRootWrapper);
    } }, dependencies: [i5.NgIf, i12.MatError, i2.CdrEditorComponent, i2.EntityColumnEditorComponent, i2.LdsReplacePipe, i3$1.TranslatePipe] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AuthenticationRootComponent, [{
        type: Component,
        args: [{ selector: 'imx-authentication-root', template: "<imx-entity-column-editor *ngIf=\"application\" [column]=\"application.IsAuthenticationIntegrated.Column\"\r\n(controlCreated)=\"form.addControl($event.name, $event.control)\">\r\n</imx-entity-column-editor>\r\n<mat-error *ngIf=\"form?.errors?.relationInvalid\">\r\n  {{ '#LDS#Please specify a value for {0}.' | translate | ldsReplace:application.AuthenticationRoot.GetMetadata().GetDisplay() }}\r\n</mat-error>\r\n<imx-cdr-editor *ngIf=\"authenticationRootWrapper\"\r\n  [cdr]=\"authenticationRootWrapper\"\r\n  (controlCreated)=\"form.addControl('authenticationRoot', $event)\"\r\n  (valueChange)=\"form.updateValueAndValidity()\">\r\n</imx-cdr-editor>\r\n" }]
    }], null, { application: [{
            type: Input
        }], controlCreated: [{
            type: Output
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EditApplicationComponent_div_3_imx_typed_entity_select_8_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-typed-entity-select", 12);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_imx_typed_entity_select_8_Template_imx_typed_entity_select_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r3 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r3.applicationForm.addControl("shops", $event)); })("selectionChanged", function EditApplicationComponent_div_3_imx_typed_entity_select_8_Template_imx_typed_entity_select_selectionChanged_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r5 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r5.shopSelectionChanged($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("data", ctx_r1.shopsData);
} }
function EditApplicationComponent_div_3_imx_typed_entity_select_9_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-typed-entity-select", 12);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_imx_typed_entity_select_9_Template_imx_typed_entity_select_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r7); const ctx_r6 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r6.applicationForm.addControl("accounts", $event)); })("selectionChanged", function EditApplicationComponent_div_3_imx_typed_entity_select_9_Template_imx_typed_entity_select_selectionChanged_0_listener($event) { i0.ɵɵrestoreView(_r7); const ctx_r8 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r8.accountSelectionChanged($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("data", ctx_r2.accountsData);
} }
function EditApplicationComponent_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r10 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 7)(1, "imx-application-image-select", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_application_image_select_controlCreated_1_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r9 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r9.applicationForm.addControl(ctx_r9.application.JPegPhoto.Column.ColumnName, $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_2_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r11 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r11.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_3_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r12 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r12.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "imx-entity-column-editor", 9);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_4_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_5_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r14 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r14.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_6_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r15 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r15.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_7_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r16 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r16.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(8, EditApplicationComponent_div_3_imx_typed_entity_select_8_Template, 1, 1, "imx-typed-entity-select", 10);
    i0.ɵɵtemplate(9, EditApplicationComponent_div_3_imx_typed_entity_select_9_Template, 1, 1, "imx-typed-entity-select", 10);
    i0.ɵɵelementStart(10, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_10_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r17 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r17.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_11_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r18 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r18.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "imx-authentication-root", 11);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_authentication_root_controlCreated_12_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r19 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r19.applicationForm.addControl("authRoot", $event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_13_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r20 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r20.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_14_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(15, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_15_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r22 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r22.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_16_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r23 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r23.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(17, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_17_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r24 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r24.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(18, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_18_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r25 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r25.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(19, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_19_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r26 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r26.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(20, "imx-entity-column-editor", 8);
    i0.ɵɵlistener("controlCreated", function EditApplicationComponent_div_3_Template_imx_entity_column_editor_controlCreated_20_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r27 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r27.applicationForm.addControl($event.name, $event.control)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.JPegPhoto == null ? null : ctx_r0.application.JPegPhoto.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.Ident_AOBApplication == null ? null : ctx_r0.application.Ident_AOBApplication.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.Description == null ? null : ctx_r0.application.Description.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.UID_AccProductGroup == null ? null : ctx_r0.application.UID_AccProductGroup.Column)("readonly", true);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.UID_PersonHead == null ? null : ctx_r0.application.UID_PersonHead.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.UID_AERoleOwner == null ? null : ctx_r0.application.UID_AERoleOwner.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.UID_AERoleApprover == null ? null : ctx_r0.application.UID_AERoleApprover.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r0.shopsData);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r0.accountsData);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.ApplicationEnvironment == null ? null : ctx_r0.application.ApplicationEnvironment.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.ApplicationWebURL == null ? null : ctx_r0.application.ApplicationWebURL.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("application", ctx_r0.application);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.IsFederationEnabled == null ? null : ctx_r0.application.IsFederationEnabled.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.IsMultiFactorEnabled == null ? null : ctx_r0.application.IsMultiFactorEnabled.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.IsSSOEnabled == null ? null : ctx_r0.application.IsSSOEnabled.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.SSORedirectionUrl == null ? null : ctx_r0.application.SSORedirectionUrl.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.PurchasedLicenses == null ? null : ctx_r0.application.PurchasedLicenses.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.RiskIndex == null ? null : ctx_r0.application.RiskIndex.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.UID_FunctionalArea == null ? null : ctx_r0.application.UID_FunctionalArea.Column);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("column", ctx_r0.application == null ? null : ctx_r0.application.NextRunDate == null ? null : ctx_r0.application.NextRunDate.Column);
} }
class EditApplicationComponent {
    constructor(logger, shopsProvider, snackbar, busyService, accountsProvider, errorHandler, sidesheetRef, confirmation, translate, ldsReplace, application, dialog) {
        this.logger = logger;
        this.shopsProvider = shopsProvider;
        this.snackbar = snackbar;
        this.busyService = busyService;
        this.accountsProvider = accountsProvider;
        this.errorHandler = errorHandler;
        this.sidesheetRef = sidesheetRef;
        this.confirmation = confirmation;
        this.translate = translate;
        this.ldsReplace = ldsReplace;
        this.application = application;
        this.dialog = dialog;
        this.applicationForm = new UntypedFormGroup({});
        this.close = new EventEmitter();
        this.shopsSelection = new SelectionContainer((item) => item.UID_ITShopOrg.value);
        this.accountsSelection = new SelectionContainer((item) => item.GetEntity().GetKeys().join());
        this.sidesheetRef.closeClicked().subscribe(async () => {
            if (!this.hasUnsavedChanges()) {
                await this.cancelProcess();
                return;
            }
            if (await this.confirmation.confirmLeaveWithUnsavedChanges()) {
                await this.cancelProcess();
            }
        });
        this.accountsData = this.getAccountsData();
        this.shopsData = this.getShopsData();
    }
    shopSelectionChanged(selection) {
        this.shopsSelection.selected = selection;
    }
    accountSelectionChanged(selection) {
        this.accountsSelection.selected = selection;
    }
    canSubmit() {
        return this.hasUnsavedChanges() && !this.applicationForm.invalid;
    }
    hasUnsavedChanges() {
        return this.application != null && this.applicationForm.dirty;
    }
    async submitData() {
        const overlayRef = this.busyService.show();
        try {
            await this.saveShops();
            await this.saveAccounts();
            this.logger.debug(this, 'submitData - commit application changes...');
            await this.application.GetEntity().Commit(true);
            this.applicationForm.markAsPristine();
            this.close.emit(this.application?.UID_AOBApplication?.value);
            this.snackbar.open({ key: '#LDS#The application has been successfully saved.' }, '#LDS#Close', { duration: 3000 });
        }
        catch (error) {
            this.errorHandler.handleError(error);
        }
        finally {
            setTimeout(() => this.busyService.hide(overlayRef));
            this.sidesheetRef.close();
        }
    }
    async cancelProcess() {
        if (this.hasUnsavedChanges()) {
            this.applicationForm.markAsPristine();
            this.snackbar.open({ key: '#LDS#The changes were discarded.' }, '#LDS#Close', { duration: 3000 });
        }
        this.close.emit(this.application?.UID_AOBApplication?.value);
        this.sidesheetRef.close();
    }
    editTranslation() {
        const dialogConfig = {
            data: this.application,
            width: '600px'
        };
        this.dialog.open(TranslationEditorComponent, dialogConfig);
    }
    getShopsData() {
        return {
            title: '#LDS#Heading Edit IT Shop Structures',
            valueWrapper: {
                display: this.shopsProvider.display,
                name: 'shops',
                canEdit: true
            },
            getInitialDisplay: async () => {
                const info = await this.shopsProvider.getFirstAndCount(this.application.UID_AOBApplication.value);
                return this.buildInitalValue(info.first, info.count);
            },
            getSelected: async () => {
                this.shopsSelection.init((await this.shopsProvider.getApplicationInShop(this.application.UID_AOBApplication.value, { PageSize: 100000 }))?.Data);
                return this.shopsSelection.selected;
            },
            getTyped: parameters => this.shopsProvider.get(parameters),
        };
    }
    async saveShops() {
        if (this.shopsData) {
            this.logger.debug(this, 'submitData - update shops...');
            const result = await this.shopsProvider.updateApplicationInShops(this.application, this.shopsSelection.getChangeSet());
            if (!result) {
                this.logger.error(this, 'Attempt to update the shops failed');
            }
        }
    }
    getAccountsData() {
        return {
            title: '#LDS#Heading Edit User Accounts',
            valueWrapper: {
                display: this.accountsProvider.display,
                name: 'accounts',
                canEdit: true
            },
            getInitialDisplay: async () => {
                const info = await this.accountsProvider.getFirstAndCount(this.application.UID_AOBApplication.value);
                return this.buildInitalValue(info.first, info.count);
            },
            getSelected: async () => {
                this.accountsSelection.init(await this.accountsProvider.getAssigned(this.application.UID_AOBApplication.value, { PageSize: 100000 }));
                return this.accountsSelection.selected;
            },
            dynamicFkRelation: {
                tables: this.accountsProvider.getCandidateTables(),
                getSelectedTableName: selected => {
                    if (selected?.length > 0) {
                        return DbObjectKey.FromXml(selected[0].GetEntity().GetColumn('XObjectKey').GetValue()).TableName;
                    }
                    return undefined;
                }
            },
        };
    }
    async saveAccounts() {
        if (this.accountsData) {
            this.logger.debug(this, 'submitData - update accounts...');
            const result = await this.accountsProvider.updateApplicationUsesAccounts(this.application, this.accountsSelection.getChangeSet());
            if (!result) {
                this.logger.error(this, 'Attempt to update the accounts failed');
            }
        }
    }
    async buildInitalValue(entity, count) {
        return count < 1 ? '' :
            count === 1 ? entity.GetEntity().GetDisplay() :
                this.ldsReplace.transform(await this.translate.get('#LDS#{0} items selected').toPromise(), count);
    }
}
EditApplicationComponent.ɵfac = function EditApplicationComponent_Factory(t) { return new (t || EditApplicationComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ShopsService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i2.LdsReplacePipe), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$2.MatDialog)); };
EditApplicationComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditApplicationComponent, selectors: [["imx-edit-application"]], outputs: { close: "close" }, decls: 14, vars: 12, consts: [["eui-sidesheet-content", ""], [1, "imx-form", 3, "formGroup"], ["class", "imx-input-fields", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["data-imx-identifier", "editApp-translate", "mat-raised-button", "", "type", "button", 1, "justify-start", 3, "click"], ["data-imx-identifier", "editApp-cancel", "mat-stroked-button", "", "type", "button", 3, "click"], ["data-imx-identifier", "editApp-save", "mat-raised-button", "", "type", "button", "color", "primary", 3, "disabled", "click"], [1, "imx-input-fields"], [3, "column", "controlCreated"], [3, "column", "readonly", "controlCreated"], [3, "data", "controlCreated", "selectionChanged", 4, "ngIf"], [3, "application", "controlCreated"], [3, "data", "controlCreated", "selectionChanged"]], template: function EditApplicationComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "form", 1);
        i0.ɵɵtemplate(3, EditApplicationComponent_div_3_Template, 21, 21, "div", 2);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(4, "div", 3)(5, "button", 4);
        i0.ɵɵlistener("click", function EditApplicationComponent_Template_button_click_5_listener() { return ctx.editTranslation(); });
        i0.ɵɵtext(6);
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(8, "button", 5);
        i0.ɵɵlistener("click", function EditApplicationComponent_Template_button_click_8_listener() { return ctx.cancelProcess(); });
        i0.ɵɵtext(9);
        i0.ɵɵpipe(10, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(11, "button", 6);
        i0.ɵɵlistener("click", function EditApplicationComponent_Template_button_click_11_listener() { return ctx.submitData(); });
        i0.ɵɵtext(12);
        i0.ɵɵpipe(13, "translate");
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("formGroup", ctx.applicationForm);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.application);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 6, "#LDS#Edit translations"), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(10, 8, "#LDS#Cancel"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", !ctx.canSubmit());
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 10, "#LDS#Save"), " ");
    } }, dependencies: [i5.NgIf, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i7.MatButton, i6.MatCard, i8.ɵNgNoValidate, i8.NgControlStatusGroup, i8.FormGroupDirective, i2.TypedEntitySelectComponent, i2.EntityColumnEditorComponent, ApplicationImageSelectComponent, AuthenticationRootComponent, i3$1.TranslatePipe], styles: [".imx-form[_ngcontent-%COMP%]{display:flex;justify-content:space-between;margin-right:10px}.imx-input-fields[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex-grow:1;max-width:600px}.imx-checkbox-error[_ngcontent-%COMP%]{margin-left:24px}.eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditApplicationComponent, [{
        type: Component,
        args: [{ selector: 'imx-edit-application', template: "<div eui-sidesheet-content>\r\n  <mat-card>\r\n    <form class=\"imx-form\" [formGroup]=\"applicationForm\">\r\n      <div class=\"imx-input-fields\" *ngIf=\"application\">\r\n        <imx-application-image-select [column]=\"application?.JPegPhoto?.Column\" (controlCreated)=\"applicationForm.addControl(application.JPegPhoto.Column.ColumnName, $event)\">\r\n        </imx-application-image-select>\r\n        <imx-entity-column-editor [column]=\"application?.Ident_AOBApplication?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.Description?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\"> </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.UID_AccProductGroup?.Column\" [readonly]=\"true\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.UID_PersonHead?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.UID_AERoleOwner?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.UID_AERoleApprover?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-typed-entity-select\r\n          *ngIf=\"shopsData\"\r\n          [data]=\"shopsData\"\r\n          (controlCreated)=\"applicationForm.addControl('shops', $event)\"\r\n          (selectionChanged)=\"shopSelectionChanged($event)\"\r\n        >\r\n        </imx-typed-entity-select>\r\n        <imx-typed-entity-select\r\n          *ngIf=\"accountsData\"\r\n          [data]=\"accountsData\"\r\n          (controlCreated)=\"applicationForm.addControl('accounts', $event)\"\r\n          (selectionChanged)=\"accountSelectionChanged($event)\"\r\n        >\r\n        </imx-typed-entity-select>\r\n        <imx-entity-column-editor [column]=\"application?.ApplicationEnvironment?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.ApplicationWebURL?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-authentication-root [application]=\"application\" (controlCreated)=\"applicationForm.addControl('authRoot', $event)\"> </imx-authentication-root>\r\n        <imx-entity-column-editor [column]=\"application?.IsFederationEnabled?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.IsMultiFactorEnabled?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.IsSSOEnabled?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\"> </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.SSORedirectionUrl?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.PurchasedLicenses?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.RiskIndex?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\"> </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.UID_FunctionalArea?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n        <imx-entity-column-editor [column]=\"application?.NextRunDate?.Column\" (controlCreated)=\"applicationForm.addControl($event.name, $event.control)\">\r\n        </imx-entity-column-editor>\r\n      </div>\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n\r\n<div eui-sidesheet-actions>\r\n  <button data-imx-identifier=\"editApp-translate\" mat-raised-button type=\"button\" class=\"justify-start\" (click)=\"editTranslation()\">\r\n    {{ '#LDS#Edit translations' | translate }}\r\n  </button>\r\n  <button data-imx-identifier=\"editApp-cancel\" mat-stroked-button type=\"button\" (click)=\"cancelProcess()\">\r\n    {{ '#LDS#Cancel' | translate }}\r\n  </button>\r\n  <button data-imx-identifier=\"editApp-save\" mat-raised-button type=\"button\" (click)=\"submitData()\" [disabled]=\"!canSubmit()\" color=\"primary\">\r\n    {{ '#LDS#Save' | translate }}\r\n  </button>\r\n</div>\r\n", styles: [".imx-form{display:flex;justify-content:space-between;margin-right:10px}.imx-input-fields{display:flex;flex-direction:column;flex-grow:1;max-width:600px}.imx-checkbox-error{margin-left:24px}.eui-sidesheet-actions .justify-start{margin-right:auto}.eui-sidesheet-actions button:not(:last-of-type):not(.justify-start){margin-right:10px}\n"] }]
    }], function () { return [{ type: i2.ClassloggerService }, { type: ShopsService }, { type: i2.SnackBarService }, { type: i1$1.EuiLoadingService }, { type: AccountsService }, { type: i0.ErrorHandler }, { type: i1$1.EuiSidesheetRef }, { type: i2.ConfirmationService }, { type: i3$1.TranslateService }, { type: i2.LdsReplacePipe }, { type: i13$2.PortalApplication, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: i1$2.MatDialog }]; }, { close: [{
            type: Output
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ServiceCategoryService {
    constructor(apiClient) {
        this.apiClient = apiClient;
    }
    get serviceCategorySchema() {
        return this.apiClient.typedClient.PortalServicecategories.GetSchema();
    }
    async get(parameters = {}) {
        return this.apiClient.typedClient.PortalServicecategories.Get(parameters);
    }
    createChild() {
        const entity = this.apiClient.typedClient.PortalServicecategories.createEntity();
        return entity.GetEntity();
    }
    async delete(uid) {
        return this.apiClient.client.portal_servicecategories_delete(uid);
    }
}
ServiceCategoryService.ɵfac = function ServiceCategoryService_Factory(t) { return new (t || ServiceCategoryService)(i0.ɵɵinject(i1.QerApiService)); };
ServiceCategoryService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ServiceCategoryService, factory: ServiceCategoryService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ServiceCategoryService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: i1.QerApiService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/** Provider of servicecategory-data for the imx-data-tree */
class ServiceCategoryTreeDatabase extends TreeDatabase {
    constructor(loadingServiceElemental, settings, serviceCategoriesProvider, uidRootElement) {
        super();
        this.loadingServiceElemental = loadingServiceElemental;
        this.settings = settings;
        this.serviceCategoriesProvider = serviceCategoriesProvider;
        this.uidRootElement = uidRootElement;
        this.identifierColumnName = 'FullPath';
        this.canSearch = true;
    }
    async getData(showLoading, parameters = { ParentKey: '' }) {
        if (parameters.ParentKey != '') {
            return this.loadData(showLoading, parameters);
        }
        return this.loadRoot(showLoading);
    }
    async loadRoot(showLoading) {
        let entities;
        let overlayRef;
        if (showLoading) {
            setTimeout(() => (overlayRef = this.loadingServiceElemental.show()));
        }
        try {
            const opts = {
                PageSize: 1,
                StartIndex: 0,
                filter: [
                    {
                        ColumnName: 'UID_AccProductGroup',
                        Value1: this.uidRootElement,
                    },
                ],
            };
            const serviceCategories = await this.serviceCategoriesProvider.get(opts);
            entities = {
                entities: serviceCategories?.Data?.map((element) => element.GetEntity()),
                canLoadMore: false,
                totalCount: serviceCategories.totalCount,
            };
        }
        finally {
            if (showLoading) {
                setTimeout(() => this.loadingServiceElemental.hide(overlayRef));
            }
        }
        return entities;
    }
    async loadData(showLoading, parameters) {
        let entities;
        let overlayRef;
        if (showLoading) {
            setTimeout(() => (overlayRef = this.loadingServiceElemental.show()));
        }
        try {
            const opts = {
                PageSize: this.settings.DefaultPageSize,
                StartIndex: 0,
                ...parameters,
            };
            const serviceCategories = await this.serviceCategoriesProvider.get(opts);
            entities = {
                entities: serviceCategories?.Data?.map((element) => element.GetEntity()),
                canLoadMore: opts.StartIndex + opts.PageSize < serviceCategories.totalCount,
                totalCount: serviceCategories.totalCount,
            };
        }
        finally {
            if (showLoading) {
                setTimeout(() => this.loadingServiceElemental.hide(overlayRef));
            }
        }
        return entities;
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function EditServiceCategoryInformationComponent_imx_cdr_editor_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 6);
    i0.ɵɵlistener("controlCreated", function EditServiceCategoryInformationComponent_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.formGroup.controls.cdrArray.push($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r1 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r1);
    i0.ɵɵattribute("data-imx-identifier", "edit-service-category-information-" + cdr_r1.column.ColumName);
} }
class EditServiceCategoryInformationComponent {
    constructor(categoryProvider, confirm, ref, cdrFactoryService, data) {
        this.categoryProvider = categoryProvider;
        this.confirm = confirm;
        this.ref = ref;
        this.cdrFactoryService = cdrFactoryService;
        this.data = data;
        this.formGroup = new FormGroup({
            cdrArray: new FormArray([]),
        });
        this.ref.closeClicked().subscribe(async () => {
            if (!this.formGroup.dirty || (await this.confirm.confirmLeaveWithUnsavedChanges())) {
                this.ref.close(false);
            }
        });
    }
    get formArray() {
        return this.formGroup.controls.cdrArray;
    }
    async ngOnInit() {
        const schema = this.categoryProvider.serviceCategorySchema;
        const columnNames = [
            schema.Columns.Ident_AccProductGroup,
            schema.Columns.Description,
            schema.Columns.UID_OrgRuler,
            schema.Columns.UID_PWODecisionMethod,
            schema.Columns.UID_OrgAttestator,
            schema.Columns.JPegPhoto,
        ].map(elem => elem.ColumnName);
        this.cdrList = this.cdrFactoryService.buildCdrFromColumnList(this.data.serviceCategory, columnNames);
        if (!this.data.isNew) {
            this.cdrList.push(new BaseCdr(this.data.serviceCategory.GetColumn(schema.Columns.UID_AccProductGroupParent.ColumnName)));
        }
    }
    save() {
        this.ref.close(true);
    }
}
EditServiceCategoryInformationComponent.ɵfac = function EditServiceCategoryInformationComponent_Factory(t) { return new (t || EditServiceCategoryInformationComponent)(i0.ɵɵdirectiveInject(ServiceCategoryService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.CdrFactoryService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
EditServiceCategoryInformationComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditServiceCategoryInformationComponent, selectors: [["imx-edit-service-category-information"]], decls: 8, vars: 3, consts: [["eui-sidesheet-content", ""], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "data-imx-identifier", "edit-service-category-information-button-save", "color", "primary", 3, "disabled", "click"], ["translate", ""], [3, "cdr", "controlCreated"]], template: function EditServiceCategoryInformationComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "form", 1);
        i0.ɵɵtemplate(3, EditServiceCategoryInformationComponent_imx_cdr_editor_3_Template, 1, 2, "imx-cdr-editor", 2);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(4, "div", 3)(5, "button", 4);
        i0.ɵɵlistener("click", function EditServiceCategoryInformationComponent_Template_button_click_5_listener() { return ctx.save(); });
        i0.ɵɵelementStart(6, "span", 5);
        i0.ɵɵtext(7, "#LDS#Save");
        i0.ɵɵelementEnd()()();
    } if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("formGroup", ctx.formGroup);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx.cdrList);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", !ctx.formGroup.dirty || ctx.formGroup.invalid);
    } }, dependencies: [i5.NgForOf, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i7.MatButton, i6.MatCard, i8.ɵNgNoValidate, i8.NgControlStatusGroup, i2.CdrEditorComponent, i8.FormGroupDirective, i3$1.TranslateDirective] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditServiceCategoryInformationComponent, [{
        type: Component,
        args: [{ selector: 'imx-edit-service-category-information', template: "<div eui-sidesheet-content>\r\n  <mat-card>\r\n    <form [formGroup]=\"formGroup\">\r\n      <imx-cdr-editor\r\n        *ngFor=\"let cdr of cdrList\"\r\n        [cdr]=\"cdr\"\r\n        [attr.data-imx-identifier]=\"'edit-service-category-information-' + cdr.column.ColumName\"\r\n        (controlCreated)=\"formGroup.controls.cdrArray.push($event)\"\r\n      >\r\n      </imx-cdr-editor>\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n<div eui-sidesheet-actions>\r\n  <button [disabled]=\"!formGroup.dirty || formGroup.invalid\" mat-flat-button data-imx-identifier=\"edit-service-category-information-button-save\" color=\"primary\" (click)=\"save()\">\r\n    <span translate>#LDS#Save</span>\r\n  </button>\r\n</div>\r\n" }]
    }], function () { return [{ type: ServiceCategoryService }, { type: i2.ConfirmationService }, { type: i1$1.EuiSidesheetRef }, { type: i2.CdrFactoryService }, { type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$7 = ["dataTreeWrapper"];
function ServiceCategoryComponent_ng_template_4_button_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 6);
    i0.ɵɵlistener("click", function ServiceCategoryComponent_ng_template_4_button_1_Template_button_click_0_listener($event) { i0.ɵɵrestoreView(_r6); const entity_r2 = i0.ɵɵnextContext().$implicit; const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.onDelete($event, entity_r2)); });
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelement(3, "eui-icon", 7);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const entity_r2 = i0.ɵɵnextContext().$implicit;
    let tmp_2_0;
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(2, 5, "#LDS#Delete service category"));
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 3, "#LDS#Delete service category"))("data-imx-identifier", "service-category-delete-" + ((tmp_2_0 = entity_r2.GetKeys()) == null ? null : tmp_2_0.join(",")));
} }
function ServiceCategoryComponent_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, ServiceCategoryComponent_ng_template_4_button_1_Template, 4, 7, "button", 3);
    i0.ɵɵelementStart(2, "button", 4);
    i0.ɵɵlistener("click", function ServiceCategoryComponent_ng_template_4_Template_button_click_2_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r9); const entity_r2 = restoredCtx.$implicit; const ctx_r8 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r8.addChildCategory($event, entity_r2)); });
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelement(5, "eui-icon", 5);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const entity_r2 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext();
    let tmp_3_0;
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r1.isDeletable(entity_r2));
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(4, 6, "#LDS#Add child service category"));
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(3, 4, "#LDS#Add child service category"))("data-imx-identifier", "service-category-add-child-for-" + ((tmp_3_0 = entity_r2.GetKeys()) == null ? null : tmp_3_0.join(",")));
} }
class ServiceCategoryComponent {
    constructor(categoryService, settingsService, busyService, snackbar, sidesheet, translate, confirm, application) {
        this.categoryService = categoryService;
        this.settingsService = settingsService;
        this.busyService = busyService;
        this.snackbar = snackbar;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.confirm = confirm;
        this.application = application;
        this.initializeTree();
    }
    async onServiceCategorySelected(entity) {
        const oldParent = entity.GetColumn('UID_AccProductGroupParent').GetValue();
        const result = await this.editServiceCategory(entity, 'edit');
        if (result) {
            const overlay = this.busyService.show();
            try {
                await entity.Commit(true);
            }
            catch (exception) {
                await entity.DiscardChanges();
                throw exception;
            }
            finally {
                this.busyService.hide(overlay);
            }
            this.treeDatabase.updateNodeItem(entity);
            if (oldParent !== entity.GetColumn('UID_AccProductGroupParent').GetValue()) {
                this.tryToMoveElement(entity, entity.GetColumn('UID_AccProductGroupParent').GetValue());
                this.snackbar.open({ key: '#LDS#The changes have been successfully saved.' });
            }
        }
        else {
            await entity.DiscardChanges();
        }
    }
    async onDelete(evt, entity) {
        evt.stopPropagation();
        if (!(await this.confirm.confirmDelete('#LDS#Heading Delete Service Category', '#LDS#Are you sure you want to delete the service category?'))) {
            return;
        }
        const overlay = this.busyService.show();
        try {
            await this.categoryService.delete(entity.GetKeys()[0]);
        }
        finally {
            this.busyService.hide(overlay);
        }
        this.dataTreeWrapper.deleteNode(entity, false);
        this.snackbar.open({ key: '#LDS#The changes have been successfully saved.' });
    }
    async addChildCategory(evt, entity) {
        evt.stopPropagation();
        const newEntity = this.categoryService.createChild();
        newEntity.GetColumn('UID_AccProductGroupParent').PutValueStruct({ DataValue: entity.GetKeys()[0], DisplayValue: entity.GetDisplay() });
        const result = await this.editServiceCategory(newEntity, 'create');
        if (result) {
            const overlay = this.busyService.show();
            try {
                await newEntity.Commit(true);
            }
            finally {
                this.busyService.hide(overlay);
            }
            this.snackbar.open({ key: '#LDS#The changes have been successfully saved.' });
            this.add(entity, newEntity);
        }
        else {
            await entity.DiscardChanges();
        }
    }
    isDeletable(entity) {
        return TreeDatabase.getId(entity) !== this.application.UID_AccProductGroup.value && !this.dataTreeWrapper?.hasChildren(entity);
    }
    tryToMoveElement(entity, newParentId) {
        this.dataTreeWrapper.deleteNode(entity, true);
        const realParent = this.dataTreeWrapper.getEntityById(newParentId);
        if (realParent) {
            this.addToParent(realParent, entity);
        }
    }
    add(entity, newEntity) {
        const parentId = newEntity.GetColumn('UID_AccProductGroupParent').GetValue();
        if (parentId === entity.GetKeys()[0]) {
            // the new category was added as a child
            this.addToParent(entity, newEntity);
        }
        else {
            // the user updated  UID_AccProductGroupParent before saving, try to add a node to the real parent (onöy possible, if the new parent is rendered)
            const realParent = this.dataTreeWrapper.getEntityById(parentId);
            if (realParent) {
                this.addToParent(realParent, newEntity);
            }
        }
    }
    addToParent(entity, newEntity) {
        if (this.dataTreeWrapper.isExpanded(entity)) {
            this.dataTreeWrapper.add(newEntity, TreeDatabase.getId(entity));
        }
        else {
            this.dataTreeWrapper.updateNode(entity, { expandable: true });
            this.dataTreeWrapper.expandNode(entity);
        }
    }
    initializeTree() {
        this.treeDatabase = new ServiceCategoryTreeDatabase(this.busyService, this.settingsService, this.categoryService, this.application.UID_AccProductGroup.value);
        this.treeDatabase.initialized.subscribe(async () => {
            this.dataTreeWrapper.treeRendered.subscribe(() => {
                this.dataTreeWrapper.expandNode(this.treeDatabase.topLevelEntities[0]);
                this.treeDatabase.initialized.unsubscribe(); // can be unsubscribed again, because it only needed for initial loading
            });
        });
    }
    async editServiceCategory(serviceCategory, mode) {
        return await this.sidesheet
            .open(EditServiceCategoryInformationComponent, {
            title: await this.translate
                .get(mode === 'edit' ? '#LDS#Heading Edit Service Category' : '#LDS#Heading Create Service Category')
                .toPromise(),
            subTitle: mode === 'edit' ? serviceCategory.GetDisplay() : '',
            padding: '0px',
            width: 'max(650px, 65%)',
            disableClose: true,
            testId: mode === 'edit' ? 'edit-service-category' : 'create-service-category',
            data: { serviceCategory, isNew: mode === 'create' },
        })
            .afterClosed()
            .toPromise();
    }
}
ServiceCategoryComponent.ɵfac = function ServiceCategoryComponent_Factory(t) { return new (t || ServiceCategoryComponent)(i0.ɵɵdirectiveInject(ServiceCategoryService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
ServiceCategoryComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ServiceCategoryComponent, selectors: [["imx-service-category"]], viewQuery: function ServiceCategoryComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0$7, 7);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTreeWrapper = _t.first);
    } }, decls: 5, vars: 2, consts: [["eui-sidesheet-content", ""], ["data-imx-identifier", "service-category-data-tree-categorytree", 3, "database", "withSelectedNodeHighlight", "nodeSelected"], ["dataTreeWrapper", ""], ["mat-button", "", "color", "warn", "class", "mat-icon-button", 3, "matTooltip", "click", 4, "ngIf"], ["mat-button", "", "color", "primary", 1, "mat-icon-button", 3, "matTooltip", "click"], ["icon", "add"], ["mat-button", "", "color", "warn", 1, "mat-icon-button", 3, "matTooltip", "click"], ["icon", "delete"]], template: function ServiceCategoryComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "imx-data-tree-wrapper", 1, 2);
        i0.ɵɵlistener("nodeSelected", function ServiceCategoryComponent_Template_imx_data_tree_wrapper_nodeSelected_2_listener($event) { return ctx.onServiceCategorySelected($event); });
        i0.ɵɵtemplate(4, ServiceCategoryComponent_ng_template_4_Template, 6, 8, "ng-template");
        i0.ɵɵelementEnd()()();
    } if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("database", ctx.treeDatabase)("withSelectedNodeHighlight", false);
    } }, dependencies: [i5.NgIf, i1$1.EuiIconComponent, i1$1.EuiSidesheetContentDirective, i7.MatButton, i6.MatCard, i8$1.MatTooltip, i2.DataTreeWrapperComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ServiceCategoryComponent, [{
        type: Component,
        args: [{ selector: 'imx-service-category', template: "<div eui-sidesheet-content>\r\n  <mat-card>\r\n    <imx-data-tree-wrapper\r\n      #dataTreeWrapper\r\n      [database]=\"treeDatabase\"\r\n      [withSelectedNodeHighlight]=\"false\"\r\n      (nodeSelected)=\"onServiceCategorySelected($event)\"\r\n      data-imx-identifier=\"service-category-data-tree-categorytree\"\r\n    >\r\n      <ng-template let-entity>\r\n        <div>\r\n          <button *ngIf=\"isDeletable(entity)\"\r\n            [attr.aria-label]=\"'#LDS#Delete service category' | translate\"\r\n            [attr.data-imx-identifier]=\"'service-category-delete-' + entity.GetKeys()?.join(',')\"\r\n            [matTooltip]=\"'#LDS#Delete service category' | translate\"\r\n            mat-button color=\"warn\"\r\n            class=\"mat-icon-button\"\r\n            (click)=\"onDelete($event,entity)\"\r\n          >\r\n            <eui-icon icon=\"delete\"></eui-icon>\r\n          </button>\r\n           <button\r\n            [attr.aria-label]=\"'#LDS#Add child service category' | translate\"\r\n            [attr.data-imx-identifier]=\"'service-category-add-child-for-' + entity.GetKeys()?.join(',')\"\r\n            [matTooltip]=\"'#LDS#Add child service category' | translate\"\r\n            mat-button color=\"primary\"\r\n            class=\"mat-icon-button\"\r\n            (click)=\"addChildCategory($event,entity)\"\r\n          >\r\n            <eui-icon icon=\"add\"></eui-icon>\r\n          </button>\r\n        </div>\r\n      </ng-template>\r\n    </imx-data-tree-wrapper>\r\n  </mat-card>\r\n</div>\r\n", styles: [":host .eui-sidesheet-content{display:flex;flex-direction:column}:host .eui-sidesheet-content .mat-card{display:flex;flex-direction:column;flex:1 1 auto}\n"] }]
    }], function () { return [{ type: ServiceCategoryService }, { type: i2.SettingsService }, { type: i1$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i1$1.EuiSidesheetService }, { type: i3$1.TranslateService }, { type: i2.ConfirmationService }, { type: i13$2.PortalApplication, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }]; }, { dataTreeWrapper: [{
            type: ViewChild,
            args: ['dataTreeWrapper', { static: true }]
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ApplicationPropertyComponent_eui_icon_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 3);
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r0.icon);
} }
const _c0$6 = ["*"];
class ApplicationPropertyComponent {
}
ApplicationPropertyComponent.ɵfac = function ApplicationPropertyComponent_Factory(t) { return new (t || ApplicationPropertyComponent)(); };
ApplicationPropertyComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationPropertyComponent, selectors: [["imx-application-property"]], inputs: { display: "display", icon: "icon" }, ngContentSelectors: _c0$6, decls: 5, vars: 2, consts: [["class", "imx-user-icon", 3, "icon", 4, "ngIf"], [1, "imx-application-property"], [1, "imx-application-property-display"], [1, "imx-user-icon", 3, "icon"]], template: function ApplicationPropertyComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵprojectionDef();
        i0.ɵɵtemplate(0, ApplicationPropertyComponent_eui_icon_0_Template, 1, 1, "eui-icon", 0);
        i0.ɵɵelementStart(1, "div", 1);
        i0.ɵɵprojection(2);
        i0.ɵɵelementStart(3, "span", 2);
        i0.ɵɵtext(4);
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        i0.ɵɵproperty("ngIf", ctx.icon);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(ctx.display);
    } }, dependencies: [i5.NgIf, i1$1.EuiIconComponent], styles: ["[_nghost-%COMP%]{display:flex;align-items:center;justify-items:center;min-height:40px}.imx-user-icon[_ngcontent-%COMP%]{color:#2f3233;background-color:#c4cacc;opacity:.6;border-radius:50%;text-align:center;line-height:35px;min-width:35px;min-height:35px;margin-right:12px}.imx-application-property[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-application-property[_ngcontent-%COMP%]   .imx-application-property-display[_ngcontent-%COMP%]{font-size:12px;color:#aab0b3;font-weight:600;overflow:hidden;text-overflow:ellipsis}.eui-dark-theme   [_nghost-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{color:#c4cacc;background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .imx-user-icon[_ngcontent-%COMP%]{color:#dfe4e6;background-color:#000}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationPropertyComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-property', template: "<eui-icon *ngIf=\"icon\" [icon]=\"icon\" class='imx-user-icon'></eui-icon>\r\n<div class=\"imx-application-property\">\r\n  <ng-content></ng-content>\r\n  <span class=\"imx-application-property-display\">{{ display }}</span>\r\n</div>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;align-items:center;justify-items:center;min-height:40px}.imx-user-icon{color:#2f3233;background-color:#c4cacc;opacity:.6;border-radius:50%;text-align:center;line-height:35px;min-width:35px;min-height:35px;margin-right:12px}.imx-application-property{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-application-property .imx-application-property-display{font-size:12px;color:#aab0b3;font-weight:600;overflow:hidden;text-overflow:ellipsis}.eui-dark-theme :host .imx-user-icon{color:#c4cacc;background-color:#2f3233}.eui-contrast-theme :host .imx-user-icon{color:#dfe4e6;background-color:#000}\n"] }]
    }], null, { display: [{
            type: Input
        }], icon: [{
            type: Input
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ColumnInfoComponent {
}
ColumnInfoComponent.ɵfac = function ColumnInfoComponent_Factory(t) { return new (t || ColumnInfoComponent)(); };
ColumnInfoComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ColumnInfoComponent, selectors: [["imx-column-info"]], inputs: { property: "property", icon: "icon", placeholder: "placeholder" }, decls: 5, vars: 5, consts: [[3, "display", "icon"], [1, "imx-user-properties"]], template: function ColumnInfoComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-application-property", 0)(1, "div", 1)(2, "span");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd()()();
    } if (rf & 2) {
        i0.ɵɵproperty("display", ctx.property == null ? null : ctx.property.Column.GetMetadata().GetDisplay())("icon", ctx.icon);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate((ctx.property == null ? null : ctx.property.Column.GetDisplayValue()) || "-" + (ctx.placeholder || i0.ɵɵpipeBind1(4, 3, "#LDS#Not set")) + "-");
    } }, dependencies: [ApplicationPropertyComponent, i3$1.TranslatePipe], styles: [".imx-user-properties[_ngcontent-%COMP%]{overflow:hidden;text-overflow:ellipsis}.imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-weight:600;color:#616566}.eui-dark-theme   [_nghost-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-user-properties[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#fff}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ColumnInfoComponent, [{
        type: Component,
        args: [{ selector: 'imx-column-info', template: "<imx-application-property [display]=\"property?.Column.GetMetadata().GetDisplay()\" [icon]=\"icon\">\r\n  <div class=\"imx-user-properties\">\r\n    <span>{{ property?.Column.GetDisplayValue() || ('-' + (placeholder || ('#LDS#Not set' | translate)) + '-') }}</span>\r\n  </div>\r\n</imx-application-property>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.imx-user-properties{overflow:hidden;text-overflow:ellipsis}.imx-user-properties>span{font-weight:600;color:#616566}.eui-dark-theme :host .imx-user-properties>span{color:#dfe4e6}.eui-contrast-theme :host .imx-user-properties>span{color:#fff}\n"] }]
    }], null, { property: [{
            type: Input
        }], icon: [{
            type: Input
        }], placeholder: [{
            type: Input
        }] }); })();

const _c0$5 = ["multiValueControl"];
function ApplicationDetailsComponent_imx_busy_indicator_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-busy-indicator");
} }
function ApplicationDetailsComponent_span_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate("-" + i0.ɵɵpipeBind1(2, 1, "#LDS#None assigned") + "-");
} }
function ApplicationDetailsComponent_span_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(ctx_r2.assignedShops[0].GetEntity().GetDisplay());
} }
function ApplicationDetailsComponent_button_16_Template(rf, ctx) { if (rf & 1) {
    const _r15 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 26);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_button_16_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r15); const ctx_r14 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r14.showMore(ctx_r14.assignedShops, ctx_r14.shopsDisplay, "library")); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "ldsReplace");
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(2, 1, i0.ɵɵpipeBind1(3, 4, "#LDS#and {0} more..."), ctx_r3.assignedShops.length - 1), " ");
} }
function ApplicationDetailsComponent_span_24_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 27);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Not published"));
} }
function ApplicationDetailsComponent_span_25_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵelement(1, "eui-icon", 29);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Will be published"), " ");
} }
function ApplicationDetailsComponent_span_26_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 30)(1, "mat-icon", 18);
    i0.ɵɵtext(2, "check_circle");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 1, "#LDS#Published"), " ");
} }
function ApplicationDetailsComponent_div_27_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 31)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "shortDate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r7 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, ctx_r7.application.ActivationDate.value));
} }
function ApplicationDetailsComponent_span_89_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate("-" + i0.ɵɵpipeBind1(2, 1, "#LDS#None selected") + "-");
} }
function ApplicationDetailsComponent_span_90_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r9 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(ctx_r9.accountsInformation.first.GetEntity().GetDisplay());
} }
function ApplicationDetailsComponent_button_91_Template(rf, ctx) { if (rf & 1) {
    const _r17 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 32);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_button_91_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r17); const ctx_r16 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r16.showMoreAccounts()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "ldsReplace");
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r10 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(2, 1, i0.ɵɵpipeBind1(3, 4, "#LDS#and {0} more..."), ctx_r10.accountsInformation.count - 1), " ");
} }
function ApplicationDetailsComponent_mat_card_103_Template(rf, ctx) { if (rf & 1) {
    const _r20 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 33)(1, "button", 34)(2, "eui-icon", 35);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_eui_icon_click_2_listener($event) { i0.ɵɵrestoreView(_r20); const ctx_r19 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r19.menuClicked($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "mat-menu", null, 36)(7, "button", 37);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_7_listener($event) { i0.ɵɵrestoreView(_r20); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.publishApplication($event)); });
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(10, "button", 38);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_10_listener($event) { i0.ɵɵrestoreView(_r20); const ctx_r22 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r22.unpublishApplication($event)); });
    i0.ɵɵtext(11);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "button", 39);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_13_listener() { i0.ɵɵrestoreView(_r20); const ctx_r23 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r23.editServiceCategories()); });
    i0.ɵɵtext(14);
    i0.ɵɵpipe(15, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(16, "button", 40);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_16_listener() { i0.ɵɵrestoreView(_r20); const ctx_r24 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r24.deleteApplication()); });
    i0.ɵɵpipe(17, "translate");
    i0.ɵɵelement(18, "eui-icon", 41);
    i0.ɵɵtext(19);
    i0.ɵɵpipe(20, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(21, "button", 42);
    i0.ɵɵlistener("click", function ApplicationDetailsComponent_mat_card_103_Template_button_click_21_listener() { i0.ɵɵrestoreView(_r20); const ctx_r25 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r25.editApplication()); });
    i0.ɵɵpipe(22, "translate");
    i0.ɵɵelement(23, "eui-icon", 43);
    i0.ɵɵtext(24);
    i0.ɵɵpipe(25, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const _r18 = i0.ɵɵreference(6);
    const ctx_r11 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("matMenuTriggerFor", _r18);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 12, "#LDS#Actions"), " ");
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("disabled", !ctx_r11.isPublishable);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 14, "#LDS#Publish"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r11.isUnpublishable);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 16, "#LDS#Unpublish"), " ");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(15, 18, "#LDS#Edit service categories"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", !ctx_r11.canBeDeleted);
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(17, 20, "#LDS#Delete application"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(20, 22, "#LDS#Delete"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(22, 24, "#LDS#Edit Application"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(25, 26, "#LDS#Edit"), " ");
} }
function ApplicationDetailsComponent_ng_template_104_li_4_eui_icon_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 51);
} if (rf & 2) {
    const data_r26 = i0.ɵɵnextContext(2).$implicit;
    i0.ɵɵproperty("icon", data_r26.icon);
} }
function ApplicationDetailsComponent_ng_template_104_li_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "li", 48)(1, "mat-card");
    i0.ɵɵtemplate(2, ApplicationDetailsComponent_ng_template_104_li_4_eui_icon_2_Template, 1, 1, "eui-icon", 49);
    i0.ɵɵelementStart(3, "mat-card-title", 50);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const content_r28 = ctx.$implicit;
    const data_r26 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵattribute("data-imx-identifier", "imx-application-details-" + data_r26.caption + "-" + content_r28);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", data_r26.icon);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(content_r28);
} }
function ApplicationDetailsComponent_ng_template_104_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 44);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "mat-dialog-content")(3, "ul");
    i0.ɵɵtemplate(4, ApplicationDetailsComponent_ng_template_104_li_4_Template, 5, 3, "li", 45);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(5, "mat-dialog-actions", 46)(6, "button", 47);
    i0.ɵɵtext(7);
    i0.ɵɵpipe(8, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r26 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r26.caption);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngForOf", data_r26.parts);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 3, "#LDS#Close"));
} }
const _c1$4 = function (a0) { return { hidden: a0 }; };
class ApplicationDetailsComponent {
    constructor(entitlementsProvider, shopsProvider, euiBusyService, logger, accountsProvider, dialog, applicationprovider, snackbar, platform, aobApiService, translateService, confirmation, sidesheetService, permissions) {
        this.entitlementsProvider = entitlementsProvider;
        this.shopsProvider = shopsProvider;
        this.euiBusyService = euiBusyService;
        this.logger = logger;
        this.accountsProvider = accountsProvider;
        this.dialog = dialog;
        this.applicationprovider = applicationprovider;
        this.snackbar = snackbar;
        this.platform = platform;
        this.aobApiService = aobApiService;
        this.translateService = translateService;
        this.confirmation = confirmation;
        this.sidesheetService = sidesheetService;
        this.permissions = permissions;
        this.hasPublishedEntitlements = false;
        this.canBeDeleted = false;
        this.assignedShops = [];
        this.busyService = new BusyService();
        this.shopsDisplay = this.aobApiService.typedClient.PortalShops.GetSchema().Display;
        this.accountsDisplay = this.aobApiService.typedClient.PortalApplicationusesaccount.GetSchema().Display;
        this.busyService.busyStateChanged.subscribe((elem) => (this.isLoading = elem));
    }
    ngOnInit() {
        this.accountsInformation = {
            count: 0,
            first: null,
            uidApplication: this.application.UID_AOBApplication.value,
        };
    }
    async ngOnChanges() {
        return this.reloadData();
    }
    /**
     * Deletes the displayed application, after confirming the process by the user
     */
    async deleteApplication() {
        if (await this.confirmation.confirm({
            Title: '#LDS#Heading Delete Application',
            Message: '#LDS#Are you sure you want to delete the application?',
        })) {
            let overlayRef;
            setTimeout(() => ((overlayRef = this.euiBusyService.show())));
            try {
                await this.applicationprovider.deleteApplication(this.application.UID_AOBApplication.value);
            }
            finally {
                setTimeout(() => this.euiBusyService.hide(overlayRef));
            }
        }
    }
    /**
     * Edits the information of the associated application
     */
    async editApplication() {
        await this.sidesheetService
            .open(EditApplicationComponent, {
            title: await this.translateService.get('#LDS#Heading Edit Application').toPromise(),
            subTitle: this.application.GetEntity().GetDisplay(),
            width: '768px',
            padding: '0',
            data: this.application,
            testId: 'edit-application',
            disableClose: true,
        })
            .afterClosed()
            .toPromise();
        this.applicationprovider.applicationRefresh.next(true);
        this.application = await this.applicationprovider.reload(this.application.UID_AOBApplication.value);
        this.reloadData();
    }
    /**
     * Opens a dialog for publishing the application
     * @ignore @param _ unused mouse event
     */
    async publishApplication(_) {
        if (await this.updateShops()) {
            const dialogConfig = {
                data: {
                    action: LifecycleAction.Publish,
                    elements: [this.application],
                    shops: this.assignedShops,
                    type: 'AobApplication',
                },
                height: this.platform.TRIDENT ? '550px' : 'auto',
            };
            const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
            dialogRef.afterClosed().subscribe(async (publishData) => {
                if (publishData) {
                    this.logger.debug(this, `Publishing application) ${publishData.date && publishData.publishFuture ? `on ${publishData.date}` : 'now'}`);
                    if (await this.applicationprovider.publish(this.application, publishData)) {
                        let publishMessage = {
                            key: '#LDS#The application was successfully published. It takes a moment for the changes to take effect.',
                        };
                        if (publishData.publishFuture && publishData.date) {
                            const browserCulture = this.translateService.currentLang;
                            publishMessage = {
                                key: '#LDS#The application will be published on {0} at {1} (your local time).',
                                parameters: [publishData.date.toLocaleDateString(browserCulture), publishData.date.toLocaleTimeString(browserCulture)],
                            };
                        }
                        this.snackbar.open(publishMessage, '#LDS#Close');
                    }
                    else {
                        this.logger.error(this, 'Attempt to publish the application failed');
                    }
                }
                else {
                    this.logger.debug(this, 'dialog Cancel');
                }
            });
        }
    }
    /**
     * Opens a dialog for unpublishing the application
     * @ignore @param _ unused mouse event
     */
    unpublishApplication(_) {
        const dialogConfig = {
            data: { action: LifecycleAction.Unpublish, elements: [this.application], type: 'AobApplication' },
            width: '800px',
            height: '500px',
        };
        const dialogRef = this.dialog.open(LifecycleActionComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(async (result) => {
            if (result) {
                this.logger.debug(this, 'Unpublish application...');
                if (await this.applicationprovider.unpublish(this.application)) {
                    this.snackbar.open({ key: '#LDS#The application was successfully unpublished. It takes a moment for the changes to take effect.' }, '#LDS#Close');
                }
                else {
                    this.logger.error(this, 'Attempt to unpublish the  application failed');
                }
            }
            else {
                this.logger.debug(this, 'dialog Cancel');
            }
        });
    }
    /**
     * Checks if the specified  {@link PortalApplication|application} can be publish.
     */
    get isPublishable() {
        return this.application != null && this.application.ActivationDate.GetMetadata().CanEdit() && !this.published();
    }
    /**
     * Checks if the specified  {@link PortalApplication|application} can be unnpublish.
     */
    get isUnpublishable() {
        return this.application != null && this.application.IsInActive.GetMetadata().CanEdit() && !this.notPublished();
    }
    // TODO 222863: Use the same filter as for entitlements:
    notPublished() {
        return this.application.IsInActive && this.application.IsInActive.value && !this.application.ActivationDate.value;
    }
    willPublish() {
        return this.application.IsInActive && this.application.IsInActive.value && this.application.ActivationDate.value != null;
    }
    published() {
        return !this.application.IsInActive.value;
    }
    /**
     * Opens/Closes the menu programmatically and stopps propagation of the event.
     * Otherwise the tile would be selected/deselcted as a sideeffect.
     * @ignore Used internally in components template.
     */
    menuClicked(event) {
        this.menuTrigger.toggleMenu();
        event.stopImmediatePropagation();
    }
    /**
     *
     * @param elements Opens a dialog, that shows additional elements (because in the beginning there are only 3 elements displayed)
     * @param title A title for the dialog
     * @param iconText name of a cadence icon, that should be used
     */
    showMore(elements, title, iconText) {
        const content = { parts: elements.map((part) => part.GetEntity().GetDisplay()), caption: title, icon: iconText };
        this.dialog.open(this.chartDialog, { data: content, width: '600px', height: '400px' });
    }
    /**
     * Shows a dialog, that displays additionals accounts (because in the beginning there are only 3 elements displayed)
     */
    async showMoreAccounts() {
        let overlayRef;
        setTimeout(() => ((overlayRef = this.euiBusyService.show())));
        try {
            const elements = await this.accountsProvider.getAssigned(this.application.UID_AOBApplication.value, {
                PageSize: this.accountsInformation.count,
            });
            this.showMore(elements, this.accountsDisplay);
        }
        finally {
            setTimeout(() => this.euiBusyService.hide(overlayRef));
        }
    }
    async editServiceCategories() {
        await this.sidesheetService
            .open(ServiceCategoryComponent, {
            title: await this.translateService.get('#LDS#Heading Edit Service Categories').toPromise(),
            subTitle: this.application.GetEntity().GetDisplay(),
            width: 'max(700px,70%)',
            padding: '0',
            data: this.application,
            testId: 'edit-application-servicecategory'
        })
            .afterClosed()
            .toPromise();
    }
    async reloadData() {
        const isBusy = this.busyService.beginBusy();
        try {
            if (this.application.AuthenticationRoot.value) {
                this.application.AuthenticationRootHelper.value = this.application.AuthenticationRoot.value;
            }
            this.hasOwner = this.application.UID_PersonHead.value != null && this.application.UID_PersonHead.value !== '';
            await this.updateShops();
            const accountInfo = await this.accountsProvider.getFirstAndCount(this.application.UID_AOBApplication.value);
            this.accountsInformation = {
                ...this.accountsInformation,
                ...{ count: accountInfo.count, first: accountInfo.first },
                ...{ count: accountInfo.count, first: accountInfo.first },
            };
            const applicationEntitlements = await this.entitlementsProvider.getEntitlementsForApplication(this.application);
            if (applicationEntitlements) {
                const entitlementFilter = new EntitlementFilter();
                this.hasPublishedEntitlements = applicationEntitlements.Data.filter(entitlementFilter.published).length > 0;
                this.hasAssignedEntitlements = applicationEntitlements.Data.length > 0;
                const publishedAndWillBePublished = applicationEntitlements.Data.filter((elem) => entitlementFilter.published(elem) || entitlementFilter.willPublish(elem));
                this.canBeDeleted = (await this.permissions.isAobApplicationAdmin()) && publishedAndWillBePublished.length === 0;
            }
            else {
                this.logger.error(this, 'TypedEntityCollectionData<PortalEntitlement> is undefined');
            }
        }
        finally {
            isBusy.endBusy();
        }
    }
    async updateShops() {
        const appInShop = await this.shopsProvider.getApplicationInShop(this.application.UID_AOBApplication.value);
        if (appInShop == null) {
            this.logger.error(this, 'TypedEntityCollectionData<AobApplicationinshop> is undefined');
            return false;
        }
        this.assignedShops = appInShop.Data;
        return true;
    }
}
ApplicationDetailsComponent.ɵfac = function ApplicationDetailsComponent_Factory(t) { return new (t || ApplicationDetailsComponent)(i0.ɵɵdirectiveInject(EntitlementsService), i0.ɵɵdirectiveInject(ShopsService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i5$1.Platform), i0.ɵɵdirectiveInject(AobApiService), i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(AobPermissionsService)); };
ApplicationDetailsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationDetailsComponent, selectors: [["imx-application-details"]], viewQuery: function ApplicationDetailsComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0$5, 7);
        i0.ɵɵviewQuery(MatMenuTrigger, 5);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.chartDialog = _t.first);
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.menuTrigger = _t.first);
    } }, inputs: { application: "application" }, features: [i0.ɵɵNgOnChangesFeature], decls: 106, vars: 91, consts: [[1, "imx-application-details-content"], [4, "ngIf"], [1, "imx-application-details-grid", 3, "ngClass"], [1, "imx-application-properties", "mat-elevation-z0"], [3, "inset"], ["icon", "serviceaccount", 3, "placeholder", "property"], ["icon", "user", 3, "property"], ["icon", "library", 3, "display"], [1, "imx-application-property-multi"], ["mat-button", "", "color", "primary", "data-imx-identifier", "imx-application-details-button-show-more-shops", 3, "click", 4, "ngIf"], [1, "imx-application-state", "mat-elevation-z0"], [1, "imx-application-publish", "mat-elevation-z0"], ["class", "imx-application-unpublished-state", 4, "ngIf"], ["class", "imx-application-willbepublished-state", 4, "ngIf"], ["class", "imx-application-published-state", 4, "ngIf"], ["class", "imx-application-publish-date", 4, "ngIf"], [1, "imx-application-progress", "mat-elevation-z0"], [1, "imx-application-progress-step"], ["icon", "check"], [1, "cdk-visually-hidden"], [1, "imx-application-additionalDetails", "mat-elevation-z0"], [3, "property"], [3, "display"], ["mat-button", "", "color", "primary", "data-imx-identifier", "imx-application-details-button-load-more-accounts", 3, "click", 4, "ngIf"], ["class", "imx-button-area mat-elevation-z0", 4, "ngIf"], ["multiValueControl", ""], ["mat-button", "", "color", "primary", "data-imx-identifier", "imx-application-details-button-show-more-shops", 3, "click"], [1, "imx-application-unpublished-state"], [1, "imx-application-willbepublished-state"], ["icon", "restore", "size", "14px"], [1, "imx-application-published-state"], [1, "imx-application-publish-date"], ["mat-button", "", "color", "primary", "data-imx-identifier", "imx-application-details-button-load-more-accounts", 3, "click"], [1, "imx-button-area", "mat-elevation-z0"], ["mat-stroked-button", "", "data-imx-identifier", "imx-application-details-button-menu", 1, "imx-additional-actions", 3, "matMenuTriggerFor"], ["icon", "ellipsisvertical", 3, "click"], ["menu", "matMenu"], ["mat-menu-item", "", "data-imx-identifier", "imx-application-details-button-publish-application", 3, "disabled", "click"], ["mat-menu-item", "", "data-imx-identifier", "imx-application-details-button-unpublish-application", 3, "disabled", "click"], ["data-imx-identifier", "imx-application-details-edit-servicecategories", "mat-menu-item", "", 3, "click"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "imx-application-details-button-delete-application", 3, "disabled", "click"], ["icon", "delete"], ["color", "primary", "mat-raised-button", "", "data-imx-identifier", "imx-application-details-button-edit-application", 3, "click"], ["icon", "edit"], ["mat-dialog-title", ""], ["class", "imx-multivalue-item", 4, "ngFor", "ngForOf"], ["align", "end"], ["data-imx-identifier", "imx-application-details-button-close-list", "mat-raised-button", "", "color", "primary", "mat-dialog-close", ""], [1, "imx-multivalue-item"], ["mat-card-avatar", "", "size", "16px", 3, "icon", 4, "ngIf"], [1, "imx-card-title"], ["mat-card-avatar", "", "size", "16px", 3, "icon"]], template: function ApplicationDetailsComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0);
        i0.ɵɵtemplate(1, ApplicationDetailsComponent_imx_busy_indicator_1_Template, 1, 0, "imx-busy-indicator", 1);
        i0.ɵɵelementStart(2, "div", 2)(3, "mat-card", 3)(4, "mat-card-title");
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(7, "mat-divider", 4);
        i0.ɵɵelementStart(8, "mat-card-content");
        i0.ɵɵelement(9, "imx-column-info", 5);
        i0.ɵɵpipe(10, "translate");
        i0.ɵɵelement(11, "imx-column-info", 6);
        i0.ɵɵelementStart(12, "imx-application-property", 7)(13, "div", 8);
        i0.ɵɵtemplate(14, ApplicationDetailsComponent_span_14_Template, 3, 3, "span", 1);
        i0.ɵɵtemplate(15, ApplicationDetailsComponent_span_15_Template, 2, 1, "span", 1);
        i0.ɵɵtemplate(16, ApplicationDetailsComponent_button_16_Template, 4, 6, "button", 9);
        i0.ɵɵelementEnd()()()();
        i0.ɵɵelementStart(17, "mat-card", 10)(18, "mat-card", 11)(19, "mat-card-title");
        i0.ɵɵtext(20);
        i0.ɵɵpipe(21, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(22, "mat-divider", 4);
        i0.ɵɵelementStart(23, "mat-card-content");
        i0.ɵɵtemplate(24, ApplicationDetailsComponent_span_24_Template, 3, 3, "span", 12);
        i0.ɵɵtemplate(25, ApplicationDetailsComponent_span_25_Template, 4, 3, "span", 13);
        i0.ɵɵtemplate(26, ApplicationDetailsComponent_span_26_Template, 5, 3, "span", 14);
        i0.ɵɵtemplate(27, ApplicationDetailsComponent_div_27_Template, 4, 3, "div", 15);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(28, "mat-card", 16)(29, "mat-card-title");
        i0.ɵɵtext(30);
        i0.ɵɵpipe(31, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(32, "mat-divider", 4);
        i0.ɵɵelementStart(33, "mat-card-content")(34, "div", 17)(35, "mat-icon", 18);
        i0.ɵɵtext(36, "check_circle");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(37, "span", 19);
        i0.ɵɵtext(38);
        i0.ɵɵpipe(39, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(40, "span");
        i0.ɵɵtext(41);
        i0.ɵɵpipe(42, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(43, "div", 17)(44, "mat-icon", 18);
        i0.ɵɵtext(45, "check_circle");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(46, "span", 19);
        i0.ɵɵtext(47);
        i0.ɵɵpipe(48, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(49, "span");
        i0.ɵɵtext(50);
        i0.ɵɵpipe(51, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(52, "div", 17)(53, "mat-icon", 18);
        i0.ɵɵtext(54, "check_circle");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(55, "span", 19);
        i0.ɵɵtext(56);
        i0.ɵɵpipe(57, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(58, "span");
        i0.ɵɵtext(59);
        i0.ɵɵpipe(60, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(61, "div", 17)(62, "mat-icon", 18);
        i0.ɵɵtext(63, "check_circle");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(64, "span", 19);
        i0.ɵɵtext(65);
        i0.ɵɵpipe(66, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(67, "span");
        i0.ɵɵtext(68);
        i0.ɵɵpipe(69, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(70, "div", 17)(71, "mat-icon", 18);
        i0.ɵɵtext(72, "check_circle");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(73, "span", 19);
        i0.ɵɵtext(74);
        i0.ɵɵpipe(75, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(76, "span");
        i0.ɵɵtext(77);
        i0.ɵɵpipe(78, "translate");
        i0.ɵɵelementEnd()()()()();
        i0.ɵɵelementStart(79, "mat-card", 20)(80, "mat-card-title");
        i0.ɵɵtext(81);
        i0.ɵɵpipe(82, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(83, "mat-divider", 4);
        i0.ɵɵelementStart(84, "mat-card-content");
        i0.ɵɵelement(85, "imx-column-info", 21)(86, "imx-column-info", 21);
        i0.ɵɵelementStart(87, "imx-application-property", 22)(88, "div", 8);
        i0.ɵɵtemplate(89, ApplicationDetailsComponent_span_89_Template, 3, 3, "span", 1);
        i0.ɵɵtemplate(90, ApplicationDetailsComponent_span_90_Template, 2, 1, "span", 1);
        i0.ɵɵtemplate(91, ApplicationDetailsComponent_button_91_Template, 4, 6, "button", 23);
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(92, "imx-column-info", 21)(93, "imx-column-info", 21)(94, "imx-column-info", 21)(95, "imx-column-info", 21)(96, "imx-column-info", 21)(97, "imx-column-info", 21)(98, "imx-column-info", 21)(99, "imx-column-info", 21)(100, "imx-column-info", 21)(101, "imx-column-info", 21)(102, "imx-column-info", 21);
        i0.ɵɵelementEnd()()()();
        i0.ɵɵtemplate(103, ApplicationDetailsComponent_mat_card_103_Template, 26, 28, "mat-card", 24);
        i0.ɵɵtemplate(104, ApplicationDetailsComponent_ng_template_104_Template, 9, 5, "ng-template", null, 25, i0.ɵɵtemplateRefExtractor);
    } if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.isLoading);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(89, _c1$4, ctx.isLoading));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 59, "#LDS#General"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("inset", true);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("placeholder", i0.ɵɵpipeBind1(10, 61, "#LDS#Is being computed"))("property", ctx.application.UID_AccProductGroup);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("property", ctx.application.UID_AERoleOwner);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("display", ctx.shopsDisplay);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", !ctx.assignedShops.length);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.assignedShops.length);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.assignedShops.length > 1);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(21, 63, "#LDS#Publication status"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("inset", true);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.notPublished());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.willPublish());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.published());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.willPublish());
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(31, 65, "#LDS#Progress"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("inset", true);
        i0.ɵɵadvance(2);
        i0.ɵɵclassProp("checked", ctx.application);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(39, 67, ctx.application ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(42, 69, "#LDS#Application created"));
        i0.ɵɵadvance(2);
        i0.ɵɵclassProp("checked", ctx.hasOwner);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(48, 71, ctx.hasOwner ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(51, 73, "#LDS#Manager assigned"));
        i0.ɵɵadvance(2);
        i0.ɵɵclassProp("checked", (ctx.assignedShops == null ? null : ctx.assignedShops.length) > 0);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(57, 75, (ctx.assignedShops == null ? null : ctx.assignedShops.length) > 0 ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(60, 77, "#LDS#Shop assigned"));
        i0.ɵɵadvance(2);
        i0.ɵɵclassProp("checked", ctx.hasAssignedEntitlements);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(66, 79, ctx.hasAssignedEntitlements ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(69, 81, "#LDS#Application entitlements assigned"));
        i0.ɵɵadvance(2);
        i0.ɵɵclassProp("checked", ctx.hasPublishedEntitlements);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(75, 83, ctx.hasPublishedEntitlements ? "#LDS#ScreenReader_Checked" : "#LDS#ScreenReader_Unchecked"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(78, 85, "#LDS#Application entitlements published"));
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(82, 87, "#LDS#Additional details"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("inset", true);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("property", ctx.application.UID_PersonHead);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.UID_AERoleApprover);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("display", ctx.accountsDisplay);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.accountsInformation.count === 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.accountsInformation.count > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.accountsInformation.count > 1);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.ApplicationEnvironment);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.ApplicationWebURL);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.AuthenticationRoot);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.IsAuthenticationIntegrated);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.IsFederationEnabled);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.IsMultiFactorEnabled);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.IsSSOEnabled);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.SSORedirectionUrl);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.PurchasedLicenses);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.RiskIndex);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("property", ctx.application.UID_FunctionalArea);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.application && !ctx.isLoading);
    } }, dependencies: [i5.NgClass, i5.NgForOf, i5.NgIf, ApplicationPropertyComponent, ColumnInfoComponent, i1$1.EuiIconComponent, i7.MatButton, i6.MatCard, i6.MatCardContent, i6.MatCardTitle, i6.MatCardAvatar, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogContent, i1$2.MatDialogActions, i12$1.MatDivider, i4.MatIcon, i13$1.MatMenu, i13$1.MatMenuItem, i13$1.MatMenuTrigger, i2.BusyIndicatorComponent, i2.LdsReplacePipe, i2.ShortDatePipe, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto;min-height:100%}[_nghost-%COMP%]   .imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid.hidden[_ngcontent-%COMP%]{display:none}.imx-application-details-content[_ngcontent-%COMP%]{display:flex;overflow:hidden;flex:1 1 auto}.imx-application-details-content[_ngcontent-%COMP%]   imx-busy-indicator[_ngcontent-%COMP%]{flex:0 0 0}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;padding:16px 24px;overflow:auto;max-width:1500px;max-height:800px}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%] > .mat-card[_ngcontent-%COMP%]{background-color:transparent}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]   .mat-card-title[_ngcontent-%COMP%]{font-size:18px;line-height:36px}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]   .mat-button[_ngcontent-%COMP%]{vertical-align:middle;padding:0 2px;min-width:0;margin-left:5px}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]   .mat-button[_ngcontent-%COMP%]     .mat-button-wrapper{vertical-align:text-bottom}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]   .mat-button[hidden][_ngcontent-%COMP%]{display:none}.imx-application-details-content[_ngcontent-%COMP%]   .imx-application-details-grid[_ngcontent-%COMP%]   .mat-divider-horizontal[_ngcontent-%COMP%]{width:50px;margin-bottom:12px}.imx-application-properties[_ngcontent-%COMP%]{flex:0 0 33%;min-width:200px;box-shadow:none}.imx-application-properties[_ngcontent-%COMP%]   .mat-card-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;margin-bottom:-15px}.imx-application-properties[_ngcontent-%COMP%]   .mat-card-content[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{margin-bottom:15px}.imx-button-area[_ngcontent-%COMP%]{background-color:transparent;display:flex;flex-direction:row;justify-content:flex-end}.imx-button-area[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto;justify-self:start}.imx-button-area[_ngcontent-%COMP%]   .imx-additional-actions[_ngcontent-%COMP%]{margin-right:5px;margin-left:5px}.imx-button-area[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%], .imx-button-area[_ngcontent-%COMP%]   .mat-raised-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.imx-button-area[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:16px}.imx-application-property-multi[_ngcontent-%COMP%]{display:flex;flex-direction:column}.imx-application-property-multi[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-weight:600;overflow:hidden;text-overflow:ellipsis}.imx-application-property-multi[_ngcontent-%COMP%] > .mat-button[_ngcontent-%COMP%]{width:auto;padding:0;line-height:1.3rem;align-self:flex-start}li[_ngcontent-%COMP%]{list-style-type:none;margin:10px}li[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{display:flex;flex-direction:row;height:3.2rem}li[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%] > .imx-card-title[_ngcontent-%COMP%]{font-size:16px;flex:1;margin-left:10px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.mat-dialog-content[_ngcontent-%COMP%]{flex:1;display:flex;flex-direction:column;height:inherit}.imx-application-state[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;flex:0 0 64%;align-content:flex-start;box-shadow:none;padding:0}.imx-application-state[_ngcontent-%COMP%] > .mat-card[_ngcontent-%COMP%]{background-color:transparent}.imx-application-publish[_ngcontent-%COMP%]{flex:0 0 51%;min-width:220px;box-shadow:none;padding-left:5px;padding-right:0}.imx-application-publish[_ngcontent-%COMP%]   .mat-card-content[_ngcontent-%COMP%]{display:flex;align-items:center}.imx-application-publish[_ngcontent-%COMP%]   .mat-chip[_ngcontent-%COMP%]{border-radius:3px;width:max-content;-webkit-user-select:none;user-select:none}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]{font-weight:600;font-size:12px;display:flex;align-items:center}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{margin-right:6px}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]{font-weight:600;font-size:12px;display:flex;align-items:center}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%], .imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{margin-right:6px}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{font-size:14px;width:14px;height:14px}.imx-application-publish[_ngcontent-%COMP%]   .imx-application-publish-date[_ngcontent-%COMP%]{margin-left:10px;font-size:14px}.imx-application-progress[_ngcontent-%COMP%]{flex:0 0 48%;box-shadow:none;padding-left:0;padding-right:0}.imx-application-progress[_ngcontent-%COMP%]   .mat-card-title[_ngcontent-%COMP%]{line-height:45px}.imx-application-progress[_ngcontent-%COMP%]   .imx-application-progress-step[_ngcontent-%COMP%]{margin-bottom:8px}.imx-application-progress[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{margin-right:5px;font-size:16px;width:16px;height:16px;visibility:hidden}.imx-application-progress[_ngcontent-%COMP%]   .checked[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{visibility:visible}.imx-application-progress[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:14px}.imx-application-progress[_ngcontent-%COMP%]   .mat-card-content[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:flex;align-items:center}.imx-application-additionalDetails[_ngcontent-%COMP%]{flex:0 0 100%;box-shadow:none;overflow:hidden}.imx-application-additionalDetails[_ngcontent-%COMP%]   .mat-card-title[_ngcontent-%COMP%]{line-height:45px}.imx-application-additionalDetails[_ngcontent-%COMP%]   .mat-card-content[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap}.imx-application-additionalDetails[_ngcontent-%COMP%]   .mat-card-content[_ngcontent-%COMP%]   imx-column-info[_ngcontent-%COMP%], .imx-application-additionalDetails[_ngcontent-%COMP%]   .mat-card-content[_ngcontent-%COMP%]   imx-application-property[_ngcontent-%COMP%]{flex:0 0 33%;min-width:200px;padding-right:21px}.imx-multivalue-item[_ngcontent-%COMP%]{margin:10px 0}.mat-card-avatar[_ngcontent-%COMP%]{padding:5px;height:25px;width:25px;-webkit-user-select:none;user-select:none}[_nghost-%COMP%]     body .mat-dialog-container{display:flex;flex-direction:column}[_nghost-%COMP%]   .imx-application-property-multi[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#616566}[_nghost-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%], [_nghost-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]{color:#e36a00}[_nghost-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]{color:#4ba803}[_nghost-%COMP%]   .imx-application-progress[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{color:#4ba803}[_nghost-%COMP%]   .mat-card-avatar[_ngcontent-%COMP%]{background-color:#aab0b3;color:#fff}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-property-multi[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .mat-card-avatar[_ngcontent-%COMP%]{background-color:#616566;color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%], .eui-dark-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]{color:#edbe8e}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]{color:#99c478}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-progress[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{color:#99c478}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-property-multi[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#16191a}.eui-contrast-theme   [_nghost-%COMP%]   .mat-card-avatar[_ngcontent-%COMP%]{background-color:#2f3233;color:#444647}.eui-contrast-theme   [_nghost-%COMP%]   .mat-card[_ngcontent-%COMP%]{border-color:#16191a}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-unpublished-state[_ngcontent-%COMP%], .eui-contrast-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-willbepublished-state[_ngcontent-%COMP%]{color:#f7e4d0}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-publish[_ngcontent-%COMP%]   .imx-application-published-state[_ngcontent-%COMP%]{color:#cee3bf}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-progress[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]{color:#cee3bf}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationDetailsComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-details', template: "<div class=\"imx-application-details-content\">\r\n  <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\r\n  <div class=\"imx-application-details-grid\" [ngClass]=\"{ hidden: isLoading }\">\r\n    <mat-card class=\"imx-application-properties mat-elevation-z0\">\r\n      <mat-card-title>\r\n        {{ '#LDS#General' | translate }}\r\n      </mat-card-title>\r\n      <mat-divider [inset]=\"true\"></mat-divider>\r\n      <mat-card-content>\r\n        <imx-column-info [placeholder]=\"'#LDS#Is being computed' | translate\" [property]=\"application.UID_AccProductGroup\" icon=\"serviceaccount\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.UID_AERoleOwner\" icon=\"user\"></imx-column-info>\r\n        <imx-application-property [display]=\"shopsDisplay\" icon=\"library\">\r\n          <div class=\"imx-application-property-multi\">\r\n            <span *ngIf=\"!assignedShops.length\">{{ '-' + ('#LDS#None assigned' | translate) + '-' }}</span>\r\n            <span *ngIf=\"assignedShops.length\">{{ assignedShops[0].GetEntity().GetDisplay() }}</span>\r\n            <button\r\n              mat-button\r\n              color=\"primary\"\r\n              (click)=\"showMore(assignedShops, shopsDisplay, 'library')\"\r\n              data-imx-identifier=\"imx-application-details-button-show-more-shops\"\r\n              *ngIf=\"assignedShops.length > 1\"\r\n            >\r\n              {{ '#LDS#and {0} more...' | translate | ldsReplace : assignedShops.length - 1 }}\r\n            </button>\r\n          </div>\r\n        </imx-application-property>\r\n      </mat-card-content>\r\n    </mat-card>\r\n    <mat-card class=\"imx-application-state mat-elevation-z0\">\r\n      <mat-card class=\"imx-application-publish mat-elevation-z0\">\r\n        <mat-card-title>\r\n          {{ '#LDS#Publication status' | translate }}\r\n        </mat-card-title>\r\n        <mat-divider [inset]=\"true\"></mat-divider>\r\n        <mat-card-content>\r\n          <span *ngIf=\"notPublished()\" class=\"imx-application-unpublished-state\">{{ '#LDS#Not published' | translate }}</span>\r\n          <span *ngIf=\"willPublish()\" class=\"imx-application-willbepublished-state\">\r\n            <eui-icon icon=\"restore\" size=\"14px\"></eui-icon>\r\n            {{ '#LDS#Will be published' | translate }}\r\n          </span>\r\n          <span *ngIf=\"published()\" class=\"imx-application-published-state\">\r\n            <mat-icon icon=\"check\">check_circle</mat-icon>\r\n            {{ '#LDS#Published' | translate }}\r\n          </span>\r\n          <div *ngIf=\"willPublish()\" class=\"imx-application-publish-date\">\r\n            <span>{{ application.ActivationDate.value | shortDate }}</span>\r\n          </div>\r\n        </mat-card-content>\r\n      </mat-card>\r\n      <mat-card class=\"imx-application-progress mat-elevation-z0\">\r\n        <mat-card-title>\r\n          {{ '#LDS#Progress' | translate }}\r\n        </mat-card-title>\r\n        <mat-divider [inset]=\"true\"></mat-divider>\r\n        <mat-card-content>\r\n          <div class=\"imx-application-progress-step\" [class.checked]=\"application\">\r\n            <mat-icon icon=\"check\">check_circle</mat-icon>\r\n            <span class=\"cdk-visually-hidden\">{{ (application ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}</span>\r\n            <span>{{ '#LDS#Application created' | translate }}</span>\r\n          </div>\r\n          <div class=\"imx-application-progress-step\" [class.checked]=\"hasOwner\">\r\n            <mat-icon icon=\"check\">check_circle</mat-icon>\r\n            <span class=\"cdk-visually-hidden\">{{ (hasOwner ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}</span>\r\n            <span>{{ '#LDS#Manager assigned' | translate }}</span>\r\n          </div>\r\n          <div class=\"imx-application-progress-step\" [class.checked]=\"assignedShops?.length > 0\">\r\n            <mat-icon icon=\"check\">check_circle</mat-icon>\r\n            <span class=\"cdk-visually-hidden\">{{ (assignedShops?.length > 0 ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}</span>\r\n            <span>{{ '#LDS#Shop assigned' | translate }}</span>\r\n          </div>\r\n          <div class=\"imx-application-progress-step\" [class.checked]=\"hasAssignedEntitlements\">\r\n            <mat-icon icon=\"check\">check_circle</mat-icon>\r\n            <span class=\"cdk-visually-hidden\">{{ (hasAssignedEntitlements ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}</span>\r\n            <span>{{ '#LDS#Application entitlements assigned' | translate }}</span>\r\n          </div>\r\n          <div class=\"imx-application-progress-step\" [class.checked]=\"hasPublishedEntitlements\">\r\n            <mat-icon icon=\"check\">check_circle</mat-icon>\r\n            <span class=\"cdk-visually-hidden\">{{ (hasPublishedEntitlements ? '#LDS#ScreenReader_Checked' : '#LDS#ScreenReader_Unchecked') | translate }}</span>\r\n            <span>{{ '#LDS#Application entitlements published' | translate }}</span>\r\n          </div>\r\n        </mat-card-content>\r\n      </mat-card>\r\n    </mat-card>\r\n    <mat-card class=\"imx-application-additionalDetails mat-elevation-z0\">\r\n      <mat-card-title>\r\n        {{ '#LDS#Additional details' | translate }}\r\n      </mat-card-title>\r\n      <mat-divider [inset]=\"true\"></mat-divider>\r\n      <mat-card-content>\r\n        <imx-column-info [property]=\"application.UID_PersonHead\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.UID_AERoleApprover\"></imx-column-info>\r\n        <imx-application-property [display]=\"accountsDisplay\">\r\n          <div class=\"imx-application-property-multi\">\r\n            <span *ngIf=\"accountsInformation.count === 0\">{{ '-' + ('#LDS#None selected' | translate) + '-' }}</span>\r\n            <span *ngIf=\"accountsInformation.count > 0\">{{ accountsInformation.first.GetEntity().GetDisplay() }}</span>\r\n            <button\r\n              mat-button\r\n              color=\"primary\"\r\n              (click)=\"showMoreAccounts()\"\r\n              *ngIf=\"accountsInformation.count > 1\"\r\n              data-imx-identifier=\"imx-application-details-button-load-more-accounts\"\r\n            >\r\n              {{ '#LDS#and {0} more...' | translate | ldsReplace : accountsInformation.count - 1 }}\r\n            </button>\r\n          </div>\r\n        </imx-application-property>\r\n        <imx-column-info [property]=\"application.ApplicationEnvironment\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.ApplicationWebURL\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.AuthenticationRoot\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.IsAuthenticationIntegrated\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.IsFederationEnabled\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.IsMultiFactorEnabled\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.IsSSOEnabled\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.SSORedirectionUrl\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.PurchasedLicenses\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.RiskIndex\"></imx-column-info>\r\n        <imx-column-info [property]=\"application.UID_FunctionalArea\"></imx-column-info>\r\n      </mat-card-content>\r\n    </mat-card>\r\n  </div>\r\n</div>\r\n<mat-card class=\"imx-button-area mat-elevation-z0\" *ngIf=\"application && !isLoading \">\r\n  <button class=\"imx-additional-actions\" mat-stroked-button data-imx-identifier=\"imx-application-details-button-menu\" [matMenuTriggerFor]=\"menu\">\r\n    <eui-icon icon=\"ellipsisvertical\" (click)=\"menuClicked($event)\"></eui-icon>\r\n    {{ '#LDS#Actions' | translate }}\r\n  </button>\r\n  <mat-menu #menu=\"matMenu\">\r\n    <button mat-menu-item (click)=\"publishApplication($event)\" data-imx-identifier=\"imx-application-details-button-publish-application\" [disabled]=\"!isPublishable\">\r\n      {{ '#LDS#Publish' | translate }}\r\n    </button>\r\n    <button mat-menu-item (click)=\"unpublishApplication($event)\" data-imx-identifier=\"imx-application-details-button-unpublish-application\" [disabled]=\"!isUnpublishable\">\r\n      {{ '#LDS#Unpublish' | translate }}\r\n    </button>\r\n    <button data-imx-identifier=\"imx-application-details-edit-servicecategories\" mat-menu-item (click)=\"editServiceCategories()\">\r\n      {{ '#LDS#Edit service categories' | translate }}\r\n    </button>\r\n  </mat-menu>\r\n  <button\r\n    mat-stroked-button\r\n    color=\"warn\"\r\n    data-imx-identifier=\"imx-application-details-button-delete-application\"\r\n    [disabled]=\"!canBeDeleted\"\r\n    [attr.aria-label]=\"'#LDS#Delete application' | translate\"\r\n    (click)=\"deleteApplication()\"\r\n  >\r\n    <eui-icon icon=\"delete\"></eui-icon>\r\n    {{ '#LDS#Delete' | translate }}\r\n  </button>\r\n  <button\r\n    color=\"primary\"\r\n    mat-raised-button\r\n    data-imx-identifier=\"imx-application-details-button-edit-application\"\r\n    [attr.aria-label]=\"'#LDS#Edit Application' | translate\"\r\n    (click)=\"editApplication()\"\r\n  >\r\n    <eui-icon icon=\"edit\"></eui-icon>\r\n    {{ '#LDS#Edit' | translate }}\r\n  </button>\r\n</mat-card>\r\n\r\n\r\n\r\n<ng-template #multiValueControl let-data>\r\n  <div mat-dialog-title>{{ data.caption }}</div>\r\n  <mat-dialog-content>\r\n    <ul>\r\n      <li *ngFor=\"let content of data.parts\" class=\"imx-multivalue-item\" [attr.data-imx-identifier]=\"'imx-application-details-' + data.caption + '-' + content\">\r\n        <mat-card>\r\n          <eui-icon *ngIf=\"data.icon\" mat-card-avatar size=\"16px\" [icon]=\"data.icon\"></eui-icon>\r\n          <mat-card-title class=\"imx-card-title\">{{ content }}</mat-card-title>\r\n        </mat-card>\r\n      </li>\r\n    </ul>\r\n  </mat-dialog-content>\r\n  <mat-dialog-actions align=\"end\">\r\n    <button data-imx-identifier=\"imx-application-details-button-close-list\" mat-raised-button color=\"primary\" mat-dialog-close>{{ '#LDS#Close' | translate }}</button>\r\n  </mat-dialog-actions>\r\n</ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto;min-height:100%}:host .imx-application-details-content .imx-application-details-grid.hidden{display:none}.imx-application-details-content{display:flex;overflow:hidden;flex:1 1 auto}.imx-application-details-content imx-busy-indicator{flex:0 0 0}.imx-application-details-content .imx-application-details-grid{display:flex;flex-wrap:wrap;padding:16px 24px;overflow:auto;max-width:1500px;max-height:800px}.imx-application-details-content .imx-application-details-grid>.mat-card{background-color:transparent}.imx-application-details-content .imx-application-details-grid .mat-card-title{font-size:18px;line-height:36px}.imx-application-details-content .imx-application-details-grid .mat-button{vertical-align:middle;padding:0 2px;min-width:0;margin-left:5px}.imx-application-details-content .imx-application-details-grid .mat-button ::ng-deep .mat-button-wrapper{vertical-align:text-bottom}.imx-application-details-content .imx-application-details-grid .mat-button[hidden]{display:none}.imx-application-details-content .imx-application-details-grid .mat-divider-horizontal{width:50px;margin-bottom:12px}.imx-application-properties{flex:0 0 33%;min-width:200px;box-shadow:none}.imx-application-properties .mat-card-content{display:flex;flex-direction:column;margin-bottom:-15px}.imx-application-properties .mat-card-content>*{margin-bottom:15px}.imx-button-area{background-color:transparent;display:flex;flex-direction:row;justify-content:flex-end}.imx-button-area .justify-start{margin-right:auto;justify-self:start}.imx-button-area .imx-additional-actions{margin-right:5px;margin-left:5px}.imx-button-area .mat-stroked-button eui-icon,.imx-button-area .mat-raised-button eui-icon{font-size:14px;margin-right:4px}.imx-button-area>button:not(:last-of-type){margin-right:16px}.imx-application-property-multi{display:flex;flex-direction:column}.imx-application-property-multi>span{font-weight:600;overflow:hidden;text-overflow:ellipsis}.imx-application-property-multi>.mat-button{width:auto;padding:0;line-height:1.3rem;align-self:flex-start}li{list-style-type:none;margin:10px}li .mat-card{display:flex;flex-direction:row;height:3.2rem}li .mat-card>.imx-card-title{font-size:16px;flex:1;margin-left:10px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.mat-dialog-content{flex:1;display:flex;flex-direction:column;height:inherit}.imx-application-state{display:flex;flex-wrap:wrap;flex:0 0 64%;align-content:flex-start;box-shadow:none;padding:0}.imx-application-state>.mat-card{background-color:transparent}.imx-application-publish{flex:0 0 51%;min-width:220px;box-shadow:none;padding-left:5px;padding-right:0}.imx-application-publish .mat-card-content{display:flex;align-items:center}.imx-application-publish .mat-chip{border-radius:3px;width:max-content;-webkit-user-select:none;user-select:none}.imx-application-publish .imx-application-unpublished-state,.imx-application-publish .imx-application-willbepublished-state{font-weight:600;font-size:12px;display:flex;align-items:center}.imx-application-publish .imx-application-unpublished-state .eui-icon,.imx-application-publish .imx-application-unpublished-state .mat-icon,.imx-application-publish .imx-application-willbepublished-state .eui-icon,.imx-application-publish .imx-application-willbepublished-state .mat-icon{margin-right:6px}.imx-application-publish .imx-application-published-state{font-weight:600;font-size:12px;display:flex;align-items:center}.imx-application-publish .imx-application-published-state .eui-icon,.imx-application-publish .imx-application-published-state .mat-icon{margin-right:6px}.imx-application-publish .imx-application-published-state .mat-icon{font-size:14px;width:14px;height:14px}.imx-application-publish .imx-application-publish-date{margin-left:10px;font-size:14px}.imx-application-progress{flex:0 0 48%;box-shadow:none;padding-left:0;padding-right:0}.imx-application-progress .mat-card-title{line-height:45px}.imx-application-progress .imx-application-progress-step{margin-bottom:8px}.imx-application-progress .mat-icon{margin-right:5px;font-size:16px;width:16px;height:16px;visibility:hidden}.imx-application-progress .checked .mat-icon{visibility:visible}.imx-application-progress span{font-size:14px}.imx-application-progress .mat-card-content>div{display:flex;align-items:center}.imx-application-additionalDetails{flex:0 0 100%;box-shadow:none;overflow:hidden}.imx-application-additionalDetails .mat-card-title{line-height:45px}.imx-application-additionalDetails .mat-card-content{display:flex;flex-wrap:wrap}.imx-application-additionalDetails .mat-card-content imx-column-info,.imx-application-additionalDetails .mat-card-content imx-application-property{flex:0 0 33%;min-width:200px;padding-right:21px}.imx-multivalue-item{margin:10px 0}.mat-card-avatar{padding:5px;height:25px;width:25px;-webkit-user-select:none;user-select:none}:host ::ng-deep body .mat-dialog-container{display:flex;flex-direction:column}:host .imx-application-property-multi>span{color:#616566}:host .imx-application-unpublished-state,:host .imx-application-willbepublished-state{color:#e36a00}:host .imx-application-published-state{color:#4ba803}:host .imx-application-progress .mat-icon{color:#4ba803}:host .mat-card-avatar{background-color:#aab0b3;color:#fff}.eui-dark-theme :host .imx-application-property-multi>span{color:#dfe4e6}.eui-dark-theme :host .mat-card-avatar{background-color:#616566;color:#2f3233}.eui-dark-theme :host .imx-application-publish .imx-application-unpublished-state,.eui-dark-theme :host .imx-application-publish .imx-application-willbepublished-state{color:#edbe8e}.eui-dark-theme :host .imx-application-publish .imx-application-published-state{color:#99c478}.eui-dark-theme :host .imx-application-progress .mat-icon{color:#99c478}.eui-contrast-theme :host .imx-application-property-multi>span{color:#fff}.eui-contrast-theme :host .imx-application-content{background-color:#16191a}.eui-contrast-theme :host .mat-card-avatar{background-color:#2f3233;color:#444647}.eui-contrast-theme :host .mat-card{border-color:#16191a}.eui-contrast-theme :host .imx-application-publish .imx-application-unpublished-state,.eui-contrast-theme :host .imx-application-publish .imx-application-willbepublished-state{color:#f7e4d0}.eui-contrast-theme :host .imx-application-publish .imx-application-published-state{color:#cee3bf}.eui-contrast-theme :host .imx-application-progress .mat-icon{color:#cee3bf}\n"] }]
    }], function () { return [{ type: EntitlementsService }, { type: ShopsService }, { type: i1$1.EuiLoadingService }, { type: i2.ClassloggerService }, { type: AccountsService }, { type: i1$2.MatDialog }, { type: ApplicationsService }, { type: i2.SnackBarService }, { type: i5$1.Platform }, { type: AobApiService }, { type: i3$1.TranslateService }, { type: i2.ConfirmationService }, { type: i1$1.EuiSidesheetService }, { type: AobPermissionsService }]; }, { application: [{
            type: Input
        }], chartDialog: [{
            type: ViewChild,
            args: ['multiValueControl', { static: true }]
        }], menuTrigger: [{
            type: ViewChild,
            args: [MatMenuTrigger]
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class IdentityService {
    constructor(api) {
        this.api = api;
    }
    async get(applicationId, params) {
        return await this.api.typedClient.PortalApplicationIdentities.Get(applicationId, params);
    }
    getSchema() {
        return this.api.typedClient.PortalApplicationIdentities.GetSchema();
    }
    async getByIdentity(applicationId, identityId, params) {
        return await this.api.typedClient.PortalApplicationIdentitiesbyidentity.Getbyidentity(applicationId, identityId, params);
    }
    getByIdentitySchema() {
        return this.api.typedClient.PortalApplicationIdentitiesbyidentity.GetSchema();
    }
}
IdentityService.ɵfac = function IdentityService_Factory(t) { return new (t || IdentityService)(i0.ɵɵinject(AobApiService)); };
IdentityService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: IdentityService, factory: IdentityService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: AobApiService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function IdentityDetailComponent_ng_template_6_div_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8)(1, "eui-badge");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "shortDate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r2 = i0.ɵɵnextContext().$implicit;
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r3.translateProvider.GetColumnDisplay("ValidUntil", ctx_r3.entitySchema) + ": " + i0.ɵɵpipeBind1(3, 1, item_r2.ValidUntil.value), " ");
} }
function IdentityDetailComponent_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, IdentityDetailComponent_ng_template_6_div_0_Template, 4, 3, "div", 7);
} if (rf & 2) {
    const item_r2 = ctx.$implicit;
    i0.ɵɵproperty("ngIf", item_r2.ValidUntil.value);
} }
const _c0$4 = function () { return ["search"]; };
class IdentityDetailComponent {
    constructor(data, identityService, busyService, translateProvider) {
        this.data = data;
        this.identityService = identityService;
        this.busyService = busyService;
        this.translateProvider = translateProvider;
        this.DisplayColumns = DisplayColumns;
        this.entitySchema = this.identityService.getByIdentitySchema();
        this.navigationState = {
            PageSize: 25,
            StartIndex: 0,
            search: null,
        };
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchema.Columns['OrderState'],
            this.entitySchema.Columns['ValidUntil'],
        ];
    }
    async ngOnInit() {
        await this.setDst();
    }
    async onNavigationStateChanged(navigationState) {
        this.navigationState = navigationState;
        this.setDst();
    }
    async onSearch(keywords) {
        this.navigationState.StartIndex = 0;
        this.navigationState.search = keywords;
        this.setDst();
    }
    async setDst() {
        this.dstSettings = {
            dataSource: await this.getData(),
            entitySchema: this.entitySchema,
            navigationState: this.navigationState,
            displayedColumns: this.displayedColumns,
        };
    }
    async getData() {
        this.busyService.show();
        try {
            return await this.identityService.getByIdentity(this.data.application.GetEntity().GetKeys()[0], this.data.selectedItem.GetEntity().GetKeys()[0], this.navigationState);
        }
        finally {
            this.busyService.hide();
        }
    }
}
IdentityDetailComponent.ɵfac = function IdentityDetailComponent_Factory(t) { return new (t || IdentityDetailComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(IdentityService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.ImxTranslationProviderService)); };
IdentityDetailComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IdentityDetailComponent, selectors: [["imx-identity-detail"]], decls: 8, vars: 9, consts: [["data-imx-identifier", "identity-detail-dst", 3, "options", "settings", "search", "navigationStateChanged"], ["dst", ""], ["data-imx-identifier", "identity-detail-data-table", "mode", "manual", 3, "dst", "detailViewVisible"], ["data-imx-identifier", "identity-detail-column-default-display", 3, "entityColumn"], ["data-imx-identifier", "identity-detail-column-order-state", 3, "entityColumn"], ["data-imx-identifier", "identity-detail-column-valid-until", "columnLabel", "", 3, "entityColumn"], ["data-imx-identifier", "identity-detail-paginator", 3, "dst"], ["class", "imx-badge-container", 4, "ngIf"], [1, "imx-badge-container"]], template: function IdentityDetailComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-data-source-toolbar", 0, 1);
        i0.ɵɵlistener("search", function IdentityDetailComponent_Template_imx_data_source_toolbar_search_0_listener($event) { return ctx.onSearch($event); })("navigationStateChanged", function IdentityDetailComponent_Template_imx_data_source_toolbar_navigationStateChanged_0_listener($event) { return ctx.onNavigationStateChanged($event); });
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(2, "imx-data-table", 2);
        i0.ɵɵelement(3, "imx-data-table-column", 3)(4, "imx-data-table-column", 4);
        i0.ɵɵelementStart(5, "imx-data-table-column", 5);
        i0.ɵɵtemplate(6, IdentityDetailComponent_ng_template_6_Template, 1, 1, "ng-template");
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(7, "imx-data-source-paginator", 6);
    } if (rf & 2) {
        const _r0 = i0.ɵɵreference(1);
        i0.ɵɵproperty("options", i0.ɵɵpureFunction0(8, _c0$4))("settings", ctx.dstSettings);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r0)("detailViewVisible", false);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns["OrderState"]);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns["ValidUntil"]);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r0);
    } }, dependencies: [i5.NgIf, i1$1.EuiBadgeComponent, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.ShortDatePipe], styles: [".imx-badge-container[_ngcontent-%COMP%]{min-width:105px}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityDetailComponent, [{
        type: Component,
        args: [{ selector: 'imx-identity-detail', template: "<imx-data-source-toolbar #dst\r\n  data-imx-identifier=\"identity-detail-dst\"\r\n  [options]=\"['search']\"\r\n  [settings]=\"dstSettings\"\r\n  (search)=\"onSearch($event)\"\r\n  (navigationStateChanged)=\"onNavigationStateChanged($event)\">\r\n</imx-data-source-toolbar>\r\n<imx-data-table data-imx-identifier=\"identity-detail-data-table\" [dst]=\"dst\" [detailViewVisible]=\"false\" mode=\"manual\">\r\n  <imx-data-table-column data-imx-identifier=\"identity-detail-column-default-display\" [entityColumn]=\"entitySchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\"></imx-data-table-column>\r\n  <imx-data-table-column data-imx-identifier=\"identity-detail-column-order-state\" [entityColumn]=\"entitySchema?.Columns['OrderState']\"></imx-data-table-column>\r\n  <imx-data-table-column data-imx-identifier=\"identity-detail-column-valid-until\" [entityColumn]=\"entitySchema?.Columns['ValidUntil']\" columnLabel=\"\">\r\n    <ng-template let-item>\r\n      <div *ngIf=\"item.ValidUntil.value\" class=\"imx-badge-container\">\r\n        <eui-badge>\r\n          {{ translateProvider.GetColumnDisplay('ValidUntil', entitySchema) + ': ' + (item.ValidUntil.value | shortDate) }}\r\n        </eui-badge>\r\n      </div>\r\n    </ng-template>\r\n  </imx-data-table-column>\r\n</imx-data-table>\r\n<imx-data-source-paginator data-imx-identifier=\"identity-detail-paginator\" [dst]=\"dst\"></imx-data-source-paginator>\r\n", styles: [".imx-badge-container{min-width:105px}\n"] }]
    }], function () { return [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: IdentityService }, { type: i1$1.EuiLoadingService }, { type: i2.ImxTranslationProviderService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$3 = ["dataTable"];
function IdentitiesComponent_imx_data_table_3_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-data-table", 6, 7);
    i0.ɵɵlistener("highlightedEntityChanged", function IdentitiesComponent_imx_data_table_3_Template_imx_data_table_highlightedEntityChanged_0_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.onHighlightedEntityChanged($event)); });
    i0.ɵɵelement(2, "imx-data-table-column", 8)(3, "imx-data-table-column", 9);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    const _r0 = i0.ɵɵreference(2);
    i0.ɵɵproperty("dst", _r0)("detailViewVisible", false);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("entityColumn", ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns[ctx_r1.DisplayColumns.DISPLAY_PROPERTYNAME]);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("entityColumn", ctx_r1.entitySchema == null ? null : ctx_r1.entitySchema.Columns["DefaultEmailAddress"]);
} }
const _c1$3 = function (a1) { return { name: "view", description: a1 }; };
const _c2$1 = function (a0) { return [a0]; };
function IdentitiesComponent_imx_data_tiles_4_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-data-tiles", 10);
    i0.ɵɵlistener("badgeClicked", function IdentitiesComponent_imx_data_tiles_4_Template_imx_data_tiles_badgeClicked_0_listener($event) { i0.ɵɵrestoreView(_r7); const ctx_r6 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r6.onOpenDetails($event)); })("actionSelected", function IdentitiesComponent_imx_data_tiles_4_Template_imx_data_tiles_actionSelected_0_listener($event) { i0.ɵɵrestoreView(_r7); const ctx_r8 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r8.onSelectedTileChanged($event)); });
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    const _r0 = i0.ɵɵreference(2);
    i0.ɵɵproperty("dst", _r0)("selectable", false)("actions", i0.ɵɵpureFunction1(10, _c2$1, i0.ɵɵpureFunction1(8, _c1$3, i0.ɵɵpipeBind1(1, 6, "#LDS#Details"))))("useActionMenu", false)("titleObject", ctx_r2.entitySchema == null ? null : ctx_r2.entitySchema.Columns[ctx_r2.DisplayColumns.DISPLAY_PROPERTYNAME])("subtitleObject", ctx_r2.entitySchema == null ? null : ctx_r2.entitySchema.Columns["DefaultEmailAddress"]);
} }
const _c3$1 = function () { return ["search", "selectedViewGroup"]; };
class IdentitiesComponent {
    constructor(identityService, sidesheetService, translateService) {
        this.identityService = identityService;
        this.sidesheetService = sidesheetService;
        this.translateService = translateService;
        this.selectedView = 'cardlist';
        this.DisplayColumns = DisplayColumns;
        this.busyService = new BusyService();
        this.entitySchema = this.identityService.getSchema();
        this.initNavigationState();
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchema.Columns['DefaultEmailAddress'],
        ];
    }
    async ngOnChanges(changes) {
        if (changes.application?.currentValue?.UID_AOBApplication.value === changes.application?.previousValue?.UID_AOBApplication.value) {
            return;
        }
        const isBusy = this.busyService.beginBusy();
        try {
            this.initNavigationState();
            await this.setDst();
        }
        finally {
            isBusy.endBusy();
        }
    }
    async onNavigationStateChanged(navigationState) {
        this.navigationState = navigationState;
        await this.setDst();
    }
    onViewSelectionChanged(selectedView) {
        this.selectedView = selectedView;
    }
    /**
     * Method that is triggered by the (search) output of the data table
     * Reinits the data source
     * @param keywords the search value
     */
    async onSearch(keywords) {
        this.navigationState.StartIndex = 0;
        this.navigationState.search = keywords;
        await this.setDst();
    }
    /**
     * Method that is triggered by the (highlightedEntityChanged) output of the data table
     * opens the details
     * @param selectedItem the TypedEntity that is selected
     */
    async onHighlightedEntityChanged(selectedItem) {
        await this.onOpenDetails(selectedItem);
    }
    /**
     * Method that is triggered by the (actionSelected) output of the data tile component
     * opens the details
     * @param selectedItem the TypedEntity that is selected
     */
    async onSelectedTileChanged(selectedItem) {
        await this.onOpenDetails(selectedItem.typedEntity);
    }
    /**
     * Opens a side sheet that displays identity details
     * @param item the identity, that details should be opened
     */
    async onOpenDetails(item) {
        const data = {
            application: this.application,
            selectedItem: item,
        };
        this.sidesheetService.open(IdentityDetailComponent, {
            title: await this.translateService.get('#LDS#Heading View Application Entitlements').toPromise(),
            subTitle: data.selectedItem.GetEntity().GetDisplay(),
            width: 'max(768px, 70%)',
            testId: 'identity-view-application-entitlements',
            data: data,
        });
    }
    /**
     * Loads the data for the table
     * @returns an {@link ExtendedTypedEntityCollection | extended typed entity collection} of {@link PortalApplicationIdentities | application identities}
     */
    async getData() {
        const isBusy = this.busyService.beginBusy();
        try {
            return await this.identityService.get(this.application.GetEntity().GetKeys()[0], this.navigationState);
        }
        finally {
            isBusy.endBusy();
        }
    }
    async setDst() {
        this.dstSettings = {
            dataSource: await this.getData(),
            entitySchema: this.entitySchema,
            navigationState: this.navigationState,
            displayedColumns: this.displayedColumns,
        };
    }
    initNavigationState() {
        this.navigationState = {
            PageSize: 25,
            StartIndex: 0,
            search: null,
        };
    }
}
IdentitiesComponent.ɵfac = function IdentitiesComponent_Factory(t) { return new (t || IdentitiesComponent)(i0.ɵɵdirectiveInject(IdentityService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$1.TranslateService)); };
IdentitiesComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IdentitiesComponent, selectors: [["imx-aob-identities"]], viewQuery: function IdentitiesComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0$3, 5);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTable = _t.first);
    } }, inputs: { application: "application" }, features: [i0.ɵɵNgOnChangesFeature], decls: 6, vars: 8, consts: [[1, "imx-identities-content"], ["data-imx-identifier", "identity-dst", 3, "options", "settings", "busyService", "initalView", "search", "viewSelectionChanged", "navigationStateChanged"], ["dst", ""], ["data-imx-identifier", "identity-data-table", "mode", "manual", 3, "dst", "detailViewVisible", "highlightedEntityChanged", 4, "ngIf"], ["data-imx-identifier", "identity-tiles", "height", "150px", "icon", "user", 3, "dst", "selectable", "actions", "useActionMenu", "titleObject", "subtitleObject", "badgeClicked", "actionSelected", 4, "ngIf"], ["data-imx-identifier", "identity-paginator", 3, "dst"], ["data-imx-identifier", "identity-data-table", "mode", "manual", 3, "dst", "detailViewVisible", "highlightedEntityChanged"], ["dataTable", ""], ["data-imx-identifier", "identity-column-default-display", "data-imx-identifier", "identity-data-default", 3, "entityColumn"], ["data-imx-identifier", "identity-column-default-email", "data-imx-identifier", "identity-data-email", 3, "entityColumn"], ["data-imx-identifier", "identity-tiles", "height", "150px", "icon", "user", 3, "dst", "selectable", "actions", "useActionMenu", "titleObject", "subtitleObject", "badgeClicked", "actionSelected"]], template: function IdentitiesComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "imx-data-source-toolbar", 1, 2);
        i0.ɵɵlistener("search", function IdentitiesComponent_Template_imx_data_source_toolbar_search_1_listener($event) { return ctx.onSearch($event); })("viewSelectionChanged", function IdentitiesComponent_Template_imx_data_source_toolbar_viewSelectionChanged_1_listener($event) { return ctx.onViewSelectionChanged($event); })("navigationStateChanged", function IdentitiesComponent_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { return ctx.onNavigationStateChanged($event); });
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(3, IdentitiesComponent_imx_data_table_3_Template, 4, 4, "imx-data-table", 3);
        i0.ɵɵtemplate(4, IdentitiesComponent_imx_data_tiles_4_Template, 2, 12, "imx-data-tiles", 4);
        i0.ɵɵelement(5, "imx-data-source-paginator", 5);
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        const _r0 = i0.ɵɵreference(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("options", i0.ɵɵpureFunction0(7, _c3$1))("settings", ctx.dstSettings)("busyService", ctx.busyService)("initalView", ctx.selectedView);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.selectedView === "table");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.selectedView === "cardlist");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("dst", _r0);
    } }, dependencies: [i5.NgIf, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTilesComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{padding:30px;display:flex;flex-direction:column;height:100%;overflow:hidden;flex:1 1 auto}[_nghost-%COMP%]   .imx-identities-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}[_nghost-%COMP%]     .mat-paginator{background-color:transparent}.eui-dark-theme   [_nghost-%COMP%]     .mat-paginator{background-color:transparent}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}.eui-contrast-theme[_ngcontent-%COMP%]     .mat-paginator{background-color:transparent}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentitiesComponent, [{
        type: Component,
        args: [{ selector: 'imx-aob-identities', template: "<div class=\"imx-identities-content\">\r\n\r\n<imx-data-source-toolbar #dst\r\n  data-imx-identifier=\"identity-dst\"\r\n  [options]=\"['search', 'selectedViewGroup']\"\r\n  [settings]=\"dstSettings\"\r\n  [busyService]=\"busyService\"\r\n  [initalView]=\"selectedView\"\r\n  (search)=\"onSearch($event)\"\r\n  (viewSelectionChanged)=\"onViewSelectionChanged($event)\"\r\n  (navigationStateChanged)=\"onNavigationStateChanged($event)\">\r\n</imx-data-source-toolbar>\r\n<imx-data-table *ngIf=\"selectedView === 'table'\"\r\n  data-imx-identifier=\"identity-data-table\"\r\n  [dst]=\"dst\"\r\n  [detailViewVisible]=\"false\"\r\n  mode=\"manual\"\r\n  (highlightedEntityChanged)=\"onHighlightedEntityChanged($event)\"\r\n  #dataTable>\r\n  <imx-data-table-column\r\n    data-imx-identifier=\"identity-column-default-display\"\r\n    [entityColumn]=\"entitySchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\"\r\n    data-imx-identifier=\"identity-data-default\"></imx-data-table-column>\r\n  <imx-data-table-column\r\n    data-imx-identifier=\"identity-column-default-email\"\r\n    [entityColumn]=\"entitySchema?.Columns['DefaultEmailAddress']\"\r\n    data-imx-identifier=\"identity-data-email\"></imx-data-table-column>\r\n</imx-data-table>\r\n<imx-data-tiles *ngIf=\"selectedView === 'cardlist'\"\r\n  data-imx-identifier=\"identity-tiles\"\r\n  [dst]=\"dst\"\r\n  height=\"150px\"\r\n  icon=\"user\"\r\n  [selectable]=\"false\"\r\n  (badgeClicked)=\"onOpenDetails($event)\"\r\n  [actions]=\"[{ name: 'view', description: '#LDS#Details' | translate }]\"\r\n  [useActionMenu]=\"false\"\r\n  (actionSelected)=\"onSelectedTileChanged($event)\"\r\n  [titleObject]=\"entitySchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\"\r\n  [subtitleObject]=\"entitySchema?.Columns['DefaultEmailAddress']\"></imx-data-tiles>\r\n<imx-data-source-paginator [dst]=\"dst\" data-imx-identifier=\"identity-paginator\"></imx-data-source-paginator>\r\n</div>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{padding:30px;display:flex;flex-direction:column;height:100%;overflow:hidden;flex:1 1 auto}:host .imx-identities-content{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}:host ::ng-deep .mat-paginator{background-color:transparent}.eui-dark-theme :host ::ng-deep .mat-paginator{background-color:transparent}.eui-contrast-theme :host{background-color:#000}.eui-contrast-theme ::ng-deep .mat-paginator{background-color:transparent}\n"] }]
    }], function () { return [{ type: IdentityService }, { type: i1$1.EuiSidesheetService }, { type: i3$1.TranslateService }]; }, { application: [{
            type: Input
        }], dataTable: [{
            type: ViewChild,
            args: ['dataTable']
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ApplicationDetailComponent_div_0_img_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", 18);
} if (rf & 2) {
    const ctx_r5 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("src", ctx_r5.getImageUrl(ctx_r5.application), i0.ɵɵsanitizeUrl);
} }
function ApplicationDetailComponent_div_0_ng_template_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "eui-icon", 19);
} }
function ApplicationDetailComponent_div_0_imx_info_button_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-info-button", 20);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵnextContext(2);
    const _r1 = i0.ɵɵreference(2);
    i0.ɵɵproperty("title", i0.ɵɵpipeBind1(1, 2, "#LDS#Heading Identities With Access"))("templateRef", _r1);
} }
function ApplicationDetailComponent_div_0_ng_template_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-application-details", 21);
} if (rf & 2) {
    const ctx_r9 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("application", ctx_r9.application);
} }
function ApplicationDetailComponent_div_0_ng_template_18_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-application-hyperview", 22);
} if (rf & 2) {
    const ctx_r10 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("uidApplication", ctx_r10.application.UID_AOBApplication.value);
} }
function ApplicationDetailComponent_div_0_ng_template_21_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-kpi-overview", 21);
} if (rf & 2) {
    const ctx_r11 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("application", ctx_r11.application);
} }
function ApplicationDetailComponent_div_0_ng_template_24_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-aob-identities", 21);
} if (rf & 2) {
    const ctx_r12 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("application", ctx_r12.application);
} }
function ApplicationDetailComponent_div_0_ng_template_27_Template(rf, ctx) { if (rf & 1) {
    const _r15 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-entitlements", 23);
    i0.ɵɵlistener("reloadRequested", function ApplicationDetailComponent_div_0_ng_template_27_Template_imx_entitlements_reloadRequested_0_listener() { i0.ɵɵrestoreView(_r15); const ctx_r14 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r14.reloadApplication()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r13 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("application", ctx_r13.application);
} }
function ApplicationDetailComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r17 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 3)(1, "div", 4)(2, "div", 5);
    i0.ɵɵtemplate(3, ApplicationDetailComponent_div_0_img_3_Template, 1, 1, "img", 6);
    i0.ɵɵtemplate(4, ApplicationDetailComponent_div_0_ng_template_4_Template, 1, 0, "ng-template", null, 7, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementStart(6, "div", 8)(7, "h3");
    i0.ɵɵtext(8);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(9, ApplicationDetailComponent_div_0_imx_info_button_9_Template, 2, 4, "imx-info-button", 9);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(10, "div", 10);
    i0.ɵɵtext(11);
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(12, "mat-tab-group", 11);
    i0.ɵɵlistener("selectedTabChange", function ApplicationDetailComponent_div_0_Template_mat_tab_group_selectedTabChange_12_listener($event) { i0.ɵɵrestoreView(_r17); const ctx_r16 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r16.onSelectedTabChanged($event)); });
    i0.ɵɵelementStart(13, "mat-tab", 12);
    i0.ɵɵpipe(14, "translate");
    i0.ɵɵtemplate(15, ApplicationDetailComponent_div_0_ng_template_15_Template, 1, 1, "ng-template", 13);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "mat-tab", 14);
    i0.ɵɵpipe(17, "translate");
    i0.ɵɵtemplate(18, ApplicationDetailComponent_div_0_ng_template_18_Template, 1, 1, "ng-template", 13);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(19, "mat-tab", 15);
    i0.ɵɵpipe(20, "translate");
    i0.ɵɵtemplate(21, ApplicationDetailComponent_div_0_ng_template_21_Template, 1, 1, "ng-template", 13);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(22, "mat-tab", 16);
    i0.ɵɵpipe(23, "translate");
    i0.ɵɵtemplate(24, ApplicationDetailComponent_div_0_ng_template_24_Template, 1, 1, "ng-template", 13);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(25, "mat-tab", 17);
    i0.ɵɵpipe(26, "translate");
    i0.ɵɵtemplate(27, ApplicationDetailComponent_div_0_ng_template_27_Template, 1, 1, "ng-template", 13);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const _r6 = i0.ɵɵreference(5);
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r0.application.JPegPhoto == null ? null : ctx_r0.application.JPegPhoto.value == null ? null : ctx_r0.application.JPegPhoto.value.length)("ngIfElse", _r6);
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(ctx_r0.application.GetEntity().GetDisplay());
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r0.selectedTabIndex === 3);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r0.application.Description.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(14, 10, "#LDS#Details"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(17, 12, "#LDS#Info"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(20, 14, "#LDS#KPI"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(23, 16, "#LDS#Heading Identities With Access"));
    i0.ɵɵadvance(3);
    i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(26, 18, "#LDS#Heading Application Entitlements"));
} }
function ApplicationDetailComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "p");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can get an overview of identities that have access to at least one application entitlement of this application. Additionally, you can view which application entitlements the respective identities have access to."), " ");
} }
function ApplicationDetailComponent_ng_template_3_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "span", 28);
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span", 29);
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#No Application Selected"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Select an application to view its details."));
} }
function ApplicationDetailComponent_ng_template_3_ng_template_3_button_3_Template(rf, ctx) { if (rf & 1) {
    const _r23 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 31);
    i0.ɵɵlistener("click", function ApplicationDetailComponent_ng_template_3_ng_template_3_button_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r23); const ctx_r22 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r22.createApplication()); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Create new application"), " ");
} }
function ApplicationDetailComponent_ng_template_3_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 28);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, ApplicationDetailComponent_ng_template_3_ng_template_3_button_3_Template, 3, 3, "button", 30);
} if (rf & 2) {
    const ctx_r20 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, ctx_r20.keywords ? "#LDS#No application found" : "#LDS#No applications available"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r20.isAdmin && !ctx_r20.isLoading);
} }
function ApplicationDetailComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 24);
    i0.ɵɵelement(1, "eui-icon", 25);
    i0.ɵɵtemplate(2, ApplicationDetailComponent_ng_template_3_ng_container_2_Template, 7, 6, "ng-container", 26);
    i0.ɵɵtemplate(3, ApplicationDetailComponent_ng_template_3_ng_template_3_Template, 4, 4, "ng-template", null, 27, i0.ɵɵtemplateRefExtractor);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const _r19 = i0.ɵɵreference(4);
    const ctx_r4 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r4.totalCount)("ngIfElse", _r19);
} }
class ApplicationDetailComponent {
    constructor(base64ImageService, logger, applicationsProvider, userService, route, aobPermissionsService) {
        this.base64ImageService = base64ImageService;
        this.logger = logger;
        this.applicationsProvider = applicationsProvider;
        this.userService = userService;
        this.route = route;
        this.aobPermissionsService = aobPermissionsService;
        this.selectedTabIndex = 0;
        this.showHelper = true;
        this.isLoading = false;
        this.route.queryParams.subscribe(async (params) => {
            if (Object.keys(params).length === 0)
                this.application = null;
        });
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    async ngOnInit() {
        this.subscription = this.loadingSubject.subscribe(elem => this.isLoading = elem);
        this.isAdmin = await this.aobPermissionsService.isAobApplicationAdmin();
    }
    getImageUrl(app) {
        return this.base64ImageService.getImageUrl(app.JPegPhoto);
    }
    async onSelectedTabChanged(event) {
        await this.reloadApplication();
        this.selectedTabIndex = event.index;
        this.logger.debug(this, 'tab selected', event.tab.textLabel);
    }
    async reloadApplication() {
        this.application = await this.applicationsProvider.reload(this.application.UID_AOBApplication.value);
    }
    createApplication() {
        this.applicationsProvider.createApplication();
    }
    onHelperDismissed() {
        this.showHelper = false;
    }
}
ApplicationDetailComponent.ɵfac = function ApplicationDetailComponent_Factory(t) { return new (t || ApplicationDetailComponent)(i0.ɵɵdirectiveInject(i2.Base64ImageService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i1.UserModelService), i0.ɵɵdirectiveInject(i3.ActivatedRoute), i0.ɵɵdirectiveInject(AobPermissionsService)); };
ApplicationDetailComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationDetailComponent, selectors: [["ng-component"]], inputs: { application: "application", loadingSubject: "loadingSubject" }, decls: 5, vars: 2, consts: [["class", "imx-application-content", 4, "ngIf", "ngIfElse"], ["dialogContent", ""], ["noneSelected", ""], [1, "imx-application-content"], [1, "imx-application-details"], [1, "imx-application-details-header"], ["class", "imx-application-details-icon", 3, "src", 4, "ngIf", "ngIfElse"], ["noImage", ""], [1, "imx-application-details-title"], [3, "title", "templateRef", 4, "ngIf"], [1, "imx-application-details-subtitle"], [1, "imx-tab-group", 3, "selectedTabChange"], ["data-imx-identifier", "app-details", 3, "label"], ["matTabContent", ""], ["data-imx-identifier", "app-info", 3, "label"], ["data-imx-identifier", "app-kpi", 3, "label"], ["data-imx-identifier", "app-identities", 3, "label"], ["data-imx-identifier", "app-entitlements", 3, "label"], [1, "imx-application-details-icon", 3, "src"], ["size", "xl", "icon", "application", 1, "imx-application-details-icon"], [3, "title", "templateRef"], [3, "application"], [3, "uidApplication"], [3, "application", "reloadRequested"], [1, "imx-application-content", "imx-application-content-no-app"], ["size", "100px", "icon", "application"], [4, "ngIf", "ngIfElse"], ["noApps", ""], [1, "imx-application-content-no-app-text"], [1, "imx-application-content-no-app-description"], ["mat-raised-button", "", "color", "primary", "class", "imx-application-content-create-app", "data-imx-identifier", "button-create-app", 3, "click", 4, "ngIf"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "button-create-app", 1, "imx-application-content-create-app", 3, "click"]], template: function ApplicationDetailComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵtemplate(0, ApplicationDetailComponent_div_0_Template, 28, 20, "div", 0);
        i0.ɵɵtemplate(1, ApplicationDetailComponent_ng_template_1_Template, 3, 3, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵtemplate(3, ApplicationDetailComponent_ng_template_3_Template, 5, 2, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
    } if (rf & 2) {
        const _r3 = i0.ɵɵreference(4);
        i0.ɵɵproperty("ngIf", ctx.application)("ngIfElse", _r3);
    } }, dependencies: [i5.NgIf, ApplicationHyperviewComponent, EntitlementsComponent, i1$1.EuiIconComponent, i7.MatButton, i11$2.MatTabGroup, i11$2.MatTab, i11$2.MatTabContent, KpiOverviewComponent, i2.InfoButtonComponent, ApplicationDetailsComponent, IdentitiesComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}[_nghost-%COMP%]     .mat-tab-body-wrapper .mat-tab-body-content{overflow:hidden;height:100%;display:flex}.imx-application-details[_ngcontent-%COMP%]{display:flex;overflow-x:hidden}.imx-application-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;height:calc(100vh - 180px);overflow:hidden}.imx-application-content-no-app[_ngcontent-%COMP%]{display:flex;flex-direction:column;justify-content:center;align-items:center}.imx-application-content-no-app-description[_ngcontent-%COMP%]{font-size:18px}.imx-application-content-create-app[_ngcontent-%COMP%]{margin-top:15px}.imx-application-content-no-app-text[_ngcontent-%COMP%]{font-size:24px;font-weight:600}.imx-application-info-row[_ngcontent-%COMP%]{display:flex;align-items:center}.imx-application-details-header[_ngcontent-%COMP%]{display:grid;grid-template-columns:60px 1fr;grid-template-rows:auto;grid-row-gap:5px;align-items:center;padding:30px 40px 35px;flex-grow:1}.imx-application-details-icon[_ngcontent-%COMP%]{grid-column-start:1;grid-column-end:2;grid-row-start:1;grid-row-end:3;width:42px;height:42px;align-self:center;object-fit:cover}.imx-application-details-title[_ngcontent-%COMP%]{grid-column-start:2;grid-column-end:3;grid-row-start:1;grid-row-end:1;font-weight:400;font-size:24px;min-height:40px;margin:0 15px 0 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;flex-direction:row;align-items:center}.imx-application-details-subtitle[_ngcontent-%COMP%]{grid-column-start:2;grid-column-end:3;grid-row-start:2;grid-row-end:2;font-size:14px;margin:0 15px 0 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.imx-info[_ngcontent-%COMP%]{align-self:center;max-width:500px;margin-right:50px}.mat-tab-group[_ngcontent-%COMP%]{overflow:hidden;height:100%}imx-application-hyperview[_ngcontent-%COMP%]{overflow:auto;flex-grow:1;padding:1em}  .mat-tab-body-wrapper{height:inherit}  .mat-tab-body-wrapper .mat-tab-body-content{overflow:visible}[_nghost-%COMP%]     .mat-tab-body-content{background-color:#dfe4e61a}[_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#fff}[_nghost-%COMP%]   .imx-application-content-no-app[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#aab0b3}[_nghost-%COMP%]   .imx-application-details-subtitle[_ngcontent-%COMP%]{color:#444647}.eui-dark-theme   [_nghost-%COMP%]     .mat-tab-labels{background-color:#444647}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#444647}.eui-dark-theme   [_nghost-%COMP%]     .mat-tab-body-content{background-color:#4446478c}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-content-no-app[_ngcontent-%COMP%]   .imx-application-content-no-app-text[_ngcontent-%COMP%], .eui-dark-theme   [_nghost-%COMP%]   .imx-application-content-no-app[_ngcontent-%COMP%]   .imx-application-content-no-app-description[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-content-no-app[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#616566}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-details-subtitle[_ngcontent-%COMP%]{color:#797e80}.eui-contrast-theme   [_nghost-%COMP%]     .mat-tab-labels{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]     .mat-tab-body-content{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-content-no-app[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#16191a}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-details-subtitle[_ngcontent-%COMP%]{color:#797e80}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationDetailComponent, [{
        type: Component,
        args: [{ template: "<div class=\"imx-application-content\" *ngIf=\"application; else noneSelected\">\r\n  <div class=\"imx-application-details\">\r\n    <div class=\"imx-application-details-header\">\r\n      <img *ngIf=\"application.JPegPhoto?.value?.length; else noImage\" [src]=\"getImageUrl(application)\" class=\"imx-application-details-icon\" />\r\n      <ng-template #noImage>\r\n        <eui-icon size=\"xl\" icon=\"application\" class=\"imx-application-details-icon\"></eui-icon>\r\n      </ng-template>\r\n      <div class=\"imx-application-details-title\">\r\n        <h3>{{ application.GetEntity().GetDisplay() }}</h3>\r\n        <imx-info-button *ngIf=\"selectedTabIndex === 3\" [title]=\"'#LDS#Heading Identities With Access' | translate\" [templateRef]=\"dialogContent\"></imx-info-button>\r\n      </div>\r\n      <div class=\"imx-application-details-subtitle\">{{ application.Description.Column.GetDisplayValue() }}</div>\r\n    </div>\r\n  </div>\r\n  <mat-tab-group class=\"imx-tab-group\" (selectedTabChange)=\"onSelectedTabChanged($event)\">\r\n    <mat-tab label=\"{{ '#LDS#Details' | translate }}\" data-imx-identifier=\"app-details\">\r\n      <ng-template matTabContent>\r\n        <imx-application-details [application]=\"application\"></imx-application-details>\r\n      </ng-template>\r\n    </mat-tab>\r\n    <mat-tab label=\"{{ '#LDS#Info' | translate }}\" data-imx-identifier=\"app-info\">\r\n      <ng-template matTabContent>\r\n        <imx-application-hyperview [uidApplication]=\"application.UID_AOBApplication.value\"></imx-application-hyperview>\r\n      </ng-template>\r\n    </mat-tab>\r\n    <mat-tab label=\"{{ '#LDS#KPI' | translate }}\" data-imx-identifier=\"app-kpi\">\r\n      <ng-template matTabContent>\r\n        <imx-kpi-overview [application]=\"application\"></imx-kpi-overview>\r\n      </ng-template>\r\n    </mat-tab>\r\n    <mat-tab label=\"{{ '#LDS#Heading Identities With Access' | translate }}\" data-imx-identifier=\"app-identities\">\r\n      <ng-template matTabContent>\r\n        <imx-aob-identities [application]=\"application\"></imx-aob-identities>\r\n      </ng-template>\r\n    </mat-tab>\r\n    <mat-tab label=\"{{ '#LDS#Heading Application Entitlements' | translate }}\" data-imx-identifier=\"app-entitlements\">\r\n      <ng-template matTabContent>\r\n        <imx-entitlements [application]=\"application\" (reloadRequested)=\"reloadApplication()\"></imx-entitlements>\r\n      </ng-template>\r\n    </mat-tab>\r\n  </mat-tab-group>\r\n</div>\r\n\r\n<ng-template #dialogContent>\r\n  <p>\r\n    {{\r\n      '#LDS#Here you can get an overview of identities that have access to at least one application entitlement of this application. Additionally, you can view which application entitlements the respective identities have access to.'\r\n        | translate\r\n    }}\r\n  </p>\r\n</ng-template>\r\n\r\n<ng-template #noneSelected>\r\n  <div class=\"imx-application-content imx-application-content-no-app\">\r\n    <eui-icon size=\"100px\" icon=\"application\"></eui-icon>\r\n    <ng-container *ngIf=\"totalCount; else noApps\">\r\n      <span class=\"imx-application-content-no-app-text\">{{ '#LDS#No Application Selected' | translate }}</span>\r\n      <span class=\"imx-application-content-no-app-description\">{{ '#LDS#Select an application to view its details.' | translate }}</span>\r\n    </ng-container>\r\n    <ng-template #noApps>\r\n      <span class=\"imx-application-content-no-app-text\">\r\n        {{ (keywords ? '#LDS#No application found' : '#LDS#No applications available') | translate }}\r\n      </span>\r\n      <button\r\n        *ngIf=\"isAdmin && !isLoading\"\r\n        mat-raised-button\r\n        color=\"primary\"\r\n        (click)=\"createApplication()\"\r\n        class=\"imx-application-content-create-app\"\r\n        data-imx-identifier=\"button-create-app\"\r\n      >\r\n        {{ '#LDS#Create new application' | translate }}\r\n      </button>\r\n    </ng-template>\r\n  </div>\r\n</ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;height:100%}:host ::ng-deep .mat-tab-body-wrapper .mat-tab-body-content{overflow:hidden;height:100%;display:flex}.imx-application-details{display:flex;overflow-x:hidden}.imx-application-content{display:flex;flex-direction:column;flex:1 1 auto;height:calc(100vh - 180px);overflow:hidden}.imx-application-content-no-app{display:flex;flex-direction:column;justify-content:center;align-items:center}.imx-application-content-no-app-description{font-size:18px}.imx-application-content-create-app{margin-top:15px}.imx-application-content-no-app-text{font-size:24px;font-weight:600}.imx-application-info-row{display:flex;align-items:center}.imx-application-details-header{display:grid;grid-template-columns:60px 1fr;grid-template-rows:auto;grid-row-gap:5px;align-items:center;padding:30px 40px 35px;flex-grow:1}.imx-application-details-icon{grid-column-start:1;grid-column-end:2;grid-row-start:1;grid-row-end:3;width:42px;height:42px;align-self:center;object-fit:cover}.imx-application-details-title{grid-column-start:2;grid-column-end:3;grid-row-start:1;grid-row-end:1;font-weight:400;font-size:24px;min-height:40px;margin:0 15px 0 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;flex-direction:row;align-items:center}.imx-application-details-subtitle{grid-column-start:2;grid-column-end:3;grid-row-start:2;grid-row-end:2;font-size:14px;margin:0 15px 0 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.imx-info{align-self:center;max-width:500px;margin-right:50px}.mat-tab-group{overflow:hidden;height:100%}imx-application-hyperview{overflow:auto;flex-grow:1;padding:1em}::ng-deep .mat-tab-body-wrapper{height:inherit}::ng-deep .mat-tab-body-wrapper .mat-tab-body-content{overflow:visible}:host ::ng-deep .mat-tab-body-content{background-color:#dfe4e61a}:host .imx-application-content{background-color:#fff}:host .imx-application-content-no-app>.eui-icon{color:#aab0b3}:host .imx-application-details-subtitle{color:#444647}.eui-dark-theme :host ::ng-deep .mat-tab-labels{background-color:#444647}.eui-dark-theme :host .imx-application-content{background-color:#444647}.eui-dark-theme :host ::ng-deep .mat-tab-body-content{background-color:#4446478c}.eui-dark-theme :host .imx-application-content-no-app .imx-application-content-no-app-text,.eui-dark-theme :host .imx-application-content-no-app .imx-application-content-no-app-description{color:#c4cacc}.eui-dark-theme :host .imx-application-content-no-app>.eui-icon{color:#616566}.eui-dark-theme :host .imx-application-details-subtitle{color:#797e80}.eui-contrast-theme :host ::ng-deep .mat-tab-labels{background-color:#000}.eui-contrast-theme :host ::ng-deep .mat-tab-body-content{background-color:#000}.eui-contrast-theme :host .imx-application-content{background-color:#000}.eui-contrast-theme :host .imx-application-content-no-app>.eui-icon{color:#16191a}.eui-contrast-theme :host .imx-application-details-subtitle{color:#797e80}\n"] }]
    }], function () { return [{ type: i2.Base64ImageService }, { type: i2.ClassloggerService }, { type: ApplicationsService }, { type: i1.UserModelService }, { type: i3.ActivatedRoute }, { type: AobPermissionsService }]; }, { application: [{
            type: Input
        }], loadingSubject: [{
            type: Input
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$2 = ["tiles"];
function ApplicationNavigationComponent_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 9);
    i0.ɵɵlistener("click", function ApplicationNavigationComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onCreateNew()); });
    i0.ɵɵelement(1, "eui-icon", 10);
    i0.ɵɵelementEnd();
} }
const _c1$2 = function () { return ["search"]; };
/**
 * This component shows a  list of {@link PortalApplication[]|applications} each in an
 * {@link ApplicationCardComponent|ApplicationCardComponent}.
 */
class ApplicationNavigationComponent {
    constructor(logger, appService, settingsService, route, applicationsProvider, aobPermissionsService, overlay) {
        this.logger = logger;
        this.appService = appService;
        this.settingsService = settingsService;
        this.route = route;
        this.applicationsProvider = applicationsProvider;
        this.aobPermissionsService = aobPermissionsService;
        this.overlay = overlay;
        this.entitySchema = PortalApplication.GetEntitySchema();
        this.selectable = true;
        this.multiselect = false;
        this.hideCustomToolbar = true;
        this.filterKpiChecked = false;
        this.isAdmin = false;
        this.busyService = new BusyService();
        /**
         * An event, that is triggert, if the dataSource is changed
         */
        this.dataSourceChanged = new EventEmitter();
        /**
         * An event that is emitted, if the user selects a data tile from the list
         */
        this.applicationSelected = new EventEmitter();
        /**
         * a status that defines, how badges are calculated
         */
        this.status = {
            getBadges: (application) => this.appService.getApplicationBadges(application),
        };
    }
    async ngOnInit() {
        this.isAdmin = await this.aobPermissionsService.isAobApplicationAdmin();
        this.applicationsProvider.applicationRefresh.subscribe((res) => {
            if (res) {
                return this.getData();
            }
        });
        return this.getData({ PageSize: this.settingsService.DefaultPageSize, StartIndex: 0 });
    }
    /**
     * Emits the applicationSelected event, if the selected tile changes
     * @param selection the {@link PortalApplication | application} that is selected
     */
    async onSelectionChanged(selection) {
        const app = selection[0];
        if (app) {
            this.applicationSelected.emit(app.UID_AOBApplication.value);
        }
    }
    /**
     * Emits the applicationSelected event, if the selected tile changes
     * @param selection the {@link PortalApplication | application} that is selected
     */
    onTileSelected(isSelected) {
        if (!isSelected)
            this.applicationSelected.emit();
    }
    /**
     * Loads the {@link PortalApplication | applications} for the application view
     * @param newState the load parameter for the api call
     * @param keywords possible search parameter
     */
    async getData(newState, keywords) {
        if (newState) {
            this.navigationState = newState;
        }
        const isBusy = this.busyService.beginBusy();
        this.loadingSubject?.next(true);
        try {
            const dataSource = await this.appService.get(this.navigationState);
            if (dataSource) {
                this.dstSettings = {
                    dataSource,
                    entitySchema: this.entitySchema,
                    navigationState: this.navigationState,
                };
            }
            else {
                this.dstSettings = undefined;
                this.logger.error(this, 'TypedEntityCollectionData<PortalApplication> is undefined');
            }
            this.dataSourceChanged.emit({ keywords, dataSource });
            this.route.queryParams.subscribe(async (params) => {
                if (params.id) {
                    let app = dataSource.Data.find((x) => x.UID_AOBApplication.value == params.id);
                    this.selectedEntity = app;
                }
            });
        }
        finally {
            isBusy.endBusy();
            this.loadingSubject?.next(false);
        }
    }
    clearSelection() {
        this.tiles?.clearSelection();
    }
    onCreateNew() {
        this.clearSelection();
        this.appService.createApplication();
    }
    async onSearch(keywords) {
        this.logger.debug(this, `Searching for: ${keywords}`);
        this.appService.abortCall();
        this.navigationState.StartIndex = 0;
        if (keywords == null || keywords.length === 0) {
            this.navigationState.search = null;
        }
        else {
            this.navigationState.search = keywords;
        }
        return this.getData(undefined, keywords);
    }
    async filterApplicationsWithKpiIssues() {
        this.navigationState.filterkpi = this.filterKpiChecked;
        this.navigationState.StartIndex = 0;
        await this.getData();
    }
}
ApplicationNavigationComponent.ɵfac = function ApplicationNavigationComponent_Factory(t) { return new (t || ApplicationNavigationComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i3.ActivatedRoute), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(AobPermissionsService), i0.ɵɵdirectiveInject(i5$2.Overlay)); };
ApplicationNavigationComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationNavigationComponent, selectors: [["imx-application-navigation"]], viewQuery: function ApplicationNavigationComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0$2, 7);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.tiles = _t.first);
    } }, outputs: { dataSourceChanged: "dataSourceChanged", applicationSelected: "applicationSelected" }, decls: 15, vars: 24, consts: [[1, "imx-main-container"], [1, "imx-title-area"], ["mat-icon-button", "", "class", "mat-elevation-z4 imx-icon-button", "data-imx-identifier", "navigation-button-create-app", 3, "click", 4, "ngIf"], [3, "ngModel", "disabled", "change", "ngModelChange"], [3, "settings", "options", "hideCustomToolbar", "itemStatus", "busyService", "alwaysVisible", "navigationStateChanged", "search"], ["dst", ""], ["fallbackIcon", "application", 1, "imx-application-list", 3, "dst", "selectable", "multiSelect", "image", "titleObject", "subtitleObject", "selectedEntity", "selectionChanged", "selected"], ["tiles", ""], [1, "mat-elevation-z2", 3, "dst"], ["mat-icon-button", "", "data-imx-identifier", "navigation-button-create-app", 1, "mat-elevation-z4", "imx-icon-button", 3, "click"], ["size", "20px", "icon", "add"]], template: function ApplicationNavigationComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "h2");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(5, "imx-help-contextual");
        i0.ɵɵtemplate(6, ApplicationNavigationComponent_button_6_Template, 2, 0, "button", 2);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "mat-checkbox", 3);
        i0.ɵɵlistener("change", function ApplicationNavigationComponent_Template_mat_checkbox_change_7_listener() { return ctx.filterApplicationsWithKpiIssues(); })("ngModelChange", function ApplicationNavigationComponent_Template_mat_checkbox_ngModelChange_7_listener($event) { return ctx.filterKpiChecked = $event; });
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(10, "imx-data-source-toolbar", 4, 5);
        i0.ɵɵlistener("navigationStateChanged", function ApplicationNavigationComponent_Template_imx_data_source_toolbar_navigationStateChanged_10_listener($event) { return ctx.getData($event); })("search", function ApplicationNavigationComponent_Template_imx_data_source_toolbar_search_10_listener($event) { return ctx.onSearch($event); });
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(12, "imx-data-tiles", 6, 7);
        i0.ɵɵlistener("selectionChanged", function ApplicationNavigationComponent_Template_imx_data_tiles_selectionChanged_12_listener($event) { return ctx.onSelectionChanged($event); })("selectionChanged", function ApplicationNavigationComponent_Template_imx_data_tiles_selectionChanged_12_listener($event) { return ctx.onSelectionChanged($event); })("selected", function ApplicationNavigationComponent_Template_imx_data_tiles_selected_12_listener($event) { return ctx.onTileSelected($event); });
        i0.ɵɵelementEnd();
        i0.ɵɵelement(14, "imx-data-source-paginator", 8);
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        const _r1 = i0.ɵɵreference(11);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 19, "#LDS#Applications"));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", ctx.isAdmin);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngModel", ctx.filterKpiChecked)("disabled", !(ctx.dstSettings == null ? null : ctx.dstSettings.dataSource == null ? null : ctx.dstSettings.dataSource.totalCount));
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 21, "#LDS#Only show applications with KPI issues"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(23, _c1$2))("hideCustomToolbar", ctx.hideCustomToolbar)("itemStatus", ctx.status)("busyService", ctx.busyService)("alwaysVisible", true);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r1)("selectable", ctx.selectable)("multiSelect", false)("image", ctx.entitySchema == null ? null : ctx.entitySchema.Columns["JPegPhoto"])("titleObject", ctx.entitySchema == null ? null : ctx.entitySchema.Columns["Ident_AOBApplication"])("subtitleObject", ctx.entitySchema == null ? null : ctx.entitySchema.Columns["Description"])("selectedEntity", ctx.selectedEntity);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r1);
    } }, dependencies: [i5.NgIf, i1$1.EuiIconComponent, i7.MatButton, i9$1.MatCheckbox, i8.NgControlStatus, i8.NgModel, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTilesComponent, i2.HelpContextualComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:inherit;max-width:400px}[_nghost-%COMP%]   h2[_ngcontent-%COMP%]{font-size:24px;font-weight:600}[_nghost-%COMP%]   .mat-checkbox[_ngcontent-%COMP%]{margin-top:10px;font-size:12px}[_nghost-%COMP%]   imx-data-tiles[_ngcontent-%COMP%]{flex-grow:1}[_nghost-%COMP%]   imx-data-source-paginator[_ngcontent-%COMP%]{margin-top:10px;min-width:400px}[_nghost-%COMP%]   .imx-main-container[_ngcontent-%COMP%]{display:flex;height:inherit;flex-direction:column;overflow:hidden;flex:1 1 auto}[_nghost-%COMP%]   .imx-overlay[_ngcontent-%COMP%]{background-color:#f9fbfc;opacity:.5;width:100%;height:100%}[_nghost-%COMP%]   .imx-title-area[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center}[_nghost-%COMP%]   .imx-icon-button[_ngcontent-%COMP%]{line-height:27px;background-color:#fff;margin-left:15px}[_nghost-%COMP%]   .imx-application-list[_ngcontent-%COMP%]{padding-right:20px;padding-top:20px;overflow-y:auto;display:flex;flex-direction:column}[_nghost-%COMP%]   .imx-application-list[_ngcontent-%COMP%]     .imx-data-container{overflow-y:initial}[_nghost-%COMP%]     .mat-badge-warn .mat-badge-content{background-color:#616566}[_nghost-%COMP%]     .badgeContainer{width:355px}[_nghost-%COMP%]     imx-data-tile>.cardContainer>.imx-selected-icon-container{margin-left:0}[_nghost-%COMP%]     .mat-card.imx-data-tile-container{padding:35px 50px 0 25px}[_nghost-%COMP%]     .mat-card.imx-data-tile-container .imx-data-tile-subtitle.mat-subheading-1{align-self:baseline;top:10px;white-space:normal;overflow:hidden;text-overflow:inherit;position:relative;height:2.4em;line-height:18px}[_nghost-%COMP%]     .mat-card.imx-data-tile-container .imx-data-tile-subtitle.mat-subheading-1:after{content:\"\";text-align:right;position:absolute;bottom:0;right:0;width:30px;height:1.2em;background:linear-gradient(to right,rgba(255,255,255,0),rgb(255,255,255) 60%)}@supports (-webkit-line-clamp: 3){[_nghost-%COMP%]     .mat-card.imx-data-tile-container .imx-data-tile-subtitle.mat-subheading-1{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;height:auto;top:0}[_nghost-%COMP%]     .mat-card.imx-data-tile-container .imx-data-tile-subtitle.mat-subheading-1:after{display:none}}.eui-dark-theme   [_nghost-%COMP%]   .imx-overlay[_ngcontent-%COMP%]{background-color:#16191a}.eui-dark-theme   [_nghost-%COMP%]     .mat-badge-warn .mat-badge-content{background-color:#919799}.eui-dark-theme   [_nghost-%COMP%]   .imx-icon-button[_ngcontent-%COMP%]{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]     .imx-selected-icon-container{background-color:#99c478}.eui-contrast-theme   [_nghost-%COMP%]   .imx-overlay[_ngcontent-%COMP%]{background-color:#16191a}.eui-contrast-theme   [_nghost-%COMP%]     .mat-badge-warn .mat-badge-content{background-color:#919799}.eui-contrast-theme   [_nghost-%COMP%]   .imx-icon-button[_ngcontent-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]     .imx-selected-icon-container{background-color:#99c478}.eui-dark-theme   [_nghost-%COMP%]   .mat-icon-button[_ngcontent-%COMP%]{background-color:#444647}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationNavigationComponent, [{
        type: Component,
        args: [{ selector: 'imx-application-navigation', template: "<div class=\"imx-main-container\">\r\n  <div class=\"imx-title-area\">\r\n    <h2>{{ '#LDS#Applications' | translate }}</h2>\r\n    <imx-help-contextual></imx-help-contextual>\r\n    <button *ngIf=\"isAdmin\" mat-icon-button (click)=\"onCreateNew()\" class=\"mat-elevation-z4 imx-icon-button\" data-imx-identifier=\"navigation-button-create-app\">\r\n      <eui-icon size=\"20px\" icon=\"add\"></eui-icon>\r\n    </button>\r\n  </div>\r\n  <mat-checkbox (change)=\"filterApplicationsWithKpiIssues()\" [(ngModel)]=\"filterKpiChecked\" [disabled]=\"!dstSettings?.dataSource?.totalCount\">\r\n    {{ '#LDS#Only show applications with KPI issues' | translate }}\r\n  </mat-checkbox>\r\n  <imx-data-source-toolbar\r\n    #dst\r\n    [settings]=\"dstSettings\"\r\n    (navigationStateChanged)=\"getData($event)\"\r\n    [options]=\"['search']\"\r\n    [hideCustomToolbar]=\"hideCustomToolbar\"\r\n    [itemStatus]=\"status\"\r\n    [busyService]=\"busyService\"\r\n    (search)=\"onSearch($event)\"\r\n    [alwaysVisible]=\"true\"\r\n  >\r\n  </imx-data-source-toolbar>\r\n\r\n  <imx-data-tiles\r\n    #tiles\r\n    class=\"imx-application-list\"\r\n    [dst]=\"dst\"\r\n    [selectable]=\"selectable\"\r\n    [multiSelect]=\"false\"\r\n    [image]=\"entitySchema?.Columns['JPegPhoto']\"\r\n    fallbackIcon=\"application\"\r\n    [titleObject]=\"entitySchema?.Columns['Ident_AOBApplication']\"\r\n    [subtitleObject]=\"entitySchema?.Columns['Description']\"\r\n    (selectionChanged)=\"onSelectionChanged($event)\"\r\n    [selectedEntity]=\"selectedEntity\"\r\n    (selectionChanged)=\"onSelectionChanged($event)\"\r\n    (selected)=\"onTileSelected($event)\"\r\n  >\r\n  </imx-data-tiles>\r\n\r\n  <imx-data-source-paginator class=\"mat-elevation-z2\" [dst]=\"dst\"></imx-data-source-paginator>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;height:inherit;max-width:400px}:host h2{font-size:24px;font-weight:600}:host .mat-checkbox{margin-top:10px;font-size:12px}:host imx-data-tiles{flex-grow:1}:host imx-data-source-paginator{margin-top:10px;min-width:400px}:host .imx-main-container{display:flex;height:inherit;flex-direction:column;overflow:hidden;flex:1 1 auto}:host .imx-overlay{background-color:#f9fbfc;opacity:.5;width:100%;height:100%}:host .imx-title-area{display:flex;flex-direction:row;align-items:center}:host .imx-icon-button{line-height:27px;background-color:#fff;margin-left:15px}:host .imx-application-list{padding-right:20px;padding-top:20px;overflow-y:auto;display:flex;flex-direction:column}:host .imx-application-list ::ng-deep .imx-data-container{overflow-y:initial}:host ::ng-deep .mat-badge-warn .mat-badge-content{background-color:#616566}:host ::ng-deep .badgeContainer{width:355px}:host ::ng-deep imx-data-tile>.cardContainer>.imx-selected-icon-container{margin-left:0}:host ::ng-deep .mat-card.imx-data-tile-container{padding:35px 50px 0 25px}:host ::ng-deep .mat-card.imx-data-tile-container .imx-data-tile-subtitle.mat-subheading-1{align-self:baseline;top:10px;white-space:normal;overflow:hidden;text-overflow:inherit;position:relative;height:2.4em;line-height:18px}:host ::ng-deep .mat-card.imx-data-tile-container .imx-data-tile-subtitle.mat-subheading-1:after{content:\"\";text-align:right;position:absolute;bottom:0;right:0;width:30px;height:1.2em;background:linear-gradient(to right,rgba(255,255,255,0),rgb(255,255,255) 60%)}@supports (-webkit-line-clamp: 3){:host ::ng-deep .mat-card.imx-data-tile-container .imx-data-tile-subtitle.mat-subheading-1{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;height:auto;top:0}:host ::ng-deep .mat-card.imx-data-tile-container .imx-data-tile-subtitle.mat-subheading-1:after{display:none}}.eui-dark-theme :host .imx-overlay{background-color:#16191a}.eui-dark-theme :host ::ng-deep .mat-badge-warn .mat-badge-content{background-color:#919799}.eui-dark-theme :host .imx-icon-button{background-color:#2f3233}.eui-dark-theme :host ::ng-deep .imx-selected-icon-container{background-color:#99c478}.eui-contrast-theme :host .imx-overlay{background-color:#16191a}.eui-contrast-theme :host ::ng-deep .mat-badge-warn .mat-badge-content{background-color:#919799}.eui-contrast-theme :host .imx-icon-button{background-color:#2f3233}.eui-contrast-theme :host ::ng-deep .imx-selected-icon-container{background-color:#99c478}.eui-dark-theme :host .mat-icon-button{background-color:#444647}\n"] }]
    }], function () { return [{ type: i2.ClassloggerService }, { type: ApplicationsService }, { type: i2.SettingsService }, { type: i3.ActivatedRoute }, { type: ApplicationsService }, { type: AobPermissionsService }, { type: i5$2.Overlay }]; }, { dataSourceChanged: [{
            type: Output
        }], applicationSelected: [{
            type: Output
        }], tiles: [{
            type: ViewChild,
            args: ['tiles', { static: true }]
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationsComponent {
    constructor(logger, applicationsProvider, busyService, router, route, snackbar) {
        this.logger = logger;
        this.applicationsProvider = applicationsProvider;
        this.busyService = busyService;
        this.router = router;
        this.route = route;
        this.snackbar = snackbar;
        this.subscriptions = [];
        this.loadingSubject = new Subject();
        this.subscriptions.push(this.applicationsProvider.onApplicationCreated.subscribe(async (uidApplication) => {
            this.selectedApplication = await this.applicationsProvider.reload(uidApplication);
            if (this.selectedApplication == null) {
                return;
            }
            if (this.dataSource?.Data) {
                this.dataSource.Data.shift();
                this.dataSource.Data.unshift(this.selectedApplication);
            }
            this.applicationContent.application = this.selectedApplication;
            return this.redirectToAppDetails(this.selectedApplication.UID_AOBApplication.value);
        }));
        this.subscriptions.push(this.applicationsProvider.onApplicationDeleted.subscribe(async (uidApplication) => {
            const index = this.dataSource.Data.findIndex(elem => elem.UID_AOBApplication.value === uidApplication);
            if (index < 0) {
                return this.redirectToAppDetails(null);
            }
            const removed = this.dataSource.Data.splice(index, 1);
            this.applicationContent.application = null;
            this.snackbar.open({ key: '#LDS#The application "{0}" has been successfully deleted.', parameters: [removed[0].GetEntity().GetDisplay()] });
            return this.redirectToAppDetails(null);
        }));
    }
    ngOnInit() {
        this.route.queryParams.subscribe(async (params) => {
            this.logger.trace(this, 'Routing parameters', params);
            this.selectedApplication = undefined;
            if (params?.id == null) {
                return;
            }
            if (params.id) {
                this.selectedApplication = await this.applicationsProvider.reload(params.id);
            }
            this.applicationContent.application = this.selectedApplication;
            if (!this.selectedApplication) {
                this.applicationNavigation.clearSelection();
            }
            if (this.selectedApplication && this.isEditRoute(this.route)) {
                await this.redirectToAppDetails(this.selectedApplication.UID_AOBApplication.value);
            }
        });
    }
    ngOnDestroy() {
        this.subscriptions.forEach((subscription) => subscription.unsubscribe());
    }
    onActivateNavigationOutlet(componentRef) {
        this.logger.trace(this, 'Initializing Application Navigation View', componentRef);
        this.applicationNavigation = componentRef;
        this.applicationNavigation.loadingSubject = this.loadingSubject;
        this.subscriptions.push(this.applicationNavigation.applicationSelected.subscribe((uidApplication) => this.redirectToAppDetails(uidApplication)));
        this.subscriptions.push(this.applicationNavigation.dataSourceChanged.subscribe((changeSet) => {
            this.dataSource = changeSet?.dataSource;
            this.applicationContent.totalCount = this.dataSource?.totalCount ?? 0;
            this.applicationContent.keywords = changeSet?.keywords;
        }));
    }
    async onActivateContentOutlet(applicationContent) {
        this.applicationContent = applicationContent;
        this.applicationContent.loadingSubject = this.loadingSubject;
        this.logger.trace(this, 'Initializing Application Content View', this.applicationContent);
        if (this.selectedApplication == null) {
            return;
        }
        // reload app:
        this.selectedApplication = await this.applicationsProvider.reload(this.selectedApplication.UID_AOBApplication.value);
        if (applicationContent instanceof ApplicationDetailComponent) {
            this.applicationContent.application = this.selectedApplication;
        }
    }
    isEditRoute(route) {
        return (route.children &&
            route.children.length > 1 &&
            route.children[1].routeConfig.outlet.toLowerCase() === 'content' &&
            route.children[1].routeConfig.path.toLowerCase() === 'edit');
    }
    async redirectToAppDetails(uidApplication) {
        this.logger.trace(this, 'Redirecting to details view.');
        return this.router.navigate(['applications', { outlets: { content: ['detail'] } }], uidApplication ? { queryParams: { id: uidApplication } } : undefined);
    }
}
ApplicationsComponent.ɵfac = function ApplicationsComponent_Factory(t) { return new (t || ApplicationsComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i3.Router), i0.ɵɵdirectiveInject(i3.ActivatedRoute), i0.ɵɵdirectiveInject(i2.SnackBarService)); };
ApplicationsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ApplicationsComponent, selectors: [["imx-applications"]], decls: 4, vars: 0, consts: [[1, "imx-application-navigation"], [3, "activate"], [1, "imx-application-content", "mat-elevation-z1"], ["name", "content", 3, "activate"]], template: function ApplicationsComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "router-outlet", 1);
        i0.ɵɵlistener("activate", function ApplicationsComponent_Template_router_outlet_activate_1_listener($event) { return ctx.onActivateNavigationOutlet($event); });
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(2, "div", 2)(3, "router-outlet", 3);
        i0.ɵɵlistener("activate", function ApplicationsComponent_Template_router_outlet_activate_3_listener($event) { return ctx.onActivateContentOutlet($event); });
        i0.ɵɵelementEnd()();
    } }, dependencies: [i3.RouterOutlet], styles: ["[_nghost-%COMP%]{display:flex;margin:0;flex:1 1 auto;height:calc(100% - 120px)}.imx-application-navigation[_ngcontent-%COMP%]{display:flex;margin-right:30px}.imx-application-content[_ngcontent-%COMP%]{flex:1 1 auto;background-color:#fff;overflow:hidden}.mat-raised-button[_ngcontent-%COMP%]{justify-self:center;margin-top:30px}.eui-dark-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]     .imx-application-content .mat-tab-body{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .imx-application-content[_ngcontent-%COMP%]{background-color:#16191a}.eui-contrast-theme   [_nghost-%COMP%]     .imx-application-content .mat-tab-body{background-color:#16191a}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationsComponent, [{
        type: Component,
        args: [{ selector: 'imx-applications', template: "<div class=\"imx-application-navigation\">\r\n  <router-outlet (activate)=\"onActivateNavigationOutlet($event)\"></router-outlet>\r\n</div>\r\n<div class=\"imx-application-content mat-elevation-z1\">\r\n  <router-outlet name=\"content\" (activate)=\"onActivateContentOutlet($event)\" ></router-outlet>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;margin:0;flex:1 1 auto;height:calc(100% - 120px)}.imx-application-navigation{display:flex;margin-right:30px}.imx-application-content{flex:1 1 auto;background-color:#fff;overflow:hidden}.mat-raised-button{justify-self:center;margin-top:30px}.eui-dark-theme :host .imx-application-content{background-color:#2f3233}.eui-dark-theme :host ::ng-deep .imx-application-content .mat-tab-body{background-color:#2f3233}.eui-contrast-theme :host .imx-application-content{background-color:#16191a}.eui-contrast-theme :host ::ng-deep .imx-application-content .mat-tab-body{background-color:#16191a}\n"] }]
    }], function () { return [{ type: i2.ClassloggerService }, { type: ApplicationsService }, { type: i1$1.EuiLoadingService }, { type: i3.Router }, { type: i3.ActivatedRoute }, { type: i2.SnackBarService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationHyperviewModule {
}
ApplicationHyperviewModule.ɵfac = function ApplicationHyperviewModule_Factory(t) { return new (t || ApplicationHyperviewModule)(); };
ApplicationHyperviewModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ApplicationHyperviewModule });
ApplicationHyperviewModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [ApplicationHyperviewService], imports: [CommonModule, HyperViewModule, TranslateModule, MatDialogModule, MatButtonModule, EuiCoreModule, BusyIndicatorModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationHyperviewModule, [{
        type: NgModule,
        args: [{
                declarations: [ApplicationHyperviewComponent],
                imports: [CommonModule, HyperViewModule, TranslateModule, MatDialogModule, MatButtonModule, EuiCoreModule, BusyIndicatorModule],
                providers: [ApplicationHyperviewService],
                exports: [ApplicationHyperviewComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ApplicationHyperviewModule, { declarations: [ApplicationHyperviewComponent], imports: [CommonModule, HyperViewModule, TranslateModule, MatDialogModule, MatButtonModule, EuiCoreModule, BusyIndicatorModule], exports: [ApplicationHyperviewComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationPropertyModule {
}
ApplicationPropertyModule.ɵfac = function ApplicationPropertyModule_Factory(t) { return new (t || ApplicationPropertyModule)(); };
ApplicationPropertyModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ApplicationPropertyModule });
ApplicationPropertyModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        EuiCoreModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationPropertyModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    ApplicationPropertyComponent
                ],
                exports: [
                    ApplicationPropertyComponent,
                ],
                imports: [
                    CommonModule,
                    EuiCoreModule
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ApplicationPropertyModule, { declarations: [ApplicationPropertyComponent], imports: [CommonModule,
        EuiCoreModule], exports: [ApplicationPropertyComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ColumnInfoModule {
}
ColumnInfoModule.ɵfac = function ColumnInfoModule_Factory(t) { return new (t || ColumnInfoModule)(); };
ColumnInfoModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ColumnInfoModule });
ColumnInfoModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [ApplicationPropertyModule,
        CommonModule,
        DisableControlModule,
        EuiCoreModule,
        QbmModule,
        TranslateModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ColumnInfoModule, [{
        type: NgModule,
        args: [{
                declarations: [ColumnInfoComponent],
                imports: [
                    ApplicationPropertyModule,
                    CommonModule,
                    DisableControlModule,
                    EuiCoreModule,
                    QbmModule,
                    TranslateModule,
                    ReactiveFormsModule,
                    MatButtonModule,
                    MatFormFieldModule,
                    MatInputModule
                ],
                exports: [ColumnInfoComponent]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ColumnInfoModule, { declarations: [ColumnInfoComponent], imports: [ApplicationPropertyModule,
        CommonModule,
        DisableControlModule,
        EuiCoreModule,
        QbmModule,
        TranslateModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule], exports: [ColumnInfoComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobUserModule {
}
AobUserModule.ɵfac = function AobUserModule_Factory(t) { return new (t || AobUserModule)(); };
AobUserModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: AobUserModule });
AobUserModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        MatIconModule,
        UserModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobUserModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    UserComponent
                ],
                imports: [
                    CommonModule,
                    MatIconModule,
                    UserModule
                ],
                exports: [
                    UserComponent
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(AobUserModule, { declarations: [UserComponent], imports: [CommonModule,
        MatIconModule,
        UserModule], exports: [UserComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class LifecycleActionsModule {
}
LifecycleActionsModule.ɵfac = function LifecycleActionsModule_Factory(t) { return new (t || LifecycleActionsModule)(); };
LifecycleActionsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: LifecycleActionsModule });
LifecycleActionsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        FormsModule,
        LdsReplaceModule,
        MatButtonModule,
        MatCardModule,
        MatDialogModule,
        MatDatepickerModule,
        MatFormFieldModule,
        MatInputModule,
        MatRadioModule,
        ReactiveFormsModule,
        QbmModule,
        TranslateModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(LifecycleActionsModule, [{
        type: NgModule,
        args: [{
                declarations: [LifecycleActionComponent],
                imports: [
                    CommonModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    EuiCoreModule,
                    FormsModule,
                    LdsReplaceModule,
                    MatButtonModule,
                    MatCardModule,
                    MatDialogModule,
                    MatDatepickerModule,
                    MatFormFieldModule,
                    MatInputModule,
                    MatRadioModule,
                    ReactiveFormsModule,
                    QbmModule,
                    TranslateModule
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(LifecycleActionsModule, { declarations: [LifecycleActionComponent], imports: [CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        FormsModule,
        LdsReplaceModule,
        MatButtonModule,
        MatCardModule,
        MatDialogModule,
        MatDatepickerModule,
        MatFormFieldModule,
        MatInputModule,
        MatRadioModule,
        ReactiveFormsModule,
        QbmModule,
        TranslateModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementEditModule {
}
EntitlementEditModule.ɵfac = function EntitlementEditModule_Factory(t) { return new (t || EntitlementEditModule)(); };
EntitlementEditModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: EntitlementEditModule });
EntitlementEditModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CdrModule,
        CommonModule,
        EuiCoreModule,
        FormsModule,
        MatButtonModule,
        MatCardModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatInputModule,
        ReactiveFormsModule,
        ServiceItemTagsModule,
        TranslateModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementEditModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    EntitlementEditComponent
                ],
                exports: [
                    EntitlementEditComponent
                ],
                imports: [
                    CdrModule,
                    CommonModule,
                    EuiCoreModule,
                    FormsModule,
                    MatButtonModule,
                    MatCardModule,
                    MatCheckboxModule,
                    MatFormFieldModule,
                    MatInputModule,
                    ReactiveFormsModule,
                    ServiceItemTagsModule,
                    TranslateModule
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(EntitlementEditModule, { declarations: [EntitlementEditComponent], imports: [CdrModule,
        CommonModule,
        EuiCoreModule,
        FormsModule,
        MatButtonModule,
        MatCardModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatInputModule,
        ReactiveFormsModule,
        ServiceItemTagsModule,
        TranslateModule], exports: [EntitlementEditComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EntitlementsModule {
}
EntitlementsModule.ɵfac = function EntitlementsModule_Factory(t) { return new (t || EntitlementsModule)(); };
EntitlementsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: EntitlementsModule });
EntitlementsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        EntitlementsService
    ], imports: [ClassloggerModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTilesModule,
        DisableControlModule,
        EuiCoreModule,
        EuiMaterialModule,
        EntitlementEditModule,
        FormsModule,
        LdsReplaceModule,
        MatBadgeModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatIconModule,
        MatRadioModule,
        MatTableModule,
        MatTooltipModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatSlideToggleModule,
        MatInputModule,
        MatMenuModule,
        QbmModule,
        ReactiveFormsModule,
        TranslateModule,
        AobUserModule,
        LifecycleActionsModule,
        CdrModule,
        ScrollingModule,
        SqlWizardModule,
        InfoModalDialogModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EntitlementsModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    EntitlementsAddComponent,
                    EntitlementsComponent,
                    EntitlementDetailComponent,
                    SystemRoleConfigComponent,
                    EntitlementEditAutoAddComponent,
                    MappedEntitlementsPreviewComponent
                ],
                imports: [
                    ClassloggerModule,
                    CommonModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    DataTilesModule,
                    DisableControlModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    EntitlementEditModule,
                    FormsModule,
                    LdsReplaceModule,
                    MatBadgeModule,
                    MatButtonToggleModule,
                    MatCardModule,
                    MatCheckboxModule,
                    MatIconModule,
                    MatRadioModule,
                    MatTableModule,
                    MatTooltipModule,
                    MatButtonModule,
                    MatDividerModule,
                    MatFormFieldModule,
                    MatSlideToggleModule,
                    MatInputModule,
                    MatMenuModule,
                    QbmModule,
                    ReactiveFormsModule,
                    TranslateModule,
                    AobUserModule,
                    LifecycleActionsModule,
                    CdrModule,
                    ScrollingModule,
                    SqlWizardModule,
                    InfoModalDialogModule
                ],
                providers: [
                    EntitlementsService
                ],
                exports: [
                    EntitlementsComponent
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(EntitlementsModule, { declarations: [EntitlementsAddComponent,
        EntitlementsComponent,
        EntitlementDetailComponent,
        SystemRoleConfigComponent,
        EntitlementEditAutoAddComponent,
        MappedEntitlementsPreviewComponent], imports: [ClassloggerModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTilesModule,
        DisableControlModule,
        EuiCoreModule,
        EuiMaterialModule,
        EntitlementEditModule,
        FormsModule,
        LdsReplaceModule,
        MatBadgeModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatIconModule,
        MatRadioModule,
        MatTableModule,
        MatTooltipModule,
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatSlideToggleModule,
        MatInputModule,
        MatMenuModule,
        QbmModule,
        ReactiveFormsModule,
        TranslateModule,
        AobUserModule,
        LifecycleActionsModule,
        CdrModule,
        ScrollingModule,
        SqlWizardModule,
        InfoModalDialogModule], exports: [EntitlementsComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class KpiModule {
}
KpiModule.ɵfac = function KpiModule_Factory(t) { return new (t || KpiModule)(); };
KpiModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: KpiModule });
KpiModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [KpiOverviewService], imports: [CommonModule,
        TranslateModule,
        MatCardModule,
        MatButtonModule,
        MatTooltipModule,
        EuiCoreModule,
        EuiMaterialModule,
        ClassloggerModule,
        BusyIndicatorModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(KpiModule, [{
        type: NgModule,
        args: [{
                imports: [
                    CommonModule,
                    TranslateModule,
                    MatCardModule,
                    MatButtonModule,
                    MatTooltipModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    ClassloggerModule,
                    BusyIndicatorModule,
                ],
                declarations: [KpiOverviewComponent],
                providers: [KpiOverviewService],
                exports: [KpiOverviewComponent],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(KpiModule, { declarations: [KpiOverviewComponent], imports: [CommonModule,
        TranslateModule,
        MatCardModule,
        MatButtonModule,
        MatTooltipModule,
        EuiCoreModule,
        EuiMaterialModule,
        ClassloggerModule,
        BusyIndicatorModule], exports: [KpiOverviewComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApplicationsModule {
}
ApplicationsModule.ɵfac = function ApplicationsModule_Factory(t) { return new (t || ApplicationsModule)(); };
ApplicationsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ApplicationsModule });
ApplicationsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        ApplicationsService
    ], imports: [CommonModule,
        ApplicationHyperviewModule,
        ApplicationPropertyModule,
        ClassloggerModule,
        ColumnInfoModule,
        EntitlementsModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        KpiModule,
        LdsReplaceModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatButtonModule,
        MatCardModule,
        MatDividerModule,
        MatIconModule,
        MatInputModule,
        MatTabsModule,
        SelectModule,
        MatDialogModule,
        MatTooltipModule,
        QbmModule,
        DateModule,
        ReactiveFormsModule,
        TranslateModule,
        AobUserModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTilesModule,
        DataTreeModule,
        DataTreeWrapperModule,
        RouterModule,
        OverlayModule,
        PortalModule,
        FkAdvancedPickerModule,
        EntityModule,
        ImageModule,
        CdrModule,
        InfoModalDialogModule,
        HelpContextualModule,
        BusyIndicatorModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApplicationsModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    ApplicationsComponent,
                    ApplicationDetailComponent,
                    ApplicationDetailsComponent,
                    ApplicationNavigationComponent,
                    EditApplicationComponent,
                    ApplicationCreateComponent,
                    ApplicationImageSelectComponent,
                    ImageSelectorDialogComponent,
                    AuthenticationRootComponent,
                    IdentitiesComponent,
                    IdentityDetailComponent,
                    ServiceCategoryComponent,
                    EditServiceCategoryInformationComponent
                ],
                imports: [
                    CommonModule,
                    ApplicationHyperviewModule,
                    ApplicationPropertyModule,
                    ClassloggerModule,
                    ColumnInfoModule,
                    EntitlementsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    FormsModule,
                    KpiModule,
                    LdsReplaceModule,
                    MatAutocompleteModule,
                    MatBadgeModule,
                    MatButtonModule,
                    MatCardModule,
                    MatDividerModule,
                    MatIconModule,
                    MatInputModule,
                    MatTabsModule,
                    SelectModule,
                    MatDialogModule,
                    MatTooltipModule,
                    QbmModule,
                    DateModule,
                    ReactiveFormsModule,
                    TranslateModule,
                    AobUserModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    DataTilesModule,
                    DataTreeModule,
                    DataTreeWrapperModule,
                    RouterModule,
                    OverlayModule,
                    PortalModule,
                    FkAdvancedPickerModule,
                    EntityModule,
                    ImageModule,
                    CdrModule,
                    InfoModalDialogModule,
                    HelpContextualModule,
                    BusyIndicatorModule,
                ],
                providers: [
                    ApplicationsService
                ],
                exports: [
                    ApplicationsComponent,
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ApplicationsModule, { declarations: [ApplicationsComponent,
        ApplicationDetailComponent,
        ApplicationDetailsComponent,
        ApplicationNavigationComponent,
        EditApplicationComponent,
        ApplicationCreateComponent,
        ApplicationImageSelectComponent,
        ImageSelectorDialogComponent,
        AuthenticationRootComponent,
        IdentitiesComponent,
        IdentityDetailComponent,
        ServiceCategoryComponent,
        EditServiceCategoryInformationComponent], imports: [CommonModule,
        ApplicationHyperviewModule,
        ApplicationPropertyModule,
        ClassloggerModule,
        ColumnInfoModule,
        EntitlementsModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        KpiModule,
        LdsReplaceModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatButtonModule,
        MatCardModule,
        MatDividerModule,
        MatIconModule,
        MatInputModule,
        MatTabsModule,
        SelectModule,
        MatDialogModule,
        MatTooltipModule,
        QbmModule,
        DateModule,
        ReactiveFormsModule,
        TranslateModule,
        AobUserModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTilesModule,
        DataTreeModule,
        DataTreeWrapperModule,
        RouterModule,
        OverlayModule,
        PortalModule,
        FkAdvancedPickerModule,
        EntityModule,
        ImageModule,
        CdrModule,
        InfoModalDialogModule,
        HelpContextualModule,
        BusyIndicatorModule], exports: [ApplicationsComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * A service that provides endpoints for KPI features
 */
class GlobalKpiService {
    constructor(aobClient, apiProvider) {
        this.aobClient = aobClient;
        this.apiProvider = apiProvider;
    }
    /**
     * Encapsules the aob/kpi GET endpoint
     */
    async get() {
        return this.apiProvider.request(() => this.aobClient.client.portal_kpi_get());
    }
}
GlobalKpiService.ɵfac = function GlobalKpiService_Factory(t) { return new (t || GlobalKpiService)(i0.ɵɵinject(AobApiService), i0.ɵɵinject(i2.ApiClientService)); };
GlobalKpiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GlobalKpiService, factory: GlobalKpiService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GlobalKpiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: AobApiService }, { type: i2.ApiClientService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$1 = ["chartdialog"];
const _c1$1 = function () { return { minimumFractionDigits: 0, maximumFractionDigits: 3 }; };
function GlobalKpiComponent_ng_container_8_li_2_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "li")(1, "span", 6);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "span", 7);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "button", 8);
    i0.ɵɵlistener("click", function GlobalKpiComponent_ng_container_8_li_2_Template_button_click_5_listener() { const restoredCtx = i0.ɵɵrestoreView(_r8); const kpi_r6 = restoredCtx.$implicit; const ctx_r7 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r7.showDetails(kpi_r6)); });
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const kpi_r6 = ctx.$implicit;
    const ctx_r5 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(!kpi_r6.calculated ? "-" : !kpi_r6.currentDataValue ? "" : kpi_r6.currentDataValue.toLocaleString(ctx_r5.browserCulture, i0.ɵɵpureFunction0(6, _c1$1)));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(kpi_r6.chartData.Display);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("disabled", !ctx_r5.isCalculated(kpi_r6.chartData));
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 4, "#LDS#View"), " ");
} }
function GlobalKpiComponent_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "ul", 4);
    i0.ɵɵtemplate(2, GlobalKpiComponent_ng_container_8_li_2_Template, 8, 7, "li", 5);
    i0.ɵɵelementEnd();
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r0.kpiData);
} }
function GlobalKpiComponent_ng_template_9_div_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 17);
    i0.ɵɵelement(1, "eui-billboard", 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r9 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("options", data_r9.pieChart);
} }
function GlobalKpiComponent_ng_template_9_h3_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "h3");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#History"));
} }
function GlobalKpiComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 9)(1, "div", 10);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "button", 11);
    i0.ɵɵelement(4, "eui-icon", 12);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(5, "div", 13)(6, "p", 14);
    i0.ɵɵtext(7);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(8, GlobalKpiComponent_ng_template_9_div_8_Template, 2, 1, "div", 15);
    i0.ɵɵtemplate(9, GlobalKpiComponent_ng_template_9_h3_9_Template, 3, 3, "h3", 16);
    i0.ɵɵelementStart(10, "div", 17);
    i0.ɵɵelement(11, "eui-billboard", 18);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r9 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(data_r9.chartData.Display);
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(data_r9.chartData.Description);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", data_r9.pieChart != null);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", data_r9.chartOptions != null);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("options", data_r9.chartDetails);
} }
function GlobalKpiComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 20)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, "#LDS#No global KPIs defined"));
} }
/**
 * Builds a component, that displays global KPI data (key performance indicators)
 * Every KPI is displayed with its display value
 * Every KPI card has a "Details" Button, to show a detailed chart
 */
class GlobalKpiComponent {
    constructor(logger, kpiProvider, matDialog, busyService, translateService) {
        this.logger = logger;
        this.kpiProvider = kpiProvider;
        this.matDialog = matDialog;
        this.busyService = busyService;
        this.translateService = translateService;
        this.kpiData = [];
        this.colors = ['#B4E6F4', '#82D5ED', '#50C4E6', '#2BB7E0',
            '#05AADB', '#04A3D7', '#0499D2', '#0390CD', '#017FC4'];
        this.browserCulture = this.translateService.currentLang;
        translateService.get('#LDS#No data available')
            .subscribe((trans) => this.noDataLoaded = trans);
        translateService.get('#LDS#Used in business roles')
            .subscribe((trans) => this.business = trans);
        translateService.get('#LDS#Using central directory')
            .subscribe((trans) => this.central = trans);
        translateService.get('#LDS#Other')
            .subscribe((trans) => this.others = trans);
    }
    /**
     * Loads the chartDto objects and inits the component
     */
    async ngOnInit() {
        let overlayRef;
        setTimeout(() => overlayRef = this.busyService.show());
        try {
            this.kpiData = (await this.kpiProvider.get())
                .map((elem, i) => this.buildKpiData(i, elem));
        }
        finally {
            setTimeout(() => this.busyService.hide(overlayRef));
        }
    }
    /**
     * @ignore opens a dialog that shows the details of a KPI
     * @param chart the data of a single chart
     */
    showDetails(kpi) {
        if (kpi.chartData.Data.length === 0) {
            return;
        }
        kpi.chartDetails = this.buildLineOptions(kpi.chartData, kpi.pieChart != null, kpi.names);
        this.matDialog.open(this.chartDialog, { data: kpi, minWidth: 600, autoFocus: false });
    }
    /**
     * @ignore determines whether a chart has detailed data
     * @param chart the data of a single chart
     * @returns true, if the KPI has DataPoits also false
     */
    isCalculated(chart) {
        return chart.Data != null && chart.Data.length > 0 && chart.Data[0].Points != null;
    }
    /**
     * @ignore determines whether an application has chart data or not
     * @returns true, if there are any KPIs else false
     */
    hasKpis() {
        return (this.kpiData != null && this.kpiData.length > 0 && this.kpiData.some(elem => elem != null));
    }
    buildKpiData(chartIndex, chart) {
        const calc = this.isCalculated(chart);
        if (!calc) {
            return { index: chartIndex, chartData: chart, calculated: false, names: [] };
        }
        let currentData = null;
        let pieOptions = null;
        let captions;
        switch (chartIndex) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 7:
            case 8:
                currentData = chart.Data[0].Points[0].Value;
                captions = chart.Data.map(ch => ch.Name);
                break;
            case 4:
                pieOptions = this.buildSingleValueChart(chart, this.central);
                captions = [this.central];
                break;
            case 6:
                pieOptions = this.buildSingleValueChart(chart, this.business);
                captions = [this.central];
                break;
            case 5:
                pieOptions = this.buildPieChart(chart);
                captions = chart.Data.map(ch => ch.Name);
                break;
        }
        return { index: chartIndex, chartData: chart, calculated: calc, names: captions, currentDataValue: currentData, pieChart: pieOptions };
    }
    buildSingleValueChart(chart, name) {
        if (!this.isCalculated(chart)) {
            this.logger.debug(this, 'The chart is not calculated yet, therefore no chart is build');
            return undefined;
        }
        return {
            size: { width: 271, height: 271 },
            data: {
                columns: [['data1', chart.Data[0].Points[0].Value],
                    ['data2', 100 - chart.Data[0].Points[0].Value]],
                names: { data1: name, data2: this.others },
                colors: { data1: this.colors[0], data2: '#CCC' },
                type: pie(),
                empty: {
                    label: {
                        text: this.noDataLoaded
                    }
                }
            }, pie: {
                padAngle: 0.01,
                label: {
                    format: d => `${d.toLocaleString(this.browserCulture, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`,
                    threshold: 0.06
                },
            }
        };
    }
    buildPieChart(chart) {
        if (!this.isCalculated(chart)) {
            this.logger.debug(this, 'The chart is not calculated yet, therefore no chart is build');
            return undefined;
        }
        return {
            size: { width: 271, height: 271 },
            data: {
                columns: chart.Data.map((ch, index) => ['data' + index, ch.Points[0].Value]),
                names: this.toObject(chart.Data.map((ch, index) => ({ key: 'data' + index, value: ch.Name }))),
                colors: this.toObject(chart.Data.map((ch, index) => ({ key: 'data' + index, value: this.colors[index] }))),
                type: pie(),
                empty: {
                    label: {
                        text: this.noDataLoaded
                    }
                }
            }, pie: {
                padAngle: 0.01,
                label: {
                    format: d => `${d.toLocaleString(this.browserCulture, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`,
                    threshold: 0.06
                },
            }
        };
    }
    /**
     * @ignore converts an array of string arrays to an object ( first strign is the property name
     * second string the value)
     * @param array an array of string arrays
     *
     */
    toObject(array) {
        const ret = {};
        for (const elem of array) {
            ret[elem.key] = elem.value;
        }
        return ret;
    }
    /**
     * @ignore determines whether a chart has more then one data point
     * @param chart the data of a single chart
     * @returns true, if the chart has multiple points else it return false
     */
    hasMultipleDataPoints(chart) {
        return this.isCalculated(chart) && chart.Data[0].Points.length > 1;
    }
    /**
     * @ignore Build the ChartOptions that can be displayed with billboard.js
     * @param chart the data of a single chart
     * @returns a ChartOptions object, that can be used by billboard.js
     */
    buildLineOptions(chart, isPercentage, names) {
        const yAxis = new YAxisInformation(chart.Data.map((serie, id) => new SeriesInformation(names[id], serie.Points.map((point) => point.Value), this.colors[id])));
        yAxis.tickConfiguration = {
            format: (d) => isPercentage ? `${d.toLocaleString(this.browserCulture)}%` : `${d.toLocaleString(this.browserCulture)}`,
            values: this.accumulateTicks(chart)
        };
        const lineChartOptions = new LineChartOptions(new XAxisInformation('date', chart.Data[0].Points.map((point) => new Date(point.Date)), {
            count: 6,
            format: (d) => d.toLocaleDateString(this.browserCulture)
        }), yAxis);
        lineChartOptions.useCurvedLines = false;
        lineChartOptions.hideLegend = chart.Data.length === 1;
        lineChartOptions.showPoints = !this.hasMultipleDataPoints(chart);
        lineChartOptions.size = { width: 500, height: 325 };
        return lineChartOptions.options;
    }
    accumulateTicks(chart) {
        const ret = [];
        const max = Math.max.apply(Math, chart.Data.map(o => this.getMax(o.Points)));
        const steps = Math.max(1, Math.trunc(max / 10)) + 1;
        ret.push(0);
        if (max <= 0) {
            return ret;
        }
        for (let index = 1; index <= 10; index++) {
            ret.push(index * steps);
        }
        return ret;
    }
    getMax(points) {
        return Math.max.apply(Math, points.map(o => o.Value));
    }
}
GlobalKpiComponent.ɵfac = function GlobalKpiComponent_Factory(t) { return new (t || GlobalKpiComponent)(i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(GlobalKpiService), i0.ɵɵdirectiveInject(i1$2.MatDialog), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i3$1.TranslateService)); };
GlobalKpiComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GlobalKpiComponent, selectors: [["imx-global-kpi"]], viewQuery: function GlobalKpiComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0$1, 7);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.chartDialog = _t.first);
    } }, decls: 13, vars: 8, consts: [[1, "mat-headline"], [4, "ngIf", "ngIfElse"], ["chartdialog", ""], ["nonExisting", ""], [1, "imx-kpi-list"], [4, "ngFor", "ngForOf"], [1, "imx-kpi-number"], [1, "imx-kpi-display"], ["color", "primary", "mat-button", "", "data-imx-identifier", "global_KPI_showShowDetails", 3, "disabled", "click"], ["mat-dialog-title", ""], [1, "imx-title-text"], ["mat-icon-button", "", "color", "basic", "data-imx-identifier", "global_KPI_closeChartDialog", "mat-dialog-close", "", 1, "imx-close-dialog-button"], ["icon", "close", "size", "large"], ["mat-dialog-content", ""], [1, "imx-subtitle-text"], ["class", "imx-chart", 4, "ngIf"], [4, "ngIf"], [1, "imx-chart"], [3, "options"], [1, "imx-kpi-chart", 3, "options"], [1, "imx-aob-kpi-empty"]], template: function GlobalKpiComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "h2", 0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "mat-card")(4, "mat-card-subtitle");
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "mat-card-content");
        i0.ɵɵtemplate(8, GlobalKpiComponent_ng_container_8_Template, 3, 1, "ng-container", 1);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(9, GlobalKpiComponent_ng_template_9_Template, 12, 5, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵtemplate(11, GlobalKpiComponent_ng_template_11_Template, 4, 3, "ng-template", null, 3, i0.ɵɵtemplateRefExtractor);
    } if (rf & 2) {
        const _r3 = i0.ɵɵreference(12);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, "#LDS#Global KPIs"), "\n");
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 6, "#LDS#These KPIs give you an overview of your applications, their contents and states."));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", ctx.hasKpis())("ngIfElse", _r3);
    } }, dependencies: [i5.NgForOf, i5.NgIf, i6.MatCard, i6.MatCardContent, i6.MatCardSubtitle, i7.MatButton, i1$2.MatDialogClose, i1$2.MatDialogTitle, i1$2.MatDialogContent, i1$1.EuiBillboardComponent, i1$1.EuiIconComponent, i3$1.TranslatePipe], styles: ["li[_ngcontent-%COMP%]{list-style-type:none;margin:0 15px 0 32px;display:table-row;align-items:center}li[_ngcontent-%COMP%] > .imx-kpi-display[_ngcontent-%COMP%]{display:table-cell;width:100%}li[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:nth-child(3n){display:table-cell}li[_ngcontent-%COMP%] > .imx-kpi-number[_ngcontent-%COMP%]{display:table-cell;color:#919799;text-align:right;font-size:16px;font-weight:600;padding:0 16px 0 0}.mat-card[_ngcontent-%COMP%]{display:flex;flex-direction:column}.mat-card-content[_ngcontent-%COMP%]{padding:0 10px 0 35px;overflow:auto}.mat-card-content[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:last-child{margin-bottom:10px}.mat-card-subtitle[_ngcontent-%COMP%]{font-size:16px;color:#2f3233;font-weight:400;padding:5px 33px 20px;margin-bottom:0;flex-grow:1}p[_ngcontent-%COMP%]{font-size:14px;color:#919799;margin-top:0}h3[_ngcontent-%COMP%]{font-size:16px;font-weight:600;margin:30px 0 15px;text-align:center}.imx-kpi-list[_ngcontent-%COMP%]{overflow:auto;margin-bottom:5px;display:table}.imx-chart[_ngcontent-%COMP%]{display:flex;justify-content:center;flex-direction:row}.mat-dialog-title[_ngcontent-%COMP%]{display:flex;margin:0}.mat-dialog-content[_ngcontent-%COMP%]{max-height:100%}.imx-title-text[_ngcontent-%COMP%]{text-align:center;margin:0 0 0 45px;flex:1}.imx-subtitle-text[_ngcontent-%COMP%]{text-align:center;margin:0}.imx-close-dialog-button[_ngcontent-%COMP%]{right:-15px;top:-15px}.imx-aob-kpi-empty[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;margin-bottom:10px;margin-top:10px}.imx-aob-kpi-empty[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{margin-left:24px}.imx-aob-kpi-empty[_ngcontent-%COMP%] > .eui-icon[_ngcontent-%COMP%]{color:#aab0b3}  .bb-chart-arc text{fill:#2f3233}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GlobalKpiComponent, [{
        type: Component,
        args: [{ selector: 'imx-global-kpi', template: "<h2 class=\"mat-headline\">\r\n  {{ '#LDS#Global KPIs' | translate }}\r\n</h2>\r\n<mat-card>\r\n  <mat-card-subtitle>{{ '#LDS#These KPIs give you an overview of your applications, their contents and states.' | translate }}</mat-card-subtitle>\r\n  <mat-card-content>\r\n    <ng-container *ngIf=\"hasKpis(); else nonExisting\">\r\n      <ul class=\"imx-kpi-list\">\r\n        <li *ngFor=\"let kpi of kpiData\">\r\n          <span class=\"imx-kpi-number\">{{\r\n            !kpi.calculated ? '-' : !kpi.currentDataValue ? '' : kpi.currentDataValue.toLocaleString(this.browserCulture, { minimumFractionDigits: 0, maximumFractionDigits: 3 })\r\n          }}</span>\r\n          <span class=\"imx-kpi-display\">{{ kpi.chartData.Display }}</span>\r\n          <button [disabled]=\"!isCalculated(kpi.chartData)\" color=\"primary\" mat-button data-imx-identifier=\"global_KPI_showShowDetails\" (click)=\"showDetails(kpi)\">\r\n            {{ '#LDS#View' | translate }}\r\n          </button>\r\n        </li>\r\n      </ul>\r\n    </ng-container>\r\n  </mat-card-content>\r\n</mat-card>\r\n\r\n<ng-template #chartdialog let-data>\r\n  <div mat-dialog-title>\r\n    <div class=\"imx-title-text\">{{ data.chartData.Display }}</div>\r\n    <button mat-icon-button color=\"basic\" data-imx-identifier=\"global_KPI_closeChartDialog\" class=\"imx-close-dialog-button\" mat-dialog-close>\r\n      <eui-icon icon=\"close\" size=\"large\"></eui-icon>\r\n    </button>\r\n  </div>\r\n  <div mat-dialog-content>\r\n    <p class=\"imx-subtitle-text\">{{ data.chartData.Description }}</p>\r\n    <div class=\"imx-chart\" *ngIf=\"data.pieChart != null\">\r\n      <eui-billboard class=\"imx-kpi-chart\" [options]=\"data.pieChart\"></eui-billboard>\r\n    </div>\r\n    <h3 *ngIf=\"data.chartOptions != null\">{{ '#LDS#History' | translate }}</h3>\r\n    <div class=\"imx-chart\">\r\n      <eui-billboard [options]=\"data.chartDetails\"></eui-billboard>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<!-- Template for non existing entitlements -->\r\n<ng-template #nonExisting>\r\n  <div class=\"imx-aob-kpi-empty\">\r\n    <span>{{ '#LDS#No global KPIs defined' | translate }}</span>\r\n  </div>\r\n</ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */li{list-style-type:none;margin:0 15px 0 32px;display:table-row;align-items:center}li>.imx-kpi-display{display:table-cell;width:100%}li :nth-child(3n){display:table-cell}li>.imx-kpi-number{display:table-cell;color:#919799;text-align:right;font-size:16px;font-weight:600;padding:0 16px 0 0}.mat-card{display:flex;flex-direction:column}.mat-card-content{padding:0 10px 0 35px;overflow:auto}.mat-card-content>:last-child{margin-bottom:10px}.mat-card-subtitle{font-size:16px;color:#2f3233;font-weight:400;padding:5px 33px 20px;margin-bottom:0;flex-grow:1}p{font-size:14px;color:#919799;margin-top:0}h3{font-size:16px;font-weight:600;margin:30px 0 15px;text-align:center}.imx-kpi-list{overflow:auto;margin-bottom:5px;display:table}.imx-chart{display:flex;justify-content:center;flex-direction:row}.mat-dialog-title{display:flex;margin:0}.mat-dialog-content{max-height:100%}.imx-title-text{text-align:center;margin:0 0 0 45px;flex:1}.imx-subtitle-text{text-align:center;margin:0}.imx-close-dialog-button{right:-15px;top:-15px}.imx-aob-kpi-empty{display:flex;flex-direction:column;align-items:center;margin-bottom:10px;margin-top:10px}.imx-aob-kpi-empty span{margin-left:24px}.imx-aob-kpi-empty>.eui-icon{color:#aab0b3}::ng-deep .bb-chart-arc text{fill:#2f3233}\n"] }]
    }], function () { return [{ type: i2.ClassloggerService }, { type: GlobalKpiService }, { type: i1$2.MatDialog }, { type: i1$1.EuiLoadingService }, { type: i3$1.TranslateService }]; }, { chartDialog: [{
            type: ViewChild,
            args: ['chartdialog', { static: true }]
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobApplicationsGuardService {
    constructor(aobPermissionService, authentication, appConfig, router, routeGuardService) {
        this.aobPermissionService = aobPermissionService;
        this.authentication = authentication;
        this.appConfig = appConfig;
        this.router = router;
        this.routeGuardService = routeGuardService;
    }
    async canActivate(route, state) {
        if (await this.routeGuardService.canActivate(route, state)) {
            const isApplicationOwner = await this.aobPermissionService.isAobApplicationOwner();
            const isApplicationAdmin = await this.aobPermissionService.isAobApplicationAdmin();
            if (!isApplicationOwner && !isApplicationAdmin) {
                this.router.navigate([this.appConfig.Config.routeConfig.start], { queryParams: {} });
            }
            return isApplicationOwner || isApplicationAdmin;
        }
        this.router.navigate([this.appConfig.Config.routeConfig.login]);
        return false;
    }
    ngOnDestroy() {
        if (this.onSessionResponse) {
            this.onSessionResponse.unsubscribe();
        }
    }
}
AobApplicationsGuardService.ɵfac = function AobApplicationsGuardService_Factory(t) { return new (t || AobApplicationsGuardService)(i0.ɵɵinject(AobPermissionsService), i0.ɵɵinject(i2.AuthenticationService), i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i3.Router), i0.ɵɵinject(i2.RouteGuardService)); };
AobApplicationsGuardService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobApplicationsGuardService, factory: AobApplicationsGuardService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobApplicationsGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: AobPermissionsService }, { type: i2.AuthenticationService }, { type: i2.AppConfigService }, { type: i3.Router }, { type: i2.RouteGuardService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AobKpiGuardService {
    constructor(aobPermissionService, authentication, appConfig, router, routeGuardService) {
        this.aobPermissionService = aobPermissionService;
        this.authentication = authentication;
        this.appConfig = appConfig;
        this.router = router;
        this.routeGuardService = routeGuardService;
    }
    async canActivate(route, state) {
        if (await this.routeGuardService.canActivate(route, state)) {
            const isApplicationAdmin = await this.aobPermissionService.isAobApplicationAdmin();
            if (!isApplicationAdmin) {
                this.router.navigate([this.appConfig.Config.routeConfig.start], { queryParams: {} });
            }
            return isApplicationAdmin;
        }
        this.router.navigate([this.appConfig.Config.routeConfig.login]);
        return false;
    }
    ngOnDestroy() {
        if (this.onSessionResponse) {
            this.onSessionResponse.unsubscribe();
        }
    }
}
AobKpiGuardService.ɵfac = function AobKpiGuardService_Factory(t) { return new (t || AobKpiGuardService)(i0.ɵɵinject(AobPermissionsService), i0.ɵɵinject(i2.AuthenticationService), i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i3.Router), i0.ɵɵinject(i2.RouteGuardService)); };
AobKpiGuardService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AobKpiGuardService, factory: AobKpiGuardService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobKpiGuardService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: AobPermissionsService }, { type: i2.AuthenticationService }, { type: i2.AppConfigService }, { type: i3.Router }, { type: i2.RouteGuardService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ImageService {
    constructor(qerClient, sanitizer, apiProvider) {
        this.qerClient = qerClient;
        this.sanitizer = sanitizer;
        this.apiProvider = apiProvider;
    }
    /**
     * Gets the person image URL converted to a SafeUrl
     */
    async getPersonImageUrl(uid) {
        if (uid && uid.length > 0) {
            const imageData = await this.apiProvider.request(() => this.qerClient.client.portal_person_image_get(uid));
            if (imageData != null && imageData.size > 0 && ['image/png', 'image/jpeg', 'image/gif'].includes(imageData.type)) {
                return this.sanitizer.sanitize(SecurityContext.URL, URL.createObjectURL(imageData));
            }
        }
        return undefined;
    }
}
ImageService.ɵfac = function ImageService_Factory(t) { return new (t || ImageService)(i0.ɵɵinject(i1.QerApiService), i0.ɵɵinject(i2$1.DomSanitizer), i0.ɵɵinject(i2.ApiClientService)); };
ImageService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ImageService, factory: ImageService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ImageService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: i1.QerApiService }, { type: i2$1.DomSanitizer }, { type: i2.ApiClientService }]; }, null); })();

const _c0 = ["img"];
function StartPageComponent_img_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "img", null, 9);
} }
function StartPageComponent_mat_icon_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-icon", 10);
    i0.ɵɵtext(1, "account_circle");
    i0.ɵɵelementEnd();
} }
function StartPageComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 11)(1, "div");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div", 12);
    i0.ɵɵtext(5);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(3, 2, "#LDS#Welcome"), ",\u00A0");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r2.name);
} }
function StartPageComponent_mat_card_content_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card-content");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "ldsReplace");
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(2, 1, i0.ɵɵpipeBind1(3, 4, "#LDS#{0} Applications"), ctx_r3.numberOfApplications), " ");
} }
function StartPageComponent_ng_template_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-card-content");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#No Applications Created"), " ");
} }
const _c1 = function () { return ["navigation"]; };
const _c2 = function () { return ["detail"]; };
const _c3 = function (a0, a1) { return { primary: a0, content: a1 }; };
const _c4 = function (a0) { return { outlets: a0 }; };
const _c5 = function (a1) { return ["/applications", a1]; };
function StartPageComponent_button_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "button", 13);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("routerLink", i0.ɵɵpureFunction1(11, _c5, i0.ɵɵpureFunction1(9, _c4, i0.ɵɵpureFunction2(6, _c3, i0.ɵɵpureFunction0(4, _c1), i0.ɵɵpureFunction0(5, _c2)))));
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 2, "#LDS#Manage"));
} }
const _c6 = function () { return ["edit"]; };
const _c7 = function () { return { create: true }; };
function StartPageComponent_button_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "button", 14);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵproperty("routerLink", i0.ɵɵpureFunction1(12, _c5, i0.ɵɵpureFunction1(10, _c4, i0.ɵɵpureFunction2(7, _c3, i0.ɵɵpureFunction0(5, _c1), i0.ɵɵpureFunction0(6, _c6)))))("queryParams", i0.ɵɵpureFunction0(14, _c7));
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 3, "#LDS#Create"));
} }
function StartPageComponent_imx_global_kpi_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-global-kpi");
} }
class StartPageComponent {
    constructor(busyService, applicationsProvider, logger, userService, imageProvider, aobPermissionsService, authentication) {
        this.busyService = busyService;
        this.applicationsProvider = applicationsProvider;
        this.logger = logger;
        this.userService = userService;
        this.imageProvider = imageProvider;
        this.aobPermissionsService = aobPermissionsService;
        this.numberOfApplications = 0;
        this.authSubscription = authentication.onSessionResponse?.subscribe(async (sessionState) => {
            this.name = sessionState.Username;
            this.imageUrl = await this.imageProvider.getPersonImageUrl(sessionState.UserUid);
            this.img.nativeElement.src = this.imageUrl;
        });
    }
    ngOnDestroy() {
        this.authSubscription?.unsubscribe();
    }
    async ngOnInit() {
        let overlayRef;
        setTimeout(() => (overlayRef = this.busyService.show()));
        try {
            this.logger.debug(this, 'get number of applications...');
            const apps = await this.applicationsProvider.get();
            if (apps) {
                this.numberOfApplications = apps.totalCount;
            }
            else {
                this.logger.error(this, 'TypedEntityCollectionData<AobApplication> is undefined');
            }
            this.isAdmin = await this.aobPermissionsService.isAobApplicationAdmin();
        }
        finally {
            setTimeout(() => this.busyService.hide(overlayRef));
        }
    }
}
StartPageComponent.ɵfac = function StartPageComponent_Factory(t) { return new (t || StartPageComponent)(i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(ApplicationsService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1.UserModelService), i0.ɵɵdirectiveInject(ImageService), i0.ɵɵdirectiveInject(AobPermissionsService), i0.ɵɵdirectiveInject(i2.AuthenticationService)); };
StartPageComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StartPageComponent, selectors: [["imx-start"]], viewQuery: function StartPageComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(_c0, 5);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.img = _t.first);
    } }, decls: 17, vars: 11, consts: [[1, "imx-user-card"], [1, "imx-user-image-row"], [4, "ngIf"], ["class", "imx-user-icon", 4, "ngIf"], ["class", "imx-user-text-row", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["noAppsAvailable", ""], ["mat-button", "", "color", "primary", 3, "routerLink", 4, "ngIf"], ["mat-button", "", "color", "primary", 3, "routerLink", "queryParams", 4, "ngIf"], ["img", ""], [1, "imx-user-icon"], [1, "imx-user-text-row"], [1, "imx-user-name"], ["mat-button", "", "color", "primary", 3, "routerLink"], ["mat-button", "", "color", "primary", 3, "routerLink", "queryParams"]], template: function StartPageComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-content", 0)(2, "div", 1);
        i0.ɵɵtemplate(3, StartPageComponent_img_3_Template, 2, 0, "img", 2);
        i0.ɵɵtemplate(4, StartPageComponent_mat_icon_4_Template, 2, 0, "mat-icon", 3);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(5, StartPageComponent_div_5_Template, 6, 4, "div", 4);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(6, "mat-card")(7, "mat-card-title");
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(10, StartPageComponent_mat_card_content_10_Template, 4, 6, "mat-card-content", 5);
        i0.ɵɵtemplate(11, StartPageComponent_ng_template_11_Template, 3, 3, "ng-template", null, 6, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵelementStart(13, "mat-card-actions");
        i0.ɵɵtemplate(14, StartPageComponent_button_14_Template, 3, 13, "button", 7);
        i0.ɵɵtemplate(15, StartPageComponent_button_15_Template, 3, 15, "button", 8);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(16, StartPageComponent_imx_global_kpi_16_Template, 1, 0, "imx-global-kpi", 2);
    } if (rf & 2) {
        const _r4 = i0.ɵɵreference(12);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", ctx.imageUrl);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx.imageUrl);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.name);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(9, 9, "#LDS#Applications"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.numberOfApplications > 0)("ngIfElse", _r4);
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("ngIf", ctx.numberOfApplications > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.isAdmin);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.isAdmin);
    } }, dependencies: [i5.NgIf, i7.MatButton, i6.MatCard, i6.MatCardContent, i6.MatCardTitle, i6.MatCardActions, i4.MatIcon, i3.RouterLink, GlobalKpiComponent, i2.LdsReplacePipe, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-wrap:wrap;overflow:auto}img[_ngcontent-%COMP%]{max-width:100px;max-height:100px}.mat-card[_ngcontent-%COMP%]{width:365px;height:179px;margin:50px 20px 0;display:flex;flex-direction:column;flex:0 0 auto}.mat-card-title[_ngcontent-%COMP%]{padding:20px 33px 0;font-size:24px;font-weight:600;margin-bottom:0}.mat-card[_ngcontent-%COMP%] > .mat-card-actions[_ngcontent-%COMP%]:last-child{padding-bottom:25px}.mat-card-content[_ngcontent-%COMP%]{font-size:16px;padding:5px 33px 10px;margin-bottom:0;flex-grow:1}.mat-card-actions[_ngcontent-%COMP%]{display:flex;flex-direction:row;padding:0 25px}.mat-button[_ngcontent-%COMP%]{font-size:16px}.imx-user-card[_ngcontent-%COMP%]{font-size:24px;padding:0 10px 18px}.imx-user-image-row[_ngcontent-%COMP%]{text-align:center}.imx-user-text-row[_ngcontent-%COMP%]{text-align:center;text-overflow:ellipsis;display:flex;flex-direction:row;align-items:center;justify-content:center}.imx-user-name[_ngcontent-%COMP%]{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}.imx-user-icon[_ngcontent-%COMP%]{font-size:100px;text-align:center;display:inline;color:#0a96d1}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StartPageComponent, [{
        type: Component,
        args: [{ selector: 'imx-start', template: "<mat-card>\r\n  <mat-card-content class=\"imx-user-card\">\r\n    <div class=\"imx-user-image-row\">\r\n      <!-- Safely set src from ts -->\r\n      <img #img *ngIf=\"imageUrl\">\r\n      <mat-icon *ngIf=\"!imageUrl\" class=\"imx-user-icon\">account_circle</mat-icon>\r\n    </div>\r\n    <div *ngIf=\"name\" class=\"imx-user-text-row\">\r\n      <div>{{ '#LDS#Welcome'| translate }},&nbsp;</div>\r\n      <div class=\"imx-user-name\">{{ name }}</div>\r\n    </div>\r\n  </mat-card-content>\r\n</mat-card>\r\n<mat-card>\r\n  <mat-card-title>{{ '#LDS#Applications' | translate }}</mat-card-title>\r\n  <mat-card-content *ngIf=\"numberOfApplications > 0; else noAppsAvailable\">\r\n    {{ '#LDS#{0} Applications' | translate | ldsReplace:numberOfApplications }}\r\n  </mat-card-content>\r\n  <ng-template #noAppsAvailable>\r\n    <mat-card-content>\r\n      {{ '#LDS#No Applications Created' | translate }}\r\n    </mat-card-content>\r\n  </ng-template>\r\n  <mat-card-actions>\r\n    <button mat-button color=\"primary\" *ngIf=\"numberOfApplications > 0\"\r\n      [routerLink]=\"['/applications', {outlets: { primary: ['navigation'], content: ['detail']}}]\">{{ '#LDS#Manage' | translate }}</button>\r\n    <button *ngIf=\"isAdmin\" mat-button color=\"primary\"\r\n      [routerLink]=\"['/applications', {outlets: { primary: ['navigation'], content: ['edit']}}]\"\r\n      [queryParams]=\"{ create: true }\">{{ '#LDS#Create' | translate }}</button>\r\n  </mat-card-actions>\r\n</mat-card>\r\n<imx-global-kpi *ngIf=\"isAdmin\"></imx-global-kpi>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-wrap:wrap;overflow:auto}img{max-width:100px;max-height:100px}.mat-card{width:365px;height:179px;margin:50px 20px 0;display:flex;flex-direction:column;flex:0 0 auto}.mat-card-title{padding:20px 33px 0;font-size:24px;font-weight:600;margin-bottom:0}.mat-card>.mat-card-actions:last-child{padding-bottom:25px}.mat-card-content{font-size:16px;padding:5px 33px 10px;margin-bottom:0;flex-grow:1}.mat-card-actions{display:flex;flex-direction:row;padding:0 25px}.mat-button{font-size:16px}.imx-user-card{font-size:24px;padding:0 10px 18px}.imx-user-image-row{text-align:center}.imx-user-text-row{text-align:center;text-overflow:ellipsis;display:flex;flex-direction:row;align-items:center;justify-content:center}.imx-user-name{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left}.imx-user-icon{font-size:100px;text-align:center;display:inline;color:#0a96d1}\n"] }]
    }], function () { return [{ type: i1$1.EuiLoadingService }, { type: ApplicationsService }, { type: i2.ClassloggerService }, { type: i1.UserModelService }, { type: ImageService }, { type: AobPermissionsService }, { type: i2.AuthenticationService }]; }, { img: [{
            type: ViewChild,
            args: ['img']
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GlobalKpiModule {
}
GlobalKpiModule.ɵfac = function GlobalKpiModule_Factory(t) { return new (t || GlobalKpiModule)(); };
GlobalKpiModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: GlobalKpiModule });
GlobalKpiModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [GlobalKpiService], imports: [CommonModule,
        MatCardModule,
        MatButtonModule,
        MatDialogModule,
        EuiCoreModule,
        TranslateModule,
        TilesModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GlobalKpiModule, [{
        type: NgModule,
        args: [{
                declarations: [GlobalKpiComponent, KpiTileComponent],
                imports: [
                    CommonModule,
                    MatCardModule,
                    MatButtonModule,
                    MatDialogModule,
                    EuiCoreModule,
                    TranslateModule,
                    TilesModule
                ],
                providers: [GlobalKpiService],
                exports: [GlobalKpiComponent]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(GlobalKpiModule, { declarations: [GlobalKpiComponent, KpiTileComponent], imports: [CommonModule,
        MatCardModule,
        MatButtonModule,
        MatDialogModule,
        EuiCoreModule,
        TranslateModule,
        TilesModule], exports: [GlobalKpiComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class StartPageModule {
}
StartPageModule.ɵfac = function StartPageModule_Factory(t) { return new (t || StartPageModule)(); };
StartPageModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: StartPageModule });
StartPageModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        LdsReplaceModule,
        MatButtonModule,
        MatCardModule,
        MatIconModule,
        TranslateModule,
        ClassloggerModule,
        AobUserModule,
        QbmModule,
        RouterModule,
        GlobalKpiModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StartPageModule, [{
        type: NgModule,
        args: [{
                declarations: [StartPageComponent],
                imports: [
                    CommonModule,
                    LdsReplaceModule,
                    MatButtonModule,
                    MatCardModule,
                    MatIconModule,
                    TranslateModule,
                    ClassloggerModule,
                    AobUserModule,
                    QbmModule,
                    RouterModule,
                    GlobalKpiModule
                ],
                exports: [
                    StartPageComponent
                ],
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(StartPageModule, { declarations: [StartPageComponent], imports: [CommonModule,
        LdsReplaceModule,
        MatButtonModule,
        MatCardModule,
        MatIconModule,
        TranslateModule,
        ClassloggerModule,
        AobUserModule,
        QbmModule,
        RouterModule,
        GlobalKpiModule], exports: [StartPageComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'applications/kpi',
        component: GlobalKpiComponent,
        canActivate: [AobKpiGuardService],
        resolve: [RouteGuardService],
    },
    {
        path: 'applications',
        component: ApplicationsComponent,
        canActivate: [AobApplicationsGuardService],
        resolve: [RouteGuardService],
        children: [
            {
                path: 'navigation',
                component: ApplicationNavigationComponent,
                canActivate: [RouteGuardService],
                resolve: [RouteGuardService],
                data: {
                    contextId: HELP_CONTEXTUAL.Applications,
                },
            },
            {
                path: 'detail',
                component: ApplicationDetailComponent,
                outlet: 'content',
                canActivate: [RouteGuardService],
                resolve: [RouteGuardService],
            },
            { path: ':create:id', redirectTo: 'applications', pathMatch: 'full' },
        ],
    },
];
class AobConfigModule {
    constructor(initializer, docSvc, logger) {
        this.initializer = initializer;
        this.docSvc = docSvc;
        this.logger = logger;
        this.logger.info(this, '🔥 AOB loaded');
        this.initializer.onInit(routes);
        this.configureDocPaths();
        this.logger.info(this, '▶️ AOB initialized');
    }
    configureDocPaths() {
        // Web Portal for Application Governance User Guide
        var appgovDoc = {
            paths: {
                'en-US': 'imx/doc/OneIM_AOB_UserGuide_en-us.html5/OneIM_AOB_UserGuide.html',
                'de-DE': 'imx/doc/OneIM_AOB_UserGuide_de-de.html5/OneIM_AOB_UserGuide.html',
                'de-CH': 'imx/doc/OneIM_AOB_UserGuide_de-de.html5/OneIM_AOB_UserGuide.html',
                'de-AT': 'imx/doc/OneIM_AOB_UserGuide_de-de.html5/OneIM_AOB_UserGuide.html',
            },
        };
        this.docSvc.chapters['applications'] = {
            chapterUid: '35FE656D-A608-4B16-A55F-B758D5B72F75',
            document: appgovDoc,
        };
    }
}
AobConfigModule.ɵfac = function AobConfigModule_Factory(t) { return new (t || AobConfigModule)(i0.ɵɵinject(AobService), i0.ɵɵinject(i2.DocChapterService), i0.ɵɵinject(i2.ClassloggerService)); };
AobConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: AobConfigModule });
AobConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [ApplicationsModule,
        CommonModule,
        EntitlementsModule,
        EuiCoreModule,
        EuiMaterialModule,
        StartPageModule,
        TilesModule,
        TranslateModule,
        RouterModule.forChild(routes)] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AobConfigModule, [{
        type: NgModule,
        args: [{
                imports: [
                    ApplicationsModule,
                    CommonModule,
                    EntitlementsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    StartPageModule,
                    TilesModule,
                    TranslateModule,
                    RouterModule.forChild(routes),
                ],
                declarations: [LockInfoAlertComponent],
            }]
    }], function () { return [{ type: AobService }, { type: i2.DocChapterService }, { type: i2.ClassloggerService }]; }, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(AobConfigModule, { declarations: [LockInfoAlertComponent], imports: [ApplicationsModule,
        CommonModule,
        EntitlementsModule,
        EuiCoreModule,
        EuiMaterialModule,
        StartPageModule,
        TilesModule,
        TranslateModule, i3.RouterModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Hier kommen die zu exportierenden Komponenten hin
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AobConfigModule, ApplicationsComponent, ApplicationsModule, EntitlementsComponent, EntitlementsModule, StartPageComponent };
//# sourceMappingURL=aob.mjs.map
