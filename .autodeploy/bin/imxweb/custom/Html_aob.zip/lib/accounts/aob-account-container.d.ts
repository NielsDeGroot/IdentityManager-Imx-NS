import { TypedEntity, EntitySchema } from 'imx-qbm-dbts';
export declare class AobAccountContainer extends TypedEntity {
    static GetEntitySchema(): EntitySchema;
}
