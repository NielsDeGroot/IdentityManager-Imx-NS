import { ClassloggerService, DocChapterService } from 'qbm';
import { AobService } from './aob.service';
import * as i0 from "@angular/core";
import * as i1 from "./extensions/service-items-edit/lock-info-alert/lock-info-alert.component";
import * as i2 from "./applications/applications.module";
import * as i3 from "@angular/common";
import * as i4 from "./entitlements/entitlements.module";
import * as i5 from "@elemental-ui/core";
import * as i6 from "./start-page/start-page.module";
import * as i7 from "qer";
import * as i8 from "@ngx-translate/core";
import * as i9 from "@angular/router";
export declare class AobConfigModule {
    private readonly initializer;
    private readonly docSvc;
    private readonly logger;
    constructor(initializer: AobService, docSvc: DocChapterService, logger: ClassloggerService);
    private configureDocPaths;
    static ɵfac: i0.ɵɵFactoryDeclaration<AobConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AobConfigModule, [typeof i1.LockInfoAlertComponent], [typeof i2.ApplicationsModule, typeof i3.CommonModule, typeof i4.EntitlementsModule, typeof i5.EuiCoreModule, typeof i5.EuiMaterialModule, typeof i6.StartPageModule, typeof i7.TilesModule, typeof i8.TranslateModule, typeof i9.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AobConfigModule>;
}
