import * as i0 from "@angular/core";
export declare class ApplicationPropertyComponent {
    display: string;
    icon: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationPropertyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApplicationPropertyComponent, "imx-application-property", never, { "display": "display"; "icon": "icon"; }, {}, never, ["*"], false>;
}
