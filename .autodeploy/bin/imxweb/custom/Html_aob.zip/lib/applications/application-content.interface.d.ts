import { PortalApplication, PortalApplicationNew } from 'imx-api-aob';
import { Subject } from 'rxjs';
export interface ApplicationContent {
    application: PortalApplication | PortalApplicationNew;
    totalCount?: number;
    keywords?: string;
    loadingSubject?: Subject<boolean>;
}
