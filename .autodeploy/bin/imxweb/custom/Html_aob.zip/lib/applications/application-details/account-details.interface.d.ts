import { TypedEntity } from 'imx-qbm-dbts';
export interface AccountDetails {
    count: number;
    first: TypedEntity;
    uidApplication: string;
}
