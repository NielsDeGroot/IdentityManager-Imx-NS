import { OnChanges, TemplateRef, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatMenuTrigger } from '@angular/material/menu';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { Platform } from '@angular/cdk/platform';
import { TranslateService } from '@ngx-translate/core';
import { PortalApplication } from 'imx-api-aob';
import { BusyService, ClassloggerService, ConfirmationService, SnackBarService } from 'qbm';
import { ShopsService } from '../../shops/shops.service';
import { EntitlementsService } from '../../entitlements/entitlements.service';
import { TypedEntity } from 'imx-qbm-dbts';
import { AccountsService } from '../../accounts/accounts.service';
import { ApplicationsService } from '../applications.service';
import { AobApiService } from '../../aob-api-client.service';
import { AccountDetails } from './account-details.interface';
import { AobPermissionsService } from '../../permissions/aob-permissions.service';
import * as i0 from "@angular/core";
export declare class ApplicationDetailsComponent implements OnChanges, OnInit {
    private entitlementsProvider;
    readonly shopsProvider: ShopsService;
    private readonly euiBusyService;
    private readonly logger;
    readonly accountsProvider: AccountsService;
    private readonly dialog;
    private readonly applicationprovider;
    private readonly snackbar;
    private readonly platform;
    private readonly aobApiService;
    private readonly translateService;
    private readonly confirmation;
    private readonly sidesheetService;
    private readonly permissions;
    /**
     * The {@link PortalApplication | AobApplication}
     */
    application: PortalApplication;
    chartDialog: TemplateRef<any>;
    menuTrigger: MatMenuTrigger;
    hasAssignedEntitlements: boolean;
    hasPublishedEntitlements: boolean;
    canBeDeleted: boolean;
    hasOwner: boolean;
    accountsInformation: AccountDetails;
    assignedShops: TypedEntity[];
    readonly shopsDisplay: string;
    readonly accountsDisplay: string;
    busyService: BusyService;
    isLoading: any;
    constructor(entitlementsProvider: EntitlementsService, shopsProvider: ShopsService, euiBusyService: EuiLoadingService, logger: ClassloggerService, accountsProvider: AccountsService, dialog: MatDialog, applicationprovider: ApplicationsService, snackbar: SnackBarService, platform: Platform, aobApiService: AobApiService, translateService: TranslateService, confirmation: ConfirmationService, sidesheetService: EuiSidesheetService, permissions: AobPermissionsService);
    ngOnInit(): void;
    ngOnChanges(): Promise<void>;
    /**
     * Deletes the displayed application, after confirming the process by the user
     */
    deleteApplication(): Promise<void>;
    /**
     * Edits the information of the associated application
     */
    editApplication(): Promise<void>;
    /**
     * Opens a dialog for publishing the application
     * @ignore @param _ unused mouse event
     */
    publishApplication(_: MouseEvent): Promise<void>;
    /**
     * Opens a dialog for unpublishing the application
     * @ignore @param _ unused mouse event
     */
    unpublishApplication(_: MouseEvent): void;
    /**
     * Checks if the specified  {@link PortalApplication|application} can be publish.
     */
    get isPublishable(): boolean;
    /**
     * Checks if the specified  {@link PortalApplication|application} can be unnpublish.
     */
    get isUnpublishable(): boolean;
    notPublished(): boolean;
    willPublish(): boolean;
    published(): boolean;
    /**
     * Opens/Closes the menu programmatically and stopps propagation of the event.
     * Otherwise the tile would be selected/deselcted as a sideeffect.
     * @ignore Used internally in components template.
     */
    menuClicked(event: MouseEvent): void;
    /**
     *
     * @param elements Opens a dialog, that shows additional elements (because in the beginning there are only 3 elements displayed)
     * @param title A title for the dialog
     * @param iconText name of a cadence icon, that should be used
     */
    showMore(elements: TypedEntity[], title: string, iconText?: string): void;
    /**
     * Shows a dialog, that displays additionals accounts (because in the beginning there are only 3 elements displayed)
     */
    showMoreAccounts(): Promise<void>;
    editServiceCategories(): Promise<void>;
    private reloadData;
    private updateShops;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApplicationDetailsComponent, "imx-application-details", never, { "application": "application"; }, {}, never, never, false>;
}
