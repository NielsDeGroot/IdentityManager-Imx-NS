import { OnChanges } from '@angular/core';
import { BusyService, ClassloggerService } from 'qbm';
import { ShapeData } from 'imx-api-qer';
import { ApplicationHyperviewService } from './application-hyperview.service';
import * as i0 from "@angular/core";
export declare class ApplicationHyperviewComponent implements OnChanges {
    private classlogger;
    private hyperviewprovider;
    shapes: ShapeData[];
    uidApplication: string;
    busyService: BusyService;
    isLoading: boolean;
    constructor(classlogger: ClassloggerService, hyperviewprovider: ApplicationHyperviewService);
    ngOnChanges(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationHyperviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApplicationHyperviewComponent, "imx-application-hyperview", never, { "uidApplication": "uidApplication"; }, {}, never, never, false>;
}
