import * as i0 from "@angular/core";
import * as i1 from "./application-hyperview.component";
import * as i2 from "@angular/common";
import * as i3 from "qbm";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@angular/material/dialog";
import * as i6 from "@angular/material/button";
import * as i7 from "@elemental-ui/core";
export declare class ApplicationHyperviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationHyperviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ApplicationHyperviewModule, [typeof i1.ApplicationHyperviewComponent], [typeof i2.CommonModule, typeof i3.HyperViewModule, typeof i4.TranslateModule, typeof i5.MatDialogModule, typeof i6.MatButtonModule, typeof i7.EuiCoreModule, typeof i3.BusyIndicatorModule], [typeof i1.ApplicationHyperviewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ApplicationHyperviewModule>;
}
