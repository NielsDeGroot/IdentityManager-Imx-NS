import { ApiClientService } from 'qbm';
import { ShapeData } from 'imx-api-qer';
import { QerApiService } from 'qer';
import * as i0 from "@angular/core";
export declare class ApplicationHyperviewService {
    private readonly apiClient;
    private readonly apiProvider;
    constructor(apiClient: QerApiService, apiProvider: ApiClientService);
    get(uidApplication: string): Promise<ShapeData[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationHyperviewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApplicationHyperviewService>;
}
