import { EventEmitter, OnInit } from '@angular/core';
import { Overlay } from '@angular/cdk/overlay';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { PortalApplication, PortalApplicationNew } from 'imx-api-aob';
import { CollectionLoadParameters, TypedEntityCollectionData, TypedEntity } from 'imx-qbm-dbts';
import { BusyService, ClassloggerService, DataSourceToolbarSettings, DataTileBadge, SettingsService } from 'qbm';
import { ApplicationsService } from '../applications.service';
import { AobPermissionsService } from '../../permissions/aob-permissions.service';
import * as i0 from "@angular/core";
/**
 * This component shows a  list of {@link PortalApplication[]|applications} each in an
 * {@link ApplicationCardComponent|ApplicationCardComponent}.
 */
export declare class ApplicationNavigationComponent implements OnInit {
    private logger;
    private readonly appService;
    private readonly settingsService;
    private readonly route;
    private readonly applicationsProvider;
    private readonly aobPermissionsService;
    overlay: Overlay;
    dstSettings: DataSourceToolbarSettings;
    readonly entitySchema: import("imx-qbm-dbts").StaticSchema<"XObjectKey" | "XDateInserted" | "XDateUpdated" | "XTouched" | "XUserInserted" | "XUserUpdated" | "Description" | "XMarkedForDeletion" | "IsInActive" | "UID_PersonHead" | "UID_AccProductGroup" | "JPegPhoto" | "WhereClause" | "UID_AOBApplication" | "ActivationDate" | "ApplicationEnvironment" | "ApplicationWebURL" | "AuthenticationRoot" | "Ident_AOBApplication" | "IsAuthenticationIntegrated" | "IsFederationEnabled" | "IsMultiFactorEnabled" | "IsSSOEnabled" | "NextRunDate" | "PurchasedLicenses" | "RiskIndex" | "SSORedirectionUrl" | "UID_AERoleApprover" | "UID_AERoleOwner" | "UID_FunctionalArea" | "UID_ITShopSrcBT" | "WhereClauseAddOn" | "HasKpiIssues" | "AuthenticationRootHelper">;
    selectable: boolean;
    multiselect: boolean;
    hideCustomToolbar: boolean;
    filterKpiChecked: boolean;
    isAdmin: boolean;
    selectedEntity: TypedEntity;
    loadingSubject: Subject<boolean>;
    busyService: BusyService;
    /**
     * An event, that is triggert, if the dataSource is changed
     */
    readonly dataSourceChanged: EventEmitter<{
        keywords?: string;
        dataSource: TypedEntityCollectionData<PortalApplication>;
    }>;
    /**
     * An event that is emitted, if the user selects a data tile from the list
     */
    readonly applicationSelected: EventEmitter<string>;
    /**
     * a status that defines, how badges are calculated
     */
    readonly status: {
        getBadges: (application: PortalApplication | PortalApplicationNew) => DataTileBadge[];
    };
    private navigationState;
    private readonly tiles;
    constructor(logger: ClassloggerService, appService: ApplicationsService, settingsService: SettingsService, route: ActivatedRoute, applicationsProvider: ApplicationsService, aobPermissionsService: AobPermissionsService, overlay: Overlay);
    ngOnInit(): Promise<void>;
    /**
     * Emits the applicationSelected event, if the selected tile changes
     * @param selection the {@link PortalApplication | application} that is selected
     */
    onSelectionChanged(selection: PortalApplication[]): Promise<void>;
    /**
     * Emits the applicationSelected event, if the selected tile changes
     * @param selection the {@link PortalApplication | application} that is selected
     */
    onTileSelected(isSelected: any): void;
    /**
     * Loads the {@link PortalApplication | applications} for the application view
     * @param newState the load parameter for the api call
     * @param keywords possible search parameter
     */
    getData(newState?: CollectionLoadParameters, keywords?: string): Promise<void>;
    clearSelection(): void;
    onCreateNew(): void;
    onSearch(keywords: string): Promise<void>;
    filterApplicationsWithKpiIssues(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationNavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApplicationNavigationComponent, "imx-application-navigation", never, {}, { "dataSourceChanged": "dataSourceChanged"; "applicationSelected": "applicationSelected"; }, never, never, false>;
}
