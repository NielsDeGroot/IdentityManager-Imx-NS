import { ErrorHandler } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { PortalApplication, PortalApplicationInteractive, PortalApplicationNew } from 'imx-api-aob';
import { TypedEntityCollectionData, CollectionLoadParameters, EntitySchema } from 'imx-qbm-dbts';
import { ApiClientService, ClassloggerService, DataTileBadge, SnackBarService } from 'qbm';
import { AobApiService } from '../aob-api-client.service';
import * as i0 from "@angular/core";
/**
 * This service provides methods for handling with {@link PortalApplication[]|applications}.
 * {@link ApplicationCardComponent|ApplicationCardComponent}.
 */
export declare class ApplicationsService {
    private readonly aobClient;
    private readonly logger;
    private readonly errorHandler;
    private readonly apiProvider;
    private readonly translateService;
    private readonly sidesheet;
    private readonly snackbar;
    private readonly busyService;
    readonly onApplicationCreated: Subject<string>;
    readonly onApplicationDeleted: Subject<string>;
    applicationRefresh: BehaviorSubject<Boolean>;
    abortController: AbortController;
    private badgePublished;
    private badgeKpiErrors;
    private badgeNew;
    private publishedText;
    private kpiErrorsText;
    private newBadgeText;
    get applicationSchema(): EntitySchema;
    private get theme();
    constructor(aobClient: AobApiService, logger: ClassloggerService, errorHandler: ErrorHandler, apiProvider: ApiClientService, translateService: TranslateService, sidesheet: EuiSidesheetService, snackbar: SnackBarService, busyService: EuiLoadingService);
    /**
     * Encapsules the aob/applications GET endpoint and delivers a list of {@link PortalApplication[]|applications}.
     */
    get(parameters?: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalApplication>>;
    reload(uidApplication: string): Promise<PortalApplicationInteractive>;
    createNew(): PortalApplicationNew;
    tryCommit(application: PortalApplication | PortalApplicationNew, reload?: boolean): Promise<boolean>;
    /**
     * Publishs the given {@link PortalApplication[]|applications} by setting IsInactive to false or an ActivationDate to the given date.
     */
    publish(application: PortalApplication, publishData: {
        publishFuture: boolean;
        date: Date;
    }): Promise<boolean>;
    /**
     * Unpublishs the given {@link PortalApplication[]|applications} by setting IsInactive to true and ActivationDate to the default.
     */
    unpublish(application: PortalApplication): Promise<boolean>;
    /**
     * Shows a badge on the given {@link PortalApplication[]|applications},
     * if the application is published or has kpi issues.
     */
    getApplicationBadges(application: PortalApplication | PortalApplicationNew): DataTileBadge[];
    createApplication(): Promise<void>;
    deleteApplication(uid: string): Promise<void>;
    abortCall(): void;
    private isPublished;
    private hasKpiIssues;
    private createdToday;
    /**
     * Updates the badges, that are used on the application tiles, according to the used theme
     *
     * @param theme Currently used EuiTheme
     */
    private updateBadges;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApplicationsService>;
}
