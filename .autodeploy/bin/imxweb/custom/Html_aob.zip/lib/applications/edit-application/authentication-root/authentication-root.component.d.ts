import { EventEmitter, OnInit } from '@angular/core';
import { AbstractControl, UntypedFormGroup } from '@angular/forms';
import { PortalApplication } from 'imx-api-aob';
import { BaseCdr } from 'qbm';
import * as i0 from "@angular/core";
export declare class AuthenticationRootComponent implements OnInit {
    readonly form: UntypedFormGroup;
    authenticationRootWrapper: BaseCdr;
    application: PortalApplication;
    readonly controlCreated: EventEmitter<AbstractControl<any, any>>;
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthenticationRootComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AuthenticationRootComponent, "imx-authentication-root", never, { "application": "application"; }, { "controlCreated": "controlCreated"; }, never, never, false>;
}
