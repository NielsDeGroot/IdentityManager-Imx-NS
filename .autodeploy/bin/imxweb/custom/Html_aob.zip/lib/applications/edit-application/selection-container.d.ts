export declare class SelectionContainer<T> {
    private getKey;
    selected: T[];
    private assigned;
    constructor(getKey: (item: T) => string);
    init(assigned: T[]): void;
    getChangeSet(): {
        add: T[];
        remove: T[];
    };
    private equals;
}
