import { PortalApplication } from "imx-api-aob";
import { TypedEntity } from "imx-qbm-dbts";
export interface IdentityDetailData {
    application: PortalApplication;
    selectedItem: TypedEntity;
}
