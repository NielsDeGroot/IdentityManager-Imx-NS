import { OnInit } from '@angular/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { CollectionLoadParameters, DisplayColumns, EntitySchema, IClientProperty } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings, ImxTranslationProviderService } from 'qbm';
import { IdentityDetailData } from '../identity-detail-data';
import { IdentityService } from '../identity.service';
import * as i0 from "@angular/core";
export declare class IdentityDetailComponent implements OnInit {
    data: IdentityDetailData;
    private readonly identityService;
    private readonly busyService;
    readonly translateProvider: ImxTranslationProviderService;
    dstSettings: DataSourceToolbarSettings;
    navigationState: CollectionLoadParameters;
    DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    displayedColumns: IClientProperty[];
    constructor(data: IdentityDetailData, identityService: IdentityService, busyService: EuiLoadingService, translateProvider: ImxTranslationProviderService);
    ngOnInit(): Promise<void>;
    onNavigationStateChanged(navigationState: CollectionLoadParameters): Promise<void>;
    onSearch(keywords: string): Promise<void>;
    private setDst;
    private getData;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentityDetailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IdentityDetailComponent, "imx-identity-detail", never, {}, {}, never, never, false>;
}
