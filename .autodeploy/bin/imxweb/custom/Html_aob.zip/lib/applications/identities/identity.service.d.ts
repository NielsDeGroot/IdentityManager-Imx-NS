import { PortalApplicationIdentities, PortalApplicationIdentitiesbyidentity } from 'imx-api-aob';
import { CollectionLoadParameters, EntitySchema, ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { AobApiService } from '../../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class IdentityService {
    private readonly api;
    constructor(api: AobApiService);
    get(applicationId: string, params?: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalApplicationIdentities, unknown>>;
    getSchema(): EntitySchema;
    getByIdentity(applicationId: string, identityId: string, params?: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalApplicationIdentitiesbyidentity, unknown>>;
    getByIdentitySchema(): EntitySchema;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentityService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IdentityService>;
}
