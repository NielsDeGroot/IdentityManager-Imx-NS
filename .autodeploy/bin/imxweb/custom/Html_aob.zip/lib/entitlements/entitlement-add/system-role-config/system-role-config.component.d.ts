import { AfterViewInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MatSelectionListChange } from '@angular/material/list';
import { MatRadioChange } from '@angular/material/radio';
import { EuiLoadingService, EuiSidesheetRef } from '@elemental-ui/core';
import { TypedEntity } from 'imx-qbm-dbts';
import { SettingsService } from 'qbm';
import { SystemRoleConfigService } from './system-role-config.service';
import * as i0 from "@angular/core";
export declare class SystemRoleConfigComponent implements AfterViewInit, OnDestroy {
    readonly data: {
        uid: string;
        createOnly: boolean;
    };
    private readonly sidesheetRef;
    private readonly busyService;
    private readonly addToExistingProvider;
    private readonly settingsService;
    private readonly changeDetectorRef;
    readonly form: UntypedFormGroup;
    type: 'new' | 'existing';
    selectedRole: string;
    showHelperAlert: boolean;
    candidates: TypedEntity[];
    private viewport;
    private parameters;
    private readonly subscriptions;
    constructor(data: {
        uid: string;
        createOnly: boolean;
    }, sidesheetRef: EuiSidesheetRef, busyService: EuiLoadingService, addToExistingProvider: SystemRoleConfigService, settingsService: SettingsService, changeDetectorRef: ChangeDetectorRef);
    ngAfterViewInit(): Promise<void>;
    ngOnDestroy(): void;
    typeChanged(evt: MatRadioChange): Promise<void>;
    updateSelected(selection: MatSelectionListChange): Promise<void>;
    onHelperDismissed(): void;
    close(createNew: boolean): void;
    private loadData;
    LdsAddOrCreate: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SystemRoleConfigComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SystemRoleConfigComponent, "ng-component", never, {}, {}, never, never, false>;
}
