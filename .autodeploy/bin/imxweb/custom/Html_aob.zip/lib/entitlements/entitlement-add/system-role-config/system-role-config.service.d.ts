import { PortalEntitlementSystemrole } from 'imx-api-aob';
import { CollectionLoadParameters, EntitySchema, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { AobApiService } from '../../../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class SystemRoleConfigService {
    private readonly aobClient;
    constructor(aobClient: AobApiService);
    get roleSchema(): EntitySchema;
    getExistingRoles(application: string, parameters: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalEntitlementSystemrole>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SystemRoleConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SystemRoleConfigService>;
}
