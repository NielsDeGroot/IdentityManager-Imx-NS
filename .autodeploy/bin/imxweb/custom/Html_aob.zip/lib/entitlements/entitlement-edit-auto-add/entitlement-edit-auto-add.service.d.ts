import { EntitlementToAddData } from 'imx-api-aob';
import { CollectionLoadParameters, EntityCollectionData, FilterProperty, InteractiveEntityStateData } from 'imx-qbm-dbts';
import { SqlWizardApiService } from 'qbm';
import { AobApiService } from '../../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class EntitlementEditAutoAddService implements SqlWizardApiService {
    private readonly api;
    constructor(api: AobApiService);
    getFilterProperties(table: string): Promise<FilterProperty[]>;
    getCandidates(parentTable: string, options?: CollectionLoadParameters): Promise<EntityCollectionData>;
    showEntitlementsToMap(state: InteractiveEntityStateData): Promise<EntitlementToAddData>;
    mapEntitlementsToApplication(uidApplication: string): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementEditAutoAddService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EntitlementEditAutoAddService>;
}
