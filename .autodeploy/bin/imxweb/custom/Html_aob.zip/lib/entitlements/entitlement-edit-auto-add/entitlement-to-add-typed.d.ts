import { EntitySchema, IReadValue, TypedEntity } from 'imx-qbm-dbts';
export declare class EntitlementToAddTyped extends TypedEntity {
    readonly IsAssignedToMe: IReadValue<boolean>;
    readonly IsAssignedToOther: IReadValue<boolean>;
    readonly DisplayName: IReadValue<string>;
    readonly CanonicalName: IReadValue<string>;
    readonly UID_AOBApplicationConflicted: IReadValue<string>;
    static GetEntitySchema(): EntitySchema;
}
