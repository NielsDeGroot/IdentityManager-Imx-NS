import { OnInit } from '@angular/core';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { CollectionLoadParameters, DisplayColumns, EntitySchema, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings } from 'qbm';
import { EntitlementToAddTyped } from '../entitlement-to-add-typed';
import * as i0 from "@angular/core";
export declare class MappedEntitlementsPreviewComponent implements OnInit {
    data: {
        withSave: boolean;
        entitlementToAdd: TypedEntityCollectionData<EntitlementToAddTyped>;
    };
    private readonly sidesheetRef;
    settings: DataSourceToolbarSettings;
    readonly DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    navigationState: CollectionLoadParameters;
    alertText: string;
    speedupText: string;
    constructor(data: {
        withSave: boolean;
        entitlementToAdd: TypedEntityCollectionData<EntitlementToAddTyped>;
    }, sidesheetRef: EuiSidesheetRef);
    apply(map: boolean): void;
    getCount(type: '' | 'add' | 'assigned' | 'conflicted'): number;
    navigate(source: CollectionLoadParameters): void;
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MappedEntitlementsPreviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MappedEntitlementsPreviewComponent, "ng-component", never, {}, {}, never, never, false>;
}
