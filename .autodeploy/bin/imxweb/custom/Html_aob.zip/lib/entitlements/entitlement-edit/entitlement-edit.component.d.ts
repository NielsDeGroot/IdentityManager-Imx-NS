import { ErrorHandler, OnChanges, SimpleChanges, OnInit, EventEmitter } from '@angular/core';
import { UntypedFormGroup, AbstractControl } from '@angular/forms';
import { EuiLoadingService } from '@elemental-ui/core';
import { PortalEntitlement, PortalEntitlementServiceitem } from 'imx-api-aob';
import { CdrFactoryService, ClassloggerService, ColumnDependentReference } from 'qbm';
import { ServiceItemTagsService } from 'qer';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
/**
 * A component that provides a form for viewing and editing entitlements/roles.
 */
export declare class EntitlementEditComponent implements OnChanges, OnInit {
    private readonly tagProvider;
    private readonly logger;
    private readonly router;
    private readonly errorHandler;
    private readonly cdrFactoryService;
    private readonly busyService;
    readonly form: UntypedFormGroup;
    productTagsInitial: string[];
    productTagsSelected: string[];
    loadingTags: boolean;
    cdrList: ColumnDependentReference[];
    cdrListServiceItem: ColumnDependentReference[];
    entitlement: PortalEntitlement;
    serviceItem: PortalEntitlementServiceitem;
    readonly controlCreated: EventEmitter<AbstractControl<any, any>>;
    readonly saved: EventEmitter<any>;
    constructor(tagProvider: ServiceItemTagsService, logger: ClassloggerService, router: Router, errorHandler: ErrorHandler, cdrFactoryService: CdrFactoryService, busyService: EuiLoadingService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    /**
     * Saves all changes of specified  {@link PortalEntitlement|entitlement}.
     * @param entitlement The {@link PortalEntitlement|entitlement} to be saved.
     */
    save(): Promise<void>;
    private initTags;
    private tryCommit;
    private saveTags;
    private getTagsChangeSet;
    get isEditableEntitlement(): boolean;
    manageEntitlement(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntitlementEditComponent, "imx-entitlement-edit", never, { "entitlement": "entitlement"; "serviceItem": "serviceItem"; }, { "controlCreated": "controlCreated"; "saved": "saved"; }, never, never, false>;
}
