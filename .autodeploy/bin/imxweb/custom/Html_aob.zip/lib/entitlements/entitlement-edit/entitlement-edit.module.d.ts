import * as i0 from "@angular/core";
import * as i1 from "./entitlement-edit.component";
import * as i2 from "qbm";
import * as i3 from "@angular/common";
import * as i4 from "@elemental-ui/core";
import * as i5 from "@angular/forms";
import * as i6 from "@angular/material/button";
import * as i7 from "@angular/material/card";
import * as i8 from "@angular/material/checkbox";
import * as i9 from "@angular/material/form-field";
import * as i10 from "@angular/material/input";
import * as i11 from "qer";
import * as i12 from "@ngx-translate/core";
export declare class EntitlementEditModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementEditModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EntitlementEditModule, [typeof i1.EntitlementEditComponent], [typeof i2.CdrModule, typeof i3.CommonModule, typeof i4.EuiCoreModule, typeof i5.FormsModule, typeof i6.MatButtonModule, typeof i7.MatCardModule, typeof i8.MatCheckboxModule, typeof i9.MatFormFieldModule, typeof i10.MatInputModule, typeof i5.ReactiveFormsModule, typeof i11.ServiceItemTagsModule, typeof i12.TranslateModule], [typeof i1.EntitlementEditComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EntitlementEditModule>;
}
