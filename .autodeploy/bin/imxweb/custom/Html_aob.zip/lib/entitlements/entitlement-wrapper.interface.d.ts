import { PortalEntitlement, PortalEntitlementServiceitem } from 'imx-api-aob';
export interface EntitlementWrapper {
    entitlement: PortalEntitlement;
    serviceItem: PortalEntitlementServiceitem;
}
