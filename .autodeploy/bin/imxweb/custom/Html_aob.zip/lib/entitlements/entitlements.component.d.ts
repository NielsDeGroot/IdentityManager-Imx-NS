import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { Platform } from '@angular/cdk/platform';
import { TranslateService } from '@ngx-translate/core';
import { SnackBarService, DataSourceToolbarSettings, ClassloggerService, DataTileBadge, SettingsService, SystemInfoService, MetadataService, DataTableComponent, DataTilesComponent, BusyService } from 'qbm';
import { PortalEntitlement, PortalApplication } from 'imx-api-aob';
import { CollectionLoadParameters, IClientProperty, DisplayColumns, EntitySchema } from 'imx-qbm-dbts';
import { EntitlementsService } from './entitlements.service';
import { EntitlementsType } from './entitlements.model';
import { EntitlementFilter } from './entitlement-filter';
import { ShopsService } from '../shops/shops.service';
import { ServiceItemsService } from '../service-items/service-items.service';
import { EntitlementEditAutoAddService } from './entitlement-edit-auto-add/entitlement-edit-auto-add.service';
import * as i0 from "@angular/core";
/**
 * A component for viewing, editing and acting all {@link PortalEntitlement|entitlements} for a given {@link PortalApplication|application}.
 *
 * @see addEntitlements
 * @see addRoles
 * @see publish
 * @see unpublish
 * @see unassign
 */
export declare class EntitlementsComponent implements OnChanges {
    private readonly logger;
    private matDialog;
    private entitlementsProvider;
    private readonly euiBusyService;
    private readonly dialog;
    private readonly snackbar;
    private readonly shopsProvider;
    private readonly serviceItemsProvider;
    private readonly platform;
    private readonly translateService;
    private readonly sidesheet;
    private readonly settingsService;
    private readonly systemInfo;
    private readonly metadata;
    private readonly autoAddService;
    /** The {@link PortalApplication|application} */
    application: PortalApplication;
    reloadRequested: EventEmitter<void>;
    table: DataTableComponent<PortalEntitlement>;
    tiles: DataTilesComponent;
    readonly DisplayColumns: typeof DisplayColumns;
    readonly EntitlementsType: typeof EntitlementsType;
    dstSettings: DataSourceToolbarSettings;
    navigationState: CollectionLoadParameters;
    selections: PortalEntitlement[];
    publishDisabled: boolean;
    unpublishDisabled: boolean;
    unassignedDisabled: boolean;
    isUsedInDialog: boolean;
    readonly entitySchema: EntitySchema;
    readonly filter: EntitlementFilter;
    busyService: BusyService;
    isSystemRoleEnabled: boolean;
    isLoading: boolean;
    /**
     * Checks, if there's a dynamic assignment rule attached to this application
     */
    get hasConditionForDynamicAssignment(): boolean;
    /**
     * Defines a set of status information methods, that are used to determine the status of each element in the entitlements table
     */
    readonly status: {
        getBadges: (entitlement: PortalEntitlement) => DataTileBadge[];
        enabled: (_: PortalEntitlement) => boolean;
    };
    private readonly displayedColumns;
    private readonly updatedTableNames;
    constructor(logger: ClassloggerService, matDialog: MatDialog, entitlementsProvider: EntitlementsService, euiBusyService: EuiLoadingService, dialog: MatDialog, snackbar: SnackBarService, shopsProvider: ShopsService, serviceItemsProvider: ServiceItemsService, platform: Platform, translateService: TranslateService, sidesheet: EuiSidesheetService, settingsService: SettingsService, systemInfo: SystemInfoService, metadata: MetadataService, autoAddService: EntitlementEditAutoAddService);
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    /**
     * checks, if an Entitlement can be edited
     * @param aobEntitlement the entitlement to check
     * @returns true, if the entitlements Ident_AOBEntitlement or Description property can be edited
     */
    canEdit(aobEntitlement: PortalEntitlement): boolean;
    openInfo(event: Event): void;
    /**
     * Opens a sidesheet to assign new entitlements to the application
     * Afterwards entitlements are added to the application as single entitlements or wrapped into a system role
     */
    addNewElement(): Promise<void>;
    /**
     * Applys the dynamic assignment rule, that is defined for the application
     */
    applyMappingForDynamicAssignments(): Promise<void>;
    /**
     * Opens a side sheet to create/edit the dynamic assignement rule that belongs to the application
     */
    editConditionForDynamicAssignments(): Promise<void>;
    /**
     * Call to publish the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to publish
     */
    publish(aobEntitlement?: PortalEntitlement): Promise<void>;
    /**
     * Call to unpublish the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to unpublish
     */
    unpublish(aobEntitlement?: PortalEntitlement): Promise<void>;
    /**
     * Call to unassign the specified {@link PortalEntitlement|entitlement} or the list of selected {@link PortalEntitlement|entitlements}
     * from the associated {@link PortalApplication|application}.
     * @param aobEntitlement the {@link PortalEntitlement|entitlement} to unassign
     */
    unassign(aobEntitlement?: PortalEntitlement): Promise<void>;
    /**
     * Call to get data from server depending on the {@link CollectionLoadParameters}.
     * @param resetNavigationState Indicates wether the navigation state should be reset or not.
     * @param newState Optional argument for loading new date for the given {@link CollectionLoadParameters}.
     */
    getData(resetNavigationState?: boolean, newState?: CollectionLoadParameters): Promise<void>;
    /**
     * Opens a side sheet to edit entitlement information
     * @param entitlement the entitlement to edit
     */
    editEntitlement(entitlement: PortalEntitlement): Promise<void>;
    /**
     * Triggered action from the {@link DataTableComponent} or {@link TilesComponent} after the selection have changed.
     */
    onSelectionChanged(selection: PortalEntitlement[]): void;
    /**
     * Triggered action from the {@link DataSourceToolbar|DataSourceToolbar} after the grouping have changed.
     */
    onGroupingChanged(col: IClientProperty): void;
    getType(data: PortalEntitlement): string;
    private addDirectEntitlements;
    private buildRoleAndAddItToApplication;
    private clearSelections;
    private navigate;
    private updateTableNames;
    private createEntitlementWrapper;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntitlementsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntitlementsComponent, "imx-entitlements", never, { "application": "application"; }, { "reloadRequested": "reloadRequested"; }, never, never, false>;
}
