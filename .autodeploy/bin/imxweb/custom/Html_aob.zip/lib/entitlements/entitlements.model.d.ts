export declare enum EntitlementsType {
    UnsGroup = 0,
    Eset = 1,
    Qerresource = 2,
    Rpsreport = 3,
    Tsbaccountdef = 4
}
export interface AddEntitlementParameter {
    defaultType: EntitlementsType;
    isSystemRolesEnabled: boolean;
    uidApplication: string;
}
export interface EntitlementSourceType {
    entitlementsType: EntitlementsType;
    display: string;
}
