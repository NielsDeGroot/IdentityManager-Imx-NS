import { IExtension } from 'qbm';
import { LockInfoAlertComponent } from './lock-info-alert.component';
export declare class LockInfoAlertExtension implements IExtension {
    static readonly id = "serviceItemEditForm.alert";
    instance: typeof LockInfoAlertComponent;
}
