import { OnInit } from '@angular/core';
import { PortalServiceitems } from 'imx-api-qer';
import * as i0 from "@angular/core";
export declare class LockInfoAlertComponent implements OnInit {
    serviceItem: PortalServiceitems;
    isLocked: boolean;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LockInfoAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LockInfoAlertComponent, "imx-lock-info-alert", never, { "serviceItem": "serviceItem"; }, {}, never, never, false>;
}
