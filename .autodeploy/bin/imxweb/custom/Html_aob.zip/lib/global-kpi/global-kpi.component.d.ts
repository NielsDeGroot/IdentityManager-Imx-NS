import { OnInit, TemplateRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { MatDialog } from '@angular/material/dialog';
import { ChartDto } from 'imx-api-aob';
import { ClassloggerService } from 'qbm';
import { GlobalKpiService } from './global-kpi.service';
import { KpiData } from './kpi-data.interface';
import * as i0 from "@angular/core";
export declare class GlobalKpiComponent implements OnInit {
    private readonly logger;
    private kpiProvider;
    private matDialog;
    private readonly busyService;
    readonly translateService: TranslateService;
    kpiData: KpiData[];
    browserCulture: string;
    /**
     * @ignore Only used with template
     */
    chartDialog: TemplateRef<any>;
    private noDataLoaded;
    private business;
    private central;
    private others;
    private readonly colors;
    constructor(logger: ClassloggerService, kpiProvider: GlobalKpiService, matDialog: MatDialog, busyService: EuiLoadingService, translateService: TranslateService);
    /**
     * Loads the chartDto objects and inits the component
     */
    ngOnInit(): Promise<void>;
    /**
     * @ignore opens a dialog that shows the details of a KPI
     * @param chart the data of a single chart
     */
    showDetails(kpi: KpiData): void;
    /**
     * @ignore determines whether a chart has detailed data
     * @param chart the data of a single chart
     * @returns true, if the KPI has DataPoits also false
     */
    isCalculated(chart: ChartDto): boolean;
    /**
     * @ignore determines whether an application has chart data or not
     * @returns true, if there are any KPIs else false
     */
    hasKpis(): boolean;
    private buildKpiData;
    private buildSingleValueChart;
    private buildPieChart;
    /**
     * @ignore converts an array of string arrays to an object ( first strign is the property name
     * second string the value)
     * @param array an array of string arrays
     *
     */
    private toObject;
    /**
     * @ignore determines whether a chart has more then one data point
     * @param chart the data of a single chart
     * @returns true, if the chart has multiple points else it return false
     */
    private hasMultipleDataPoints;
    /**
     * @ignore Build the ChartOptions that can be displayed with billboard.js
     * @param chart the data of a single chart
     * @returns a ChartOptions object, that can be used by billboard.js
     */
    private buildLineOptions;
    private accumulateTicks;
    private getMax;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalKpiComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GlobalKpiComponent, "imx-global-kpi", never, {}, {}, never, never, false>;
}
