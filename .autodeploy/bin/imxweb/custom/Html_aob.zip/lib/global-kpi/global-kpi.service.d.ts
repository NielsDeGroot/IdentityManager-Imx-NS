import { ApiClientService } from 'qbm';
import { ChartDto } from 'imx-api-aob';
import { AobApiService } from '../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class GlobalKpiService {
    private aobClient;
    private readonly apiProvider;
    constructor(aobClient: AobApiService, apiProvider: ApiClientService);
    /**
     * Encapsules the aob/kpi GET endpoint
     */
    get(): Promise<ChartDto[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalKpiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GlobalKpiService>;
}
