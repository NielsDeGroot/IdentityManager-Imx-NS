import { ChartOptions } from 'billboard.js';
import { ChartDto } from 'imx-api-aob';
export interface KpiData {
    index: number;
    chartData: ChartDto;
    chartDetails?: ChartOptions;
    currentDataValue?: number;
    pieChart?: ChartOptions;
    calculated: boolean;
    names: string[];
}
