import { Router } from '@angular/router';
import { AobPermissionsService } from '../../permissions/aob-permissions.service';
import * as i0 from "@angular/core";
export declare class KpiTileComponent {
    private readonly router;
    private readonly aobPermissionService;
    constructor(router: Router, aobPermissionService: AobPermissionsService);
    isAobOwner: boolean;
    ngOnInit(): Promise<void>;
    goToGlobalKpi(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<KpiTileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KpiTileComponent, "imx-kpi-tile", never, {}, {}, never, never, false>;
}
