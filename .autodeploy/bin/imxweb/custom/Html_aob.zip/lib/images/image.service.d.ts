import { DomSanitizer } from '@angular/platform-browser';
import { ApiClientService } from 'qbm';
import { QerApiService } from 'qer';
import * as i0 from "@angular/core";
export declare class ImageService {
    private readonly qerClient;
    private readonly sanitizer;
    private readonly apiProvider;
    constructor(qerClient: QerApiService, sanitizer: DomSanitizer, apiProvider: ApiClientService);
    /**
     * Gets the person image URL converted to a SafeUrl
     */
    getPersonImageUrl(uid: string): Promise<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ImageService>;
}
