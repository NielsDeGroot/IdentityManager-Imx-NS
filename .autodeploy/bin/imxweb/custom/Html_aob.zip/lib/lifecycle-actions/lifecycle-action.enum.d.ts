/**
 * The list of all possible actions on the {@link PortalEntitlement|PortalEntitlements} for an {@link PortalApplication|PortalApplication}.
 */
export declare enum LifecycleAction {
    Publish = 0,
    Unpublish = 1,
    Unassign = 2
}
