import * as i0 from "@angular/core";
import * as i1 from "./lifecycle-action.component";
import * as i2 from "@angular/common";
import * as i3 from "qbm";
import * as i4 from "@elemental-ui/core";
import * as i5 from "@angular/forms";
import * as i6 from "@angular/material/button";
import * as i7 from "@angular/material/card";
import * as i8 from "@angular/material/dialog";
import * as i9 from "@angular/material/datepicker";
import * as i10 from "@angular/material/form-field";
import * as i11 from "@angular/material/input";
import * as i12 from "@angular/material/radio";
import * as i13 from "@ngx-translate/core";
export declare class LifecycleActionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LifecycleActionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LifecycleActionsModule, [typeof i1.LifecycleActionComponent], [typeof i2.CommonModule, typeof i3.DataSourceToolbarModule, typeof i3.DataTableModule, typeof i4.EuiCoreModule, typeof i5.FormsModule, typeof i3.LdsReplaceModule, typeof i6.MatButtonModule, typeof i7.MatCardModule, typeof i8.MatDialogModule, typeof i9.MatDatepickerModule, typeof i10.MatFormFieldModule, typeof i11.MatInputModule, typeof i12.MatRadioModule, typeof i5.ReactiveFormsModule, typeof i3.QbmModule, typeof i13.TranslateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LifecycleActionsModule>;
}
