export declare function isAobApplicationOwner(features: string[]): boolean;
export declare function isAobApplicationAdmin(features: string[]): boolean;
