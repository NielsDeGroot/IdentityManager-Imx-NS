import { UserModelService } from 'qer';
import * as i0 from "@angular/core";
export declare class AobPermissionsService {
    private readonly userService;
    constructor(userService: UserModelService);
    isAobApplicationOwner(): Promise<boolean>;
    isAobApplicationAdmin(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AobPermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AobPermissionsService>;
}
