import { ApiClientService } from 'qbm';
import { PortalEntitlement, PortalEntitlementServiceitem } from 'imx-api-aob';
import { CollectionLoadParameters, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { AobApiService } from '../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class ServiceItemsService {
    private readonly aobClient;
    private readonly apiProvider;
    constructor(aobClient: AobApiService, apiProvider: ApiClientService);
    get(entitlement: PortalEntitlement, parameters?: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalEntitlementServiceitem>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceItemsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServiceItemsService>;
}
