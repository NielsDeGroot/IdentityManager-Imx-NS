import { ClassloggerService, ApiClientService } from 'qbm';
import { CollectionLoadParameters, TypedEntity, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { PortalShops, PortalApplicationinshop, PortalApplication } from 'imx-api-aob';
import { AobApiService } from '../aob-api-client.service';
import * as i0 from "@angular/core";
export declare class ShopsService {
    private readonly aobClient;
    private readonly logger;
    private readonly apiProvider;
    get display(): string;
    constructor(aobClient: AobApiService, logger: ClassloggerService, apiProvider: ApiClientService);
    get(parameters?: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalShops>>;
    getApplicationInShop(application: string, parameters?: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalApplicationinshop>>;
    getFirstAndCount(uidApplication: string): Promise<{
        first: TypedEntity;
        count: number;
    }>;
    updateApplicationInShops(application: PortalApplication, changeSet: {
        add: PortalShops[];
        remove: PortalShops[];
    }): Promise<boolean>;
    private addShops;
    private removeShops;
    static isAssigned(shop: PortalShops, shopsAssigned: PortalApplicationinshop[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShopsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShopsService>;
}
