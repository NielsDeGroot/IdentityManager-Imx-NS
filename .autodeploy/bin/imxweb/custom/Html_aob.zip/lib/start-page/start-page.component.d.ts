import { OnDestroy, OnInit } from '@angular/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { AuthenticationService, ClassloggerService } from 'qbm';
import { UserModelService } from 'qer';
import { ApplicationsService } from '../applications/applications.service';
import { ImageService } from '../images/image.service';
import { AobPermissionsService } from '../permissions/aob-permissions.service';
import * as i0 from "@angular/core";
export declare class StartPageComponent implements OnInit, OnDestroy {
    private readonly busyService;
    private readonly applicationsProvider;
    private readonly logger;
    private readonly userService;
    private readonly imageProvider;
    private readonly aobPermissionsService;
    private img;
    numberOfApplications: number;
    isAdmin: boolean;
    name: string;
    imageUrl: string;
    private authSubscription;
    constructor(busyService: EuiLoadingService, applicationsProvider: ApplicationsService, logger: ClassloggerService, userService: UserModelService, imageProvider: ImageService, aobPermissionsService: AobPermissionsService, authentication: AuthenticationService);
    ngOnDestroy(): void;
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StartPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StartPageComponent, "imx-start", never, {}, {}, never, never, false>;
}
