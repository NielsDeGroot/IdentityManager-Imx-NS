import * as i0 from '@angular/core';
import { Injectable, Component, ViewChild, Input, Inject, NgModule } from '@angular/core';
import * as i1$2 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i1 from 'qbm';
import { BusyService, CdrFactoryService, CdrModule, DataSourceToolbarModule, DataTableModule, BusyIndicatorModule, SelectedElementsModule, HelpContextualModule, HELP_CONTEXTUAL, RouteGuardService } from 'qbm';
import { __awaiter } from 'tslib';
import { TypedEntityBuilder, CompareOperator, FilterType, DisplayColumns, XOrigin, ValType, DbObjectKey } from 'imx-qbm-dbts';
import * as i6$1 from '@angular/forms';
import { FormGroup, UntypedFormArray, FormArray, ReactiveFormsModule } from '@angular/forms';
import * as i3 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import { V2Client, TypedClient, PortalRespApplication } from 'imx-api-apc';
import * as i1$1 from 'qer';
import { SourceDetectiveType, SourceDetectiveSidesheetComponent, ServiceItemsEditFormModule } from 'qer';
import * as i4 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i3$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i6 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i7 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i9 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i10 from '@angular/material/tooltip';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApcApiService {
    constructor(config, logger, translationProvider) {
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
}
ApcApiService.ɵfac = function ApcApiService_Factory(t) { return new (t || ApcApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
ApcApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApcApiService, factory: ApcApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApcApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i1.ImxTranslationProviderService }]; }, null);
})();

class SoftwareService {
    constructor(project, api, qerClient) {
        this.project = project;
        this.api = api;
        this.qerClient = qerClient;
        this.resourceMap = new Map();
        this.abortController = new AbortController();
        this.appInfo = {
            table: 'Application',
            caption: '#LDS#Software',
            accProduct: this.api.typedClient.PortalResourcesApplicationServiceitem,
            resp: {
                type: PortalRespApplication,
                get: (parameter) => __awaiter(this, void 0, void 0, function* () {
                    if ((parameter === null || parameter === void 0 ? void 0 : parameter.search) !== undefined) {
                        // abort the request only while searching
                        this.abortCall();
                    }
                    return this.api.client.portal_resp_application_get(parameter, { signal: this.abortController.signal });
                }),
                schema: this.api.typedClient.PortalRespApplication.GetSchema(),
                dataModel: (filter) => __awaiter(this, void 0, void 0, function* () { return this.api.client.portal_resp_application_datamodel_get({ filter }); }),
                interactive: this.api.typedClient.PortalRespApplicationInteractive,
            },
        };
    }
    get(parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            const conf = this.appInfo.resp;
            if (!conf)
                return null;
            const builder = new TypedEntityBuilder(conf.type);
            const data = yield conf.get(parameter);
            return builder.buildReadWriteEntities(data, conf.schema);
        });
    }
    getDataModel(filter) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.appInfo.resp.dataModel(filter);
        });
    }
    getInteractive(id) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.appInfo.resp.interactive.Get_byid(id)).Data[0];
        });
    }
    getSchema(interactive) {
        return interactive ? this.appInfo.resp.interactive.GetSchema() : this.appInfo.resp.schema;
    }
    get membershipSchema() {
        return this.api.typedClient.PortalResourcesApplicationsMembership.GetSchema();
    }
    getEditableFields(objectType, entity, primary = false) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.config == null) {
                this.config = yield this.project.getConfig();
            }
            const list = primary ? this.config.OwnershipConfig.PrimaryFields : this.config.OwnershipConfig.EditableFields;
            return list[objectType].filter((name) => entity.GetSchema().Columns[name]);
        });
    }
    getServiceItem(uidAccProduct) {
        return __awaiter(this, void 0, void 0, function* () {
            const filter = [
                {
                    Type: FilterType.Compare,
                    CompareOp: CompareOperator.Equal,
                    ColumnName: 'UID_AccProduct',
                    Value1: uidAccProduct,
                },
            ];
            const item = yield this.appInfo.accProduct.Get({ filter });
            return item.Data.length > 0 ? item.Data[0] : undefined;
        });
    }
    getMemberShips(uidApplication, parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalResourcesApplicationsMembership.Get(uidApplication, parameter);
        });
    }
    deleteGroupMembers(uidSoftware, uidPersonList) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield Promise.all(uidPersonList.map((item) => __awaiter(this, void 0, void 0, function* () {
                (yield this.api.typedClient.PortalResourcesApplicationsMembership.Delete(uidSoftware, item)).Data[0];
            })));
        });
    }
    unsubscribeMembership(item) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.qerClient.client.portal_itshop_unsubscribe_post({ UidPwo: [item.GetEntity().GetColumn('UID_PersonWantsOrg').GetValue()] });
        });
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
}
SoftwareService.ɵfac = function SoftwareService_Factory(t) { return new (t || SoftwareService)(i0.ɵɵinject(i1$1.ProjectConfigurationService), i0.ɵɵinject(ApcApiService), i0.ɵɵinject(i1$1.QerApiService)); };
SoftwareService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: SoftwareService, factory: SoftwareService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SoftwareService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: i1$1.ProjectConfigurationService }, { type: ApcApiService }, { type: i1$1.QerApiService }]; }, null);
})();

const _c0$2 = ["membersTable"];
function SoftwareMembershipsComponent_eui_alert_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r6 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-alert", 17);
        i0.ɵɵlistener("dismissed", function SoftwareMembershipsComponent_eui_alert_4_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.onWarningDismissed()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 4, ctx_r0.LdsNotUnsubscribableHint));
    }
}
function SoftwareMembershipsComponent_ng_template_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r7 = ctx.$implicit;
        let tmp_0_0;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", item_r7 == null ? null : (tmp_0_0 = item_r7.GetEntity()) == null ? null : tmp_0_0.GetDisplay(), " ");
    }
}
function SoftwareMembershipsComponent_ng_template_15_eui_badge_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-badge", 20);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r9 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r9.entitySchema.Columns.XMarkedForDeletion.Display, " ");
    }
}
function SoftwareMembershipsComponent_ng_template_15_eui_badge_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-badge", 20);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Membership is ineffective"), " ");
    }
}
function SoftwareMembershipsComponent_ng_template_15_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 18)(1, "div");
        i0.ɵɵtemplate(2, SoftwareMembershipsComponent_ng_template_15_eui_badge_2_Template, 2, 1, "eui-badge", 19);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "div");
        i0.ɵɵtemplate(4, SoftwareMembershipsComponent_ng_template_15_eui_badge_4_Template, 3, 3, "eui-badge", 19);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const item_r8 = ctx.$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", item_r8.XMarkedForDeletion.value);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", !item_r8.XIsInEffect.value);
    }
}
const _c1 = function () { return ["search"]; };
class SoftwareMembershipsComponent {
    constructor(softwareService, sideSheet, translate, confirmationService, snackBarService) {
        this.softwareService = softwareService;
        this.sideSheet = sideSheet;
        this.translate = translate;
        this.confirmationService = confirmationService;
        this.snackBarService = snackBarService;
        this.DisplayColumns = DisplayColumns;
        this.entitySchema = this.softwareService.membershipSchema;
        this.selections = [];
        this.showUnsubscribeWarning = false;
        this.status = {
            enabled: (item) => {
                var _a, _b;
                return item.XOrigin.value === XOrigin.Direct || ((_b = (_a = item.UID_PersonWantsOrg) === null || _a === void 0 ? void 0 : _a.value) !== null && _b !== void 0 ? _b : '') !== '';
            },
        };
        this.navigationState = {};
        this.busyService = new BusyService();
        this.membershipHint = '#LDS#Here you can manage the memberships of the software application. You can remove memberships and view the assignment analysis for each membership.';
        this.LdsNotUnsubscribableHint = '#LDS#There is at least one membership you cannot unsubscribe. You can only unsubscribe memberships you have requested.';
        this.displayColumns = [
            this.entitySchema.Columns.UID_Person,
            this.entitySchema.Columns.XOrigin,
            this.entitySchema.Columns.XDateInserted,
            this.entitySchema.Columns.ValidUntil,
            { ColumnName: 'badges', Type: ValType.String },
        ];
    }
    get canDeleteSelected() {
        return this.selections.length > 0 && this.selections.every((item) => item.XOrigin.value === XOrigin.Direct);
    }
    get canUnsubscribeSelected() {
        return this.selections.length > 0 && this.selections.every((item) => { var _a, _b; return ((_b = (_a = item.UID_PersonWantsOrg) === null || _a === void 0 ? void 0 : _a.value) !== null && _b !== void 0 ? _b : '') !== ''; });
    }
    ngOnChanges(changes) {
        return __awaiter(this, void 0, void 0, function* () {
            if (changes.uidSoftware && changes.uidSoftware.currentValue) {
                return this.getData({});
            }
        });
    }
    onSearch(keyword) {
        return __awaiter(this, void 0, void 0, function* () {
            this.getData({ search: keyword, StartIndex: 0 });
        });
    }
    onSelectionChanged(selection) {
        this.selections = selection;
    }
    showDetails(item) {
        return __awaiter(this, void 0, void 0, function* () {
            const uidPerson = item.UID_Person.value;
            const objectKey = DbObjectKey.FromXml(item.XObjectKey.value);
            const data = {
                UID_Person: uidPerson,
                Type: SourceDetectiveType.MembershipOfSystemEntitlement,
                UID: objectKey.Keys.join(','),
                TableName: objectKey.TableName,
            };
            this.sideSheet.open(SourceDetectiveSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Assignment Analysis').toPromise(),
                subTitle: item.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(60%,600px)',
                disableClose: false,
                testId: 'software-memberships-assingment-analysis',
                data,
            });
        });
    }
    getData(navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState = navigationState;
            const isBusy = this.busyService.beginBusy();
            try {
                this.dstSettings = {
                    dataSource: yield this.softwareService.getMemberShips(this.uidSoftware, this.navigationState),
                    entitySchema: this.entitySchema,
                    navigationState: this.navigationState,
                    displayedColumns: this.displayColumns,
                };
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    deleteSelected() {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.confirmationService.confirm({
                Title: '#LDS#Heading Remove Memberships',
                Message: '#LDS#The removal of memberships may take some time. The displayed data may differ from the actual state. Are you sure you want to remove the selected memberships?',
                identifier: 'group-members-confirm-delete-memberships',
            })) {
                const isBusy = this.busyService.beginBusy();
                try {
                    yield this.softwareService.deleteGroupMembers(this.uidSoftware, this.selections.map((i) => i.GetEntity().GetColumn('UID_Person').GetValue()));
                    this.membersTable.clearSelection();
                    this.snackBarService.open({ key: '#LDS#The memberships have been successfully removed.' }, '#LDS#Close');
                    yield this.getData({ search: this.navigationState.search });
                }
                finally {
                    isBusy.endBusy();
                }
            }
        });
    }
    onWarningDismissed() {
        this.showUnsubscribeWarning = false;
    }
    unsubscribeMembership() {
        return __awaiter(this, void 0, void 0, function* () {
            // if there is at least 1 item, that is not unsubscribable, show a warning instead
            const notSubscribable = this.selections.some((entity) => entity.GetEntity().GetColumn('IsRequestCancellable').GetValue() === false);
            if (notSubscribable) {
                this.showUnsubscribeWarning = true;
                this.membersTable.clearSelection();
                return;
            }
            if (yield this.confirmationService.confirm({
                Title: '#LDS#Heading Unsubscribe Memberships',
                Message: '#LDS#Are you sure you want to unsubscribe the selected memberships?',
                identifier: 'group-members-confirm-unsubscribe-membership',
            })) {
                const isBusy = this.busyService.beginBusy();
                try {
                    yield Promise.all(this.selections.map((entity) => this.softwareService.unsubscribeMembership(entity)));
                    this.snackBarService.open({
                        key: '#LDS#The memberships have been successfully unsubscribed. It may take some time for the changes to take effect. The displayed data may differ from the actual state.',
                    });
                }
                finally {
                    isBusy.endBusy();
                    this.membersTable.clearSelection();
                    yield this.getData({ search: this.navigationState.search });
                }
            }
        });
    }
}
SoftwareMembershipsComponent.ɵfac = function SoftwareMembershipsComponent_Factory(t) { return new (t || SoftwareMembershipsComponent)(i0.ɵɵdirectiveInject(SoftwareService), i0.ɵɵdirectiveInject(i3.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$1.TranslateService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(i1.SnackBarService)); };
SoftwareMembershipsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SoftwareMembershipsComponent, selectors: [["imx-software-memberships"]], viewQuery: function SoftwareMembershipsComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$2, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.membersTable = _t.first);
        }
    }, inputs: { uidSoftware: "uidSoftware" }, features: [i0.ɵɵNgOnChangesFeature], decls: 31, vars: 32, consts: [[1, "helper-alert-container"], ["condensed", "true", "type", "info", 1, "helper-alert", 3, "colored", "dismissable"], ["class", "helper-alert", "type", "warning", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "imx-table-content"], ["data-imx-identifier", "software-memberships-data-source-toolbar", 3, "settings", "options", "itemStatus", "busyService", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], ["data-imx-identifier", "software-membeships-data-table", "detailViewVisible", "false", "mode", "manual", 3, "dst", "showSelectedItemsMenu", "selectable", "selectionChanged", "highlightedEntityChanged"], ["membersTable", ""], [3, "entityColumn"], ["columnName", "badges"], ["data-imx-identifier", "software-paginator", 3, "dst"], ["eui-sidesheet-actions", ""], [3, "selectedElements"], [1, "imx-menu-spacer"], ["mat-stroked-button", "", "data-imx-identifier", "software-memberships-cancel-selected", 3, "disabled", "click"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "software-memberships-delete-selected", 3, "disabled", "click"], ["icon", "delete"], ["type", "warning", 1, "helper-alert", 3, "condensed", "colored", "dismissable", "dismissed"], [1, "imx-badge-container"], ["color", "gray", 4, "ngIf"], ["color", "gray"]], template: function SoftwareMembershipsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "eui-alert", 1);
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(4, SoftwareMembershipsComponent_eui_alert_4_Template, 3, 6, "eui-alert", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card")(6, "div", 3)(7, "imx-data-source-toolbar", 4, 5);
            i0.ɵɵlistener("navigationStateChanged", function SoftwareMembershipsComponent_Template_imx_data_source_toolbar_navigationStateChanged_7_listener($event) { return ctx.getData($event); })("search", function SoftwareMembershipsComponent_Template_imx_data_source_toolbar_search_7_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "imx-data-table", 6, 7);
            i0.ɵɵlistener("selectionChanged", function SoftwareMembershipsComponent_Template_imx_data_table_selectionChanged_10_listener($event) { return ctx.onSelectionChanged($event); })("highlightedEntityChanged", function SoftwareMembershipsComponent_Template_imx_data_table_highlightedEntityChanged_10_listener($event) { return ctx.showDetails($event); });
            i0.ɵɵelementStart(12, "imx-data-table-column", 8);
            i0.ɵɵtemplate(13, SoftwareMembershipsComponent_ng_template_13_Template, 2, 1, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(14, "imx-data-table-generic-column", 9);
            i0.ɵɵtemplate(15, SoftwareMembershipsComponent_ng_template_15_Template, 5, 2, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(16, "imx-data-table-column", 8)(17, "imx-data-table-column", 8)(18, "imx-data-table-column", 8)(19, "imx-data-table-column", 8);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(20, "imx-data-source-paginator", 10);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(21, "div", 11);
            i0.ɵɵelement(22, "imx-selected-elements", 12)(23, "div", 13);
            i0.ɵɵelementStart(24, "button", 14);
            i0.ɵɵlistener("click", function SoftwareMembershipsComponent_Template_button_click_24_listener() { return ctx.unsubscribeMembership(); });
            i0.ɵɵtext(25);
            i0.ɵɵpipe(26, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(27, "button", 15);
            i0.ɵɵlistener("click", function SoftwareMembershipsComponent_Template_button_click_27_listener() { return ctx.deleteSelected(); });
            i0.ɵɵelement(28, "eui-icon", 16);
            i0.ɵɵtext(29);
            i0.ɵɵpipe(30, "translate");
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r1 = i0.ɵɵreference(8);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("colored", true)("dismissable", true);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 23, ctx.membershipHint), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.showUnsubscribeWarning);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(31, _c1))("itemStatus", ctx.status)("busyService", ctx.busyService)("searchBoxText", i0.ɵɵpipeBind1(9, 25, "#LDS#Search"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r1)("showSelectedItemsMenu", false)("selectable", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_Person);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.XOrigin);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.XDateInserted);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.ValidUntil);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r1);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("selectedElements", ctx.selections);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canUnsubscribeSelected);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(26, 27, "#LDS#Unsubscribe"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canDeleteSelected);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(30, 29, "#LDS#Remove"), " ");
        }
    }, dependencies: [i4.NgIf, i1.DataSourceToolbarComponent, i1.DataSourcePaginatorComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i1.DataTableGenericColumnComponent, i6.MatCard, i7.MatButton, i3.EuiAlertComponent, i3.EuiBadgeComponent, i3.EuiIconComponent, i3.EuiSidesheetActionsDirective, i1.SelectedElementsComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}[_nghost-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.hidden[_ngcontent-%COMP%]{display:none}.mat-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:20px}.imx-table-content[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}imx-busy-indicator[_ngcontent-%COMP%]{flex:1 1 auto;justify-content:center;align-items:center}.helper-alert[_ngcontent-%COMP%]{margin:12px}.helper-alert-container[_ngcontent-%COMP%]{margin:0 20px}imx-selected-elements[_ngcontent-%COMP%]{margin-left:10px}.imx-menu-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:12px}.imx-badge-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{display:table-cell}.imx-badge-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%] > .eui-badge[_ngcontent-%COMP%]{margin:0 5px}.imx-badge-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%] > .eui-badge[_ngcontent-%COMP%]     .eui-badge-content{white-space:nowrap}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SoftwareMembershipsComponent, [{
            type: Component,
            args: [{ selector: 'imx-software-memberships', template: "<div class=\"helper-alert-container\">\r\n  <eui-alert class=\"helper-alert\" condensed=\"true\" [colored]=\"true\" type=\"info\" [dismissable]=\"true\">\r\n    {{ membershipHint | translate }}\r\n  </eui-alert>\r\n  <eui-alert class=\"helper-alert\" *ngIf=\"showUnsubscribeWarning\" type=\"warning\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\" (dismissed)=\"onWarningDismissed()\">{{\r\n    LdsNotUnsubscribableHint | translate\r\n  }}</eui-alert>\r\n</div>\r\n\r\n<mat-card>\r\n  <div class=\"imx-table-content\">\r\n    <!-- todo after DataTableMerge: Busy-Indicator setzen-->\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      data-imx-identifier=\"software-memberships-data-source-toolbar\"\r\n      [settings]=\"dstSettings\"\r\n      [options]=\"['search']\"\r\n      [itemStatus]=\"status\"\r\n      [busyService]=\"busyService\"\r\n      [searchBoxText]=\"'#LDS#Search' | translate\"\r\n      (navigationStateChanged)=\"getData($event)\"\r\n      (search)=\"onSearch($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n\r\n    <imx-data-table\r\n      #membersTable\r\n      data-imx-identifier=\"software-membeships-data-table\"\r\n      [dst]=\"dst\"\r\n      [showSelectedItemsMenu]=\"false\"\r\n      [selectable]=\"true\"\r\n      (selectionChanged)=\"onSelectionChanged($event)\"\r\n      detailViewVisible=\"false\"\r\n      mode=\"manual\"\r\n      (highlightedEntityChanged)=\"showDetails($event)\"\r\n    >\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n        <ng-template let-item>\r\n          <div>\r\n            {{ item?.GetEntity()?.GetDisplay() }}\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-column>\r\n      <imx-data-table-generic-column columnName=\"badges\">\r\n        <ng-template let-item>\r\n          <div class=\"imx-badge-container\">\r\n            <div>\r\n              <eui-badge color=\"gray\" *ngIf=\"item.XMarkedForDeletion.value\">\r\n                {{ entitySchema.Columns.XMarkedForDeletion.Display }}\r\n              </eui-badge>\r\n            </div>\r\n            <div>\r\n              <eui-badge color=\"gray\" *ngIf=\"!item.XIsInEffect.value\">\r\n                {{ '#LDS#Membership is ineffective' | translate }}\r\n              </eui-badge>\r\n            </div>\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-generic-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_Person\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.XOrigin\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.XDateInserted\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.ValidUntil\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n    <imx-data-source-paginator data-imx-identifier=\"software-paginator\" [dst]=\"dst\"></imx-data-source-paginator>\r\n  </div>\r\n</mat-card>\r\n<div eui-sidesheet-actions>\r\n  <imx-selected-elements [selectedElements]=\"selections\"></imx-selected-elements>\r\n  <div class=\"imx-menu-spacer\"></div>\r\n  <button mat-stroked-button [disabled]=\"!canUnsubscribeSelected\" data-imx-identifier=\"software-memberships-cancel-selected\" (click)=\"unsubscribeMembership()\">\r\n    {{ '#LDS#Unsubscribe' | translate }}\r\n  </button>\r\n  <button mat-stroked-button color=\"warn\" [disabled]=\"!canDeleteSelected\" data-imx-identifier=\"software-memberships-delete-selected\" (click)=\"deleteSelected()\">\r\n    <eui-icon icon=\"delete\"></eui-icon>\r\n    {{ '#LDS#Remove' | translate }}\r\n  </button>\r\n</div>\r\n", styles: [":host{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}:host eui-icon{font-size:14px;margin-right:4px}.hidden{display:none}.mat-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:20px}.imx-table-content{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}imx-busy-indicator{flex:1 1 auto;justify-content:center;align-items:center}.helper-alert{margin:12px}.helper-alert-container{margin:0 20px}imx-selected-elements{margin-left:10px}.imx-menu-spacer{flex:1 1 auto}.eui-sidesheet-actions button:not(:last-of-type){margin-right:12px}.imx-badge-container>div{display:table-cell}.imx-badge-container>div>.eui-badge{margin:0 5px}.imx-badge-container>div>.eui-badge ::ng-deep .eui-badge-content{white-space:nowrap}\n"] }]
        }], function () { return [{ type: SoftwareService }, { type: i3.EuiSidesheetService }, { type: i3$1.TranslateService }, { type: i1.ConfirmationService }, { type: i1.SnackBarService }]; }, { uidSoftware: [{
                type: Input
            }], membersTable: [{
                type: ViewChild,
                args: ['membersTable']
            }] });
})();

function SoftwareSidesheetComponent_ng_template_2_eui_icon_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "eui-icon", 15);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
    }
}
function SoftwareSidesheetComponent_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 12);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelementStart(2, "span", 13);
        i0.ɵɵtext(3, "#LDS#Heading Main Data");
        i0.ɵɵelementEnd();
        i0.ɵɵtext(4, "\u00A0 ");
        i0.ɵɵtemplate(5, SoftwareSidesheetComponent_ng_template_2_eui_icon_5_Template, 2, 3, "eui-icon", 14);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, ctx_r0.softwareFormGroup.dirty ? "#LDS#You have unsaved changes" : ""));
        i0.ɵɵadvance(5);
        i0.ɵɵproperty("ngIf", ctx_r0.softwareFormGroup.dirty);
    }
}
function SoftwareSidesheetComponent_imx_busy_indicator_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-busy-indicator");
    }
}
function SoftwareSidesheetComponent_imx_cdr_editor_9_Template(rf, ctx) {
    if (rf & 1) {
        const _r10 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 16);
        i0.ɵɵlistener("controlCreated", function SoftwareSidesheetComponent_imx_cdr_editor_9_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r9 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r9.softwareFormGroup.controls.array.push($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r8 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r8);
    }
}
function SoftwareSidesheetComponent_ng_template_16_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 1)(1, "div", 2);
        i0.ɵɵelement(2, "imx-software-memberships", 17);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("uidSoftware", ctx_r3.data.uidSoftware);
    }
}
function SoftwareSidesheetComponent_mat_tab_17_ng_template_1_eui_icon_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "eui-icon", 15);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
    }
}
function SoftwareSidesheetComponent_mat_tab_17_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 12);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelementStart(2, "span", 13);
        i0.ɵɵtext(3, "#LDS#Heading Service Item");
        i0.ɵɵelementEnd();
        i0.ɵɵtext(4, "\u00A0 ");
        i0.ɵɵtemplate(5, SoftwareSidesheetComponent_mat_tab_17_ng_template_1_eui_icon_5_Template, 2, 3, "eui-icon", 14);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r11 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, ctx_r11.serviceItemGroup.dirty ? "#LDS#You have unsaved changes" : ""));
        i0.ɵɵadvance(5);
        i0.ɵɵproperty("ngIf", ctx_r11.serviceItemGroup.dirty);
    }
}
function SoftwareSidesheetComponent_mat_tab_17_imx_busy_indicator_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-busy-indicator");
    }
}
function SoftwareSidesheetComponent_mat_tab_17_imx_service_items_edit_form_8_Template(rf, ctx) {
    if (rf & 1) {
        const _r16 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-service-items-edit-form", 21);
        i0.ɵɵlistener("formControlCreated", function SoftwareSidesheetComponent_mat_tab_17_imx_service_items_edit_form_8_Template_imx_service_items_edit_form_formControlCreated_0_listener($event) { i0.ɵɵrestoreView(_r16); const ctx_r15 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r15.serviceItemGroup.controls.serviceItemParameter.push($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r13 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("busyService", ctx_r13.busyService)("serviceItem", ctx_r13.serviceItem);
    }
}
const _c0$1 = function (a0) { return { hidden: a0 }; };
function SoftwareSidesheetComponent_mat_tab_17_Template(rf, ctx) {
    if (rf & 1) {
        const _r18 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-tab");
        i0.ɵɵtemplate(1, SoftwareSidesheetComponent_mat_tab_17_ng_template_1_Template, 6, 4, "ng-template", 0);
        i0.ɵɵelementStart(2, "div", 1)(3, "div", 2)(4, "div", 3)(5, "mat-card");
        i0.ɵɵtemplate(6, SoftwareSidesheetComponent_mat_tab_17_imx_busy_indicator_6_Template, 1, 0, "imx-busy-indicator", 4);
        i0.ɵɵelementStart(7, "form", 18);
        i0.ɵɵtemplate(8, SoftwareSidesheetComponent_mat_tab_17_imx_service_items_edit_form_8_Template, 1, 2, "imx-service-items-edit-form", 19);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(9, "div", 7)(10, "button", 20);
        i0.ɵɵlistener("click", function SoftwareSidesheetComponent_mat_tab_17_Template_button_click_10_listener() { i0.ɵɵrestoreView(_r18); const ctx_r17 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r17.saveServiceItem()); });
        i0.ɵɵtext(11);
        i0.ɵɵpipe(12, "translate");
        i0.ɵɵelementEnd()()()()();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext();
        i0.ɵɵadvance(6);
        i0.ɵɵproperty("ngIf", ctx_r4.isLoading);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r4.serviceItemGroup)("ngClass", i0.ɵɵpureFunction1(8, _c0$1, ctx_r4.isLoading));
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r4.serviceItem);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", ctx_r4.isLoading || ctx_r4.serviceItemGroup.pristine || ctx_r4.serviceItemGroup.invalid);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 6, "#LDS#Save"), " ");
    }
}
function SoftwareSidesheetComponent_ng_template_18_Template(rf, ctx) { }
class SoftwareSidesheetComponent {
    constructor(data, cdrFactory, changeDetector, softwareService, sidesheetRef, confirmation) {
        this.data = data;
        this.cdrFactory = cdrFactory;
        this.changeDetector = changeDetector;
        this.softwareService = softwareService;
        this.softwareFormGroup = new FormGroup({ array: new UntypedFormArray([]) });
        this.serviceItemGroup = new FormGroup({ serviceItemParameter: new FormArray([]) });
        this.isLoading = false;
        this.subscriptions = [];
        this.busyService = new BusyService();
        this.subscriptions.push(sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
            var _a;
            if ((((_a = this.serviceItemGroup) === null || _a === void 0 ? void 0 : _a.dirty) || this.softwareFormGroup.dirty) && !(yield confirmation.confirmLeaveWithUnsavedChanges())) {
                return;
            }
            sidesheetRef.close(false);
        })));
        this.subscriptions.push(this.busyService.busyStateChanged.subscribe((state) => {
            this.isLoading = state;
            this.changeDetector.detectChanges();
        }));
    }
    get withProduct() {
        var _a;
        const value = (_a = this.productColumn) === null || _a === void 0 ? void 0 : _a.GetValue();
        return value != null && value != '';
    }
    get productColumn() {
        return this.entity == null ? undefined : CdrFactoryService.tryGetColumn(this.entity.GetEntity(), 'UID_AccProduct');
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                //Load main item and service item
                this.entity = yield this.softwareService.getInteractive(this.data.uidSoftware);
                //load editable fields
                this.editableFields = yield this.softwareService.getEditableFields('Application', this.entity.GetEntity());
                this.serviceItem = this.productColumn ? yield this.softwareService.getServiceItem(this.productColumn.GetValue()) : null;
                // build cdr
                this.cdrList = this.cdrFactory.buildCdrFromColumnList(this.entity.GetEntity(), this.editableFields);
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    ngOnDestroy() {
        this.subscriptions.forEach((s) => s.unsubscribe());
    }
    /**
     * Saves the main data and reloads the form for further editing
     */
    submit() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                yield this.entity.GetEntity().Commit();
                this.entity = yield this.softwareService.getInteractive(this.data.uidSoftware);
                this.softwareFormGroup.controls.array.clear();
                this.cdrList = this.cdrFactory.buildCdrFromColumnList(this.entity.GetEntity(), this.editableFields);
                this.softwareFormGroup.markAsPristine();
                this.changeDetector.detectChanges();
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    /**
     * Saves the service item and reloads the form for further editing
     */
    saveServiceItem() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                yield this.serviceItem.GetEntity().Commit();
                this.serviceItemGroup.controls.serviceItemParameter.clear();
                this.serviceItem = this.productColumn ? yield this.softwareService.getServiceItem(this.productColumn.GetValue()) : null;
                this.serviceItemGroup.markAsPristine();
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
}
SoftwareSidesheetComponent.ɵfac = function SoftwareSidesheetComponent_Factory(t) { return new (t || SoftwareSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.CdrFactoryService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(SoftwareService), i0.ɵɵdirectiveInject(i3.EuiSidesheetRef), i0.ɵɵdirectiveInject(i1.ConfirmationService)); };
SoftwareSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SoftwareSidesheetComponent, selectors: [["ng-component"]], decls: 20, vars: 14, consts: [["mat-tab-label", ""], [1, "imx-tab-content"], [1, "imx-tab-content-body"], ["eui-sidesheet-content", ""], [4, "ngIf"], [3, "formGroup", "ngClass"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "software-sidesheet-save-button", 3, "disabled", "click"], [3, "label"], ["matTabContent", ""], ["productMissing", ""], [3, "matTooltip"], ["translate", ""], ["icon", "save", "class", "imx-dirty-indicator", "size", "s", 4, "ngIf"], ["icon", "save", "size", "s", 1, "imx-dirty-indicator"], [3, "cdr", "controlCreated"], [3, "uidSoftware"], [1, "imx-service-item-form", 3, "formGroup", "ngClass"], [3, "busyService", "serviceItem", "formControlCreated", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "service-items-edit-sidesheet-button-save", 3, "disabled", "click"], [3, "busyService", "serviceItem", "formControlCreated"]], template: function SoftwareSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group")(1, "mat-tab");
            i0.ɵɵtemplate(2, SoftwareSidesheetComponent_ng_template_2_Template, 6, 4, "ng-template", 0);
            i0.ɵɵelementStart(3, "div", 1)(4, "div", 2)(5, "div", 3)(6, "mat-card");
            i0.ɵɵtemplate(7, SoftwareSidesheetComponent_imx_busy_indicator_7_Template, 1, 0, "imx-busy-indicator", 4);
            i0.ɵɵelementStart(8, "form", 5);
            i0.ɵɵtemplate(9, SoftwareSidesheetComponent_imx_cdr_editor_9_Template, 1, 1, "imx-cdr-editor", 6);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(10, "div", 7)(11, "button", 8);
            i0.ɵɵlistener("click", function SoftwareSidesheetComponent_Template_button_click_11_listener() { return ctx.submit(); });
            i0.ɵɵtext(12);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementEnd()()()()();
            i0.ɵɵelementStart(14, "mat-tab", 9);
            i0.ɵɵpipe(15, "translate");
            i0.ɵɵtemplate(16, SoftwareSidesheetComponent_ng_template_16_Template, 3, 1, "ng-template", 10);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(17, SoftwareSidesheetComponent_mat_tab_17_Template, 13, 10, "mat-tab", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(18, SoftwareSidesheetComponent_ng_template_18_Template, 0, 0, "ng-template", null, 11, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
            i0.ɵɵadvance(7);
            i0.ɵɵproperty("ngIf", ctx.isLoading);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("formGroup", ctx.softwareFormGroup)("ngClass", i0.ɵɵpureFunction1(12, _c0$1, ctx.isLoading));
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.softwareFormGroup.dirty || ctx.softwareFormGroup.invalid);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 8, "#LDS#Save"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(15, 10, "#LDS#Memberships"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.withProduct);
        }
    }, dependencies: [i4.NgClass, i4.NgForOf, i4.NgIf, i1.CdrEditorComponent, i3$1.TranslateDirective, i6$1.ɵNgNoValidate, i6$1.NgControlStatusGroup, i6$1.FormGroupDirective, i6.MatCard, i7.MatButton, i3.EuiIconComponent, i3.EuiSidesheetContentDirective, i3.EuiSidesheetActionsDirective, i9.MatTabGroup, i9.MatTabLabel, i9.MatTab, i9.MatTabContent, i10.MatTooltip, i1.BusyIndicatorComponent, i1$1.ServiceItemsEditFormComponent, SoftwareMembershipsComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}[_nghost-%COMP%]   .mat-tab-group[_ngcontent-%COMP%]{flex-grow:1;overflow:auto}[_nghost-%COMP%]     .mat-tab-body-wrapper{height:100%}[_nghost-%COMP%]     .mat-tab-body-content{display:flex;flex-direction:column}[_nghost-%COMP%]     .mat-tab-group{height:100%}[_nghost-%COMP%]     .mat-tab-group .mat-tab-header{padding:0 32px}[_nghost-%COMP%]   .imx-tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%}[_nghost-%COMP%]   .imx-tab-content[_ngcontent-%COMP%]   .imx-tab-content-body[_ngcontent-%COMP%]{flex:1 1 auto;overflow:hidden;display:flex;flex-direction:column}[_nghost-%COMP%]   .imx-tab-content[_ngcontent-%COMP%]   .imx-tab-content-body[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;overflow:hidden;padding:16px}[_nghost-%COMP%]   .imx-tab-content[_ngcontent-%COMP%]   .imx-tab-content-body[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%] > form[_ngcontent-%COMP%]{padding-right:10px;overflow:auto}[_nghost-%COMP%]   .imx-tab-content[_ngcontent-%COMP%]   .imx-cdr-group[_ngcontent-%COMP%]{flex:1 1 auto;overflow:auto;padding-right:10px}[_nghost-%COMP%]   .hidden[_ngcontent-%COMP%]{display:none}[_nghost-%COMP%]   .imx-content-card[_ngcontent-%COMP%]{margin:20px;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .imx-content-card[_ngcontent-%COMP%]   .imx-service-item-form[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}[_nghost-%COMP%]   .imx-tab-content[_ngcontent-%COMP%]   .imx-action-buttons[_ngcontent-%COMP%]{background-color:#fff}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#fff}.eui-dark-theme   [_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .imx-tab-content[_ngcontent-%COMP%]   .imx-action-buttons[_ngcontent-%COMP%]{background-color:#444647}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SoftwareSidesheetComponent, [{
            type: Component,
            args: [{ template: "<mat-tab-group>\r\n  <mat-tab>\r\n    <ng-template mat-tab-label>\r\n      <div [matTooltip]=\"(softwareFormGroup.dirty ? '#LDS#You have unsaved changes' : '') | translate\">\r\n        <span translate>#LDS#Heading Main Data</span>&nbsp;\r\n        <eui-icon *ngIf=\"softwareFormGroup.dirty\" icon=\"save\" class=\"imx-dirty-indicator\" size=\"s\" [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"></eui-icon>\r\n      </div>\r\n    </ng-template>\r\n    <div class=\"imx-tab-content\">\r\n      <div class=\"imx-tab-content-body\">\r\n        <div eui-sidesheet-content>\r\n          <mat-card>\r\n            <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\r\n            <form [formGroup]=\"softwareFormGroup\" [ngClass]=\"{ hidden: isLoading }\">\r\n              <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"softwareFormGroup.controls.array.push($event)\"></imx-cdr-editor>\r\n            </form>\r\n          </mat-card>\r\n        </div>\r\n        <div eui-sidesheet-actions>\r\n          <button mat-flat-button color=\"primary\" [disabled]=\"!softwareFormGroup.dirty || softwareFormGroup.invalid\" data-imx-identifier=\"software-sidesheet-save-button\" (click)=\"submit()\">\r\n            {{ '#LDS#Save' | translate }}\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </mat-tab>\r\n  <mat-tab [label]=\"'#LDS#Memberships' | translate\">\r\n    <ng-template matTabContent>\r\n      <div class=\"imx-tab-content\">\r\n        <div class=\"imx-tab-content-body\">\r\n          <imx-software-memberships [uidSoftware]=\"data.uidSoftware\"></imx-software-memberships>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n  <mat-tab *ngIf=\"withProduct\">\r\n    <ng-template mat-tab-label>\r\n      <div [matTooltip]=\"(serviceItemGroup.dirty ? '#LDS#You have unsaved changes' : '') | translate\">\r\n        <span translate>#LDS#Heading Service Item</span>&nbsp;\r\n        <eui-icon *ngIf=\"serviceItemGroup.dirty\" icon=\"save\" class=\"imx-dirty-indicator\" size=\"s\" [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"></eui-icon>\r\n      </div>\r\n    </ng-template>\r\n    <div class=\"imx-tab-content\">\r\n      <div class=\"imx-tab-content-body\">\r\n        <div eui-sidesheet-content>\r\n          <mat-card>\r\n            <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\r\n            <form class=\"imx-service-item-form\" [formGroup]=\"serviceItemGroup\" [ngClass]=\"{ hidden: isLoading }\">\r\n              <imx-service-items-edit-form *ngIf=\"serviceItem\" [busyService]=\"busyService\" [serviceItem]=\"serviceItem\" (formControlCreated)=\"serviceItemGroup.controls.serviceItemParameter.push($event)\">\r\n              </imx-service-items-edit-form>\r\n            </form>\r\n          </mat-card>\r\n        </div>\r\n        <div eui-sidesheet-actions>\r\n          <button\r\n            mat-flat-button\r\n            color=\"primary\"\r\n            data-imx-identifier=\"service-items-edit-sidesheet-button-save\"\r\n            (click)=\"saveServiceItem()\"\r\n            [disabled]=\"isLoading || serviceItemGroup.pristine || serviceItemGroup.invalid\"\r\n          >\r\n            {{ '#LDS#Save' | translate }}\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </mat-tab>\r\n</mat-tab-group>\r\n\r\n<ng-template #productMissing> </ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;height:100%}:host .mat-tab-group{flex-grow:1;overflow:auto}:host ::ng-deep .mat-tab-body-wrapper{height:100%}:host ::ng-deep .mat-tab-body-content{display:flex;flex-direction:column}:host ::ng-deep .mat-tab-group{height:100%}:host ::ng-deep .mat-tab-group .mat-tab-header{padding:0 32px}:host .imx-tab-content{display:flex;flex-direction:column;height:100%}:host .imx-tab-content .imx-tab-content-body{flex:1 1 auto;overflow:hidden;display:flex;flex-direction:column}:host .imx-tab-content .imx-tab-content-body .mat-card{height:100%;display:flex;flex-direction:column;overflow:hidden;padding:16px}:host .imx-tab-content .imx-tab-content-body .mat-card>form{padding-right:10px;overflow:auto}:host .imx-tab-content .imx-cdr-group{flex:1 1 auto;overflow:auto;padding-right:10px}:host .hidden{display:none}:host .imx-content-card{margin:20px;display:flex;flex-direction:column;overflow:hidden}:host .imx-content-card .imx-service-item-form{display:flex;flex-direction:column;flex:1 1 auto;overflow:auto}:host .imx-tab-content .imx-action-buttons{background-color:#fff}:host .eui-sidesheet-content ::ng-deep .mat-tab-group .mat-tab-header{background-color:#fff}.eui-dark-theme :host .eui-sidesheet-content ::ng-deep .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-dark-theme :host .imx-tab-content .imx-action-buttons{background-color:#444647}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i1.CdrFactoryService }, { type: i0.ChangeDetectorRef }, { type: SoftwareService }, { type: i3.EuiSidesheetRef }, { type: i1.ConfirmationService }];
    }, null);
})();

function SoftwareComponent_imx_data_table_column_12_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r5 = ctx.$implicit;
        let tmp_0_0;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", item_r5 == null ? null : (tmp_0_0 = item_r5.GetEntity()) == null ? null : tmp_0_0.GetDisplay(), " ");
    }
}
function SoftwareComponent_imx_data_table_column_12_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-data-table-column", 11);
        i0.ɵɵtemplate(1, SoftwareComponent_imx_data_table_column_12_ng_template_1_Template, 2, 1, "ng-template");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵproperty("entityColumn", ctx_r2.entitySchema.Columns[ctx_r2.DisplayColumns.DISPLAY_PROPERTYNAME]);
    }
}
function SoftwareComponent_imx_data_table_column_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-data-table-column", 11);
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵproperty("entityColumn", ctx_r3.entitySchema.Columns.Requestable);
    }
}
const _c0 = function () { return ["search", "filter", "settings"]; };
class SoftwareComponent {
    constructor(resourceProvider, metadata, sidesheet, ldsReplace, translate) {
        this.resourceProvider = resourceProvider;
        this.metadata = metadata;
        this.sidesheet = sidesheet;
        this.ldsReplace = ldsReplace;
        this.translate = translate;
        this.DisplayColumns = DisplayColumns;
        this.busyService = new BusyService();
        this.navigationState = {};
        this.isAdmin = false;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                this.entitySchema = this.resourceProvider.getSchema(false);
                yield this.metadata.updateNonExisting(['Application']);
                this.dataModel = yield this.resourceProvider.getDataModel(undefined);
            }
            finally {
                isBusy.endBusy();
            }
            this.tablenameDisplay = this.metadata.tables['Application'].Display;
            this.displayColumns = [this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]];
            if (this.entitySchema.Columns.Requestable) {
                this.displayColumns.splice(1, 0, this.entitySchema.Columns.Requestable);
            }
            this.navigate();
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.navigate();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.navigate();
        });
    }
    showDetails(item) {
        return __awaiter(this, void 0, void 0, function* () {
            const sidesheetRef = this.sidesheet.open(SoftwareSidesheetComponent, {
                title: this.ldsReplace.transform(yield this.translate.get('#LDS#Heading Edit {0}').toPromise(), this.tablenameDisplay),
                headerColour: 'blue',
                padding: '0px',
                width: 'max(600px, 60%)',
                disableClose: true,
                testId: 'software-sidesheet',
                data: {
                    uidSoftware: item.GetEntity().GetKeys()[0],
                },
            });
            sidesheetRef.afterClosed().subscribe((result) => __awaiter(this, void 0, void 0, function* () {
                if (result) {
                    yield this.navigate();
                }
            }));
        });
    }
    navigate() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const dataSource = yield this.resourceProvider.get(this.navigationState);
                if (dataSource) {
                    this.dstSettings = {
                        dataSource: dataSource,
                        entitySchema: this.entitySchema,
                        navigationState: this.navigationState,
                        displayedColumns: this.displayColumns,
                        filters: this.dataModel.Filters,
                        dataModel: this.dataModel,
                    };
                }
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
}
SoftwareComponent.ɵfac = function SoftwareComponent_Factory(t) { return new (t || SoftwareComponent)(i0.ɵɵdirectiveInject(SoftwareService), i0.ɵɵdirectiveInject(i1.MetadataService), i0.ɵɵdirectiveInject(i3.EuiSidesheetService), i0.ɵɵdirectiveInject(i1.LdsReplacePipe), i0.ɵɵdirectiveInject(i3$1.TranslateService)); };
SoftwareComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SoftwareComponent, selectors: [["ng-component"]], inputs: { contextId: "contextId" }, decls: 15, vars: 13, consts: [[1, "imx-data-tree-container"], [1, "data-explorer-card-header"], [1, "data-explorer-card-header-bg"], [3, "contextId"], [1, "imx-card-content"], ["data-imx-identifier", "software-data-source-toolbar", 3, "settings", "busyService", "options", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], ["data-imx-identifier", "software-data-table", "detailViewVisible", "false", "mode", "manual", 3, "dst", "highlightedEntityChanged"], ["dataTable", ""], [3, "entityColumn", 4, "ngIf"], ["data-imx-identifier", "software-paginator", 3, "dst"], [3, "entityColumn"]], template: function SoftwareComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card", 0)(1, "div", 1)(2, "div", 2)(3, "h3");
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(5, "imx-help-contextual", 3);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "div", 4)(7, "imx-data-source-toolbar", 5, 6);
            i0.ɵɵlistener("navigationStateChanged", function SoftwareComponent_Template_imx_data_source_toolbar_navigationStateChanged_7_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function SoftwareComponent_Template_imx_data_source_toolbar_search_7_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "imx-data-table", 7, 8);
            i0.ɵɵlistener("highlightedEntityChanged", function SoftwareComponent_Template_imx_data_table_highlightedEntityChanged_10_listener($event) { return ctx.showDetails($event); });
            i0.ɵɵtemplate(12, SoftwareComponent_imx_data_table_column_12_Template, 2, 1, "imx-data-table-column", 9);
            i0.ɵɵtemplate(13, SoftwareComponent_imx_data_table_column_13_Template, 1, 1, "imx-data-table-column", 9);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(14, "imx-data-source-paginator", 10);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(8);
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(ctx.tablenameDisplay);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("contextId", ctx.contextId);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("busyService", ctx.busyService)("options", i0.ɵɵpureFunction0(12, _c0))("searchBoxText", i0.ɵɵpipeBind1(9, 10, "#LDS#Search"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.entitySchema);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.entitySchema && ctx.entitySchema.Columns.Requestable);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i4.NgIf, i1.DataSourceToolbarComponent, i1.DataSourcePaginatorComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i6.MatCard, i1.HelpContextualComponent, i3$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;height:100vh;overflow:hidden}imx-data-table[_ngcontent-%COMP%]{flex-grow:1}.imx-subtext[_ngcontent-%COMP%]{font-size:smaller;color:#aab0b3}.data-explorer-card-header[_ngcontent-%COMP%]{background-color:#fff;border-top-left-radius:4px;border-top-right-radius:4px;z-index:100;border:1px solid rgba(10,150,209,.6);margin-bottom:20px}.data-explorer-card-header[_ngcontent-%COMP%]   .data-explorer-card-header-bg[_ngcontent-%COMP%]{border-top-left-radius:4px;border-top-right-radius:4px;background-color:#cbe8f2;padding:10px 24px;display:flex;align-items:center;justify-content:flex-start;height:45px}.data-explorer-card-header[_ngcontent-%COMP%]   .data-explorer-card-header-bg[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{font-weight:400}.imx-page-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-data-tree-container[_ngcontent-%COMP%]{overflow:hidden;background-color:#fff;display:flex;flex-direction:column;height:100%}.imx-data-tree-container[_ngcontent-%COMP%]   .imx-create-button[_ngcontent-%COMP%]{margin-top:20px;display:flex;justify-content:flex-end}.imx-table[_ngcontent-%COMP%]{margin-top:16px}.imx-card-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.data-explorer-bottom-button-row[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:flex-end;margin-top:15px;align-self:end}.data-explorer-bottom-button-row[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:not(:last-child){margin-right:15px}.imx-row-icon[_ngcontent-%COMP%]{align-self:center;margin-right:15px;text-align:right;display:block}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-tree-container[_ngcontent-%COMP%], .eui-dark-theme   [_nghost-%COMP%]   .data-explorer-card-header-bg[_ngcontent-%COMP%]{background:#444647}.eui-dark-theme   [_nghost-%COMP%]   .data-explorer-card-header[_ngcontent-%COMP%]   .data-explorer-card-header-bg[_ngcontent-%COMP%]{background:#016b91}.hidden[_ngcontent-%COMP%]{display:none}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SoftwareComponent, [{
            type: Component,
            args: [{ template: "<mat-card class=\"imx-data-tree-container\">\r\n  <div class=\"data-explorer-card-header\">\r\n    <div class=\"data-explorer-card-header-bg\">\r\n      <h3>{{ tablenameDisplay }}</h3>\r\n      <imx-help-contextual [contextId]=\"contextId\"></imx-help-contextual>\r\n    </div>\r\n  </div>\r\n  <div class=\"imx-card-content\">\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      data-imx-identifier=\"software-data-source-toolbar\"\r\n      [settings]=\"dstSettings\"\r\n      [busyService]=\"busyService\"\r\n      [options]=\"['search', 'filter', 'settings']\"\r\n      [searchBoxText]=\"'#LDS#Search' | translate\"\r\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n      (search)=\"onSearch($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n    <imx-data-table #dataTable data-imx-identifier=\"software-data-table\" [dst]=\"dst\" detailViewVisible=\"false\" mode=\"manual\" (highlightedEntityChanged)=\"showDetails($event)\">\r\n      <imx-data-table-column *ngIf=\"entitySchema\" [entityColumn]=\"entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n        <ng-template let-item>\r\n          <div>\r\n            {{ item?.GetEntity()?.GetDisplay() }}\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-column>\r\n      <imx-data-table-column *ngIf=\"entitySchema && entitySchema.Columns.Requestable\" [entityColumn]=\"entitySchema.Columns.Requestable\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n    <imx-data-source-paginator data-imx-identifier=\"software-paginator\" [dst]=\"dst\"></imx-data-source-paginator>\r\n  </div>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;height:100vh;overflow:hidden}imx-data-table{flex-grow:1}.imx-subtext{font-size:smaller;color:#aab0b3}.data-explorer-card-header{background-color:#fff;border-top-left-radius:4px;border-top-right-radius:4px;z-index:100;border:1px solid rgba(10,150,209,.6);margin-bottom:20px}.data-explorer-card-header .data-explorer-card-header-bg{border-top-left-radius:4px;border-top-right-radius:4px;background-color:#cbe8f2;padding:10px 24px;display:flex;align-items:center;justify-content:flex-start;height:45px}.data-explorer-card-header .data-explorer-card-header-bg h3{font-weight:400}.imx-page-card{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.imx-data-tree-container{overflow:hidden;background-color:#fff;display:flex;flex-direction:column;height:100%}.imx-data-tree-container .imx-create-button{margin-top:20px;display:flex;justify-content:flex-end}.imx-table{margin-top:16px}.imx-card-content{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.data-explorer-bottom-button-row{display:flex;flex-direction:row;align-items:flex-end;margin-top:15px;align-self:end}.data-explorer-bottom-button-row>*:not(:last-child){margin-right:15px}.imx-row-icon{align-self:center;margin-right:15px;text-align:right;display:block}.eui-dark-theme :host .imx-data-tree-container,.eui-dark-theme :host .data-explorer-card-header-bg{background:#444647}.eui-dark-theme :host .data-explorer-card-header .data-explorer-card-header-bg{background:#016b91}.hidden{display:none}\n"] }]
        }], function () { return [{ type: SoftwareService }, { type: i1.MetadataService }, { type: i3.EuiSidesheetService }, { type: i1.LdsReplacePipe }, { type: i3$1.TranslateService }]; }, { contextId: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SoftwareModule {
}
SoftwareModule.ɵfac = function SoftwareModule_Factory(t) { return new (t || SoftwareModule)(); };
SoftwareModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: SoftwareModule });
SoftwareModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        CdrModule,
        DataSourceToolbarModule,
        DataTableModule,
        TranslateModule,
        ReactiveFormsModule,
        MatCardModule,
        MatButtonModule,
        EuiCoreModule,
        EuiMaterialModule,
        MatTabsModule,
        BusyIndicatorModule,
        SelectedElementsModule,
        ServiceItemsEditFormModule,
        HelpContextualModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SoftwareModule, [{
            type: NgModule,
            args: [{
                    declarations: [SoftwareComponent, SoftwareSidesheetComponent, SoftwareMembershipsComponent],
                    imports: [
                        CommonModule,
                        CdrModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        TranslateModule,
                        ReactiveFormsModule,
                        MatCardModule,
                        MatButtonModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        MatTabsModule,
                        BusyIndicatorModule,
                        SelectedElementsModule,
                        ServiceItemsEditFormModule,
                        HelpContextualModule
                    ],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(SoftwareModule, { declarations: [SoftwareComponent, SoftwareSidesheetComponent, SoftwareMembershipsComponent], imports: [CommonModule,
            CdrModule,
            DataSourceToolbarModule,
            DataTableModule,
            TranslateModule,
            ReactiveFormsModule,
            MatCardModule,
            MatButtonModule,
            EuiCoreModule,
            EuiMaterialModule,
            MatTabsModule,
            BusyIndicatorModule,
            SelectedElementsModule,
            ServiceItemsEditFormModule,
            HelpContextualModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    constructor(router, myResponsibilitiesRegistryService) {
        this.router = router;
        this.myResponsibilitiesRegistryService = myResponsibilitiesRegistryService;
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.setupMyResponsibilitiesView();
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMyResponsibilitiesView() {
        this.myResponsibilitiesRegistryService.registerFactory((preProps, groups) => ({
            instance: SoftwareComponent,
            sortOrder: 10,
            name: 'Application',
            caption: '#LDS#Software',
            data: {
                TableName: 'Application',
                Count: 0,
            },
            contextId: HELP_CONTEXTUAL.MyResponsibilitiesApplication
        }));
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i1$2.Router), i0.ɵɵinject(i1$1.MyResponsibilitiesRegistryService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i1$2.Router }, { type: i1$1.MyResponsibilitiesRegistryService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [{
        path: 'resp/Application',
        component: SoftwareComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService],
    },
];
class ApcConfigModule {
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 APC loaded');
        this.initializer.onInit(routes);
        console.log('▶️ APC initialized');
    }
}
ApcConfigModule.ɵfac = function ApcConfigModule_Factory(t) { return new (t || ApcConfigModule)(i0.ɵɵinject(InitService)); };
ApcConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ApcConfigModule });
ApcConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [RouterModule.forChild(routes),
        SoftwareModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApcConfigModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule.forChild(routes),
                        SoftwareModule
                    ]
                }]
        }], function () { return [{ type: InitService }]; }, null);
})();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ApcConfigModule, { imports: [i1$2.RouterModule, SoftwareModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of apc
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApcConfigModule };
//# sourceMappingURL=apc.mjs.map
