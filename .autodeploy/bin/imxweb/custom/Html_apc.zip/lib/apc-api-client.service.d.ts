import { V2Client, TypedClient } from 'imx-api-apc';
import { AppConfigService, ClassloggerService, ImxTranslationProviderService } from 'qbm';
import * as i0 from "@angular/core";
export declare class ApcApiService {
    private readonly logger;
    private readonly translationProvider;
    private tc;
    get typedClient(): TypedClient;
    private c;
    get client(): V2Client;
    constructor(config: AppConfigService, logger: ClassloggerService, translationProvider: ImxTranslationProviderService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ApcApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApcApiService>;
}
