import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/router";
import * as i2 from "./software/software.module";
export declare class ApcConfigModule {
    private readonly initializer;
    constructor(initializer: InitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ApcConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ApcConfigModule, never, [typeof i1.RouterModule, typeof i2.SoftwareModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ApcConfigModule>;
}
