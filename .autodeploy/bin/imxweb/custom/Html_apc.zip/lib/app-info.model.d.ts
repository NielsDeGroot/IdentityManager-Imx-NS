import { EntitySchema, DataModel, FilterData } from 'imx-qbm-dbts';
export interface ResourceDataModel {
    getModel(filter: FilterData[]): Promise<DataModel>;
}
export interface ResourceInfo {
    table: string;
    caption?: string;
    admin?: ResourceInfoApiWrapper;
    resp?: ResourceInfoApiWrapper;
    accProduct?: any;
}
export interface ResourceInfoApiWrapper {
    get?: any;
    type?: any;
    schema?: EntitySchema;
    dataModel?: any;
    interactive?: any;
}
