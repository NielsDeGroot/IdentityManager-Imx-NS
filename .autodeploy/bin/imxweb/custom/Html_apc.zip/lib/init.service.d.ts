import { Router, Route } from '@angular/router';
import { MyResponsibilitiesRegistryService } from 'qer';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly router;
    private readonly myResponsibilitiesRegistryService;
    constructor(router: Router, myResponsibilitiesRegistryService: MyResponsibilitiesRegistryService);
    onInit(routes: Route[]): void;
    private addRoutes;
    private setupMyResponsibilitiesView;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
