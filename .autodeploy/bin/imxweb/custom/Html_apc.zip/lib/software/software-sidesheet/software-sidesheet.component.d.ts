import { ChangeDetectorRef, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormArray, FormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { IEntityColumn, TypedEntity } from 'imx-qbm-dbts';
import { CdrFactoryService, ColumnDependentReference, ConfirmationService } from 'qbm';
import { SoftwareService } from '../software.service';
import * as i0 from "@angular/core";
/**
 * internal interface for the main form
 */
interface ServiceItemGroup {
    serviceItemParameter: UntypedFormArray;
}
/**
 * internal interface for the service item form
 */
interface SoftwareFormGroup {
    array: UntypedFormArray;
}
export declare class SoftwareSidesheetComponent implements OnInit, OnDestroy {
    readonly data: {
        uidSoftware: string;
    };
    private cdrFactory;
    private readonly changeDetector;
    private readonly softwareService;
    cdrList: ColumnDependentReference[];
    softwareFormGroup: FormGroup<SoftwareFormGroup>;
    serviceItemGroup: FormGroup<ServiceItemGroup>;
    isLoading: boolean;
    serviceItem: TypedEntity;
    get withProduct(): boolean;
    get productColumn(): IEntityColumn | undefined;
    private subscriptions;
    private entity;
    private editableFields;
    private busyService;
    constructor(data: {
        uidSoftware: string;
    }, cdrFactory: CdrFactoryService, changeDetector: ChangeDetectorRef, softwareService: SoftwareService, sidesheetRef: EuiSidesheetRef, confirmation: ConfirmationService);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    /**
     * Saves the main data and reloads the form for further editing
     */
    submit(): Promise<void>;
    /**
     * Saves the service item and reloads the form for further editing
     */
    saveServiceItem(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SoftwareSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SoftwareSidesheetComponent, "ng-component", never, {}, {}, never, never, false>;
}
export {};
