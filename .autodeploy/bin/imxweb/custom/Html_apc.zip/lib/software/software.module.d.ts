import * as i0 from "@angular/core";
import * as i1 from "./software.component";
import * as i2 from "./software-sidesheet/software-sidesheet.component";
import * as i3 from "./software-sidesheet/software-memberships/software-memberships.component";
import * as i4 from "@angular/common";
import * as i5 from "qbm";
import * as i6 from "@ngx-translate/core";
import * as i7 from "@angular/forms";
import * as i8 from "@angular/material/card";
import * as i9 from "@angular/material/button";
import * as i10 from "@elemental-ui/core";
import * as i11 from "@angular/material/tabs";
import * as i12 from "qer";
export declare class SoftwareModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SoftwareModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SoftwareModule, [typeof i1.SoftwareComponent, typeof i2.SoftwareSidesheetComponent, typeof i3.SoftwareMembershipsComponent], [typeof i4.CommonModule, typeof i5.CdrModule, typeof i5.DataSourceToolbarModule, typeof i5.DataTableModule, typeof i6.TranslateModule, typeof i7.ReactiveFormsModule, typeof i8.MatCardModule, typeof i9.MatButtonModule, typeof i10.EuiCoreModule, typeof i10.EuiMaterialModule, typeof i11.MatTabsModule, typeof i5.BusyIndicatorModule, typeof i5.SelectedElementsModule, typeof i12.ServiceItemsEditFormModule, typeof i5.HelpContextualModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SoftwareModule>;
}
