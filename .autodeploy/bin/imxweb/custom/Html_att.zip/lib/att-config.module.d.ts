import { ClassloggerService } from 'qbm';
import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "./dashboard-plugin/dashboard-plugin.component";
import * as i2 from "@angular/common";
import * as i3 from "qer";
import * as i4 from "./decision/attestation-decision.module";
import * as i5 from "@angular/router";
import * as i6 from "./runs/attestation-runs.module";
import * as i7 from "@angular/material/icon";
import * as i8 from "@angular/material/list";
import * as i9 from "@ngx-translate/core";
import * as i10 from "@elemental-ui/core";
export declare class AttConfigModule {
    private readonly initializer;
    private readonly logger;
    constructor(initializer: InitService, logger: ClassloggerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AttConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AttConfigModule, [typeof i1.DashboardPluginComponent], [typeof i2.CommonModule, typeof i3.TilesModule, typeof i4.AttestationDecisionModule, typeof i5.RouterModule, typeof i6.AttestationRunsModule, typeof i7.MatIconModule, typeof i8.MatListModule, typeof i9.TranslateModule, typeof i10.EuiCoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AttConfigModule>;
}
