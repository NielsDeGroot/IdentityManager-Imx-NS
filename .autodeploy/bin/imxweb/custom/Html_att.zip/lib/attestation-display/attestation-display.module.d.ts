import * as i0 from "@angular/core";
import * as i1 from "./attestation-display.component";
import * as i2 from "@angular/common";
import * as i3 from "qbm";
export declare class AttestationDisplayModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationDisplayModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AttestationDisplayModule, [typeof i1.AttestationDisplayComponent], [typeof i2.CommonModule, typeof i3.ParameterizedTextModule], [typeof i1.AttestationDisplayComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AttestationDisplayModule>;
}
