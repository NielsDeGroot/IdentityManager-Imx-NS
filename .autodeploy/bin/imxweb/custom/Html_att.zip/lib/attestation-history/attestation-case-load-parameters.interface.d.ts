import { CollectionLoadParameters, FilterData } from 'imx-qbm-dbts';
export interface AttestationCaseLoadParameters extends CollectionLoadParameters {
    by?: string;
    def?: string;
    objecttable?: string;
    objectuid?: string;
    uidpolicy?: string;
    groupFilter?: FilterData[];
    state?: string;
    attestationtype?: string;
    type?: string;
    risk?: string;
    uid_persondecision?: string;
}
