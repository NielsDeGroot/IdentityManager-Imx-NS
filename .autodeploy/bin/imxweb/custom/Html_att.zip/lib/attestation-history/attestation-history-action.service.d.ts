import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { AttestationCaseData, PortalAttestationCase } from 'imx-api-att';
import { IReadValue } from 'imx-qbm-dbts';
import { EntityService, SnackBarService } from 'qbm';
import { AttestationCasesService } from '../decision/attestation-cases.service';
import { AttestationActionService } from '../attestation-action/attestation-action.service';
import { AttestationCaseAction } from '../attestation-action/attestation-case-action.interface';
import * as i0 from "@angular/core";
export declare class AttestationHistoryActionService {
    private readonly attestationCasesService;
    private readonly sidesheet;
    private readonly busyService;
    private readonly translate;
    private readonly snackBar;
    private readonly entityService;
    private readonly action;
    readonly applied: Subject<unknown>;
    constructor(attestationCasesService: AttestationCasesService, sidesheet: EuiSidesheetService, busyService: EuiLoadingService, translate: TranslateService, snackBar: SnackBarService, entityService: EntityService, action: AttestationActionService);
    canDecide(attestationCase: {
        DecisionLevel: IReadValue<number>;
        UID_QERWorkingMethod: IReadValue<string>;
        data: AttestationCaseData;
    }, userUid: string): boolean;
    approve(attestationCases: AttestationCaseAction[], isEscalation: boolean): Promise<void>;
    deny(attestationCases: AttestationCaseAction[], isEscalation: boolean): Promise<void>;
    revokeAdditional(attestationCases: PortalAttestationCase[]): Promise<void>;
    recallDecision(attestationCases: PortalAttestationCase[]): Promise<void>;
    private editAction;
    private createCdrReason;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AttestationHistoryActionService>;
}
