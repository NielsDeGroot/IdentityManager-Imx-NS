import { OnDestroy } from '@angular/core';
import { EuiDownloadOptions, EuiSidesheetRef, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PortalAttestationCaseHistory } from 'imx-api-att';
import { AuthenticationService, ColumnDependentReference } from 'qbm';
import { Approvers } from '../../decision/approvers.interface';
import { AttestationHistoryActionService } from '../attestation-history-action.service';
import { AttestationHistoryCase } from '../attestation-history-case';
import { AttestationCasesService } from '../../decision/attestation-cases.service';
import * as i0 from "@angular/core";
export declare class AttestationHistoryDetailsComponent implements OnDestroy {
    private readonly sideSheet;
    private readonly translate;
    private readonly sideSheetRef;
    readonly attestationAction: AttestationHistoryActionService;
    private readonly attestationCasesService;
    get canDecide(): boolean;
    get allowedActionCount(): number;
    userUid: string;
    readonly case: AttestationHistoryCase;
    readonly approvers: Approvers;
    readonly workflowHistoryData: PortalAttestationCaseHistory[];
    readonly parameters: ColumnDependentReference[];
    readonly propertyInfo: ColumnDependentReference[];
    readonly reportType: string;
    readonly reportDownload: EuiDownloadOptions;
    readonly showApprovalActions: boolean;
    private readonly subscriptions;
    constructor(data: {
        case: AttestationHistoryCase;
        approvers: Approvers;
        showApprovalActions: boolean;
    }, sideSheet: EuiSidesheetService, translate: TranslateService, sideSheetRef: EuiSidesheetRef, attestationAction: AttestationHistoryActionService, attestationCasesService: AttestationCasesService, authentication: AuthenticationService);
    ngOnDestroy(): void;
    viewSource(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationHistoryDetailsComponent, "imx-attestation-history-details", never, {}, {}, never, never, false>;
}
