import { EventEmitter, OnInit } from '@angular/core';
import { PortalPersonAll } from 'imx-api-qer';
import { PersonService } from 'qer';
import { ColumnDependentReference, DataSourceToolbarComponent, DataSourceToolbarSelectedFilter, EntityService } from 'qbm';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class AttestationHistoryFilterComponent implements OnInit {
    private entityService;
    private translator;
    private person;
    dst: DataSourceToolbarComponent;
    selectedFiltersChanged: EventEmitter<string>;
    personData: PortalPersonAll[];
    selectedUid: string;
    dstFilterRef: DataSourceToolbarSelectedFilter;
    identityCdr: ColumnDependentReference;
    private skipSelectionEmitMode;
    constructor(entityService: EntityService, translator: TranslateService, person: PersonService);
    ngOnInit(): Promise<void>;
    updateSelectedEntity(): void;
    clearPersonFilterSelection(clearSelectControl?: boolean): Promise<void>;
    onCustomFilterClearedExternally(filter: DataSourceToolbarSelectedFilter): void;
    private createCdrPerson;
    private clearDstSelectedFilter;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationHistoryFilterComponent, "imx-attestation-history-filter", never, { "dst": "dst"; }, { "selectedFiltersChanged": "selectedFiltersChanged"; }, never, never, false>;
}
