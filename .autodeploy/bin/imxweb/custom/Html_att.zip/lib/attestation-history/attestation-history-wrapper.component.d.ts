import { OnDestroy } from '@angular/core';
import { AuthenticationService } from 'qbm';
import { AttestationHistoryActionService } from './attestation-history-action.service';
import { AttestationHistoryCase } from './attestation-history-case';
import * as i0 from "@angular/core";
export declare class AttestationHistoryWrapperComponent implements OnDestroy {
    readonly attestationAction: AttestationHistoryActionService;
    get canPerformActions(): boolean;
    get canWithdrawDelegation(): boolean;
    get canRecallDecision(): boolean;
    selectedCases: AttestationHistoryCase[];
    private userUid;
    private readonly subscriptions;
    constructor(attestationAction: AttestationHistoryActionService, authentication: AuthenticationService);
    ngOnDestroy(): void;
    onSelectionChanged(items: AttestationHistoryCase[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationHistoryWrapperComponent, "imx-attestation-history-wrapper", never, {}, {}, never, never, false>;
}
