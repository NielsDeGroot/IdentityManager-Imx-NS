import { DataModel, ExtendedTypedEntityCollection, FilterData, GroupInfoData, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { AttCaseDataRead, PortalAttestationCase } from 'imx-api-att';
import { ParameterDataService } from 'qer';
import { ApiService } from '../api.service';
import { AttestationHistoryCase } from './attestation-history-case';
import { AttestationCaseLoadParameters } from './attestation-case-load-parameters.interface';
import { DataSourceToolbarExportMethod } from 'qbm';
import * as i0 from "@angular/core";
export declare class AttestationHistoryService {
    private readonly attClient;
    private readonly parameterDataService;
    abortController: AbortController;
    constructor(attClient: ApiService, parameterDataService: ParameterDataService);
    get(parameters: AttestationCaseLoadParameters): Promise<ExtendedTypedEntityCollection<PortalAttestationCase, AttCaseDataRead>>;
    getAttestations(loadParameters?: AttestationCaseLoadParameters): Promise<TypedEntityCollectionData<AttestationHistoryCase> | undefined>;
    exportAttestation(loadParameters: AttestationCaseLoadParameters): DataSourceToolbarExportMethod;
    getDataModel(objecttable?: string, objectuid?: string, groupFilter?: FilterData[]): Promise<DataModel>;
    getGroupInfo(parameters?: AttestationCaseLoadParameters): Promise<GroupInfoData>;
    abortCall(): void;
    private getParameterCandidates;
    private getFilterTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationHistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AttestationHistoryService>;
}
