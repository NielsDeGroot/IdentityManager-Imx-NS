import { OnInit } from '@angular/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { AttestationSnapshotData } from 'imx-api-att';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class AttestationSnapshotComponent implements OnInit {
    private readonly attApi;
    private readonly busy;
    snapshot: AttestationSnapshotData;
    uidCase: string;
    date: string;
    constructor(attApi: ApiService, busy: EuiLoadingService);
    ngOnInit(): Promise<void>;
    get attestationDate(): string;
    /**
     * Ordering Objects array by Display (if Displays are equal, then by TableDisplay) in ascending order
     */
    private sortObjectsByDisplay;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationSnapshotComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationSnapshotComponent, "imx-attestation-snapshot", never, { "uidCase": "uidCase"; "date": "date"; }, {}, never, never, false>;
}
