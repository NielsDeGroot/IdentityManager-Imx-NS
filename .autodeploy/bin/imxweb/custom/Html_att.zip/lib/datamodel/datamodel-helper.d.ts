import { CollectionLoadParameters, DataModel, GroupInfoData } from 'imx-qbm-dbts';
import { DataSourceToolbarGroupData } from 'qbm';
export declare function createGroupData(dataModel: DataModel, getGroupInfo: (parameters: {
    by?: string;
    def?: string;
} & CollectionLoadParameters) => Promise<GroupInfoData>, disableGroupingFor: string[]): DataSourceToolbarGroupData;
