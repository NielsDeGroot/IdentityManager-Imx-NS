import { EntityData } from 'imx-qbm-dbts';
export interface Approvers {
    current: EntityData[];
    future: EntityData[];
    canSeeSteps: boolean;
}
