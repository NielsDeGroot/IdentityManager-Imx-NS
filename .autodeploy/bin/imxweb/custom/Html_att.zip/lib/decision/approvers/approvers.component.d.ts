import { Approvers } from '../approvers.interface';
import * as i0 from "@angular/core";
export declare class ApproversComponent {
    approvers: Approvers;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApproversComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApproversComponent, "imx-approvers", never, { "approvers": "approvers"; }, {}, never, never, false>;
}
