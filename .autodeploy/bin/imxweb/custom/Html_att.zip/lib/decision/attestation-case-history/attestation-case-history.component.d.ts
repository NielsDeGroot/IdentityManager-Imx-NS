import { OnInit } from '@angular/core';
import { BusyService, DataSourceToolbarSettings } from 'qbm';
import { CollectionLoadParameters, EntitySchema, IClientProperty, TypedEntity } from 'imx-qbm-dbts';
import { AttestationCaseHistoryService } from './attestation-case-history.service';
import { PortalAttestationCase } from 'imx-api-att';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { AttestationHistoryService } from '../../attestation-history/attestation-history.service';
import { TranslateService } from '@ngx-translate/core';
import { AttestationCasesService } from '../attestation-cases.service';
import * as i0 from "@angular/core";
export declare class AttestationCaseHistoryComponent implements OnInit {
    private readonly attestationCaseHistoryService;
    private readonly busyServiceElemental;
    private readonly historyService;
    private readonly sideSheet;
    private readonly translator;
    private readonly attestationCaseService;
    case: PortalAttestationCase;
    dstSettings: DataSourceToolbarSettings;
    busyService: BusyService;
    entitySchema: EntitySchema;
    navigationState: CollectionLoadParameters;
    displayedColumns: IClientProperty[];
    constructor(attestationCaseHistoryService: AttestationCaseHistoryService, busyServiceElemental: EuiLoadingService, historyService: AttestationHistoryService, sideSheet: EuiSidesheetService, translator: TranslateService, attestationCaseService: AttestationCasesService);
    ngOnInit(): Promise<void>;
    /**
     * Updates the navigation state and reloads the data.
     * @param navigationState reloads data based on the new navigation state
     */
    onNavigationStateChanged(navigationState: CollectionLoadParameters): Promise<void>;
    /**
     * Searches attestation cases based on the provided keywords.
     * @param keywords The search keywords entered by the user
     */
    onSearch(keywords: string): Promise<void>;
    /**
     * Shows the details of the selected attestation case in a side sheet
     * @param selectedItem The item, that was selected from the table
     */
    onHighlightedEntityChanged(selectedItem: TypedEntity): Promise<void>;
    private getData;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationCaseHistoryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationCaseHistoryComponent, "imx-attestation-case-history", never, { "case": "case"; }, {}, never, never, false>;
}
