import { PortalAttestationCase } from 'imx-api-att';
import { CollectionLoadParameters, ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { AttestationHistoryCase } from '../../attestation-history/attestation-history-case';
import { AttestationHistoryService } from '../../attestation-history/attestation-history.service';
import * as i0 from "@angular/core";
export declare class AttestationCaseHistoryService {
    private attestationHistoryService;
    constructor(attestationHistoryService: AttestationHistoryService);
    /**
     * Gets attestation cases for the given attestation case's policy and object key, excluding the given attestation case itself
     * @param state The collection load parameters
     */
    getAttestationCasesForDecision(state: CollectionLoadParameters, attestationCase: PortalAttestationCase): Promise<ExtendedTypedEntityCollection<AttestationHistoryCase, unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationCaseHistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AttestationCaseHistoryService>;
}
