import { AttCaseDataRead, AttestationCaseData, AttestationCaseUiData, PortalAttestationApprove } from 'imx-api-att';
import { IEntity, IEntityColumn, TypedEntity } from 'imx-qbm-dbts';
import { ParameterDataContainer } from 'qer';
import { ColumnDependentReference } from 'qbm';
import { AttestationCaseAction } from '../attestation-action/attestation-case-action.interface';
export declare class AttestationCase extends PortalAttestationApprove implements AttestationCaseAction {
    private readonly baseObject;
    private readonly parameterDataContainer;
    get decisionOffset(): number;
    get isOverdue(): boolean;
    get attestationParameters(): IEntityColumn[];
    get canAskAQuestion(): boolean;
    readonly propertyInfo: ColumnDependentReference[];
    readonly key: string;
    readonly data: AttestationCaseData;
    readonly typedEntity: TypedEntity;
    readonly propertiesForAction: IEntityColumn[];
    readonly uiData: AttestationCaseUiData;
    get hasPolicyViolation(): boolean;
    private directDecisionTarget;
    private readonly workflowWrapper;
    /**
     * Data representation of an attestation case
     * @param baseObject object that is being attested
     * @param isUserEscalationApprover flag to indicate if this object is seen by a user that has escalated approval perms
     * @param parameterDataContainer additional data for filtering
     * @param extendedCollectionData extended data
     */
    constructor(baseObject: PortalAttestationApprove, parameterDataContainer: ParameterDataContainer, extendedCollectionData: {
        index: number;
    } & AttCaseDataRead);
    updateDirectDecisionTarget(workflow: IEntity): void;
    commit(reload?: boolean): Promise<void>;
    canDenyApproval(userUid: string): boolean;
    getLevelNumbers(userUid: string): number[];
    canRerouteDecision(userUid: string): boolean;
    canAddApprover(userUid: string): boolean;
    get hasOpenQuestions(): boolean;
    canDelegateDecision(userUid: string): boolean;
    hasAskedLastQuestion(userUid: string): boolean;
    canWithdrawAddApprover(userUid: string): boolean;
    canEscalateDecision(userUid: string): boolean;
}
