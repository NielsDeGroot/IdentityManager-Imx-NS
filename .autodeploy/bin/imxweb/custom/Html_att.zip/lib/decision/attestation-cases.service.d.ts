import { EuiDownloadOptions } from '@elemental-ui/core';
import { AttestationCaseData, DecisionInput, DenyDecisionInput, DirectDecisionInput, EntitlementLossDto, OtherApproverInput, PortalAttestationApprove, PortalAttestationCaseHistory, PwoQueryInput, ReasonInput } from 'imx-api-att';
import { CollectionLoadParameters, DataModel, EntitySchema, GroupInfoData, IReadValue, TypedEntity, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { AppConfigService, DataSourceToolbarExportMethod, ElementalUiConfigService } from 'qbm';
import { ParameterDataService } from 'qer';
import { ApiService } from '../api.service';
import { AttestationCaseLoadParameters } from '../attestation-history/attestation-case-load-parameters.interface';
import { Approvers } from './approvers.interface';
import { AttestationCase } from './attestation-case';
import { AttestationDecisionLoadParameters } from './attestation-decision-load-parameters';
import * as i0 from "@angular/core";
export declare class AttestationCasesService {
    private readonly attClient;
    private readonly parameterDataService;
    private readonly elementalUiConfigService;
    private readonly config;
    isChiefApproval: boolean;
    abortController: AbortController;
    private readonly historyBuilder;
    private readonly apiClientMethodFactory;
    constructor(attClient: ApiService, parameterDataService: ParameterDataService, elementalUiConfigService: ElementalUiConfigService, config: AppConfigService);
    get attestationApproveSchema(): EntitySchema;
    get attestationCaseSchema(): EntitySchema;
    get(attDecisionParameters?: AttestationDecisionLoadParameters, signal?: AbortSignal): Promise<TypedEntityCollectionData<AttestationCase>>;
    exportData(attDecisionParameters: AttestationDecisionLoadParameters): DataSourceToolbarExportMethod;
    getNumberOfPending(parameters: AttestationCaseLoadParameters): Promise<number>;
    getDataModel(): Promise<DataModel>;
    getGroupInfo(parameters?: {
        by?: string;
        def?: string;
    } & CollectionLoadParameters): Promise<GroupInfoData>;
    getApprovers(attestationCase: TypedEntity & {
        DecisionLevel: IReadValue<number>;
        UID_QERWorkingMethod: IReadValue<string>;
        data: AttestationCaseData;
    }): Promise<Approvers>;
    createHistoryTypedEntities(data: AttestationCaseData): TypedEntityCollectionData<PortalAttestationCaseHistory>;
    getLossPreviewEntities(attestationCase: AttestationCase): Promise<EntitlementLossDto[]>;
    getReportDownloadOptions(attestationCase: TypedEntity): EuiDownloadOptions;
    /**
     * Approve or deny the attestation case
     * @param attestationCase The attestation case
     * @param input reason and/or standard reason
     */
    makeDecision(attestationCase: PortalAttestationApprove, input: DecisionInput): Promise<any>;
    /**
     * Entscheidungsworkflow auf einen bestimmten Schritt setzen
     * @param attestationCase The attestation case
     * @param input reason and/or standard reason
     */
    directDecision(attestationCase: PortalAttestationApprove, input: DirectDecisionInput): Promise<any>;
    escalateDecision(attestationCase: PortalAttestationApprove, input: ReasonInput): Promise<any>;
    /**
     * Eine andere Person zusätzlich zur mir zur Entscheidung berechtigen
     * @param attestationCase The attestation case
     * @param input reason and/or standard reason
     */
    addAdditional(attestationCase: PortalAttestationApprove, input: OtherApproverInput): Promise<any>;
    /**
     * Eine andere Person an meiner Stelle (ersetzend) zur Entscheidung berechtigen
     * @param attestationCase The attestation case
     * @param input reason and/or standard reason
     */
    addInsteadOf(attestationCase: PortalAttestationApprove, input: OtherApproverInput): Promise<any>;
    /**
     * Zurücknehmen von AddAdditional oder AddInsteadOf
     * @param attestationCase The attestation case
     * @param input reason and/or standard reason
     */
    revokeDelegation(attestationCase: TypedEntity, input: ReasonInput): Promise<any>;
    askForHelp(attestationCase: PortalAttestationApprove, para: PwoQueryInput): Promise<void>;
    recallInquiry(attestationCase: PortalAttestationApprove, reason: ReasonInput): Promise<void>;
    resetReservation(attestationCase: PortalAttestationApprove, reason: ReasonInput): Promise<void>;
    /**
     *
     * @param attestation The case which should be answered to
     * @param answerInput the text for reasoning
     */
    answerQuestion(attestation: PortalAttestationApprove, answerInput: string): Promise<void>;
    /**
     * Zurücknehmen von AddAdditional oder AddInsteadOf
     * @param attestationCase The attestation case
     * @param input reason and/or standard reason
     */
    revokeAdditional(attestationCase: TypedEntity, input: ReasonInput): Promise<any>;
    /**
     * Zurücknehmen einer gestellten Frage
     * @param attestationCase The attestation case
     * @param input reason and/or standard reason
     */
    recallDecision(attestationCase: TypedEntity, input: ReasonInput): Promise<any>;
    /**
     * Die Entscheidung verweigern
     * @param attestationCase The attestation case
     * @param input reason and/or standard reason
     */
    denyDecision(attestationCase: PortalAttestationApprove, input: DenyDecisionInput): Promise<any>;
    abortCall(): void;
    private getKey;
    private getParameterCandidates;
    private getFilterTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationCasesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AttestationCasesService>;
}
