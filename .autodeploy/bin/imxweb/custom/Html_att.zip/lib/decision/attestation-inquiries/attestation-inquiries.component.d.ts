import { OnDestroy, OnInit } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PwoExtendedData, ViewConfigData } from 'imx-api-qer';
import { ExtendedTypedEntityCollection, EntitySchema, CollectionLoadParameters } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings, AuthenticationService, SettingsService, UserMessageService, BusyService } from 'qbm';
import { AttestationCase } from '../attestation-case';
import { AttestationCasesService } from '../attestation-cases.service';
import { AttestationActionService } from '../../attestation-action/attestation-action.service';
import { AttestationFeatureGuardService } from '../../attestation-feature-guard.service';
import { LossPreview } from '../loss-preview.interface';
import { AttestationInquiry } from './attestation-inquiry.model';
import { ViewConfigService } from 'qer';
import * as i0 from "@angular/core";
export declare class AttestationInquiriesComponent implements OnInit, OnDestroy {
    readonly actionService: AttestationActionService;
    private readonly attestationCasesService;
    private readonly attFeatureService;
    private viewConfigService;
    private readonly sidesheet;
    private readonly messageService;
    private readonly busyServiceElemental;
    private readonly translate;
    dstSettings: DataSourceToolbarSettings;
    readonly entitySchema: EntitySchema;
    attestationCasesCollection: ExtendedTypedEntityCollection<AttestationCase, PwoExtendedData>;
    hasData: boolean;
    isUserEscalationApprover: boolean;
    mitigatingControlsPerViolation: boolean;
    private readonly table;
    lossPreview: LossPreview;
    private navigationState;
    private displayedColumns;
    private readonly subscriptions;
    private dataModel;
    private viewConfig;
    private viewConfigPath;
    userUid: string;
    AttestationInquiry: typeof AttestationInquiry;
    busyService: BusyService;
    constructor(actionService: AttestationActionService, attestationCasesService: AttestationCasesService, attFeatureService: AttestationFeatureGuardService, viewConfigService: ViewConfigService, sidesheet: EuiSidesheetService, messageService: UserMessageService, busyServiceElemental: EuiLoadingService, translate: TranslateService, settingsService: SettingsService, authentication: AuthenticationService);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    getData(parameters?: CollectionLoadParameters, isInitialLoad?: boolean): Promise<void>;
    updateConfig(config: ViewConfigData): Promise<void>;
    deleteConfigById(id: string): Promise<void>;
    /**
     * Occurs when user clicks the edit button for a request
     *
     * @param pwo Selected PortalItshopApproveRequests.
     */
    editCase(attestationCase: AttestationCase): Promise<void>;
    getInquiryText(pwo: AttestationCase): string;
    getInquirer(pwo: AttestationCase): string;
    getQueryDate(pwo: AttestationCase): Date;
    onSearch(keywords: string): Promise<void>;
    private updateTable;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationInquiriesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationInquiriesComponent, "imx-attestation-inquiries", never, {}, {}, never, never, false>;
}
