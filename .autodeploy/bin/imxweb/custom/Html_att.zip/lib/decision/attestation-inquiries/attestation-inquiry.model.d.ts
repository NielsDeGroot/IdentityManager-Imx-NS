export declare class AttestationInquiry {
    static headCaption: string;
    static queryCaption: string;
    static queryDate: string;
}
