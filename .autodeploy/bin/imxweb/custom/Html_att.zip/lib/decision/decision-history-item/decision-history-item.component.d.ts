import { PortalAttestationCaseHistory } from 'imx-api-att';
import { DecisionHistoryService } from 'qer';
import * as i0 from "@angular/core";
export declare class DecisionHistoryItemComponent {
    readonly decisionHistory: DecisionHistoryService;
    workflowHistoryEntity: PortalAttestationCaseHistory;
    constructor(decisionHistory: DecisionHistoryService);
    static ɵfac: i0.ɵɵFactoryDeclaration<DecisionHistoryItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DecisionHistoryItemComponent, "imx-decision-history-item", never, { "workflowHistoryEntity": "workflowHistoryEntity"; }, {}, never, never, false>;
}
