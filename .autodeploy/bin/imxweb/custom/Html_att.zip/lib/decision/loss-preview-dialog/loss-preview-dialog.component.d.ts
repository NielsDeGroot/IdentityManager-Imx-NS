import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { LossPreview } from '../loss-preview.interface';
import * as i0 from "@angular/core";
export declare class LossPreviewDialogComponent implements OnInit {
    dialogRef: MatDialogRef<LossPreviewDialogComponent>;
    readonly data: LossPreview;
    lossPreview: LossPreview;
    constructor(dialogRef: MatDialogRef<LossPreviewDialogComponent>, data: LossPreview);
    ngOnInit(): void;
    onDeny(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LossPreviewDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LossPreviewDialogComponent, "imx-loss-preview-dialog", never, {}, {}, never, never, false>;
}
