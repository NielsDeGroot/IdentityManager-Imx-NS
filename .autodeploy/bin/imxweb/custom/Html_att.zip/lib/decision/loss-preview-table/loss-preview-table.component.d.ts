import { OnInit } from '@angular/core';
import { EntitlementLossDto } from 'imx-api-att';
import { LossPreview } from '../loss-preview.interface';
import { AttestationCasesService } from '../attestation-cases.service';
import * as i0 from "@angular/core";
export declare class LossPreviewTableComponent implements OnInit {
    private caseService;
    lossPreview: LossPreview;
    showTitle: boolean;
    isLoading: boolean;
    lossPreviewItems: EntitlementLossDto[];
    lossPreviewHeaders: string[];
    lossPreviewDisplayKeys: EntitlementLossDto;
    constructor(caseService: AttestationCasesService);
    ngOnInit(): Promise<void>;
    loadData(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LossPreviewTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LossPreviewTableComponent, "imx-loss-preview-table", never, { "lossPreview": "lossPreview"; "showTitle": "showTitle"; }, {}, never, never, false>;
}
