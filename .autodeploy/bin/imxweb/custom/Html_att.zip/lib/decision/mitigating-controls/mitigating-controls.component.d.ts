import { UntypedFormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { IEntityColumn } from 'imx-qbm-dbts';
import { ColumnDependentReference } from 'qbm';
import * as i0 from "@angular/core";
export declare class MitigatingControlsComponent {
    readonly data: {
        column: IEntityColumn;
    };
    dialogRef: MatDialogRef<MitigatingControlsComponent>;
    mitigatingControlCdr: ColumnDependentReference;
    formGroup: UntypedFormGroup;
    constructor(data: {
        column: IEntityColumn;
    }, dialogRef: MatDialogRef<MitigatingControlsComponent>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MitigatingControlsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MitigatingControlsComponent, "imx-mitigating-controls", never, {}, {}, never, never, false>;
}
