import { OnChanges, SimpleChanges } from '@angular/core';
import { EntityValue } from 'imx-qbm-dbts';
import { ColumnDependentReference } from 'qbm';
import * as i0 from "@angular/core";
export declare class EntityPropertyEditorComponent implements OnChanges {
    cdr: ColumnDependentReference;
    property: EntityValue<any>;
    hideIfEmpty: boolean;
    caption: string;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityPropertyEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EntityPropertyEditorComponent, "imx-entity-property-editor", never, { "property": "property"; "hideIfEmpty": "hideIfEmpty"; "caption": "caption"; }, {}, never, never, false>;
}
