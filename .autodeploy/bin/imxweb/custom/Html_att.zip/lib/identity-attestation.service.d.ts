import { Subject } from 'rxjs';
import { AttestationHistoryService } from './attestation-history/attestation-history.service';
import { AttestationCasesService } from './decision/attestation-cases.service';
import { AttestationHistoryActionService } from './attestation-history/attestation-history-action.service';
import { AttestationCaseLoadParameters } from './attestation-history/attestation-case-load-parameters.interface';
import { ObjectAttestationStatistics } from 'qer';
import * as i0 from "@angular/core";
export declare class IdentityAttestationService {
    private readonly attestationHistory;
    private readonly attestationApprove;
    private readonly attestationAction;
    get applied(): Subject<any>;
    constructor(attestationHistory: AttestationHistoryService, attestationApprove: AttestationCasesService, attestationAction: AttestationHistoryActionService);
    getNumberOfPendingForUser(parameters: AttestationCaseLoadParameters): Promise<ObjectAttestationStatistics>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentityAttestationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IdentityAttestationService>;
}
