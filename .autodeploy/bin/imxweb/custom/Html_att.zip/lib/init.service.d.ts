import { Router, Route } from '@angular/router';
import { ExtService, MenuService } from 'qbm';
import { NotificationRegistryService } from 'qer';
import { PermissionsService } from './admin/permissions.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly extService;
    private readonly router;
    private readonly menuService;
    private readonly notificationService;
    private readonly permissions;
    constructor(extService: ExtService, router: Router, menuService: MenuService, notificationService: NotificationRegistryService, permissions: PermissionsService);
    onInit(routes: Route[]): void;
    private addRoutes;
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
