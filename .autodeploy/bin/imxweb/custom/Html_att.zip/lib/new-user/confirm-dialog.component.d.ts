import { ParameterizedText } from 'qbm';
import * as i0 from "@angular/core";
export declare class ConfirmDialogComponent {
    ptext: ParameterizedText;
    constructor(ptext: ParameterizedText);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmDialogComponent, "ng-component", never, {}, {}, never, never, false>;
}
