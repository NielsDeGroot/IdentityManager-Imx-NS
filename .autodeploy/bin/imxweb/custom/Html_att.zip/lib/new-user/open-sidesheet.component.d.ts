import { OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class OpenSidesheetComponent implements OnInit {
    private readonly sidesheet;
    private readonly translate;
    constructor(sidesheet: EuiSidesheetService, translate: TranslateService);
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenSidesheetComponent, "ng-component", never, {}, {}, never, never, false>;
}
