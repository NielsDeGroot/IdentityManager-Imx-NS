import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { OnDestroy, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { PortalPickcategory, PortalPickcategoryItems } from 'imx-api-qer';
import { ColumnDependentReference, ConfirmationService, DataSourceToolbarSettings, DataSourceWrapper } from 'qbm';
import { PickCategorySelectIdentitiesComponent } from '../pick-category-select-identities/pick-category-select-identities.component';
import { PickCategoryService } from '../pick-category.service';
import * as i0 from "@angular/core";
export declare class PickCategoryCreateComponent implements OnInit, OnDestroy {
    data: {
        pickCategory: PortalPickcategory;
    };
    private readonly sidesheetRef;
    readonly pickCategoryService: PickCategoryService;
    readonly displayNameForm: UntypedFormGroup;
    readonly dstWrapper: DataSourceWrapper<PortalPickcategoryItems>;
    dstSettings: DataSourceToolbarSettings;
    selectedItems: PortalPickcategoryItems[];
    displayNameCdr: ColumnDependentReference;
    displayNameReadonlyCdr: ColumnDependentReference;
    private readonly subscriptions;
    selectIndentities: PickCategorySelectIdentitiesComponent;
    constructor(data: {
        pickCategory: PortalPickcategory;
    }, sidesheetRef: EuiSidesheetRef, pickCategoryService: PickCategoryService, confirmation: ConfirmationService);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    stepChange(change: StepperSelectionEvent): Promise<void>;
    showSummary(): Promise<void>;
    closeSidesheet(): void;
    private getData;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickCategoryCreateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickCategoryCreateComponent, "imx-pick-category-create", never, {}, {}, never, never, false>;
}
