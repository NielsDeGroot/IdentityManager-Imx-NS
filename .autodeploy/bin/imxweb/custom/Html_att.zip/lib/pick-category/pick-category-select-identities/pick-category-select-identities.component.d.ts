import { OnInit } from '@angular/core';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { PortalPersonAll, PortalPickcategoryItems } from 'imx-api-qer';
import { CollectionLoadParameters, IClientProperty, TypedEntity } from 'imx-qbm-dbts';
import { BusyService, DataSourceToolbarSettings, DataSourceWrapper, MetadataService } from 'qbm';
import { IdentitiesService } from 'qer';
import * as i0 from "@angular/core";
export declare class PickCategorySelectIdentitiesComponent implements OnInit {
    selectedItems: PortalPickcategoryItems[];
    private readonly sidesheetRef;
    private readonly identityService;
    private readonly metadataService;
    readonly dstWrapper: DataSourceWrapper<PortalPersonAll>;
    dstSettings: DataSourceToolbarSettings;
    displayColumns: IClientProperty[];
    selection: TypedEntity[];
    busyService: BusyService;
    embeddedMode: boolean;
    constructor(selectedItems: PortalPickcategoryItems[], sidesheetRef: EuiSidesheetRef, identityService: IdentitiesService, metadataService: MetadataService);
    ngOnInit(): Promise<void>;
    getData(navigationState?: CollectionLoadParameters): Promise<void>;
    onSelectionChanged(selection: TypedEntity[]): void;
    onAssign(): void;
    private getFilter;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickCategorySelectIdentitiesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickCategorySelectIdentitiesComponent, "imx-pick-category-select-identities", never, { "embeddedMode": "embeddedMode"; }, {}, never, never, false>;
}
