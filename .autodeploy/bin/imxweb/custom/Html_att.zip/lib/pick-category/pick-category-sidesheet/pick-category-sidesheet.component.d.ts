import { OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PortalPickcategory, PortalPickcategoryItems } from 'imx-api-qer';
import { CollectionLoadParameters } from 'imx-qbm-dbts';
import { BusyService, ClassloggerService, ConfirmationService, DataSourceToolbarSettings, DataSourceWrapper, SnackBarService } from 'qbm';
import { PickCategoryService } from '../pick-category.service';
import { UntypedFormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class PickCategorySidesheetComponent implements OnInit {
    data: {
        pickCategory: PortalPickcategory;
    };
    private readonly sidesheet;
    private readonly snackBar;
    private readonly confirmationService;
    private readonly pickCategoryService;
    private readonly translate;
    private readonly logger;
    readonly dstWrapper: DataSourceWrapper<PortalPickcategoryItems>;
    readonly form: UntypedFormGroup;
    dstSettings: DataSourceToolbarSettings;
    selectedPickedItems: PortalPickcategoryItems[];
    displayNameCdr: any;
    busyService: BusyService;
    private table;
    private uidPickCategory;
    constructor(data: {
        pickCategory: PortalPickcategory;
    }, sidesheet: EuiSidesheetService, snackBar: SnackBarService, confirmationService: ConfirmationService, pickCategoryService: PickCategoryService, translate: TranslateService, logger: ClassloggerService);
    ngOnInit(): Promise<void>;
    getData(newState?: CollectionLoadParameters): Promise<void>;
    selectedItemsCanBeDeleted(): boolean;
    onSearch(keywords: string): Promise<void>;
    onSelectionChanged(items: PortalPickcategoryItems[]): void;
    assignPickedItems(): Promise<void>;
    removePickedItems(): Promise<void>;
    saveChanges(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickCategorySidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickCategorySidesheetComponent, "imx-pick-category-sidesheet", never, {}, {}, never, never, false>;
}
