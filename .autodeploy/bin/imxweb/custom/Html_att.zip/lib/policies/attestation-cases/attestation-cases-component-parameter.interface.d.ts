import { PolicyFilterElement } from 'imx-api-att';
export interface AttestationCasesComponentParameter {
    subtitle?: string;
    uidPickCategory: string;
    uidobject: string;
    filter: PolicyFilterElement[];
    concat: string;
    canCreateRuns: boolean;
    uidpolicy?: string;
}
