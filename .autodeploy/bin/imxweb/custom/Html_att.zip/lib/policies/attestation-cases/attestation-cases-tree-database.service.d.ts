import { CollectionLoadParameters, EntitySchema } from 'imx-qbm-dbts';
import { BusyService, SettingsService, TreeDatabase, TreeNodeResultParameter } from 'qbm';
import { PolicyService } from '../policy.service';
import { AttestationCasesComponentParameter } from './attestation-cases-component-parameter.interface';
export declare class AttestationCasesTreeDatabaseService extends TreeDatabase {
    private readonly policyService;
    private readonly settingsService;
    private readonly data;
    busyService: BusyService;
    private entitySchema;
    private builder;
    constructor(policyService: PolicyService, settingsService: SettingsService, data: AttestationCasesComponentParameter, busyService: BusyService);
    getData(showLoading: boolean, parameter?: CollectionLoadParameters): Promise<TreeNodeResultParameter>;
    prepare(entitySchema: EntitySchema, withReload: boolean): Promise<void>;
    /** adds a hasChildren column to the entity */
    private buildEntityWithHasChildren;
}
