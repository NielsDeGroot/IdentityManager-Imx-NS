import { EventEmitter, OnChanges, OnDestroy } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { ColumnDependentReference } from 'qbm';
import { FilterChangedArgument } from './filter-changed-argument.interface';
import { FilterElementModel } from './filter-element-model';
import * as i0 from "@angular/core";
export declare class EditNameComponent implements OnChanges, OnDestroy {
    filterElementModel: FilterElementModel;
    identifier: string;
    testId: string;
    cdr: ColumnDependentReference;
    valueChanged: EventEmitter<FilterChangedArgument>;
    private valueChangedSubscription;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    invokeValueChangedEvent(control: AbstractControl): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditNameComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditNameComponent, "imx-edit-name", never, { "filterElementModel": "filterElementModel"; "identifier": "identifier"; "testId": "testId"; }, { "valueChanged": "valueChanged"; }, never, never, false>;
}
