import { EventEmitter, OnChanges, OnDestroy } from '@angular/core';
import { UntypedFormArray } from '@angular/forms';
import { ParmOpt } from 'imx-api-att';
import { ClassloggerService } from 'qbm';
import { FilterChangedArgument } from './filter-changed-argument.interface';
import { FilterElementModel } from './filter-element-model';
import * as i0 from "@angular/core";
export declare class EditOriginComponent implements OnChanges, OnDestroy {
    private readonly logger;
    candidates: ParmOpt[];
    readonly control: UntypedFormArray;
    filterElementModel: FilterElementModel;
    identifier: string;
    testId: string;
    valueChanged: EventEmitter<FilterChangedArgument>;
    private selectedParameter;
    private valueChangedSubscription;
    constructor(logger: ClassloggerService);
    ngOnChanges(): void;
    ngOnDestroy(): void;
    private buildNewParameterValue;
    private buildDisplay;
    private isSelected;
    private splitStringAndRemoveQuotes;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditOriginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditOriginComponent, "imx-edit-origin", never, { "filterElementModel": "filterElementModel"; "identifier": "identifier"; "testId": "testId"; }, { "valueChanged": "valueChanged"; }, never, never, false>;
}
