import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { FilterChangedArgument } from './filter-changed-argument.interface';
import { FilterElementModel } from './filter-element-model';
import * as i0 from "@angular/core";
export declare class EditThresholdComponent implements OnInit, OnDestroy {
    private readonly translateService;
    readonly riskIndexForm: UntypedFormGroup;
    readonly lowerControl: UntypedFormControl;
    readonly upperControl: UntypedFormControl;
    filterElementModel: FilterElementModel;
    identifier: string;
    testId: string;
    valueChanged: EventEmitter<FilterChangedArgument>;
    private valueChangedSubscription;
    constructor(translateService: TranslateService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditThresholdComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditThresholdComponent, "imx-edit-threshold", never, { "filterElementModel": "filterElementModel"; "identifier": "identifier"; "testId": "testId"; }, { "valueChanged": "valueChanged"; }, never, never, false>;
}
