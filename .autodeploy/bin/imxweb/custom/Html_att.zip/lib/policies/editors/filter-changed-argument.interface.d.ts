import { PolicyFilterElement } from 'imx-api-att';
export interface FilterChangedArgument extends PolicyFilterElement {
    displays?: string[];
    setName?: boolean;
}
