import { EventEmitter } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { ClassloggerService } from 'qbm';
import { FilterChangedArgument } from './filter-changed-argument.interface';
import { FilterElementModel } from './filter-element-model';
import * as i0 from "@angular/core";
export declare class FilterEditorComponent implements ControlValueAccessor {
    private readonly logger;
    onChange: (event: FilterElementModel) => void;
    onTouch: (event: any) => void;
    filterElementModel: FilterElementModel;
    testId: string;
    filterChanged: EventEmitter<FilterChangedArgument>;
    constructor(logger: ClassloggerService);
    writeValue(filter: FilterElementModel): void;
    registerOnChange(fn: (event: FilterElementModel) => void): void;
    registerOnTouched(fn: (event: any) => void): void;
    invokeFilterChangedElement(arg: FilterChangedArgument): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterEditorComponent, "imx-filter-editor", never, { "filterElementModel": "filterElementModel"; "testId": "testId"; }, { "filterChanged": "filterChanged"; }, never, never, false>;
}
