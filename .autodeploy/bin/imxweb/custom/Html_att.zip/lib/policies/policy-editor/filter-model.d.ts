import { BehaviorSubject } from 'rxjs';
import { ParmData, PolicyFilterData, PolicyFilterElement } from 'imx-api-att';
import { SelectecObjectsInfo } from '../selected-objects/selected-objects-info.interface';
import { FilterElementColumnService } from '../editors/filter-element-column.service';
import { FilterElementModel } from '../editors/filter-element-model';
export declare class FilterModel {
    readonly columnFactory: FilterElementColumnService;
    readonly isEnabledSubject: BehaviorSubject<boolean>;
    readonly attestationObjectSubject: BehaviorSubject<string>;
    totalSelectedObjectsSubject: BehaviorSubject<SelectecObjectsInfo>;
    policyFilterData: PolicyFilterData;
    parameterConfig: ParmData[];
    uidAttestationObject: string;
    constructor(columnFactory: FilterElementColumnService, isEnabledSubject: BehaviorSubject<boolean>, attestationObjectSubject: BehaviorSubject<string>);
    dispose(): void;
    updateConfig(): Promise<void>;
    addCondition(): FilterElementModel;
    deleteCondition(index: number): void;
    filterHasChanged(filterElements: FilterElementModel[], type: string): void;
    updateConcatination(concat: string): void;
    buildPolicyModel(filterElement: PolicyFilterElement, displays?: string[]): FilterElementModel;
    private filtersAreValid;
}
