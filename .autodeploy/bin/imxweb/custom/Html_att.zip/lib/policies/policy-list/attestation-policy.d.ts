import { PortalAttestationPolicy } from 'imx-api-att';
export declare class AttestationPolicy extends PortalAttestationPolicy {
    hasAttestations: boolean;
}
