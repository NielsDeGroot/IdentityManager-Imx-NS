import { CollectionLoadParameters } from 'imx-qbm-dbts';
export interface PolicyLoadParameters extends CollectionLoadParameters {
    OnlyActivePolicies?: string;
    mypolicies?: string;
}
