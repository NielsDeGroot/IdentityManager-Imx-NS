import { PolicyFilterData, PortalAttestationPolicyEdit } from 'imx-api-att';
export interface Policy {
    policy: PortalAttestationPolicyEdit;
    filterData: PolicyFilterData;
    isNew?: boolean;
    isComplienceFrameworkEnabled: boolean;
    showSampleDataWarning?: boolean;
}
export interface PolicyCopyData {
    data: PortalAttestationPolicyEdit;
    pickCategorySkipped: boolean;
}
