import { PolicyFilter } from 'imx-api-att';
export interface SelectecObjectsInfo {
    policyFilter: PolicyFilter;
    uidAttestationObject: string;
    uidPickCategory: string;
}
