import { OnDestroy, OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { BehaviorSubject } from 'rxjs';
import { PolicyFilter } from 'imx-api-att';
import { ClassloggerService } from 'qbm';
import { SelectecObjectsInfo } from './selected-objects-info.interface';
import { PolicyService } from '../policy.service';
import * as i0 from "@angular/core";
export declare class SelectedObjectsComponent implements OnInit, OnDestroy {
    private readonly sideSheet;
    private readonly policyService;
    private readonly logger;
    filter: PolicyFilter;
    uidAttestationObject: string;
    uidPickCategory: string;
    countMatching: number;
    popupTitle: string;
    popupSubtitle: string;
    isTotal: boolean;
    testId: string;
    filterSubject: BehaviorSubject<SelectecObjectsInfo>;
    constructor(sideSheet: EuiSidesheetService, policyService: PolicyService, logger: ClassloggerService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    showMatchingObjects(event?: Event): void;
    private getMatchCount;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectedObjectsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectedObjectsComponent, "imx-selected-objects", never, { "popupTitle": "popupTitle"; "popupSubtitle": "popupSubtitle"; "isTotal": "isTotal"; "testId": "testId"; "filterSubject": "filterSubject"; }, {}, never, never, false>;
}
