import { PolicyFilterData, PortalAttestationPolicygroups } from 'imx-api-att';
export interface PolicyGroup {
    policyGroup: PortalAttestationPolicygroups;
    filterData: PolicyFilterData;
    isNew?: boolean;
    isComplienceFrameworkEnabled: boolean;
}
