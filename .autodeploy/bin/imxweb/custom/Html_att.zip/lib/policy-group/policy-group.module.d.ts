import * as i0 from "@angular/core";
import * as i1 from "./policy-group-list/policy-group-list.component";
import * as i2 from "./edit-policy-group-sidesheet/edit-policy-group-sidesheet.component";
import * as i3 from "qbm";
import * as i4 from "@angular/common";
import * as i5 from "@elemental-ui/core";
import * as i6 from "@angular/forms";
import * as i7 from "@angular/material/expansion";
import * as i8 from "@angular/material/tooltip";
import * as i9 from "@angular/material/input";
import * as i10 from "@angular/material/button";
import * as i11 from "@angular/material/dialog";
import * as i12 from "@angular/material/radio";
import * as i13 from "@angular/material/checkbox";
import * as i14 from "@angular/material/slide-toggle";
import * as i15 from "@angular/material/menu";
import * as i16 from "@ngx-translate/core";
import * as i17 from "qer";
export declare class PolicyGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PolicyGroupModule, [typeof i1.PolicyGroupListComponent, typeof i2.EditPolicyGroupSidesheetComponent], [typeof i3.CdrModule, typeof i4.CommonModule, typeof i3.DataSourceToolbarModule, typeof i3.DataTableModule, typeof i5.EuiCoreModule, typeof i5.EuiMaterialModule, typeof i6.FormsModule, typeof i3.LdsReplaceModule, typeof i7.MatExpansionModule, typeof i8.MatTooltipModule, typeof i9.MatInputModule, typeof i10.MatButtonModule, typeof i11.MatDialogModule, typeof i12.MatRadioModule, typeof i13.MatCheckboxModule, typeof i14.MatSlideToggleModule, typeof i15.MatMenuModule, typeof i6.ReactiveFormsModule, typeof i16.TranslateModule, typeof i17.UserModule, typeof i3.ClassloggerModule, typeof i3.HelpContextualModule], [typeof i1.PolicyGroupListComponent, typeof i2.EditPolicyGroupSidesheetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PolicyGroupModule>;
}
