import { CollectionLoadParameters, EntityCollectionData, EntitySchema, ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { PortalAttestationPolicygroups, PolicyFilter } from 'imx-api-att';
import { ApiService } from '../api.service';
import { EuiLoadingService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { ClassloggerService } from 'qbm';
import * as i0 from "@angular/core";
export declare class PolicyGroupService {
    private api;
    private busyService;
    private readonly translator;
    private readonly logger;
    abortController: AbortController;
    private busyIndicator;
    constructor(api: ApiService, busyService: EuiLoadingService, translator: TranslateService, logger: ClassloggerService);
    get AttestationPolicyGroupSchema(): EntitySchema;
    get(parameters: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalAttestationPolicygroups, unknown>>;
    deleteAttestationPolicyGroup(uidAttestationpolicygroup: string): Promise<EntityCollectionData>;
    getPolicyGroupEdit(uid: string): Promise<ExtendedTypedEntityCollection<PortalAttestationPolicygroups, {}>>;
    buildNewEntity(reference?: PortalAttestationPolicygroups, filter?: PolicyFilter): Promise<PortalAttestationPolicygroups>;
    copyPropertiesFrom(entity: PortalAttestationPolicygroups, reference: PortalAttestationPolicygroups, filter: PolicyFilter): Promise<void>;
    getPolicyGroups(parameters: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalAttestationPolicygroups, {}>>;
    handleOpenLoader(): void;
    handleCloseLoader(): void;
    abortCall(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyGroupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PolicyGroupService>;
}
