import * as i0 from "@angular/core";
import * as i1 from "./runs.component";
import * as i2 from "./run-sidesheet.component";
import * as i3 from "./pending-approvers.component";
import * as i4 from "./send-reminder-mail.component";
import * as i5 from "./progress/progress.component";
import * as i6 from "./run-extend/run-extend.component";
import * as i7 from "./attestation/attestation.component";
import * as i8 from "./runs-grid/runs-grid.component";
import * as i9 from "./case-chart/case-chart.component";
import * as i10 from "./attestation/attestation-wrapper/attestation-wrapper.component";
import * as i11 from "@angular/common";
import * as i12 from "qbm";
import * as i13 from "@ngx-translate/core";
import * as i14 from "@elemental-ui/core";
import * as i15 from "@angular/forms";
import * as i16 from "@angular/router";
import * as i17 from "@angular/material/button";
import * as i18 from "@angular/material/dialog";
import * as i19 from "@angular/material/progress-bar";
import * as i20 from "@angular/material/sidenav";
import * as i21 from "../attestation-history/attestation-history.module";
export declare class AttestationRunsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationRunsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AttestationRunsModule, [typeof i1.RunsComponent, typeof i2.RunSidesheetComponent, typeof i3.PendingApproversComponent, typeof i4.SendReminderMailComponent, typeof i5.ProgressComponent, typeof i6.RunExtendComponent, typeof i7.AttestationComponent, typeof i8.RunsGridComponent, typeof i9.CaseChartComponent, typeof i10.AttestationWrapperComponent], [typeof i11.CommonModule, typeof i12.CdrModule, typeof i13.TranslateModule, typeof i12.DataSourceToolbarModule, typeof i12.DataTableModule, typeof i14.EuiCoreModule, typeof i14.EuiMaterialModule, typeof i15.FormsModule, typeof i16.RouterModule, typeof i17.MatButtonModule, typeof i18.MatDialogModule, typeof i19.MatProgressBarModule, typeof i20.MatSidenavModule, typeof i15.ReactiveFormsModule, typeof i12.LdsReplaceModule, typeof i21.AttestationHistoryModule, typeof i12.SelectedElementsModule, typeof i12.HelpContextualModule, typeof i12.TempBillboardModule], [typeof i1.RunsComponent, typeof i8.RunsGridComponent, typeof i10.AttestationWrapperComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AttestationRunsModule>;
}
