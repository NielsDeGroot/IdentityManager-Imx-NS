import { OnDestroy, OnInit } from '@angular/core';
import { DynamicTabDataProviderDirective } from 'qbm';
import { HelperAlertContent } from 'qer';
import { IdentityAttestationService } from '../../../identity-attestation.service';
import * as i0 from "@angular/core";
export declare class AttestationWrapperComponent implements OnInit, OnDestroy {
    private readonly attestations;
    referrer: {
        objecttable: string;
        objectuid: string;
    };
    readonly pendingAttestations: HelperAlertContent;
    private readonly subscriptions;
    constructor(attestations: IdentityAttestationService, dataProvider: DynamicTabDataProviderDirective);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private updatePendingAttestations;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationWrapperComponent, "ng-component", never, {}, {}, never, never, false>;
}
