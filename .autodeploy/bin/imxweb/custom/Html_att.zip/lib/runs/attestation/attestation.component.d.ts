import { EventEmitter, OnDestroy } from '@angular/core';
import { AuthenticationService, StorageService } from 'qbm';
import { AttestationHistoryCase } from '../../attestation-history/attestation-history-case';
import { AttestationHistoryActionService } from '../../attestation-history/attestation-history-action.service';
import { FilterData } from 'imx-qbm-dbts';
import { HelperAlertContent } from 'qer';
import * as i0 from "@angular/core";
export declare class AttestationComponent implements OnDestroy {
    readonly attestationAction: AttestationHistoryActionService;
    private readonly storageService;
    get canDecide(): boolean;
    get withAssignmentAnalysis(): boolean;
    get showHelperAlert(): boolean;
    parameters: {
        objecttable: string;
        objectuid: string;
        filter?: FilterData[];
    };
    pendingAttestations: HelperAlertContent;
    viewEscalation: boolean;
    readonly itemStatus: {
        enabled: (attestationCase: any) => boolean;
    };
    selectedCases: AttestationHistoryCase[];
    cancel: EventEmitter<any>;
    private userUid;
    private readonly subscriptions;
    constructor(attestationAction: AttestationHistoryActionService, storageService: StorageService, authentication: AuthenticationService);
    ngOnDestroy(): void;
    onSelectionChanged(items: AttestationHistoryCase[]): void;
    onHelperDismissed(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttestationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttestationComponent, "imx-attestation", never, { "parameters": "parameters"; "pendingAttestations": "pendingAttestations"; "viewEscalation": "viewEscalation"; }, { "cancel": "cancel"; }, never, never, false>;
}
