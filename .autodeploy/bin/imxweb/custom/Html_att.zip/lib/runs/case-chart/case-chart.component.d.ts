import { ElementRef, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Chart, ChartOptions } from 'billboard.js';
import { PortalAttestationRun } from 'imx-api-att';
import * as i0 from "@angular/core";
export declare class CaseChartComponent implements OnInit, OnDestroy {
    readonly translateService: TranslateService;
    run: PortalAttestationRun;
    chartData: ChartOptions;
    private chart;
    private subscriptions$;
    chartWrapper: ElementRef<HTMLElement>;
    constructor(translateService: TranslateService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    saveChart(chart: Chart): void;
    private buildSingleValueChart;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseChartComponent, "imx-case-chart", never, { "run": "run"; }, {}, never, never, false>;
}
