export declare function percentage(progress: number): number;
