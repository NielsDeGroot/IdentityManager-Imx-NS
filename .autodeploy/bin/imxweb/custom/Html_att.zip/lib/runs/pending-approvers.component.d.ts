import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ApiService } from '../api.service';
import { PortalAttestationRunApprovers } from 'imx-api-att';
import { TypedEntityCollectionData } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings } from 'qbm';
import * as i0 from "@angular/core";
export declare class PendingApproversComponent implements OnChanges {
    private readonly attApiService;
    dstSettings: DataSourceToolbarSettings;
    selected: PortalAttestationRunApprovers[];
    showHelper: boolean;
    dataSource: TypedEntityCollectionData<PortalAttestationRunApprovers>;
    readonly sendReminder: EventEmitter<PortalAttestationRunApprovers[]>;
    constructor(attApiService: ApiService);
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    onSelectionChanged(items: PortalAttestationRunApprovers[]): void;
    onHelperDismissed(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PendingApproversComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PendingApproversComponent, "imx-attestation-run-approvers", never, { "dataSource": "dataSource"; }, { "sendReminder": "sendReminder"; }, never, never, false>;
}
