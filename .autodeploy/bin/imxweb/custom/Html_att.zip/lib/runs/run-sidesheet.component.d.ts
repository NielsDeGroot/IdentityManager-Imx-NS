import { MatTabChangeEvent } from '@angular/material/tabs';
import { EuiLoadingService, EuiSidesheetRef, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { EuiDownloadOptions } from '@elemental-ui/core';
import { TypedEntityCollectionData } from 'imx-qbm-dbts';
import { PortalAttestationRun, PortalAttestationRunApprovers, RunStatisticsConfig } from 'imx-api-att';
import { SnackBarService } from 'qbm';
import { RunsService } from './runs.service';
import { AttestationActionService } from '../attestation-action/attestation-action.service';
import { AttestationHistoryActionService } from '../attestation-history/attestation-history-action.service';
import { AttestationCaseLoadParameters } from '../attestation-history/attestation-case-load-parameters.interface';
import { HelperAlertContent } from 'qer';
import * as i0 from "@angular/core";
export declare class RunSidesheetComponent {
    readonly data: {
        run: PortalAttestationRun;
        attestationRunConfig: RunStatisticsConfig;
        canSeeAttestationPolicies: boolean;
        threshold: number;
        completed: boolean;
    };
    readonly runsService: RunsService;
    private readonly snackBarService;
    private readonly sideSheet;
    private readonly translate;
    private readonly busyService;
    private readonly sideSheetRef;
    private readonly action;
    readonly run: PortalAttestationRun;
    readonly attestationRunConfig: RunStatisticsConfig;
    readonly reportDownload: EuiDownloadOptions;
    readonly threshold: number;
    approvers: TypedEntityCollectionData<PortalAttestationRunApprovers>;
    readonly attestationParameters: AttestationCaseLoadParameters;
    readonly pendingAttestations: HelperAlertContent;
    private readonly subscriptions;
    get categoryExplanation(): {
        message: string;
        limit?: number;
    };
    constructor(data: {
        run: PortalAttestationRun;
        attestationRunConfig: RunStatisticsConfig;
        canSeeAttestationPolicies: boolean;
        threshold: number;
        completed: boolean;
    }, runsService: RunsService, snackBarService: SnackBarService, sideSheet: EuiSidesheetService, translate: TranslateService, busyService: EuiLoadingService, sideSheetRef: EuiSidesheetRef, action: AttestationActionService, attestationAction: AttestationHistoryActionService);
    extendAttestationRun(): Promise<void>;
    onTabChange(event: MatTabChangeEvent): Promise<void>;
    cancel(): void;
    private updatePendingAttestations;
    static ɵfac: i0.ɵɵFactoryDeclaration<RunSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RunSidesheetComponent, "ng-component", never, {}, {}, never, never, false>;
}
