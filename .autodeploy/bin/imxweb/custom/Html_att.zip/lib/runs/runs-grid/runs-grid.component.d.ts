import { OnInit } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { CollectionLoadParameters, EntitySchema } from 'imx-qbm-dbts';
import { PortalAttestationRun, RunStatisticsConfig } from 'imx-api-att';
import { DataSourceToolbarExportMethod, DataSourceToolbarSettings, DataTableGroupedData, SettingsService } from 'qbm';
import { RunsService } from '../runs.service';
import { PermissionsService } from '../../admin/permissions.service';
import { ViewConfigData } from 'imx-api-qer';
import { ViewConfigService } from 'qer';
import * as i0 from "@angular/core";
export declare class RunsGridComponent implements OnInit {
    private runsService;
    private viewConfigService;
    private busyService;
    private sideSheet;
    private readonly settingsService;
    private readonly permissions;
    private translate;
    /**
     * Settings needed by the DataSourceToolbarComponent
     */
    dstSettings: DataSourceToolbarSettings;
    readonly categoryBadgeColor: {
        Bad: string;
        Mediocre: string;
        Good: string;
    };
    entitySchema: EntitySchema;
    uidAttestationPolicy: any;
    groupedData: {
        [key: string]: DataTableGroupedData;
    };
    attestationRunConfig: RunStatisticsConfig | undefined;
    canSeeAttestationPolicies: boolean;
    hasPendingAttestations: boolean;
    progressCalcThreshold: number;
    private runs;
    private filterOptions;
    private groupData;
    /**
     * Page size, start index, search and filtering options etc.
     */
    private navigationState;
    private readonly orderBy;
    private filter;
    private dataModel;
    private viewConfig;
    private viewConfigPath;
    constructor(runsService: RunsService, viewConfigService: ViewConfigService, busyService: EuiLoadingService, sideSheet: EuiSidesheetService, settingsService: SettingsService, permissions: PermissionsService, translate: TranslateService);
    ngOnInit(): Promise<void>;
    updateConfig(config: ViewConfigData): Promise<void>;
    deleteConfigById(id: string): Promise<void>;
    getData(newState?: CollectionLoadParameters, isInitialLoad?: boolean): Promise<void>;
    getExportMethod(): DataSourceToolbarExportMethod;
    onSearch(keywords: string): Promise<void>;
    onRunChanged(run: PortalAttestationRun): Promise<void>;
    onGroupingChange(groupInfo: {
        key: string;
        isInitial: boolean;
    }): Promise<void>;
    sendReminderEmail(): Promise<void>;
    isCompleted(run: PortalAttestationRun): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<RunsGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RunsGridComponent, "imx-runs-grid", never, { "uidAttestationPolicy": "uidAttestationPolicy"; }, {}, never, never, false>;
}
