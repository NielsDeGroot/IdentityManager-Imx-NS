import { CollectionLoadParameters, FilterData } from 'imx-qbm-dbts';
export interface RunsLoadParameters extends CollectionLoadParameters {
    groupFilter?: FilterData[];
    withpendingcases?: string;
    by?: string;
    def?: string;
}
