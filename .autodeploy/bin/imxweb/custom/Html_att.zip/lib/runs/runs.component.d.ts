import * as i0 from "@angular/core";
export declare class RunsComponent {
    canSeeAttestationPolicies: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<RunsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RunsComponent, "ng-component", never, {}, {}, never, never, false>;
}
