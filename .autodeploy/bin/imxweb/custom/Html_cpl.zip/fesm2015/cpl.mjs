import * as i5 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Pipe, EventEmitter, Output, Input, Inject, ViewChild, NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import * as i6 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i9 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import * as i5$1 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import * as i5$2 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import * as i3 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i3$1 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i4 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i2 from 'qbm';
import { BaseReadonlyCdr, BaseCdr, DataSourceWrapper, BusyService, DataSourceToolbarModule, DataTableModule, DataTableComponent, CdrModule, ExtModule, SelectedElementsModule, HelpContextualModule, HELP_CONTEXTUAL, RouteGuardService, LdsReplaceModule } from 'qbm';
import * as i1 from 'qer';
import { JustificationType, JustificationModule, TilesModule, StatisticsModule, ObjectHyperviewModule } from 'qer';
import { __awaiter, __asyncValues, __rest } from 'tslib';
import { ValType, DbObjectKey, MethodDefinition, FilterType, CompareOperator, DisplayColumns, TypedEntity, TypedEntityBuilder } from 'imx-qbm-dbts';
import * as i2$1 from '@angular/forms';
import { FormControl, UntypedFormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PortalPersonMitigatingcontrols, V2Client, TypedClient, V2ApiClientMethodFactory, PortalRulesMitigatingcontrols, PortalRulesViolations } from 'imx-api-cpl';
import * as i3$2 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i6$1 from '@angular/material/tooltip';
import * as i8 from '@angular/material/divider';
import * as i8$2 from '@angular/material/tabs';
import { MatTabGroup, MatTabsModule } from '@angular/material/tabs';
import { Subject } from 'rxjs';
import * as i4$1 from '@angular/material/core';
import * as i7 from '@angular/material/progress-spinner';
import * as i8$1 from '@angular/material/stepper';
import { MatStepperModule } from '@angular/material/stepper';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isExceptionAdmin(groups) {
    return groups.find(item => item === 'vi_4_RULEADMIN_EXCEPTION') != null;
}
function isRuleStatistics(features) {
    return features.find(item => item === 'Portal_UI_RuleStatistics') != null;
}

class CplPermissionsService {
    constructor(userService) {
        this.userService = userService;
    }
    isExceptionAdmin() {
        return __awaiter(this, void 0, void 0, function* () {
            return isExceptionAdmin((yield this.userService.getGroups()).map(group => group.Name));
        });
    }
    isRuleStatistics() {
        return __awaiter(this, void 0, void 0, function* () {
            return isRuleStatistics((yield this.userService.getFeatures()).Features);
        });
    }
}
CplPermissionsService.ɵfac = function CplPermissionsService_Factory(t) { return new (t || CplPermissionsService)(i0.ɵɵinject(i1.UserModelService)); };
CplPermissionsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: CplPermissionsService, factory: CplPermissionsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CplPermissionsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1.UserModelService }]; }, null);
})();

function DashboardPluginComponent_imx_badge_tile_0_Template(rf, ctx) {
    if (rf & 1) {
        const _r2 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-badge-tile", 1);
        i0.ɵɵlistener("actionClick", function DashboardPluginComponent_imx_badge_tile_0_Template_imx_badge_tile_actionClick_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.router.navigate(["compliance", "rulesviolations", "approve"])); });
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("caption", i0.ɵɵpipeBind1(1, 3, "#LDS#Heading Pending Rule Violations"))("value", ctx_r0.pendingItems == null ? null : ctx_r0.pendingItems.OpenNonCompliance)("identifier", "cpl-rule-violation-approvals");
    }
}
class DashboardPluginComponent {
    constructor(router, permissionService, userModelSvc) {
        this.router = router;
        this.permissionService = permissionService;
        this.userModelSvc = userModelSvc;
        this.isExceptionAdmin = false;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.isExceptionAdmin = yield this.permissionService.isExceptionAdmin();
            if (this.isExceptionAdmin) {
                this.pendingItems = yield this.userModelSvc.getPendingItems();
            }
        });
    }
}
DashboardPluginComponent.ɵfac = function DashboardPluginComponent_Factory(t) { return new (t || DashboardPluginComponent)(i0.ɵɵdirectiveInject(i3.Router), i0.ɵɵdirectiveInject(CplPermissionsService), i0.ɵɵdirectiveInject(i1.UserModelService)); };
DashboardPluginComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DashboardPluginComponent, selectors: [["ng-component"]], decls: 1, vars: 1, consts: [["data-imx-identifier", "cpl-dashboard--plugin-badge-tile-violations-approvals", 3, "caption", "value", "identifier", "actionClick", 4, "ngIf"], ["data-imx-identifier", "cpl-dashboard--plugin-badge-tile-violations-approvals", 3, "caption", "value", "identifier", "actionClick"]], template: function DashboardPluginComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, DashboardPluginComponent_imx_badge_tile_0_Template, 2, 5, "imx-badge-tile", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.isExceptionAdmin && 0 < (ctx.pendingItems == null ? null : ctx.pendingItems.OpenNonCompliance));
        }
    }, dependencies: [i5.NgIf, i1.BadgeTileComponent, i4.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DashboardPluginComponent, [{
            type: Component,
            args: [{ template: "<imx-badge-tile data-imx-identifier=\"cpl-dashboard--plugin-badge-tile-violations-approvals\"\r\n  [caption]=\"'#LDS#Heading Pending Rule Violations' | translate\" *ngIf=\"isExceptionAdmin && 0 < pendingItems?.OpenNonCompliance\"\r\n  [value]=\"pendingItems?.OpenNonCompliance\" [identifier]=\"'cpl-rule-violation-approvals'\"\r\n  (actionClick)=\"router.navigate(['compliance', 'rulesviolations', 'approve'])\">\r\n</imx-badge-tile>" }]
        }], function () { return [{ type: i3.Router }, { type: CplPermissionsService }, { type: i1.UserModelService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ExtendedDeferredOperationsData {
    constructor(deferred, entiyService) {
        this.deferred = deferred;
        this.formControl = new FormControl(undefined);
        this.isDeferredData = true;
        this.editable = false;
        this.isInActive = true;
        this.data = undefined;
        const schema = PortalPersonMitigatingcontrols.GetEntitySchema();
        this.cdrs = [
            new BaseReadonlyCdr(entiyService.createLocalEntityColumn({
                ColumnName: 'UID_MitigatingControl',
                Type: ValType.String,
            }, undefined, {
                Value: deferred.Uid,
                DisplayValue: deferred.Display,
            }), '#LDS#Mitigating control'),
            new BaseReadonlyCdr(entiyService.createLocalEntityColumn({
                ColumnName: 'IsInActive',
                Type: ValType.Bool,
            }, undefined, {
                Value: true,
                DisplayValue: '#LDS#Yes',
            }), '#LDS#Inactive'),
        ];
    }
    get uidMitigatingControl() {
        return this.deferred.Uid;
    }
    get displayMitigatingControls() {
        return this.deferred.Display;
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestMitigatingControlFilterPipe {
    transform(items, filter) {
        if (!items || !filter) {
            return items;
        }
        // filter items array, items which match and return true will be
        // kept, false will be filtered out
        return RequestMitigatingControlFilterPipe.getItems(items, filter);
    }
    static getItems(items, filter) {
        switch (filter) {
            case 'active':
                return items.filter((elem) => !elem.isDeferredData && !elem.isInActive);
            case 'inactive':
                return items.filter((elem) => !elem.isDeferredData && elem.isInActive);
            case 'deferred':
                return items.filter((elem) => elem.isDeferredData);
        }
    }
}
RequestMitigatingControlFilterPipe.ɵfac = function RequestMitigatingControlFilterPipe_Factory(t) { return new (t || RequestMitigatingControlFilterPipe)(); };
RequestMitigatingControlFilterPipe.ɵpipe = /*@__PURE__*/ i0.ɵɵdefinePipe({ name: "filtered", type: RequestMitigatingControlFilterPipe, pure: false });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RequestMitigatingControlFilterPipe, [{
            type: Pipe,
            args: [{
                    name: 'filtered',
                    pure: false,
                }]
        }], null, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Class thats extends the {@link PortalPersonMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
class RequestMitigatingControls extends PortalPersonMitigatingcontrols {
    constructor(editable, baseObject) {
        super(baseObject.GetEntity());
        this.editable = editable;
        this.baseObject = baseObject;
        this.formControl = new FormControl(undefined);
        this.isDeferredData = false;
        this.cdrs = this.initPropertyInfo();
    }
    get uidMitigatingControl() {
        return this.baseObject.UID_MitigatingControl.value;
    }
    set uidMitigatingControl(value) {
        this.baseObject.UID_MitigatingControl.value = value;
    }
    get displayMitigatingControls() {
        return this.baseObject.UID_MitigatingControl.Column.GetDisplayValue();
    }
    get isInActive() {
        return this.baseObject.IsInActive.value;
    }
    get data() {
        return this.baseObject;
    }
    initPropertyInfo() {
        const properties = [this.UID_MitigatingControl, this.IsInActive];
        return properties.map((property) => new BaseCdr(property.Column));
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing CPL API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
ApiService.ɵfac = function ApiService_Factory(t) { return new (t || ApiService)(i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ImxTranslationProviderService)); };
ApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApiService, factory: ApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i2.AppConfigService }, { type: i2.ClassloggerService }, { type: i2.ImxTranslationProviderService }]; }, null);
})();

class MitigatingControlsRequestService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    get mitigationSchema() {
        return this.apiService.typedClient.PortalPersonMitigatingcontrols.GetSchema();
    }
    getControls(uidPerson, uidNonCompliance) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.typedClient.PortalPersonMitigatingcontrols.Get(uidPerson, uidNonCompliance);
        });
    }
    createControl(uidPerson, uidNonCompliance) {
        const newMControl = this.apiService.typedClient.PortalPersonMitigatingcontrols.createEntity({
            Columns: {
                UID_NonCompliance: { Value: uidNonCompliance },
                UID_Person: { Value: uidPerson },
                IsInActive: { Value: false },
            },
        });
        return new RequestMitigatingControls(true, newMControl);
    }
    postControl(uidPerson, uidNonCompliance, mControl) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.apiService.typedClient.PortalPersonMitigatingcontrols.Post(uidPerson, uidNonCompliance, mControl);
        });
    }
    postControlRequest(uidPerson, uidNonCompliance, uidPersonWantsOrg, uidMitigatinControl) {
        return __awaiter(this, void 0, void 0, function* () {
            const inter = (yield this.apiService.typedClient.PortalPersonMitigatingcontrolsInteractive.Get(uidPerson, uidNonCompliance)).Data[0];
            yield inter.UID_PersonWantsOrg.Column.PutValue(uidPersonWantsOrg);
            yield inter.UID_MitigatingControl.Column.PutValue(uidMitigatinControl);
            yield this.apiService.client.portal_person_mitigatingcontrols_interactive_forrequest_get(uidPerson, uidNonCompliance, inter.InteractiveEntityStateData.EntityId, { keys: inter.InteractiveEntityStateData.Keys, state: inter.InteractiveEntityStateData.State });
        });
    }
    deleteControl(mControl) {
        return __awaiter(this, void 0, void 0, function* () {
            yield mControl.data.GetEntity().MarkForDeletion();
            yield mControl.data.GetEntity().Commit();
        });
    }
    getCandidates(uid, uidNonCompliance, data, parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.client.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(uid, uidNonCompliance, data, parameter);
        });
    }
}
MitigatingControlsRequestService.ɵfac = function MitigatingControlsRequestService_Factory(t) { return new (t || MitigatingControlsRequestService)(i0.ɵɵinject(ApiService)); };
MitigatingControlsRequestService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: MitigatingControlsRequestService, factory: MitigatingControlsRequestService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsRequestService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: ApiService }]; }, null);
})();

function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_mat_error_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-error");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#This field is mandatory."), " ");
    }
}
function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_mat_error_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-error");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once."), " ");
    }
}
function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-select", 9);
        i0.ɵɵlistener("selectionChange", function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_Template_eui_select_selectionChange_0_listener($event) { i0.ɵɵrestoreView(_r12); const mControl_r2 = i0.ɵɵnextContext(2).$implicit; const ctx_r10 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r10.onSelectionChange(mControl_r2, $event.value)); })("openChange", function MitigatingControlContainerComponent_div_1_div_1_eui_select_1_Template_eui_select_openChange_0_listener($event) { i0.ɵɵrestoreView(_r12); const mControl_r2 = i0.ɵɵnextContext(2).$implicit; const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.onOpenChange($event, mControl_r2)); });
        i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_div_1_eui_select_1_mat_error_1_Template, 3, 3, "mat-error", 10);
        i0.ɵɵtemplate(2, MitigatingControlContainerComponent_div_1_div_1_eui_select_1_mat_error_2_Template, 3, 3, "mat-error", 10);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r15 = i0.ɵɵnextContext(2);
        const mControl_r2 = ctx_r15.$implicit;
        const i_r3 = ctx_r15.index;
        const ctx_r7 = i0.ɵɵnextContext();
        i0.ɵɵproperty("label", ctx_r7.mitigatingCaption)("filterFunction", ctx_r7.filter)("enableFormFieldMargin", true)("options", ctx_r7.options)("inputControl", mControl_r2.formControl)("hideClearButton", true);
        i0.ɵɵattribute("data-imx-identifier", "mitigating-control-container-" + i_r3 + "-select");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", mControl_r2.formControl.errors == null ? null : mControl_r2.formControl.errors["required"]);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", mControl_r2.formControl.errors == null ? null : mControl_r2.formControl.errors["duplicated"]);
    }
}
function MitigatingControlContainerComponent_div_1_div_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 6);
        i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_div_1_eui_select_1_Template, 3, 9, "eui-select", 7);
        i0.ɵɵelement(2, "imx-cdr-editor", 8);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const mControl_r2 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", mControl_r2.editable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("cdr", mControl_r2.cdrs[1]);
    }
}
function MitigatingControlContainerComponent_div_1_div_2_imx_cdr_editor_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 8);
    }
    if (rf & 2) {
        const cdr_r18 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r18);
    }
}
function MitigatingControlContainerComponent_div_1_div_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 6);
        i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_div_2_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const mControl_r2 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", mControl_r2.cdrs);
    }
}
function MitigatingControlContainerComponent_div_1_button_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r22 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 12);
        i0.ɵɵlistener("click", function MitigatingControlContainerComponent_div_1_button_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r22); const ctx_r21 = i0.ɵɵnextContext(); const mControl_r2 = ctx_r21.$implicit; const i_r3 = ctx_r21.index; const ctx_r20 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r20.onDelete(mControl_r2, i_r3)); });
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelement(3, "eui-icon", 13);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 3, "#LDS#Removes the mitigating control"));
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(2, 5, "#LDS#Remove mitigating control"))("data-imx-identifier", "mitigating-control-container-button-delete- + index");
    }
}
function MitigatingControlContainerComponent_div_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 3);
        i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_div_1_Template, 3, 2, "div", 4);
        i0.ɵɵtemplate(2, MitigatingControlContainerComponent_div_1_div_2_Template, 2, 1, "div", 4);
        i0.ɵɵtemplate(3, MitigatingControlContainerComponent_div_1_button_3_Template, 4, 7, "button", 5);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const mControl_r2 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", mControl_r2 == null ? null : mControl_r2.editable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !mControl_r2.editable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !mControl_r2.isDeferredData);
    }
}
function MitigatingControlContainerComponent_button_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r24 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 14);
        i0.ɵɵlistener("click", function MitigatingControlContainerComponent_button_2_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r24); const ctx_r23 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r23.onCreateControl()); });
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelement(3, "eui-icon", 15);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, "#LDS#Assigns a mitigating control"));
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(2, 4, "#LDS#Assign mitigating control"));
    }
}
class MitigatingControlContainerComponent {
    constructor(cd, confirmationService) {
        this.cd = cd;
        this.confirmationService = confirmationService;
        this.mControls = [];
        this.options = [];
        this.controlDeleted = new EventEmitter();
        this.controlsRequested = new EventEmitter();
    }
    onSelectionChange(mcontrol, value) {
        return __awaiter(this, void 0, void 0, function* () {
            mcontrol.UID_MitigatingControl.value = value;
            this.formArray.updateValueAndValidity();
            this.cd.detectChanges();
            return;
        });
    }
    onOpenChange(isopen, mControl) {
        if (!isopen) {
            mControl.formControl.updateValueAndValidity({ onlySelf: true });
        }
    }
    onDelete(mControl, index) {
        return __awaiter(this, void 0, void 0, function* () {
            if (mControl.UID_MitigatingControl.value !== '' && !(yield this.confirmationService.confirmDelete())) {
                return;
            }
            if (mControl.GetEntity().GetKeys() != null) {
                this.controlDeleted.emit(mControl);
            }
            this.mControls.splice(index, 1);
            this.formArray.controls.splice(index, 1);
            this.formArray.controls.forEach((elem) => elem.updateValueAndValidity());
            this.cd.detectChanges();
        });
    }
    onCreateControl() {
        return __awaiter(this, void 0, void 0, function* () {
            this.controlsRequested.emit();
        });
    }
}
MitigatingControlContainerComponent.ɵfac = function MitigatingControlContainerComponent_Factory(t) { return new (t || MitigatingControlContainerComponent)(i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
MitigatingControlContainerComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlContainerComponent, selectors: [["imx-mitigating-control-container"]], inputs: { mControls: "mControls", mitigatingCaption: "mitigatingCaption", formArray: "formArray", options: "options" }, outputs: { controlDeleted: "controlDeleted", controlsRequested: "controlsRequested" }, decls: 3, vars: 2, consts: [[1, "content"], ["class", "mitigating-control", 4, "ngFor", "ngForOf"], ["data-imx-identifier", "mitigating-control-container-button-add", "mat-button", "", "class", "mat-icon-button", 3, "matTooltip", "click", 4, "ngIf"], [1, "mitigating-control"], ["class", "mitigating-control-properties", 4, "ngIf"], ["mat-button", "", "class", "mat-icon-button imx-delete-button", 3, "matTooltip", "click", 4, "ngIf"], [1, "mitigating-control-properties"], [3, "label", "filterFunction", "enableFormFieldMargin", "options", "inputControl", "hideClearButton", "selectionChange", "openChange", 4, "ngIf"], [3, "cdr"], [3, "label", "filterFunction", "enableFormFieldMargin", "options", "inputControl", "hideClearButton", "selectionChange", "openChange"], [4, "ngIf"], [3, "cdr", 4, "ngFor", "ngForOf"], ["mat-button", "", 1, "mat-icon-button", "imx-delete-button", 3, "matTooltip", "click"], ["icon", "delete"], ["data-imx-identifier", "mitigating-control-container-button-add", "mat-button", "", 1, "mat-icon-button", 3, "matTooltip", "click"], ["icon", "add"]], template: function MitigatingControlContainerComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, MitigatingControlContainerComponent_div_1_Template, 4, 3, "div", 1);
            i0.ɵɵtemplate(2, MitigatingControlContainerComponent_button_2_Template, 4, 6, "button", 2);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.mControls);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.options.length > 0);
        }
    }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiIconComponent, i3$1.EuiSelectComponent, i6.MatButton, i5$1.MatError, i6$1.MatTooltip, i2.CdrEditorComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{padding:16px 20px;display:flex;justify-content:flex-end}[_nghost-%COMP%]   .imx-helper-alert[_ngcontent-%COMP%]{margin-bottom:15px}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   .imx-delete-button[_ngcontent-%COMP%]{margin-top:15px;align-self:flex-start}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   .mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]   .content[_ngcontent-%COMP%]{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0;justify-self:center}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .button-actions[_ngcontent-%COMP%]{display:flex;justify-content:space-between;margin-top:20px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #ffffff}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlContainerComponent, [{
            type: Component,
            args: [{ selector: 'imx-mitigating-control-container', template: "<div class=\"content\">\r\n  <div class=\"mitigating-control\" *ngFor=\"let mControl of mControls; index as i\">\r\n    <!-- editable control-->\r\n    <div class=\"mitigating-control-properties\" *ngIf=\"mControl?.editable\">\r\n      <eui-select\r\n        *ngIf=\"mControl.editable\"\r\n        (selectionChange)=\"onSelectionChange(mControl, $event.value)\"\r\n        [label]=\"mitigatingCaption\"\r\n        [filterFunction]=\"filter\"\r\n        [enableFormFieldMargin]=\"true\"\r\n        [options]=\"options\"\r\n        [inputControl]=\"mControl.formControl\"\r\n        (openChange)=\"onOpenChange($event, mControl)\"\r\n        [hideClearButton]=\"true\"\r\n        [attr.data-imx-identifier]=\"'mitigating-control-container-' + i + '-select'\"\r\n      >\r\n        <mat-error *ngIf=\"mControl.formControl.errors?.['required']\">\r\n          {{ '#LDS#This field is mandatory.' | translate }}\r\n        </mat-error>\r\n        <mat-error *ngIf=\"mControl.formControl.errors?.['duplicated']\">\r\n          {{ '#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once.' | translate }}\r\n        </mat-error>\r\n      </eui-select>\r\n      <imx-cdr-editor [cdr]=\"mControl.cdrs[1]\"></imx-cdr-editor>\r\n    </div>\r\n    <!-- read only control-->\r\n    <div class=\"mitigating-control-properties\" *ngIf=\"!mControl.editable\">\r\n      <imx-cdr-editor *ngFor=\"let cdr of mControl.cdrs\" [cdr]=\"cdr\"></imx-cdr-editor>\r\n    </div>\r\n\r\n    <button\r\n      [matTooltip]=\"'#LDS#Removes the mitigating control' | translate\"\r\n      [attr.aria-label]=\"'#LDS#Remove mitigating control' | translate\"\r\n      [attr.data-imx-identifier]=\"'mitigating-control-container-button-delete- + index'\"\r\n      mat-button\r\n      *ngIf=\"!mControl.isDeferredData\"\r\n      class=\"mat-icon-button imx-delete-button\"\r\n      (click)=\"onDelete(mControl, i)\"\r\n    >\r\n      <eui-icon icon=\"delete\"></eui-icon>\r\n    </button>\r\n  </div>\r\n  <button\r\n    *ngIf=\"options.length > 0\"\r\n    [matTooltip]=\"'#LDS#Assigns a mitigating control' | translate\"\r\n    data-imx-identifier=\"mitigating-control-container-button-add\"\r\n    [attr.aria-label]=\"'#LDS#Assign mitigating control' | translate\"\r\n    mat-button\r\n    class=\"mat-icon-button\"\r\n    (click)=\"onCreateControl()\"\r\n  >\r\n    <eui-icon icon=\"add\"></eui-icon>\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .eui-sidesheet-actions{padding:16px 20px;display:flex;justify-content:flex-end}:host .imx-helper-alert{margin-bottom:15px}:host .control-container{display:flex;flex-direction:column;overflow:auto}:host .mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}:host .mitigating-control .imx-delete-button{margin-top:15px;align-self:flex-start}:host .mitigating-control .mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px}:host .imx-no-mitigating-controls{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}:host .imx-mitigating-control-content{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:hidden}:host .imx-mitigating-control-content .content{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}:host .imx-data-no-results{text-align:center;margin:20px 0;justify-self:center}:host .imx-data-no-results .eui-icon{font-size:100px}:host .imx-data-no-results p{margin:0;font-size:18px}:host .imx-data-no-results button{margin-top:10px}:host .button-actions{display:flex;justify-content:space-between;margin-top:20px}:host .imx-data-no-results .eui-icon{color:#dfe4e6}:host .imx-data-no-results p{color:#797e80}:host .imx-no-mitigating-controls{color:#797e80}:host .mitigating-control{border-bottom:1px solid #797e80}.eui-dark-theme :host .imx-data-no-results .eui-icon{color:#c4cacc}.eui-dark-theme :host .imx-data-no-results p{color:#dfe4e6}.eui-dark-theme :host .imx-no-mitigating-controls{color:#dfe4e6}.eui-dark-theme :host .mitigating-control{border-bottom:1px solid #dfe4e6}.eui-contrast-theme :host .imx-data-no-results .eui-icon{color:#dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}.eui-contrast-theme :host .imx-no-mitigating-controls{color:#fff}.eui-contrast-theme :host .mitigating-control{border-bottom:1px solid #ffffff}\n"] }]
        }], function () { return [{ type: i0.ChangeDetectorRef }, { type: i2.ConfirmationService }]; }, { mControls: [{
                type: Input
            }], mitigatingCaption: [{
                type: Input
            }], formArray: [{
                type: Input
            }], options: [{
                type: Input
            }], controlDeleted: [{
                type: Output
            }], controlsRequested: [{
                type: Output
            }] });
})();

function MitigatingControlsRequestComponent_div_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can assign mitigating controls to the rule violation. NOTE: If no mitigating controls have been assigned to the violated compliance rule, you cannot assign any mitigating controls to the rule violation either."), " ");
    }
}
function MitigatingControlsRequestComponent_ng_container_10_mat_card_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r8 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-card", 7)(1, "imx-mitigating-control-container", 8);
        i0.ɵɵlistener("controlsRequested", function MitigatingControlsRequestComponent_ng_container_10_mat_card_1_Template_imx_mitigating_control_container_controlsRequested_1_listener() { i0.ɵɵrestoreView(_r8); const ctx_r7 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r7.onCreateControl()); })("controlDeleted", function MitigatingControlsRequestComponent_ng_container_10_mat_card_1_Template_imx_mitigating_control_container_controlDeleted_1_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r9 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r9.onControlDeleted($event)); });
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("mControls", ctx_r6.mControls)("formArray", ctx_r6.formArray)("options", ctx_r6.options);
    }
}
function MitigatingControlsRequestComponent_ng_container_10_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtemplate(1, MitigatingControlsRequestComponent_ng_container_10_mat_card_1_Template, 2, 3, "mat-card", 6);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        const _r4 = i0.ɵɵreference(14);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r1.readOnly)("ngIfElse", _r4);
    }
}
function MitigatingControlsRequestComponent_mat_card_11_button_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 13);
        i0.ɵɵlistener("click", function MitigatingControlsRequestComponent_mat_card_11_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r12); const ctx_r11 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r11.onCreateControl()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Assign mitigating controls"), " ");
    }
}
function MitigatingControlsRequestComponent_mat_card_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 9)(1, "div", 10);
        i0.ɵɵelement(2, "eui-icon", 11);
        i0.ɵɵelementStart(3, "p");
        i0.ɵɵtext(4);
        i0.ɵɵpipe(5, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(6, MitigatingControlsRequestComponent_mat_card_11_button_6_Template, 3, 3, "button", 12);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 2, ctx_r2.options.length > 0 ? "#LDS#There are currently no mitigating controls assigned to this rule violation." : "#LDS#There are currently no mitigating controls that can be assigned to this rule violation."), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r2.options.length > 0);
    }
}
function MitigatingControlsRequestComponent_mat_card_12_Template(rf, ctx) {
    if (rf & 1) {
        const _r14 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-card", 14)(1, "button", 15);
        i0.ɵɵlistener("click", function MitigatingControlsRequestComponent_mat_card_12_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r14); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.onSave()); });
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("disabled", ctx_r3.notSaveable);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Save"), " ");
    }
}
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_1_imx_cdr_editor_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 21);
    }
    if (rf & 2) {
        const mControl_r20 = ctx.$implicit;
        i0.ɵɵproperty("cdr", mControl_r20.cdrs[0]);
    }
}
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-expansion-panel", 19)(1, "mat-expansion-panel-header")(2, "mat-panel-title");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(5, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_1_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 20);
        i0.ɵɵpipe(6, "filtered");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r17 = i0.ɵɵnextContext(3);
        i0.ɵɵproperty("expanded", true);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#Active mitigating controls"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", i0.ɵɵpipeBind2(6, 5, ctx_r17.mControls, "active"));
    }
}
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_2_imx_cdr_editor_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 21);
    }
    if (rf & 2) {
        const mControl_r22 = ctx.$implicit;
        i0.ɵɵproperty("cdr", mControl_r22.cdrs[0]);
    }
}
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-expansion-panel", 19)(1, "mat-expansion-panel-header")(2, "mat-panel-title");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(5, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_2_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 20);
        i0.ɵɵpipe(6, "filtered");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r18 = i0.ɵɵnextContext(3);
        i0.ɵɵproperty("expanded", true);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#Inactive mitigating controls"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", i0.ɵɵpipeBind2(6, 5, ctx_r18.mControls, "inactive"));
    }
}
function MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-accordion", 17);
        i0.ɵɵtemplate(1, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_1_Template, 7, 8, "mat-expansion-panel", 18);
        i0.ɵɵtemplate(2, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_mat_expansion_panel_2_Template, 7, 8, "mat-expansion-panel", 18);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r15 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r15.hasItems("active"));
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r15.hasItems("inactive"));
    }
}
function MitigatingControlsRequestComponent_ng_template_13_mat_card_1_imx_cdr_editor_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 21);
    }
    if (rf & 2) {
        const mControl_r24 = ctx.$implicit;
        i0.ɵɵproperty("cdr", mControl_r24.cdrs[0]);
    }
}
function MitigatingControlsRequestComponent_ng_template_13_mat_card_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card");
        i0.ɵɵtemplate(1, MitigatingControlsRequestComponent_ng_template_13_mat_card_1_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 20);
        i0.ɵɵpipe(2, "filtered");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r16 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", i0.ɵɵpipeBind2(2, 1, ctx_r16.mControls, "deferred"));
    }
}
function MitigatingControlsRequestComponent_ng_template_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, MitigatingControlsRequestComponent_ng_template_13_mat_accordion_0_Template, 3, 2, "mat-accordion", 16);
        i0.ɵɵtemplate(1, MitigatingControlsRequestComponent_ng_template_13_mat_card_1_Template, 3, 4, "mat-card", 2);
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext();
        i0.ɵɵproperty("ngIf", ctx_r5.mControls.length > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r5.hasItems("deferred"));
    }
}
class MitigatingControlsRequestComponent {
    constructor(mControlService, formBuilder, cd, busyService, snackbarService, settingService, confirmationService, entityService) {
        this.mControlService = mControlService;
        this.formBuilder = formBuilder;
        this.cd = cd;
        this.busyService = busyService;
        this.snackbarService = snackbarService;
        this.settingService = settingService;
        this.confirmationService = confirmationService;
        this.entityService = entityService;
        this.subscriptions$ = [];
        this.options = [];
        this.mControls = [];
        this.mControlsToDelete = [];
        this.mitigatingCaption = mControlService.mitigationSchema.Columns.UID_MitigatingControl.Display;
        this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.formGroup.get('formArray');
    }
    hasItems(filter) {
        var _a;
        return ((_a = RequestMitigatingControlFilterPipe.getItems(this.mControls, filter)) === null || _a === void 0 ? void 0 : _a.length) > 0;
    }
    get itemText() {
        return this.mControls.every((elem) => elem.isDeferredData)
            ? '#LDS#The following mitigating controls will be automatically assigned to the rule violation if this request is approved.'
            : '#LDS#The following mitigating controls are assigned to this request.';
    }
    get notSaveable() {
        if (this.mControlsToDelete.length !== 0) {
            this.formGroup.markAsDirty();
        }
        if (!this.formGroup.dirty || !this.formGroup.valid) {
            return true;
        }
        return (this.mControls.length > 0 &&
            this.mControls.every((ctrl) => {
                return !ctrl.editable || ctrl.uidMitigatingControl === null || ctrl.uidMitigatingControl === '';
            }) &&
            this.mControlsToDelete.length === 0);
    }
    get isDirty() {
        return this.formGroup.dirty || this.mControlsToDelete.length > 0;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.subscriptions$.push(this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
                if (!this.isDirty || (yield this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                    this.sidesheetRef.close();
                }
            })));
            this.headertext = !this.readOnly
                ? '#LDS#Heading Mitigating Controls Can Be Assigned Individually'
                : '#LDS#Heading Mitigating Controls';
            yield this.loadMitigatingControls();
        });
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
    onSelectionChange(mcontrol, value) {
        return __awaiter(this, void 0, void 0, function* () {
            mcontrol.UID_MitigatingControl.value = value;
            this.formArray.updateValueAndValidity();
            this.cd.detectChanges();
            return;
        });
    }
    onOpenChange(isopen, mControl) {
        if (!isopen) {
            mControl.formControl.updateValueAndValidity({ onlySelf: true });
        }
    }
    onControlDeleted(mControl) {
        this.mControlsToDelete.push(mControl);
    }
    getMControlId(mControl) {
        return mControl.GetEntity().GetColumn('UID_MitigatingControl').GetValue();
    }
    onCreateControl() {
        return __awaiter(this, void 0, void 0, function* () {
            const mControl = this.mControlService.createControl(this.uidPerson, this.uidNonCompliance);
            this.mControls.push(mControl);
            this.formArray.push(mControl.formControl);
            this.cd.detectChanges();
            mControl.formControl.setValidators([
                Validators.required,
                (control) => (this.isDuplicate(control) ? { duplicated: true } : null),
            ]);
            this.formGroup.markAsDirty();
        });
    }
    onSave() {
        return __awaiter(this, void 0, void 0, function* () {
            const overlay = this.busyService.show();
            try {
                yield this.handleSave();
            }
            finally {
                this.busyService.hide(overlay);
                this.snackbarService.open({
                    key: '#LDS#The mitigating controls have been successfully saved.',
                });
                if (this.closeOnSave) {
                    this.sidesheetRef.close();
                }
            }
        });
    }
    handleSave() {
        return __awaiter(this, void 0, void 0, function* () {
            for (const ctrl of this.mControlsToDelete) {
                yield this.mControlService.deleteControl(ctrl);
            }
            for (const ctrl of this.mControls.filter((elem) => elem.editable)) {
                if (this.uidPersonWantsOrg != null && this.uidPersonWantsOrg !== '') {
                    yield this.mControlService.postControlRequest(this.uidPerson, this.uidNonCompliance, this.uidPersonWantsOrg, ctrl.uidMitigatingControl);
                }
                else {
                    yield this.mControlService.postControl(this.uidPerson, this.uidNonCompliance, ctrl.data);
                }
            }
            if (!this.closeOnSave) {
                this.resetForm();
            }
        });
    }
    resetForm() {
        return __awaiter(this, void 0, void 0, function* () {
            // Since we must handle change detection manually, overwrite formgroup and get read-only mcontrols
            this.formGroup = new UntypedFormGroup({ formArray: this.formBuilder.array([]) });
            this.mControlsToDelete = [];
            yield this.loadMitigatingControls();
            this.cd.detectChanges();
        });
    }
    loadMitigatingControls() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.isMControlPerViolation) {
                this.mControls = [];
                return;
            }
            const overlay = this.busyService.show();
            try {
                //reload
                const data = yield this.mControlService.getControls(this.uidPerson, this.uidNonCompliance);
                this.mControls = data.Data.map((elem) => new RequestMitigatingControls(false, elem));
                this.mControls.push(...data.extendedData.MitigatingControls.map((elem) => new ExtendedDeferredOperationsData(elem, this.entityService)));
                if (!this.readOnly) {
                    this.mControls.forEach((elem) => this.formArray.push(elem.formControl));
                    yield this.initOptions();
                }
            }
            finally {
                this.busyService.hide(overlay);
            }
        });
    }
    isDuplicate(actrl) {
        const test = this.mControls.findIndex((ctrl) => ctrl.formControl != actrl && (ctrl === null || ctrl === void 0 ? void 0 : ctrl.uidMitigatingControl) === actrl.value) !== -1;
        return test;
    }
    initOptions() {
        return __awaiter(this, void 0, void 0, function* () {
            const optionCandidates = yield this.mControlService.getCandidates(this.uidPerson, this.uidNonCompliance, {}, {
                PageSize: this.settingService.PageSizeForAllElements,
            });
            this.options = optionCandidates.Entities.map((elem) => ({ display: elem.Display, value: elem.Keys[0] }));
        });
    }
}
MitigatingControlsRequestComponent.ɵfac = function MitigatingControlsRequestComponent_Factory(t) { return new (t || MitigatingControlsRequestComponent)(i0.ɵɵdirectiveInject(MitigatingControlsRequestService), i0.ɵɵdirectiveInject(i2$1.UntypedFormBuilder), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(i2.EntityService)); };
MitigatingControlsRequestComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsRequestComponent, selectors: [["imx-mitigating-controls-request"]], inputs: { uidPerson: "uidPerson", uidNonCompliance: "uidNonCompliance", uidPersonWantsOrg: "uidPersonWantsOrg", status: "status", sidesheetRef: "sidesheetRef", readOnly: "readOnly", closeOnSave: "closeOnSave", isMControlPerViolation: "isMControlPerViolation" }, decls: 15, vars: 11, consts: [["eui-sidesheet-content", "", 1, "control-container"], ["type", "info", 1, "imx-helper-alert", 3, "colored"], [4, "ngIf"], ["class", "imx-no-mitigating-controls", 4, "ngIf"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["readOnlyView", ""], ["class", "imx-mitigating-control-content", 4, "ngIf", "ngIfElse"], [1, "imx-mitigating-control-content"], [3, "mControls", "formArray", "options", "controlsRequested", "controlDeleted"], [1, "imx-no-mitigating-controls"], [1, "imx-data-no-results"], ["icon", "table"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-request-button-add", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-request-button-add", 3, "click"], ["eui-sidesheet-actions", ""], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-request-button-save", 3, "disabled", "click"], ["multi", "", 4, "ngIf"], ["multi", ""], [3, "expanded", 4, "ngIf"], [3, "expanded"], [3, "cdr", 4, "ngFor", "ngForOf"], [3, "cdr"]], template: function MitigatingControlsRequestComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "eui-alert", 1)(2, "eui-alert-header");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "eui-alert-content");
            i0.ɵɵtemplate(6, MitigatingControlsRequestComponent_div_6_Template, 3, 3, "div", 2);
            i0.ɵɵelementStart(7, "div");
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelementEnd()()();
            i0.ɵɵtemplate(10, MitigatingControlsRequestComponent_ng_container_10_Template, 2, 2, "ng-container", 2);
            i0.ɵɵtemplate(11, MitigatingControlsRequestComponent_mat_card_11_Template, 7, 4, "mat-card", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(12, MitigatingControlsRequestComponent_mat_card_12_Template, 4, 4, "mat-card", 4);
            i0.ɵɵtemplate(13, MitigatingControlsRequestComponent_ng_template_13_Template, 2, 2, "ng-template", null, 5, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("colored", true);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 7, ctx.headertext));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", !ctx.readOnly);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 9, ctx.itemText), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.mControls != null && ctx.mControls.length > 0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.readOnly && ctx.isMControlPerViolation && ctx.options.length > 0);
        }
    }, dependencies: [i2.CdrEditorComponent, i5.NgForOf, i5.NgIf, i3$1.EuiAlertComponent, i3$1.EuiAlertContentDirective, i3$1.EuiAlertHeaderDirective, i3$1.EuiIconComponent, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i6.MatButton, i3$2.MatCard, i9.MatAccordion, i9.MatExpansionPanel, i9.MatExpansionPanelHeader, i9.MatExpansionPanelTitle, MitigatingControlContainerComponent, i4.TranslatePipe, RequestMitigatingControlFilterPipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{padding:16px 20px;display:flex;justify-content:flex-end}[_nghost-%COMP%]   .imx-helper-alert[_ngcontent-%COMP%]{margin-bottom:15px}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   .imx-delete-button[_ngcontent-%COMP%]{margin-top:15px;align-self:flex-start}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   .mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]   .content[_ngcontent-%COMP%]{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0;justify-self:center}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .button-actions[_ngcontent-%COMP%]{display:flex;justify-content:space-between;margin-top:20px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #ffffff}", "[_nghost-%COMP%]   .mitigating-control-readonly[_ngcontent-%COMP%]{margin-bottom:15px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsRequestComponent, [{
            type: Component,
            args: [{ selector: 'imx-mitigating-controls-request', template: "<div class=\"control-container\" eui-sidesheet-content>\r\n  <eui-alert class=\"imx-helper-alert\" type=\"info\" [colored]=\"true\">\r\n    <eui-alert-header>{{ headertext | translate }}</eui-alert-header>\r\n    <eui-alert-content>\r\n      <div *ngIf=\"!readOnly\">\r\n        {{\r\n          '#LDS#Here you can assign mitigating controls to the rule violation. NOTE: If no mitigating controls have been assigned to the violated compliance rule, you cannot assign any mitigating controls to the rule violation either.'\r\n            | translate\r\n        }}\r\n      </div>\r\n      <div>\r\n        {{ itemText | translate }}\r\n      </div>\r\n    </eui-alert-content>\r\n  </eui-alert>\r\n  <ng-container *ngIf=\"mControls != null && mControls.length > 0\">\r\n    <mat-card class=\"imx-mitigating-control-content\" *ngIf=\"!readOnly; else readOnlyView\">\r\n      <imx-mitigating-control-container [mControls]=\"mControls\" [formArray]=\"formArray\" [options]=\"options\" (controlsRequested)=\"onCreateControl()\" (controlDeleted)=\"onControlDeleted($event)\"></imx-mitigating-control-container>\r\n    </mat-card>\r\n  </ng-container>\r\n\r\n  <mat-card class=\"imx-no-mitigating-controls\" *ngIf=\"!mControls || mControls.length == 0\">\r\n    <div class=\"imx-data-no-results\">\r\n      <eui-icon icon=\"table\"></eui-icon>\r\n      <p>\r\n        {{\r\n          (options.length > 0\r\n            ? '#LDS#There are currently no mitigating controls assigned to this rule violation.'\r\n            : '#LDS#There are currently no mitigating controls that can be assigned to this rule violation.'\r\n          ) | translate\r\n        }}\r\n      </p>\r\n      <button *ngIf=\"options.length > 0\" mat-stroked-button color=\"primary\" data-imx-identifier=\"mitigating-controls-request-button-add\" (click)=\"onCreateControl()\">\r\n        {{ '#LDS#Assign mitigating controls' | translate }}\r\n      </button>\r\n    </div>\r\n  </mat-card>\r\n</div>\r\n\r\n<mat-card eui-sidesheet-actions *ngIf=\"!readOnly && isMControlPerViolation && options.length > 0\">\r\n  <button mat-raised-button color=\"primary\" (click)=\"onSave()\" [disabled]=\"notSaveable\" data-imx-identifier=\"mitigating-controls-request-button-save\">\r\n    {{ '#LDS#Save' | translate }}\r\n  </button>\r\n</mat-card>\r\n\r\n<ng-template #readOnlyView>\r\n  <mat-accordion multi *ngIf=\"mControls.length > 0\">\r\n    <mat-expansion-panel [expanded]=\"true\" *ngIf=\"hasItems('active')\">\r\n      <mat-expansion-panel-header>\r\n        <mat-panel-title>\r\n          {{ '#LDS#Active mitigating controls' | translate }}\r\n        </mat-panel-title>\r\n      </mat-expansion-panel-header>\r\n      <imx-cdr-editor *ngFor=\"let mControl of mControls | filtered : 'active'\" [cdr]=\"mControl.cdrs[0]\"></imx-cdr-editor>\r\n    </mat-expansion-panel>\r\n    <mat-expansion-panel [expanded]=\"true\" *ngIf=\"hasItems('inactive')\">\r\n      <mat-expansion-panel-header>\r\n        <mat-panel-title>\r\n          {{ '#LDS#Inactive mitigating controls' | translate }}\r\n        </mat-panel-title>\r\n      </mat-expansion-panel-header>\r\n      <imx-cdr-editor *ngFor=\"let mControl of mControls | filtered : 'inactive'\" [cdr]=\"mControl.cdrs[0]\"></imx-cdr-editor>\r\n    </mat-expansion-panel>\r\n  </mat-accordion>\r\n  <mat-card *ngIf=\"hasItems('deferred')\">\r\n    <imx-cdr-editor *ngFor=\"let mControl of mControls | filtered : 'deferred'\" [cdr]=\"mControl.cdrs[0]\"></imx-cdr-editor>\r\n  </mat-card>\r\n</ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .eui-sidesheet-actions{padding:16px 20px;display:flex;justify-content:flex-end}:host .imx-helper-alert{margin-bottom:15px}:host .control-container{display:flex;flex-direction:column;overflow:auto}:host .mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}:host .mitigating-control .imx-delete-button{margin-top:15px;align-self:flex-start}:host .mitigating-control .mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px}:host .imx-no-mitigating-controls{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}:host .imx-mitigating-control-content{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:hidden}:host .imx-mitigating-control-content .content{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}:host .imx-data-no-results{text-align:center;margin:20px 0;justify-self:center}:host .imx-data-no-results .eui-icon{font-size:100px}:host .imx-data-no-results p{margin:0;font-size:18px}:host .imx-data-no-results button{margin-top:10px}:host .button-actions{display:flex;justify-content:space-between;margin-top:20px}:host .imx-data-no-results .eui-icon{color:#dfe4e6}:host .imx-data-no-results p{color:#797e80}:host .imx-no-mitigating-controls{color:#797e80}:host .mitigating-control{border-bottom:1px solid #797e80}.eui-dark-theme :host .imx-data-no-results .eui-icon{color:#c4cacc}.eui-dark-theme :host .imx-data-no-results p{color:#dfe4e6}.eui-dark-theme :host .imx-no-mitigating-controls{color:#dfe4e6}.eui-dark-theme :host .mitigating-control{border-bottom:1px solid #dfe4e6}.eui-contrast-theme :host .imx-data-no-results .eui-icon{color:#dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}.eui-contrast-theme :host .imx-no-mitigating-controls{color:#fff}.eui-contrast-theme :host .mitigating-control{border-bottom:1px solid #ffffff}\n", "/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host .mitigating-control-readonly{margin-bottom:15px}\n"] }]
        }], function () { return [{ type: MitigatingControlsRequestService }, { type: i2$1.UntypedFormBuilder }, { type: i0.ChangeDetectorRef }, { type: i3$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i2.SettingsService }, { type: i2.ConfirmationService }, { type: i2.EntityService }]; }, { uidPerson: [{
                type: Input
            }], uidNonCompliance: [{
                type: Input
            }], uidPersonWantsOrg: [{
                type: Input
            }], status: [{
                type: Input
            }], sidesheetRef: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], closeOnSave: [{
                type: Input
            }], isMControlPerViolation: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EditMitigatingControlsComponent {
    constructor(sidesheetRef, data) {
        this.sidesheetRef = sidesheetRef;
        this.data = data;
    }
}
EditMitigatingControlsComponent.ɵfac = function EditMitigatingControlsComponent_Factory(t) { return new (t || EditMitigatingControlsComponent)(i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
EditMitigatingControlsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditMitigatingControlsComponent, selectors: [["ng-component"]], decls: 2, vars: 7, consts: [["eui-sidesheet-content", ""], [3, "isMControlPerViolation", "closeOnSave", "uidPerson", "uidNonCompliance", "uidPersonWantsOrg", "sidesheetRef", "readOnly"]], template: function EditMitigatingControlsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "imx-mitigating-controls-request", 1);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("isMControlPerViolation", ctx.data.isMControlPerViolation)("closeOnSave", true)("uidPerson", ctx.data.uidPerson)("uidNonCompliance", ctx.data.uidNonCompliance)("uidPersonWantsOrg", ctx.data.uidPersonWantsOrg)("sidesheetRef", ctx.sidesheetRef)("readOnly", ctx.data.readOnly);
        }
    }, dependencies: [i3$1.EuiSidesheetContentDirective, MitigatingControlsRequestComponent], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{padding:0}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditMitigatingControlsComponent, [{
            type: Component,
            args: [{ template: "<div eui-sidesheet-content>\r\n  <imx-mitigating-controls-request\r\n    [isMControlPerViolation]=\"data.isMControlPerViolation\"\r\n    [closeOnSave]=\"true\"\r\n    [uidPerson]=\"data.uidPerson\"\r\n    [uidNonCompliance]=\"data.uidNonCompliance\"\r\n    [uidPersonWantsOrg]=\"data.uidPersonWantsOrg\"\r\n    [sidesheetRef]=\"sidesheetRef\"\r\n    [readOnly]=\"data.readOnly\"\r\n  ></imx-mitigating-controls-request>\r\n</div>\r\n", styles: [".eui-sidesheet-content{padding:0}\n"] }]
        }], function () {
        return [{ type: i3$1.EuiSidesheetRef }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }];
    }, null);
})();

class ItemValidatorService {
    constructor(api) {
        this.api = api;
    }
    getRules() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.api.typedClient.PortalRules.Get({ PageSize: 1000 });
        });
    }
    getRulesSchema() {
        return this.api.typedClient.PortalRules.GetSchema();
    }
}
ItemValidatorService.ɵfac = function ItemValidatorService_Factory(t) { return new (t || ItemValidatorService)(i0.ɵɵinject(ApiService)); };
ItemValidatorService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ItemValidatorService, factory: ItemValidatorService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ItemValidatorService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: ApiService }]; }, null);
})();

class ComplianceViolationService {
    constructor(api) {
        this.api = api;
    }
    getRequestViolations(pwoId) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.api.client.portal_itshop_requests_compliance_get(pwoId);
        });
    }
    getMitigatingControlsPerViolation() {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.api.client.portal_compliance_config_get()).MitigatingControlsPerViolation;
        });
    }
}
ComplianceViolationService.ɵfac = function ComplianceViolationService_Factory(t) { return new (t || ComplianceViolationService)(i0.ɵɵinject(ApiService)); };
ComplianceViolationService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ComplianceViolationService, factory: ComplianceViolationService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComplianceViolationService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: ApiService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function WorkflowViolationDetailsComponent_mat_expansion_panel_5_ng_container_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 5);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "p", 6);
        i0.ɵɵtext(5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const item_r1 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Affected identity"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", item_r1 == null ? null : item_r1.Columns["UID_PersonRelated"] == null ? null : item_r1.Columns["UID_PersonRelated"].DisplayValue, " ");
    }
}
function WorkflowViolationDetailsComponent_mat_expansion_panel_5_ng_container_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "div", 5);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "p", 6);
        i0.ɵɵtext(5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const item_r1 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Approval procedure"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", item_r1 == null ? null : item_r1.Columns["UID_PWODecisionRule"] == null ? null : item_r1.Columns["UID_PWODecisionRule"].DisplayValue, " ");
    }
}
function WorkflowViolationDetailsComponent_mat_expansion_panel_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-expansion-panel")(1, "mat-expansion-panel-header")(2, "mat-panel-title");
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "mat-panel-description");
        i0.ɵɵtext(5);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(6, WorkflowViolationDetailsComponent_mat_expansion_panel_5_ng_container_6_Template, 6, 4, "ng-container", 4);
        i0.ɵɵtemplate(7, WorkflowViolationDetailsComponent_mat_expansion_panel_5_ng_container_7_Template, 6, 4, "ng-container", 4);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r1 = ctx.$implicit;
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", item_r1 == null ? null : item_r1.Columns["UID_ComplianceRule"] == null ? null : item_r1.Columns["UID_ComplianceRule"].DisplayValue, " ");
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", item_r1 == null ? null : item_r1.Columns["DateHead"] == null ? null : item_r1.Columns["DateHead"].DisplayValue, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", item_r1 == null ? null : item_r1.Columns["UID_PersonRelated"] == null ? null : item_r1.Columns["UID_PersonRelated"].Value);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", item_r1 == null ? null : item_r1.Columns["UID_PWODecisionRule"] == null ? null : item_r1.Columns["UID_PWODecisionRule"].Value);
    }
}
class WorkflowViolationDetailsComponent {
    constructor() {
        this.violations = [];
    }
    ngOnInit() {
        this.violations = this.pwoData.WorkflowHistory.Entities.filter(item => item.Columns['UID_ComplianceRule'].Value);
    }
}
WorkflowViolationDetailsComponent.ɵfac = function WorkflowViolationDetailsComponent_Factory(t) { return new (t || WorkflowViolationDetailsComponent)(); };
WorkflowViolationDetailsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: WorkflowViolationDetailsComponent, selectors: [["imx-workflow-violation-details"]], inputs: { pwoData: "pwoData" }, decls: 6, vars: 7, consts: [["type", "info", 3, "condensed", "colored", "dismissable"], [1, "imx-content-container"], ["multi", "", 1, "imx-accordion"], [4, "ngFor", "ngForOf"], [4, "ngIf"], [1, "imx-label"], [1, "imx-description", "imx-value"]], template: function WorkflowViolationDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "eui-alert", 0);
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 1)(4, "mat-accordion", 2);
            i0.ɵɵtemplate(5, WorkflowViolationDetailsComponent_mat_expansion_panel_5_Template, 8, 4, "mat-expansion-panel", 3);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 5, "#LDS#Here you can get an overview of the rule violations that occurred in the workflow of the request."), "\n");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngForOf", ctx.violations);
        }
    }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiAlertComponent, i9.MatAccordion, i9.MatExpansionPanel, i9.MatExpansionPanelHeader, i9.MatExpansionPanelTitle, i9.MatExpansionPanelDescription, i4.TranslatePipe], styles: [".imx-content-container[_ngcontent-%COMP%]{margin-top:20px}.imx-label[_ngcontent-%COMP%]{color:#797e80;margin-bottom:-10px}.imx-value[_ngcontent-%COMP%]{margin-bottom:20px}.imx-list-value[_ngcontent-%COMP%]{margin-left:20px}.imx-first-section-item[_ngcontent-%COMP%]{margin-top:20px;margin-bottom:10px}.imx-last-section-item[_ngcontent-%COMP%]{margin-bottom:20px}.imx-horizontal-container[_ngcontent-%COMP%]{display:flex;width:100%}.imx-horizontal-container[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{margin-right:20px}.imx-list-container[_ngcontent-%COMP%]{max-height:200px;overflow:auto}.imx-description[_ngcontent-%COMP%]{overflow-wrap:break-word;word-wrap:break-word;hyphens:auto}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-title[_ngcontent-%COMP%], .imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-description[_ngcontent-%COMP%]{flex-basis:0}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-description[_ngcontent-%COMP%]{justify-content:space-between;align-items:center}.imx-no-data[_ngcontent-%COMP%]{text-align:center;margin:20px 0}.imx-no-data[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px;color:#c4cacc8c}.imx-no-data[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px;color:#919799}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(WorkflowViolationDetailsComponent, [{
            type: Component,
            args: [{ selector: 'imx-workflow-violation-details', template: "<eui-alert type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"false\">\r\n  {{ '#LDS#Here you can get an overview of the rule violations that occurred in the workflow of the request.' | translate }}\r\n</eui-alert>\r\n\r\n<div class=\"imx-content-container\">\r\n  <mat-accordion class=\"imx-accordion\" multi>\r\n    <mat-expansion-panel *ngFor=\"let item of violations\">\r\n      <mat-expansion-panel-header>\r\n        <mat-panel-title>\r\n          {{ item?.Columns['UID_ComplianceRule']?.DisplayValue }}\r\n        </mat-panel-title>\r\n        <mat-panel-description>\r\n          {{ item?.Columns['DateHead']?.DisplayValue }}\r\n        </mat-panel-description>\r\n      </mat-expansion-panel-header>\r\n\r\n      <ng-container *ngIf=\"item?.Columns['UID_PersonRelated']?.Value\">\r\n        <div class=\"imx-label\">{{ '#LDS#Affected identity' | translate }}</div>\r\n        <p class=\"imx-description imx-value\">\r\n          {{ item?.Columns['UID_PersonRelated']?.DisplayValue }}\r\n        </p>\r\n      </ng-container>\r\n\r\n      <ng-container *ngIf=\"item?.Columns['UID_PWODecisionRule']?.Value\">\r\n        <div class=\"imx-label\">{{ '#LDS#Approval procedure' | translate }}</div>\r\n        <p class=\"imx-description imx-value\">\r\n          {{ item?.Columns['UID_PWODecisionRule']?.DisplayValue }}\r\n        </p>\r\n      </ng-container>\r\n    </mat-expansion-panel>\r\n  </mat-accordion>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.imx-content-container{margin-top:20px}.imx-label{color:#797e80;margin-bottom:-10px}.imx-value{margin-bottom:20px}.imx-list-value{margin-left:20px}.imx-first-section-item{margin-top:20px;margin-bottom:10px}.imx-last-section-item{margin-bottom:20px}.imx-horizontal-container{display:flex;width:100%}.imx-horizontal-container div{margin-right:20px}.imx-list-container{max-height:200px;overflow:auto}.imx-description{overflow-wrap:break-word;word-wrap:break-word;hyphens:auto}.imx-accordion .mat-expansion-panel-header-title,.imx-accordion .mat-expansion-panel-header-description{flex-basis:0}.imx-accordion .mat-expansion-panel-header-description{justify-content:space-between;align-items:center}.imx-no-data{text-align:center;margin:20px 0}.imx-no-data .eui-icon{font-size:100px;color:#c4cacc8c}.imx-no-data p{margin:0;font-size:18px;color:#919799}\n"] }]
        }], function () { return []; }, { pwoData: [{
                type: Input
            }] });
})();

function ComplianceViolationDetailsComponent_ng_container_1_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 7);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r6.rules.length > 1 ? "#LDS#Here you can get an overview of the rule violations this request may cause." : "#LDS#Here you can see the rule violation this request may cause."), " ");
    }
}
function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_ng_container_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_7_Template(rf, ctx) {
    if (rf & 1) {
        const _r16 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-action-row")(1, "button", 13);
        i0.ɵɵlistener("click", function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_7_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r16); const item_r9 = i0.ɵɵnextContext().$implicit; const ctx_r14 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r14.addMitigationControls(item_r9)); });
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Assign mitigating controls"), " ");
    }
}
function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_8_Template(rf, ctx) {
    if (rf & 1) {
        const _r19 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-action-row")(1, "button", 14);
        i0.ɵɵlistener("click", function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_8_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r19); const item_r9 = i0.ɵɵnextContext().$implicit; const ctx_r17 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r17.addMitigationControls(item_r9)); });
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#View mitigating controls"), " ");
    }
}
const _c0$7 = function (a0) { return { $implicit: a0 }; };
function ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-expansion-panel", 11)(1, "mat-expansion-panel-header")(2, "mat-panel-title");
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "mat-panel-description");
        i0.ɵɵtext(5);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(6, ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_ng_container_6_Template, 1, 0, "ng-container", 12);
        i0.ɵɵtemplate(7, ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_7_Template, 4, 3, "mat-action-row", 1);
        i0.ɵɵtemplate(8, ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_mat_action_row_8_Template, 4, 3, "mat-action-row", 1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r9 = ctx.$implicit;
        const isFirst_r10 = ctx.first;
        const ctx_r8 = i0.ɵɵnextContext(3);
        const _r4 = i0.ɵɵreference(6);
        i0.ɵɵproperty("expanded", isFirst_r10);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", item_r9 == null ? null : item_r9.violationDetail == null ? null : item_r9.violationDetail.DisplayRule, " ");
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", item_r9 == null ? null : item_r9.violationDetail == null ? null : item_r9.violationDetail.DisplayPerson, " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngTemplateOutlet", _r4)("ngTemplateOutletContext", i0.ɵɵpureFunction1(7, _c0$7, item_r9));
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", (item_r9.violationDetail == null ? null : item_r9.violationDetail.IsExceptionApprover) && ctx_r8.isApproval && ctx_r8.mitigatingControlsPerViolation);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r8.isApproval && ctx_r8.mitigatingControlsPerViolation);
    }
}
function ComplianceViolationDetailsComponent_ng_container_1_div_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 8)(1, "mat-accordion", 9);
        i0.ɵɵtemplate(2, ComplianceViolationDetailsComponent_ng_container_1_div_2_mat_expansion_panel_2_Template, 9, 9, "mat-expansion-panel", 10);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r7 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", ctx_r7.rules);
    }
}
function ComplianceViolationDetailsComponent_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtemplate(1, ComplianceViolationDetailsComponent_ng_container_1_eui_alert_1_Template, 3, 6, "eui-alert", 3);
        i0.ɵɵtemplate(2, ComplianceViolationDetailsComponent_ng_container_1_div_2_Template, 3, 1, "div", 6);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.request != null);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.rules.length > 0);
    }
}
function ComplianceViolationDetailsComponent_div_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 15);
        i0.ɵɵelement(1, "eui-icon", 16);
        i0.ɵɵelementStart(2, "p");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 1, "#LDS#No data"));
    }
}
function ComplianceViolationDetailsComponent_eui_alert_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 7);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", false);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, "#LDS#The ad hoc compliance check cannot be run for this request."), " ");
    }
}
function ComplianceViolationDetailsComponent_imx_workflow_violation_details_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-workflow-violation-details", 17);
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵproperty("pwoData", ctx_r3.request == null ? null : ctx_r3.request.pwoData);
    }
}
function ComplianceViolationDetailsComponent_ng_template_5_imx_cdr_editor_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 20);
    }
    if (rf & 2) {
        const ctx_r21 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("cdr", ctx_r21.cdrRuleDisplay);
    }
}
function ComplianceViolationDetailsComponent_ng_template_5_imx_cdr_editor_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 20);
    }
    if (rf & 2) {
        const cdr_r25 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r25);
    }
}
function ComplianceViolationDetailsComponent_ng_template_5_ng_container_2_imx_cdr_editor_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 20);
    }
    if (rf & 2) {
        const cdr_r27 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r27);
    }
}
function ComplianceViolationDetailsComponent_ng_template_5_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtemplate(1, ComplianceViolationDetailsComponent_ng_template_5_ng_container_2_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 19);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const item_r20 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", item_r20 == null ? null : item_r20.cdrLists.sources);
    }
}
function ComplianceViolationDetailsComponent_ng_template_5_ng_container_3_li_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "li", 24);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ceItem_r30 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(ceItem_r30.Display);
    }
}
function ComplianceViolationDetailsComponent_ng_template_5_ng_container_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelement(1, "mat-divider");
        i0.ɵɵelementStart(2, "div", 21);
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "ul", 22);
        i0.ɵɵtemplate(6, ComplianceViolationDetailsComponent_ng_template_5_ng_container_3_li_6_Template, 2, 1, "li", 23);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const item_r20 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#Contributing entitlements"));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngForOf", item_r20.violationDetail.ContributingEntitlements);
    }
}
function ComplianceViolationDetailsComponent_ng_template_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, ComplianceViolationDetailsComponent_ng_template_5_imx_cdr_editor_0_Template, 1, 1, "imx-cdr-editor", 18);
        i0.ɵɵtemplate(1, ComplianceViolationDetailsComponent_ng_template_5_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 19);
        i0.ɵɵtemplate(2, ComplianceViolationDetailsComponent_ng_template_5_ng_container_2_Template, 2, 1, "ng-container", 1);
        i0.ɵɵtemplate(3, ComplianceViolationDetailsComponent_ng_template_5_ng_container_3_Template, 7, 4, "ng-container", 1);
    }
    if (rf & 2) {
        const item_r20 = ctx.$implicit;
        const ctx_r5 = i0.ɵɵnextContext();
        i0.ɵɵproperty("ngIf", ctx_r5.cdrRuleDisplay);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", item_r20 == null ? null : item_r20.cdrLists.common);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", (item_r20 == null ? null : item_r20.cdrLists == null ? null : item_r20.cdrLists.sources == null ? null : item_r20.cdrLists.sources.length) > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", (item_r20 == null ? null : item_r20.violationDetail == null ? null : item_r20.violationDetail.ContributingEntitlements) && (item_r20 == null ? null : item_r20.violationDetail == null ? null : item_r20.violationDetail.ContributingEntitlements.length) > 0);
    }
}
class ComplianceViolationDetailsComponent {
    constructor(validator, complianceApi, loadingService, metaData, entityService, sidesheets, translate, systemInfoService, data) {
        this.validator = validator;
        this.complianceApi = complianceApi;
        this.loadingService = loadingService;
        this.metaData = metaData;
        this.entityService = entityService;
        this.sidesheets = sidesheets;
        this.translate = translate;
        this.systemInfoService = systemInfoService;
        this.data = data;
        this.isApproval = false;
        this.rules = [];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const ref = this.loadingService.show();
            try {
                this.schema = this.validator.getRulesSchema();
                this.isICartItemCheck(this.data) ? yield this.loadCartItemViolations(this.data) : yield this.loadRequestViolations(this.pwoId);
                this.hasRiskIndex = (yield this.systemInfoService.get()).PreProps.includes('RISKINDEX');
                this.checkHistoryForViolations();
                this.mitigatingControlsPerViolation = yield this.complianceApi.getMitigatingControlsPerViolation();
            }
            finally {
                this.loadingService.hide(ref);
            }
        });
    }
    addMitigationControls(item) {
        return __awaiter(this, void 0, void 0, function* () {
            this.sidesheets
                .open(EditMitigatingControlsComponent, {
                title: yield this.translate.get('#LDS#Heading Mitigating Controls').toPromise(),
                subTitle: item.violationDetail.DisplayRule,
                padding: '0px',
                disableClose: true,
                width: 'max(700px, 60%)',
                testId: 'compliance-violation-details-mitigating-sidesheet',
                data: {
                    uidPerson: item.violationDetail.UidPerson,
                    uidNonCompliance: item.violationDetail.UidNonCompliance,
                    uidPersonWantsOrg: item.violationDetail.UidPersonWantsOrg,
                    readOnly: !this.isApproval,
                    isMControlPerViolation: this.mitigatingControlsPerViolation,
                },
            })
                .afterClosed()
                .toPromise();
        });
    }
    getDisplayForSource(item) {
        var _a, _b;
        return (_b = (_a = this.metaData.tables[DbObjectKey.FromXml(item.ObjectKeyEntitlement).TableName]) === null || _a === void 0 ? void 0 : _a.DisplaySingular) !== null && _b !== void 0 ? _b : '';
    }
    loadTableNamesForSources(violations) {
        return __awaiter(this, void 0, void 0, function* () {
            const sourecedRules = violations.filter((elem) => { var _a; return ((_a = elem.Sources) === null || _a === void 0 ? void 0 : _a.length) > 0; });
            if (sourecedRules.length > 0) {
                for (const source of sourecedRules) {
                    yield this.metaData.updateNonExisting(source.Sources.map((item) => DbObjectKey.FromXml(item.ObjectKeyEntitlement).TableName));
                }
            }
        });
    }
    loadCartItemViolations(cartItemCheck) {
        return __awaiter(this, void 0, void 0, function* () {
            let rules = (yield this.validator.getRules()).Data;
            yield this.loadTableNamesForSources(cartItemCheck.Detail.Violations);
            this.rules = [];
            if (cartItemCheck.Detail.Violations.length === 1) {
                this.cdrRuleDisplay = this.getDisplayRuleCdr(undefined, cartItemCheck.Detail.Violations[0]);
            }
            cartItemCheck.Detail.Violations.forEach((item) => __awaiter(this, void 0, void 0, function* () {
                const rule = rules.find((x) => x.GetEntity().GetKeys()[0] === item.UidComplianceRule);
                this.rules.push({
                    rule,
                    violationDetail: item,
                    cdrLists: yield this.buildCdrForViolations(rule, item),
                });
            }));
        });
    }
    loadRequestViolations(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const violations = yield this.complianceApi.getRequestViolations(id);
            yield this.loadTableNamesForSources(violations);
            this.rules = [];
            if (violations.length === 1) {
                this.cdrRuleDisplay = this.getDisplayRuleCdr(undefined, violations[0]);
            }
            violations.forEach((violation) => __awaiter(this, void 0, void 0, function* () {
                this.rules.push({
                    violationDetail: violation,
                    cdrLists: yield this.buildCdrForViolations(undefined, violation),
                });
            }));
        });
    }
    getDisplayRuleCdr(rule, detail) {
        const column = rule
            ? rule.GetEntity().GetColumn('DisplayRule')
            : this.buildColumn('DisplayRule', this.translate.instant('#LDS#Violated compliance rule'), detail.DisplayRule);
        return new BaseReadonlyCdr(column);
    }
    buildCdrForViolations(rule, detail) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const tableName = DbObjectKey.FromXml(detail.ObjectKeyElement).TableName;
            yield this.metaData.updateNonExisting([tableName]);
            const displayTitle = (_a = this.metaData.tables[tableName]) === null || _a === void 0 ? void 0 : _a.DisplaySingular;
            //Build common elments
            const cdrColumns = [
                this.buildColumn('DisplayElement', displayTitle, detail.DisplayElement),
                rule
                    ? rule.GetEntity().GetColumn('Description')
                    : this.buildColumn('Description', this.schema.Columns['Description'].Display, detail.Description),
                this.buildColumn('DisplayPerson', yield this.translate.get('#LDS#Identity').toPromise(), detail.DisplayPerson),
                rule
                    ? rule.GetEntity().GetColumn('RuleNumber')
                    : this.buildColumn('RuleNumber', this.schema.Columns['RuleNumber'].Display, detail.RuleNumber),
            ];
            if (this.hasRiskIndex) {
                cdrColumns.push(rule
                    ? rule.GetEntity().GetColumn('RiskIndex')
                    : this.buildColumn('RiskIndex', this.schema.Columns['RiskIndex'].Display, detail.RiskIndex, ValType.Double));
                if (rule != null &&
                    rule.GetEntity().GetColumn('RiskIndex').GetValue() !== rule.GetEntity().GetColumn('RiskIndexReduced').GetValue()) {
                    cdrColumns.push(rule.GetEntity().GetColumn('RiskIndexReduced'));
                }
                else {
                    if (detail.RiskIndex !== detail.RiskIndexReduced) {
                        cdrColumns.push(this.buildColumn('RiskIndexReduced', this.schema.Columns['RiskIndexReduced'].Display, detail.RiskIndexReduced, ValType.Double));
                    }
                }
            }
            let sources;
            if (((_b = detail.Sources) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                sources = detail.Sources.map((source, index) => new BaseReadonlyCdr(this.buildColumn(`source ${index}`, this.getDisplayForSource(source), source.Display)));
            }
            return { common: cdrColumns.map((column) => new BaseReadonlyCdr(column)), sources };
        });
    }
    buildColumn(columnName, display, value, type = ValType.String) {
        return this.entityService.createLocalEntityColumn({
            ColumnName: columnName,
            Type: type,
            Display: display,
        }, undefined, { Value: value });
    }
    checkHistoryForViolations() {
        var _a;
        if (((_a = this.request) === null || _a === void 0 ? void 0 : _a.pwoData) && this.request.pwoData.WorkflowHistory && this.request.pwoData.WorkflowHistory.Entities) {
            this.request.pwoData.WorkflowHistory.Entities.forEach((wh) => {
                const uid = wh.Columns && wh.Columns['UID_ComplianceRule'] ? wh.Columns['UID_ComplianceRule'].Value : '';
                if (uid.length > 0) {
                    this.request.complianceRuleViolation = true;
                }
            });
        }
    }
    // ICartItemCheck type guard
    isICartItemCheck(obj) {
        return 'Id' in obj && 'Status' in obj && 'Title' in obj && 'ResultText' in obj && 'Detail' in obj;
    }
}
ComplianceViolationDetailsComponent.ɵfac = function ComplianceViolationDetailsComponent_Factory(t) { return new (t || ComplianceViolationDetailsComponent)(i0.ɵɵdirectiveInject(ItemValidatorService), i0.ɵɵdirectiveInject(ComplianceViolationService), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(i2.EntityService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i2.SystemInfoService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
ComplianceViolationDetailsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ComplianceViolationDetailsComponent, selectors: [["imx-compliance-violation-details"]], inputs: { pwoId: "pwoId", request: "request", isApproval: "isApproval" }, decls: 7, vars: 4, consts: [[1, "imx-main-container"], [4, "ngIf"], ["class", "imx-no-data", 4, "ngIf"], ["type", "info", 3, "condensed", "colored", "dismissable", 4, "ngIf"], [3, "pwoData", 4, "ngIf"], ["ruleViolationTemplate", ""], ["class", "imx-content-container", 4, "ngIf"], ["type", "info", 3, "condensed", "colored", "dismissable"], [1, "imx-content-container"], ["multi", "", 1, "imx-accordion"], [3, "expanded", 4, "ngFor", "ngForOf"], [3, "expanded"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["mat-button", "", "color", "primary", "data-imx-identifier", "compliance-violation-datails-edit-mitigating-controls", 3, "click"], ["mat-button", "", "color", "primary", "data-imx-identifier", "compliance-violation-datails-view-mitigating-controls", 3, "click"], [1, "imx-no-data"], ["icon", "table"], [3, "pwoData"], [3, "cdr", 4, "ngIf"], [3, "cdr", 4, "ngFor", "ngForOf"], [3, "cdr"], [1, "imx-label", "imx-first-section-item"], [1, "imx-list-container"], ["class", "imx-list-value", 4, "ngFor", "ngForOf"], [1, "imx-list-value"]], template: function ComplianceViolationDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, ComplianceViolationDetailsComponent_ng_container_1_Template, 3, 2, "ng-container", 1);
            i0.ɵɵtemplate(2, ComplianceViolationDetailsComponent_div_2_Template, 5, 3, "div", 2);
            i0.ɵɵtemplate(3, ComplianceViolationDetailsComponent_eui_alert_3_Template, 3, 6, "eui-alert", 3);
            i0.ɵɵtemplate(4, ComplianceViolationDetailsComponent_imx_workflow_violation_details_4_Template, 1, 1, "imx-workflow-violation-details", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, ComplianceViolationDetailsComponent_ng_template_5_Template, 4, 4, "ng-template", null, 5, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.request == null || (ctx.request == null ? null : ctx.request.UiOrderState.value) === "OrderProduct");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", (ctx.rules == null || ctx.rules.length === 0) && (ctx.request == null ? null : ctx.request.UiOrderState.value) === "OrderProduct");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.request != null && (ctx.request == null ? null : ctx.request.UiOrderState.value) != "OrderProduct" && !(ctx.request == null ? null : ctx.request.complianceRuleViolation));
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.request != null && (ctx.request == null ? null : ctx.request.UiOrderState.value) != "OrderProduct" && (ctx.request == null ? null : ctx.request.complianceRuleViolation));
        }
    }, dependencies: [i2.CdrEditorComponent, i5.NgForOf, i5.NgIf, i5.NgTemplateOutlet, i3$1.EuiAlertComponent, i3$1.EuiIconComponent, i6.MatButton, i8.MatDivider, i9.MatAccordion, i9.MatExpansionPanel, i9.MatExpansionPanelActionRow, i9.MatExpansionPanelHeader, i9.MatExpansionPanelTitle, i9.MatExpansionPanelDescription, WorkflowViolationDetailsComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]     .mat-expansion-panel-body{display:flex;flex-direction:column}.imx-content-container[_ngcontent-%COMP%]{margin-top:20px}.imx-main-container[_ngcontent-%COMP%]{margin:20px}.imx-label[_ngcontent-%COMP%]{color:#797e80;margin-bottom:-10px}.imx-value[_ngcontent-%COMP%]{margin-bottom:20px}.imx-list-value[_ngcontent-%COMP%]{margin-left:20px;list-style-type:disc}.imx-first-section-item[_ngcontent-%COMP%]{margin-top:20px;margin-bottom:10px}.imx-last-section-item[_ngcontent-%COMP%]{margin-bottom:20px}.imx-horizontal-container[_ngcontent-%COMP%]{display:flex;width:100%}.imx-horizontal-container[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{margin-right:20px}.imx-list-container[_ngcontent-%COMP%]{max-height:200px;overflow:auto}.imx-description[_ngcontent-%COMP%]{overflow-wrap:break-word;word-wrap:break-word;hyphens:auto}.mat-card[_ngcontent-%COMP%]   .mat-divider-horizontal[_ngcontent-%COMP%]{position:inherit}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-title[_ngcontent-%COMP%]{flex-basis:70%}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-description[_ngcontent-%COMP%]{flex-basis:30%}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-title[_ngcontent-%COMP%]{font-weight:700}.imx-accordion[_ngcontent-%COMP%]   .mat-expansion-panel-header-description[_ngcontent-%COMP%]{justify-content:end;align-items:center;color:#919799}.imx-no-data[_ngcontent-%COMP%]{text-align:center;margin:20px 0}.imx-no-data[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px;color:#c4cacc8c}.imx-no-data[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px;color:#919799}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComplianceViolationDetailsComponent, [{
            type: Component,
            args: [{ selector: 'imx-compliance-violation-details', template: "<div class=\"imx-main-container\">\r\n  <ng-container *ngIf=\"request == null || request?.UiOrderState.value === 'OrderProduct'\">\r\n    <eui-alert *ngIf=\"request != null\" type=\"info\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"false\">\r\n      {{\r\n        (rules.length > 1 ? '#LDS#Here you can get an overview of the rule violations this request may cause.' : '#LDS#Here you can see the rule violation this request may cause.')\r\n          | translate\r\n      }}\r\n    </eui-alert>\r\n\r\n    <div *ngIf=\"rules.length > 0\" class=\"imx-content-container\">\r\n      <mat-accordion class=\"imx-accordion\" multi>\r\n        <mat-expansion-panel *ngFor=\"let item of rules; let isFirst = first\" [expanded]=\"isFirst\">\r\n          <mat-expansion-panel-header>\r\n            <mat-panel-title>\r\n              {{ item?.violationDetail?.DisplayRule }}\r\n            </mat-panel-title>\r\n            <mat-panel-description>\r\n              {{ item?.violationDetail?.DisplayPerson }}\r\n            </mat-panel-description>\r\n          </mat-expansion-panel-header>\r\n          <ng-container *ngTemplateOutlet=\"ruleViolationTemplate; context: { $implicit: item }\"></ng-container>\r\n          <mat-action-row *ngIf=\"item.violationDetail?.IsExceptionApprover && isApproval && mitigatingControlsPerViolation\">\r\n            <button mat-button color=\"primary\" (click)=\"addMitigationControls(item)\" data-imx-identifier=\"compliance-violation-datails-edit-mitigating-controls\">\r\n              {{ '#LDS#Assign mitigating controls' | translate }}\r\n            </button>\r\n          </mat-action-row>\r\n          <mat-action-row *ngIf=\"!isApproval && mitigatingControlsPerViolation\">\r\n            <button mat-button color=\"primary\" (click)=\"addMitigationControls(item)\" data-imx-identifier=\"compliance-violation-datails-view-mitigating-controls\">\r\n              {{ '#LDS#View mitigating controls' | translate }}\r\n            </button>\r\n          </mat-action-row>\r\n        </mat-expansion-panel>\r\n      </mat-accordion>\r\n    </div>\r\n  </ng-container>\r\n\r\n  <div *ngIf=\"(rules == null || rules.length === 0) && request?.UiOrderState.value === 'OrderProduct'\" class=\"imx-no-data\">\r\n    <eui-icon icon=\"table\"></eui-icon>\r\n    <p>{{ '#LDS#No data' | translate }}</p>\r\n  </div>\r\n\r\n  <eui-alert\r\n    *ngIf=\"request != null && request?.UiOrderState.value != 'OrderProduct' && !request?.complianceRuleViolation\"\r\n    type=\"info\"\r\n    [condensed]=\"true\"\r\n    [colored]=\"true\"\r\n    [dismissable]=\"false\"\r\n  >\r\n    {{ '#LDS#The ad hoc compliance check cannot be run for this request.' | translate }}\r\n  </eui-alert>\r\n\r\n  <imx-workflow-violation-details\r\n    *ngIf=\"request != null && request?.UiOrderState.value != 'OrderProduct' && request?.complianceRuleViolation\"\r\n    [pwoData]=\"request?.pwoData\"\r\n  ></imx-workflow-violation-details>\r\n</div>\r\n\r\n<ng-template #ruleViolationTemplate let-item>\r\n  <imx-cdr-editor *ngIf=\"cdrRuleDisplay\" [cdr]=\"cdrRuleDisplay\"></imx-cdr-editor>\r\n  <imx-cdr-editor *ngFor=\"let cdr of item?.cdrLists.common\" [cdr]=\"cdr\"> </imx-cdr-editor>\r\n\r\n  <ng-container *ngIf=\"item?.cdrLists?.sources?.length > 0\">\r\n    <imx-cdr-editor *ngFor=\"let cdr of item?.cdrLists.sources\" [cdr]=\"cdr\"> </imx-cdr-editor>\r\n  </ng-container>\r\n\r\n  <ng-container *ngIf=\"item?.violationDetail?.ContributingEntitlements && item?.violationDetail?.ContributingEntitlements.length > 0\">\r\n    <mat-divider></mat-divider>\r\n    <div class=\"imx-label imx-first-section-item\">{{ '#LDS#Contributing entitlements' | translate }}</div>\r\n    <ul class=\"imx-list-container\">\r\n      <li *ngFor=\"let ceItem of item.violationDetail.ContributingEntitlements\" class=\"imx-list-value\">{{ ceItem.Display }}</li>\r\n    </ul>\r\n  </ng-container>\r\n</ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host ::ng-deep .mat-expansion-panel-body{display:flex;flex-direction:column}.imx-content-container{margin-top:20px}.imx-main-container{margin:20px}.imx-label{color:#797e80;margin-bottom:-10px}.imx-value{margin-bottom:20px}.imx-list-value{margin-left:20px;list-style-type:disc}.imx-first-section-item{margin-top:20px;margin-bottom:10px}.imx-last-section-item{margin-bottom:20px}.imx-horizontal-container{display:flex;width:100%}.imx-horizontal-container div{margin-right:20px}.imx-list-container{max-height:200px;overflow:auto}.imx-description{overflow-wrap:break-word;word-wrap:break-word;hyphens:auto}.mat-card .mat-divider-horizontal{position:inherit}.imx-accordion .mat-expansion-panel-header-title{flex-basis:70%}.imx-accordion .mat-expansion-panel-header-description{flex-basis:30%}.imx-accordion .mat-expansion-panel-header-title{font-weight:700}.imx-accordion .mat-expansion-panel-header-description{justify-content:end;align-items:center;color:#919799}.imx-no-data{text-align:center;margin:20px 0}.imx-no-data .eui-icon{font-size:100px;color:#c4cacc8c}.imx-no-data p{margin:0;font-size:18px;color:#919799}\n"] }]
        }], function () {
        return [{ type: ItemValidatorService }, { type: ComplianceViolationService }, { type: i3$1.EuiLoadingService }, { type: i2.MetadataService }, { type: i2.EntityService }, { type: i3$1.EuiSidesheetService }, { type: i4.TranslateService }, { type: i2.SystemInfoService }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }];
    }, { pwoId: [{
                type: Input
            }], request: [{
                type: Input
            }], isApproval: [{
                type: Input
            }] });
})();

class CartItemComplianceCheckComponent {
    constructor(sidesheetService, translateService) {
        this.sidesheetService = sidesheetService;
        this.translateService = translateService;
    }
    onOpenDetails() {
        return __awaiter(this, void 0, void 0, function* () {
            this.sidesheetService.open(ComplianceViolationDetailsComponent, {
                title: yield this.translateService.get('#LDS#Heading View Rule Violation Details').toPromise(),
                width: 'max(550px,50%)',
                padding: '0px',
                data: this.check,
                testId: 'cart-item-compliance-violation-details',
            });
        });
    }
}
CartItemComplianceCheckComponent.ɵfac = function CartItemComplianceCheckComponent_Factory(t) { return new (t || CartItemComplianceCheckComponent)(i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService)); };
CartItemComplianceCheckComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CartItemComplianceCheckComponent, selectors: [["imx-cart-item-compliance-check"]], decls: 3, vars: 3, consts: [["data-imx-identifier", "compliance-check-button", "mat-stroked-button", "", 3, "click"]], template: function CartItemComplianceCheckComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function CartItemComplianceCheckComponent_Template_button_click_0_listener() { return ctx.onOpenDetails(); });
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#View violation details"));
        }
    }, dependencies: [i6.MatButton, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;justify-content:flex-end;margin-top:10px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CartItemComplianceCheckComponent, [{
            type: Component,
            args: [{ selector: 'imx-cart-item-compliance-check', template: "<button data-imx-identifier=\"compliance-check-button\" mat-stroked-button (click)=\"onOpenDetails()\">{{'#LDS#View violation details' | translate}}</button>\r\n", styles: [":host{display:flex;justify-content:flex-end;margin-top:10px}\n"] }]
        }], function () { return [{ type: i3$1.EuiSidesheetService }, { type: i4.TranslateService }]; }, null);
})();

class RulesService {
    constructor(apiservice, busyService, appConfig) {
        this.apiservice = apiservice;
        this.busyService = busyService;
        this.appConfig = appConfig;
        this.abortController = new AbortController();
    }
    get ruleSchema() {
        return this.apiservice.typedClient.PortalRules.GetSchema();
    }
    featureConfig() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.client.portal_compliance_config_get();
        });
    }
    getRules(parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.typedClient.PortalRules.Get(parameter, { signal: this.abortController.signal });
        });
    }
    exportRules(parameter) {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_rules_get(Object.assign(Object.assign({}, parameter), { withProperties, PageSize, StartIndex: 0 }));
                }
                else {
                    method = factory.portal_rules_get(Object.assign(Object.assign({}, parameter), { withProperties }));
                }
                return new MethodDefinition(method);
            },
        };
    }
    getDataModel() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.client.portal_rules_datamodel_get();
        });
    }
    ruleReport(uidrule) {
        const path = `rules/${uidrule}/report`;
        return `${this.appConfig.BaseUrl}/portal/${path}`;
    }
    recalculate(uidrule) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.client.portal_rules_recalculate_post(uidrule);
        });
    }
    handleOpenLoader() {
        if (!this.busyIndicator) {
            this.busyIndicator = this.busyService.show();
        }
    }
    handleCloseLoader() {
        if (this.busyIndicator) {
            setTimeout(() => {
                this.busyService.hide(this.busyIndicator);
                this.busyIndicator = undefined;
            });
        }
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
}
RulesService.ɵfac = function RulesService_Factory(t) { return new (t || RulesService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i3$1.EuiLoadingService), i0.ɵɵinject(i2.AppConfigService)); };
RulesService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RulesService, factory: RulesService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: ApiService }, { type: i3$1.EuiLoadingService }, { type: i2.AppConfigService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Class thats extends the {@link PortalRulesMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
class RulesMitigatingControls extends PortalRulesMitigatingcontrols {
    constructor(baseObject) {
        super(baseObject.GetEntity());
        this.baseObject = baseObject;
        this.propertyInfo = this.initPropertyInfo();
    }
    initPropertyInfo() {
        const properties = [
            this.UID_MitigatingControl,
        ];
        return properties
            .map(property => new BaseCdr(property.Column));
    }
}

class MitigatingControlsRulesService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    getControls(uidNonCompliance) {
        return __awaiter(this, void 0, void 0, function* () {
            const collection = yield this.apiService.typedClient.PortalRulesMitigatingcontrols.Get(uidNonCompliance);
            return {
                tableName: collection.tableName,
                totalCount: collection.totalCount,
                Data: collection.Data.map((item) => new RulesMitigatingControls(item))
            };
        });
    }
    createControl(uidCompliance) {
        // TODO: When API can handle permission issues uncomment. PBI: 305793
        const newMControl = this.apiService.typedClient.PortalRulesWorkingcopiesMitigatingcontrols.createEntity({
            Columns: {
                "UID_ComplianceRule": { Value: uidCompliance }
            }
        });
        return new RulesMitigatingControls(newMControl);
        // const newMControl = this.apiService.typedClient.PortalRulesMitigatingcontrols.createEntity({
        //   Columns: {
        //     "UID_ComplianceRule": { Value: uidCompliance }
        //   }
        // });
        // return new RulesMitigatingControls(newMControl);
    }
    postControl(uidNonCompliance, mControl) {
        return __awaiter(this, void 0, void 0, function* () {
            // TODO: When API can handle permission issues uncomment. PBI: 305793
            yield this.apiService.typedClient.PortalRulesWorkingcopiesMitigatingcontrols.Post(uidNonCompliance, mControl);
            // await this.apiService.typedClient.PortalRulesMitigatingcontrols.Post(uidNonCompliance, mControl);
        });
    }
    deleteControl(mControl) {
        return __awaiter(this, void 0, void 0, function* () {
            yield mControl.GetEntity().MarkForDeletion();
            yield mControl.GetEntity().Commit();
        });
    }
}
MitigatingControlsRulesService.ɵfac = function MitigatingControlsRulesService_Factory(t) { return new (t || MitigatingControlsRulesService)(i0.ɵɵinject(ApiService)); };
MitigatingControlsRulesService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: MitigatingControlsRulesService, factory: MitigatingControlsRulesService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsRulesService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: ApiService }]; }, null);
})();

function MitigatingControlsRulesComponent_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 5)(1, "eui-alert-header");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "eui-alert-content");
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Heading Mitigating Controls Can Be Assigned Individually"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Here you can get an overview of the mitigating controls that can be assigned to a violation of this compliance rule."));
    }
}
function MitigatingControlsRulesComponent_eui_alert_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 5)(1, "eui-alert-header");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "eui-alert-content");
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Heading Mitigating Controls Applied Globally"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Here you can get an overview of the mitigating controls that are automatically applied to every violation of this compliance rule."));
    }
}
function MitigatingControlsRulesComponent_mat_card_3_imx_cdr_editor_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r11 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 10);
        i0.ɵɵlistener("controlCreated", function MitigatingControlsRulesComponent_mat_card_3_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r10.formArray.push($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r9 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r9);
    }
}
function MitigatingControlsRulesComponent_mat_card_3_eui_icon_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r14 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-icon", 11);
        i0.ɵɵlistener("click", function MitigatingControlsRulesComponent_mat_card_3_eui_icon_3_Template_eui_icon_click_0_listener() { i0.ɵɵrestoreView(_r14); const ctx_r13 = i0.ɵɵnextContext(); const mControl_r5 = ctx_r13.$implicit; const i_r6 = ctx_r13.index; const ctx_r12 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r12.onDelete(mControl_r5, i_r6)); });
        i0.ɵɵelementEnd();
    }
}
function MitigatingControlsRulesComponent_mat_card_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 6)(1, "div", 7);
        i0.ɵɵtemplate(2, MitigatingControlsRulesComponent_mat_card_3_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 8);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(3, MitigatingControlsRulesComponent_mat_card_3_eui_icon_3_Template, 1, 0, "eui-icon", 9);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const mControl_r5 = ctx.$implicit;
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", mControl_r5.propertyInfo);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r2.canEdit);
    }
}
function MitigatingControlsRulesComponent_mat_card_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card")(1, "div", 12);
        i0.ɵɵelement(2, "eui-icon", 13);
        i0.ɵɵelementStart(3, "p");
        i0.ɵɵtext(4);
        i0.ɵɵpipe(5, "translate");
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 1, "#LDS#Currently, no mitigating controls are assigned to this compliance rule."));
    }
}
function MitigatingControlsRulesComponent_mat_card_5_Template(rf, ctx) {
    if (rf & 1) {
        const _r16 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-card", 14)(1, "button", 15);
        i0.ɵɵlistener("click", function MitigatingControlsRulesComponent_mat_card_5_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r16); const ctx_r15 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r15.onCreateControl()); });
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "button", 16);
        i0.ɵɵlistener("click", function MitigatingControlsRulesComponent_mat_card_5_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r16); const ctx_r17 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r17.onSave()); });
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 3, "#LDS#Assign mitigating controls"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", ctx_r4.formGroup.pristine || ctx_r4.formGroup.invalid || ctx_r4.formArray.length === 0);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 5, "#LDS#Save"), " ");
    }
}
class MitigatingControlsRulesComponent {
    constructor(mControlService, formBuilder, cd, busyService, snackbarService, confirmationService) {
        this.mControlService = mControlService;
        this.formBuilder = formBuilder;
        this.cd = cd;
        this.busyService = busyService;
        this.snackbarService = snackbarService;
        this.confirmationService = confirmationService;
        this.canEdit = true;
        this.subscriptions$ = [];
        this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.formGroup.get('formArray');
    }
    ngOnInit() {
        this.subscriptions$.push(this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
            if (!this.formGroup.dirty || (yield this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close();
            }
        })));
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
    getMControlId(mControl) {
        return mControl.GetEntity().GetColumn('UID_MitigatingControl').GetValue();
    }
    onCreateControl() {
        const mControl = this.mControlService.createControl(this.uidCompliance);
        this.mControls.push(mControl);
        this.formGroup.markAsDirty();
        this.cd.detectChanges();
    }
    onDelete(mControl, index) {
        return __awaiter(this, void 0, void 0, function* () {
            if (mControl.GetEntity().GetKeys()) {
                // Only call delete if the control exists on the server
                this.busyService.show();
                try {
                    yield this.mControlService.deleteControl(mControl);
                }
                finally {
                    this.busyService.hide();
                }
            }
            this.formArray.removeAt(index);
            this.mControls.splice(index, 1);
            this.cd.detectChanges();
        });
    }
    hasDuplicates() {
        const values = this.mControls.map((mControl) => this.getMControlId(mControl));
        const uniqueValues = [...new Set(values)];
        return values.length !== uniqueValues.length;
    }
    onSave() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.hasDuplicates()) {
                yield this.confirmationService.confirmGeneral({
                    ShowOk: true,
                    Title: '#LDS#Heading Mitigating Control Assigned More Than Once',
                    Message: '#LDS#Saving is not possible. At least one mitigating control is assigned more than once. Remove the multiple assigned mitigating control and try again.',
                });
                return;
            }
            this.busyService.show();
            try {
                yield this.handleSave();
            }
            finally {
                this.busyService.hide();
                this.snackbarService.open({
                    key: '#LDS#The mitigating controls have been successfully saved.',
                });
            }
        });
    }
    handleSave() {
        var e_1, _a;
        return __awaiter(this, void 0, void 0, function* () {
            try {
                for (var _b = __asyncValues(this.mControls.entries()), _c; _c = yield _b.next(), !_c.done;) {
                    const [index, mControl] = _c.value;
                    if (this.formArray.controls[index].dirty) {
                        // Only save if the form array is dirty
                        const _ = yield this.mControlService.postControl(this.uidNonCompliance, mControl.baseObject);
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) yield _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            this.resetForm();
        });
    }
    resetForm() {
        return __awaiter(this, void 0, void 0, function* () {
            // Since we must handle change detection manually, overwrite formgroup and get read-only mcontrols
            this.formGroup = new UntypedFormGroup({ formArray: this.formBuilder.array([]) });
            this.mControls = (yield this.mControlService.getControls(this.uidNonCompliance)).Data;
            this.cd.detectChanges();
        });
    }
}
MitigatingControlsRulesComponent.ɵfac = function MitigatingControlsRulesComponent_Factory(t) { return new (t || MitigatingControlsRulesComponent)(i0.ɵɵdirectiveInject(MitigatingControlsRulesService), i0.ɵɵdirectiveInject(i2$1.UntypedFormBuilder), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
MitigatingControlsRulesComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsRulesComponent, selectors: [["imx-mitigating-controls-rules"]], inputs: { isMControlPerViolation: "isMControlPerViolation", uidNonCompliance: "uidNonCompliance", uidCompliance: "uidCompliance", mControls: "mControls", sidesheetRef: "sidesheetRef", canEdit: "canEdit" }, decls: 6, vars: 5, consts: [[1, "control-container"], ["class", "imx-helper-alert", "type", "info", "condensed", "true", "colored", "true", 4, "ngIf"], ["class", "mitigating-control", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["eui-sidesheet-actions", "", "class", "button-actions", 4, "ngIf"], ["type", "info", "condensed", "true", "colored", "true", 1, "imx-helper-alert"], [1, "mitigating-control"], [1, "mitigating-control-properties"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["icon", "delete", 3, "click", 4, "ngIf"], [3, "cdr", "controlCreated"], ["icon", "delete", 3, "click"], [1, "imx-no-mitigating-controls"], ["icon", "table"], ["eui-sidesheet-actions", "", 1, "button-actions"], ["mat-stroked-button", "", "data-imx-identifier", "mitigating-controls-button-add", 3, "click"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-rules-button-save", 3, "disabled", "click"]], template: function MitigatingControlsRulesComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, MitigatingControlsRulesComponent_eui_alert_1_Template, 7, 6, "eui-alert", 1);
            i0.ɵɵtemplate(2, MitigatingControlsRulesComponent_eui_alert_2_Template, 7, 6, "eui-alert", 1);
            i0.ɵɵtemplate(3, MitigatingControlsRulesComponent_mat_card_3_Template, 4, 2, "mat-card", 2);
            i0.ɵɵtemplate(4, MitigatingControlsRulesComponent_mat_card_4_Template, 6, 3, "mat-card", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, MitigatingControlsRulesComponent_mat_card_5_Template, 7, 7, "mat-card", 4);
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.isMControlPerViolation);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.isMControlPerViolation);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.mControls);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.canEdit);
        }
    }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiAlertComponent, i3$1.EuiAlertContentDirective, i3$1.EuiAlertHeaderDirective, i3$1.EuiIconComponent, i3$1.EuiSidesheetActionsDirective, i2.CdrEditorComponent, i6.MatButton, i3$2.MatCard, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .imx-helper-alert[_ngcontent-%COMP%]{margin:0 0 20px auto;width:100%}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{padding:20px;display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   .mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{cursor:pointer;display:flex;flex-direction:column;justify-content:center}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{text-align:center;margin:20px 0}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px;color:#c4cacc8c}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px;color:#919799}[_nghost-%COMP%]   .button-actions[_ngcontent-%COMP%]{display:flex;justify-content:space-between;margin-top:20px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsRulesComponent, [{
            type: Component,
            args: [{ selector: 'imx-mitigating-controls-rules', template: "<div class=\"control-container\">\r\n  <eui-alert class=\"imx-helper-alert\" type=\"info\" condensed=\"true\" colored=\"true\" *ngIf=\"isMControlPerViolation\">\r\n    <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Can Be Assigned Individually' | translate }}</eui-alert-header>\r\n    <eui-alert-content>{{\r\n      '#LDS#Here you can get an overview of the mitigating controls that can be assigned to a violation of this compliance rule.' | translate\r\n    }}</eui-alert-content>\r\n  </eui-alert>\r\n  <eui-alert class=\"imx-helper-alert\" type=\"info\" condensed=\"true\" colored=\"true\" *ngIf=\"!isMControlPerViolation\">\r\n    <eui-alert-header>{{'#LDS#Heading Mitigating Controls Applied Globally' | translate}}</eui-alert-header>\r\n    <eui-alert-content>{{ '#LDS#Here you can get an overview of the mitigating controls that are automatically applied to every violation of this compliance rule.' | translate }}</eui-alert-content>\r\n  </eui-alert>\r\n  <mat-card class=\"mitigating-control\" *ngFor=\"let mControl of mControls; let i = index\">\r\n    <div class=\"mitigating-control-properties\">\r\n      <imx-cdr-editor *ngFor=\"let cdr of mControl.propertyInfo\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"></imx-cdr-editor>\r\n    </div>\r\n\r\n    <eui-icon *ngIf=\"canEdit\" icon=\"delete\" (click)=\"onDelete(mControl, i)\"></eui-icon>\r\n  </mat-card>\r\n\r\n  <mat-card *ngIf=\"!mControls || mControls.length == 0\">\r\n    <div class=\"imx-no-mitigating-controls\">\r\n      <eui-icon icon=\"table\"></eui-icon>\r\n      <p>{{ '#LDS#Currently, no mitigating controls are assigned to this compliance rule.' | translate }}</p>\r\n    </div>\r\n  </mat-card>\r\n</div>\r\n\r\n<mat-card *ngIf=\"canEdit\" eui-sidesheet-actions class=\"button-actions\">\r\n  <button mat-stroked-button data-imx-identifier=\"mitigating-controls-button-add\" (click)=\"onCreateControl()\">\r\n    {{ '#LDS#Assign mitigating controls' | translate }}\r\n  </button>\r\n  <button\r\n    mat-raised-button\r\n    color=\"primary\"\r\n    (click)=\"onSave()\"\r\n    [disabled]=\"formGroup.pristine || formGroup.invalid || formArray.length === 0\"\r\n    data-imx-identifier=\"mitigating-controls-rules-button-save\"\r\n  >\r\n    {{ '#LDS#Save' | translate }}\r\n  </button>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .imx-helper-alert{margin:0 0 20px auto;width:100%}:host .control-container{padding:20px;display:flex;flex-direction:column;overflow:auto}:host .mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between}:host .mitigating-control .mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px}:host .mitigating-control eui-icon{cursor:pointer;display:flex;flex-direction:column;justify-content:center}:host .imx-no-mitigating-controls{text-align:center;margin:20px 0}:host .imx-no-mitigating-controls .eui-icon{font-size:100px;color:#c4cacc8c}:host .imx-no-mitigating-controls p{margin:0;font-size:18px;color:#919799}:host .button-actions{display:flex;justify-content:space-between;margin-top:20px}\n"] }]
        }], function () { return [{ type: MitigatingControlsRulesService }, { type: i2$1.UntypedFormBuilder }, { type: i0.ChangeDetectorRef }, { type: i3$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i2.ConfirmationService }]; }, { isMControlPerViolation: [{
                type: Input
            }], uidNonCompliance: [{
                type: Input
            }], uidCompliance: [{
                type: Input
            }], mControls: [{
                type: Input
            }], sidesheetRef: [{
                type: Input
            }], canEdit: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesViolationsMultiActionComponent_imx_cdr_editor_9_Template(rf, ctx) {
    if (rf & 1) {
        const _r6 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 5);
        i0.ɵɵlistener("controlCreated", function RulesViolationsMultiActionComponent_imx_cdr_editor_9_Template_imx_cdr_editor_controlCreated_0_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r6); const cdr_r3 = restoredCtx.$implicit; const i_r4 = restoredCtx.index; const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.onFormControlCreated(cdr_r3.column.ColumnName + "_" + i_r4, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r3 = ctx.$implicit;
        const i_r4 = ctx.index;
        i0.ɵɵproperty("cdr", cdr_r3);
        i0.ɵɵattribute("data-imx-identifier", "rules-violations-multi-action-" + cdr_r3.column.ColumnName + "-" + i_r4);
    }
}
function RulesViolationsMultiActionComponent_mat_list_item_16_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-list-item")(1, "div", 6);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "div", 7);
        i0.ɵɵtext(4);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ruleViolationApproval_r7 = ctx.$implicit;
        let tmp_0_0;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", ruleViolationApproval_r7 == null ? null : (tmp_0_0 = ruleViolationApproval_r7.GetEntity()) == null ? null : tmp_0_0.GetDisplay(), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", ruleViolationApproval_r7 == null ? null : ruleViolationApproval_r7.stateBadge == null ? null : ruleViolationApproval_r7.stateBadge.caption, " ");
    }
}
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a multiple rules violations.
 * There is an alternative component for the case of a decision for a single rules
 * violation as well: {@link RulesViolationsSingleActionComponent}.
 */
class RulesViolationsMultiActionComponent {
    constructor() {
        /**
         * @ignore since this is only public because of databinding to the template
         *
         * The references depending on the columns of the rules violations that are displayed/edited during the decision.
         *
         */
        this.columns = [];
    }
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit() {
        if (this.data.actionParameters.validUntil) {
            this.columns.push(this.data.actionParameters.validUntil);
        }
        if (this.data.actionParameters.justification) {
            this.columns.push(this.data.actionParameters.justification);
        }
        this.columns.push(this.data.actionParameters.reason);
    }
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name, control) {
        // use setTimeout to make addControl asynchronous in order to avoid "NG0100: Expression has changed after it was checked"
        setTimeout(() => this.formGroup.addControl(name, control));
    }
}
RulesViolationsMultiActionComponent.ɵfac = function RulesViolationsMultiActionComponent_Factory(t) { return new (t || RulesViolationsMultiActionComponent)(); };
RulesViolationsMultiActionComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsMultiActionComponent, selectors: [["imx-rules-violations-multi-action"]], inputs: { data: "data", formGroup: "formGroup" }, decls: 17, vars: 11, consts: [[1, "imx-rules-violations-parameters"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [1, "imx-list"], ["list", ""], [4, "ngFor", "ngForOf"], [3, "cdr", "controlCreated"], ["mat-line", ""], ["mat-line", "", 1, "imx-list-item-subtitle"]], template: function RulesViolationsMultiActionComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-card-subtitle");
            i0.ɵɵtext(5);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-card-content")(8, "div", 0);
            i0.ɵɵtemplate(9, RulesViolationsMultiActionComponent_imx_cdr_editor_9_Template, 1, 2, "imx-cdr-editor", 1);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(10, "mat-card", 2)(11, "mat-card-title");
            i0.ɵɵtext(12);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(14, "mat-list", null, 3);
            i0.ɵɵtemplate(16, RulesViolationsMultiActionComponent_mat_list_item_16_Template, 5, 2, "mat-list-item", 4);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 5, "#LDS#Heading General Settings"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 7, "#LDS#Here you can make settings that are applied to each selected rule violation."), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngForOf", ctx.columns);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 9, "#LDS#Selected rules violations"), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngForOf", ctx.data == null ? null : ctx.data.rulesViolationsApprovals);
        }
    }, dependencies: [i2.CdrEditorComponent, i5.NgForOf, i3$2.MatCard, i3$2.MatCardContent, i3$2.MatCardTitle, i3$2.MatCardSubtitle, i4$1.MatLine, i5$2.MatList, i5$2.MatListItem, i4.TranslatePipe], styles: ["mat-card[_ngcontent-%COMP%]{margin-bottom:20px;display:flex;flex-direction:column}mat-card[_ngcontent-%COMP%]   .mat-card-title[_ngcontent-%COMP%]{font-size:20px}mat-card[_ngcontent-%COMP%] > .mat-selection-list[_ngcontent-%COMP%]{overflow:auto}.imx-items-title[_ngcontent-%COMP%]{font-size:16px}.imx-list[_ngcontent-%COMP%]{overflow:hidden;margin-bottom:10px}.imx-list[_ngcontent-%COMP%]   .mat-list[_ngcontent-%COMP%]{overflow:auto}.imx-list[_ngcontent-%COMP%]   mat-list-item[_ngcontent-%COMP%]{font-size:14px;height:auto;margin-bottom:10px}.imx-list[_ngcontent-%COMP%]   mat-list-item[_ngcontent-%COMP%]   .mat-line[_ngcontent-%COMP%]{white-space:normal}.imx-list[_ngcontent-%COMP%]   mat-list-item[_ngcontent-%COMP%]   .imx-list-item-subtitle[_ngcontent-%COMP%]{font-size:smaller;font-style:italic;color:#919799}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsMultiActionComponent, [{
            type: Component,
            args: [{ selector: 'imx-rules-violations-multi-action', template: "<mat-card>\r\n  <mat-card-title>\r\n    {{ '#LDS#Heading General Settings' | translate }}\r\n  </mat-card-title>\r\n  <mat-card-subtitle>\r\n    {{ '#LDS#Here you can make settings that are applied to each selected rule violation.' | translate }}\r\n  </mat-card-subtitle>\r\n  <mat-card-content>\r\n    <div class=\"imx-rules-violations-parameters\">\r\n      <imx-cdr-editor *ngFor=\"let cdr of columns; let i = index\" [cdr]=\"cdr\"\r\n        (controlCreated)=\"onFormControlCreated(cdr.column.ColumnName + '_' + i, $event)\"\r\n        [attr.data-imx-identifier]=\"'rules-violations-multi-action-' + cdr.column.ColumnName + '-' + i\">\r\n      </imx-cdr-editor>\r\n    </div>\r\n  </mat-card-content>\r\n</mat-card>\r\n<mat-card class=\"imx-list\">\r\n  <mat-card-title>\r\n    {{ '#LDS#Selected rules violations' | translate }}\r\n  </mat-card-title>\r\n  <mat-list #list>\r\n    <mat-list-item *ngFor=\"let ruleViolationApproval of data?.rulesViolationsApprovals\">\r\n      <div mat-line>\r\n        {{ ruleViolationApproval?.GetEntity()?.GetDisplay() }}\r\n      </div>\r\n      <div mat-line class=\"imx-list-item-subtitle\">\r\n        {{ ruleViolationApproval?.stateBadge?.caption }}\r\n      </div>\r\n    </mat-list-item>\r\n  </mat-list>\r\n</mat-card>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */mat-card{margin-bottom:20px;display:flex;flex-direction:column}mat-card .mat-card-title{font-size:20px}mat-card>.mat-selection-list{overflow:auto}.imx-items-title{font-size:16px}.imx-list{overflow:hidden;margin-bottom:10px}.imx-list .mat-list{overflow:auto}.imx-list mat-list-item{font-size:14px;height:auto;margin-bottom:10px}.imx-list mat-list-item .mat-line{white-space:normal}.imx-list mat-list-item .imx-list-item-subtitle{font-size:smaller;font-style:italic;color:#919799}\n"] }]
        }], null, { data: [{
                type: Input
            }], formGroup: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesViolationsSingleActionComponent_imx_cdr_editor_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r4 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 1);
        i0.ɵɵlistener("controlCreated", function RulesViolationsSingleActionComponent_imx_cdr_editor_6_Template_imx_cdr_editor_controlCreated_0_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r4); const cdr_r1 = restoredCtx.$implicit; const i_r2 = restoredCtx.index; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onFormControlCreated(cdr_r1.column.ColumnName + "_" + i_r2, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r1 = ctx.$implicit;
        const i_r2 = ctx.index;
        i0.ɵɵproperty("cdr", cdr_r1);
        i0.ɵɵattribute("data-imx-identifier", "rules-violations-single-action-" + cdr_r1.column.ColumnName + "-" + i_r2);
    }
}
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a single rules violation.
 * There is an alternative component for the case of a decision for multiple rules
 * violations as well: {@link RulesViolationsMultiActionComponent}.
 */
class RulesViolationsSingleActionComponent {
    constructor() {
        /**
         * @ignore since this is only public because of databinding to the template
         *
         * The references depending on the columns of the rules violation that are displayed/edited during the decision.
         *
         */
        this.columns = [];
    }
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit() {
        this.rulesViolation = this.data.rulesViolationsApprovals[0];
        if (this.data.actionParameters.validUntil) {
            this.columns.push(this.data.actionParameters.validUntil);
        }
        if (this.data.actionParameters.justification) {
            this.columns.push(this.data.actionParameters.justification);
        }
        this.columns.push(this.data.actionParameters.reason);
    }
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name, control) {
        // use setTimeout to make addControl asynchronous in order to avoid "NG0100: Expression has changed after it was checked"
        setTimeout(() => this.formGroup.addControl(name, control));
    }
}
RulesViolationsSingleActionComponent.ɵfac = function RulesViolationsSingleActionComponent_Factory(t) { return new (t || RulesViolationsSingleActionComponent)(); };
RulesViolationsSingleActionComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsSingleActionComponent, selectors: [["imx-rules-violations-single-action"]], inputs: { data: "data", formGroup: "formGroup" }, decls: 7, vars: 3, consts: [[3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [3, "cdr", "controlCreated"]], template: function RulesViolationsSingleActionComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card-subtitle");
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card-content");
            i0.ɵɵtemplate(6, RulesViolationsSingleActionComponent_imx_cdr_editor_6_Template, 1, 2, "imx-cdr-editor", 0);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            let tmp_0_0;
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate((tmp_0_0 = ctx.rulesViolation.GetEntity()) == null ? null : tmp_0_0.GetDisplay());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.rulesViolation == null ? null : ctx.rulesViolation.stateBadge == null ? null : ctx.rulesViolation.stateBadge.caption);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", ctx.columns);
        }
    }, dependencies: [i2.CdrEditorComponent, i5.NgForOf, i3$2.MatCard, i3$2.MatCardContent, i3$2.MatCardTitle, i3$2.MatCardSubtitle], styles: ["mat-card-content[_ngcontent-%COMP%]{overflow:hidden}mat-card-title[_ngcontent-%COMP%]{font-size:16px}mat-card-subtitle[_ngcontent-%COMP%]{font-size:15px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsSingleActionComponent, [{
            type: Component,
            args: [{ selector: 'imx-rules-violations-single-action', template: "<mat-card>\r\n  <mat-card-title>{{ rulesViolation.GetEntity()?.GetDisplay() }}</mat-card-title>\r\n  <mat-card-subtitle>{{ rulesViolation?.stateBadge?.caption }}</mat-card-subtitle>\r\n  <mat-card-content>\r\n    <imx-cdr-editor *ngFor=\"let cdr of columns; let i = index\" [cdr]=\"cdr\"\r\n      (controlCreated)=\"onFormControlCreated(cdr.column.ColumnName + '_' + i, $event)\"\r\n      [attr.data-imx-identifier]=\"'rules-violations-single-action-' + cdr.column.ColumnName + '-' + i\">\r\n    </imx-cdr-editor>\r\n  </mat-card-content>\r\n</mat-card>", styles: ["mat-card-content{overflow:hidden}mat-card-title{font-size:16px}mat-card-subtitle{font-size:15px}\n"] }]
        }], null, { data: [{
                type: Input
            }], formGroup: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesViolationsActionComponent_p_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "p");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, ctx_r0.data.description));
    }
}
function RulesViolationsActionComponent_ng_container_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelement(1, "imx-rules-violations-multi-action", 5);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r1.formGroup)("data", ctx_r1.data);
    }
}
function RulesViolationsActionComponent_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelement(1, "imx-rules-violations-single-action", 5);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r2.formGroup)("data", ctx_r2.data);
    }
}
function RulesViolationsActionComponent_button_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r5 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 6);
        i0.ɵɵlistener("click", function RulesViolationsActionComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r5); const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.sideSheetRef.close(true)); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵproperty("disabled", ctx_r3.formGroup.invalid);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Save"), " ");
    }
}
/**
 * Component displayed in a sidesheet to make a decision for one or more rules violations.
 *
 * Uses two alternate views
 * <ul>
 * <li>a) a simple view for a single rules violation</li>
 * <li>b) a complex view using bulk items for multiple rules violations.</li>
 * </ul>
 */
class RulesViolationsActionComponent {
    /**
     * Creates a new RulesViolationsActionComponent
     * @param data The pre-calculated data object.
     * @param sideSheetRef A reference to the sidesheet containing this component.
     */
    constructor(data, sideSheetRef) {
        this.data = data;
        this.sideSheetRef = sideSheetRef;
        /**
         * The form group to which the created form controls will be added.
         */
        this.formGroup = new UntypedFormGroup({});
    }
}
RulesViolationsActionComponent.ɵfac = function RulesViolationsActionComponent_Factory(t) { return new (t || RulesViolationsActionComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef)); };
RulesViolationsActionComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsActionComponent, selectors: [["imx-rules-violations-action"]], decls: 7, vars: 5, consts: [["eui-sidesheet-content", ""], [4, "ngIf"], [1, "imx-rules-violations-action-form", 3, "formGroup"], ["eui-sidesheet-actions", ""], ["data-imx-identifier", "rules-violations-action-button-save", "mat-raised-button", "", "color", "primary", 3, "disabled", "click", 4, "ngIf"], [3, "formGroup", "data"], ["data-imx-identifier", "rules-violations-action-button-save", "mat-raised-button", "", "color", "primary", 3, "disabled", "click"]], template: function RulesViolationsActionComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, RulesViolationsActionComponent_p_1_Template, 3, 3, "p", 1);
            i0.ɵɵelementStart(2, "form", 2);
            i0.ɵɵtemplate(3, RulesViolationsActionComponent_ng_container_3_Template, 2, 2, "ng-container", 1);
            i0.ɵɵtemplate(4, RulesViolationsActionComponent_ng_container_4_Template, 2, 2, "ng-container", 1);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "div", 3);
            i0.ɵɵtemplate(6, RulesViolationsActionComponent_button_6_Template, 3, 4, "button", 4);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.description);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("formGroup", ctx.formGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.rulesViolationsApprovals.length > 1);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.rulesViolationsApprovals.length === 1);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.formGroup);
        }
    }, dependencies: [i5.NgIf, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i6.MatButton, i2$1.ɵNgNoValidate, i2$1.NgControlStatusGroup, i2$1.FormGroupDirective, RulesViolationsMultiActionComponent, RulesViolationsSingleActionComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]   .imx-rules-violations-action-form[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]   .imx-rules-violations-action-form[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsActionComponent, [{
            type: Component,
            args: [{ selector: 'imx-rules-violations-action', template: "<div eui-sidesheet-content>\r\n  <p *ngIf=\"data.description\">{{ data.description | translate }}</p>\r\n  <form [formGroup]=\"formGroup\" class=\"imx-rules-violations-action-form\">\r\n    <ng-container *ngIf=\"data.rulesViolationsApprovals.length > 1\">\r\n      <imx-rules-violations-multi-action [formGroup]=\"formGroup\" [data]=\"data\">\r\n      </imx-rules-violations-multi-action>\r\n    </ng-container>\r\n    <ng-container *ngIf=\"data.rulesViolationsApprovals.length === 1\">\r\n      <imx-rules-violations-single-action [formGroup]=\"formGroup\" [data]=\"data\">\r\n      </imx-rules-violations-single-action>\r\n    </ng-container>\r\n  </form>\r\n</div>\r\n<div eui-sidesheet-actions >\r\n  <button data-imx-identifier=\"rules-violations-action-button-save\" mat-raised-button color=\"primary\"\r\n    (click)=\"sideSheetRef.close(true)\" *ngIf=\"formGroup\" [disabled]=\"formGroup.invalid\">\r\n    {{ '#LDS#Save' | translate }}\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host .eui-sidesheet-content{display:flex;flex-direction:column}:host .eui-sidesheet-content .imx-rules-violations-action-form{display:flex;flex-direction:column;overflow:auto}:host .eui-sidesheet-content .imx-rules-violations-action-form>*{display:flex;flex-direction:column;overflow:auto}:host .eui-sidesheet-content .eui-sidesheet-actions .justify-start{margin-right:auto}:host .eui-sidesheet-content .eui-sidesheet-actions button:not(:last-of-type):not(.justify-start){margin-right:10px}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i3$1.EuiSidesheetRef }];
    }, null);
})();

function ResolveComponent_mat_spinner_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner");
    }
}
function ResolveComponent_ng_container_4_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 7);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("condensed", true)("colored", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r6.LdsContributingPermissions), " ");
    }
}
function ResolveComponent_ng_container_4_eui_alert_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 7);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r7 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("condensed", true)("colored", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r7.LdsNoPermissions), "");
    }
}
function ResolveComponent_ng_container_4_mat_selection_list_3_mat_list_option_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-list-option", 10)(1, "div");
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "div", 11);
        i0.ɵɵtext(4);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const entl_r10 = ctx.$implicit;
        i0.ɵɵproperty("value", entl_r10.ObjectKeyEntitlement);
        i0.ɵɵattribute("data-imx-identifier", "multi-select-entitlement-" + entl_r10.ObjectKeyEntitlement);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(entl_r10.Display);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(entl_r10.TypeDisplay);
    }
}
function ResolveComponent_ng_container_4_mat_selection_list_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-selection-list", 8);
        i0.ɵɵlistener("ngModelChange", function ResolveComponent_ng_container_4_mat_selection_list_3_Template_mat_selection_list_ngModelChange_0_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r11 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r11.selectedEntitlements = $event); });
        i0.ɵɵtemplate(1, ResolveComponent_ng_container_4_mat_selection_list_3_mat_list_option_1_Template, 5, 4, "mat-list-option", 9);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r8 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("ngModel", ctx_r8.selectedEntitlements);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r8.entitlements);
    }
}
function ResolveComponent_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtemplate(1, ResolveComponent_ng_container_4_eui_alert_1_Template, 3, 5, "eui-alert", 3);
        i0.ɵɵtemplate(2, ResolveComponent_ng_container_4_eui_alert_2_Template, 3, 5, "eui-alert", 3);
        i0.ɵɵtemplate(3, ResolveComponent_ng_container_4_mat_selection_list_3_Template, 2, 2, "mat-selection-list", 4);
        i0.ɵɵelementStart(4, "div", 5)(5, "button", 6);
        i0.ɵɵtext(6);
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r1.entitlements.length > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r1.entitlements.length == 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r1.entitlements.length > 0);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", ctx_r1.selectedEntitlements.length < 1);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 5, "#LDS#Next"), " ");
    }
}
function ResolveComponent_mat_spinner_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner");
    }
}
function ResolveComponent_ng_container_8_mat_list_option_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-list-option", 16)(1, "div");
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "div", 11);
        i0.ɵɵtext(4);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const action_r15 = ctx.$implicit;
        i0.ɵɵproperty("value", action_r15.Id)("disabled", !action_r15.CanExecute);
        i0.ɵɵattribute("data-imx-identifier", "multi-select-action-" + action_r15.Id);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(action_r15.Display);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(action_r15.ObjectDisplay);
    }
}
function ResolveComponent_ng_container_8_imx_cdr_editor_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 17);
    }
    if (rf & 2) {
        const cdr_r16 = ctx.$implicit;
        const i_r17 = ctx.index;
        i0.ɵɵproperty("cdr", cdr_r16);
        i0.ɵɵattribute("data-imx-identifier", "resolve-cdr-" + cdr_r16.column.ColumnName + "-" + i_r17);
    }
}
function ResolveComponent_ng_container_8_Template(rf, ctx) {
    if (rf & 1) {
        const _r19 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "eui-alert", 7);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "mat-selection-list", 8);
        i0.ɵɵlistener("ngModelChange", function ResolveComponent_ng_container_8_Template_mat_selection_list_ngModelChange_4_listener($event) { i0.ɵɵrestoreView(_r19); const ctx_r18 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r18.uidActions = $event); });
        i0.ɵɵtemplate(5, ResolveComponent_ng_container_8_mat_list_option_5_Template, 5, 5, "mat-list-option", 12);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(6, ResolveComponent_ng_container_8_imx_cdr_editor_6_Template, 1, 2, "imx-cdr-editor", 13);
        i0.ɵɵelementStart(7, "div", 5)(8, "button", 14);
        i0.ɵɵtext(9);
        i0.ɵɵpipe(10, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(11, "button", 15);
        i0.ɵɵtext(12);
        i0.ɵɵpipe(13, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("condensed", true)("colored", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 9, ctx_r3.LdsActionList), "");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngModel", ctx_r3.uidActions);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r3.actions);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r3.cdrs);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 11, "#LDS#Back"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", ctx_r3.uidActions.length < 1);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 13, "#LDS#Next"), " ");
    }
}
function ResolveComponent_mat_spinner_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner");
    }
}
function ResolveComponent_ng_container_12_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 7);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r20 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("condensed", true)("colored", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r20.LdsNoLoseAdditional), "");
    }
}
function ResolveComponent_ng_container_12_ng_container_2_li_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "li", 22)(1, "div");
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "div", 11);
        i0.ɵɵtext(4);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const entl_r23 = ctx.$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(entl_r23.Display);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(entl_r23.TypeDisplay);
    }
}
function ResolveComponent_ng_container_12_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "eui-alert", 20);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "ul");
        i0.ɵɵtemplate(5, ResolveComponent_ng_container_12_ng_container_2_li_5_Template, 5, 2, "li", 21);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r21 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("condensed", true)("colored", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 4, ctx_r21.LdsLoseEntitlements), "");
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngForOf", ctx_r21.entitlementsLoseAlso);
    }
}
function ResolveComponent_ng_container_12_Template(rf, ctx) {
    if (rf & 1) {
        const _r25 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtemplate(1, ResolveComponent_ng_container_12_eui_alert_1_Template, 3, 5, "eui-alert", 3);
        i0.ɵɵtemplate(2, ResolveComponent_ng_container_12_ng_container_2_Template, 6, 6, "ng-container", 2);
        i0.ɵɵelementStart(3, "div", 5)(4, "button", 18);
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "button", 19);
        i0.ɵɵlistener("click", function ResolveComponent_ng_container_12_Template_button_click_7_listener() { i0.ɵɵrestoreView(_r25); const ctx_r24 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r24.Execute()); });
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", 0 === ctx_r5.entitlementsLoseAlso.length);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", 0 < ctx_r5.entitlementsLoseAlso.length);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Back"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(9, 6, "#LDS#Next"));
    }
}
class ResolveComponent {
    constructor(sidesheetRef, snackbar, cplApi, busySvc, metadata, entityService, data) {
        this.sidesheetRef = sidesheetRef;
        this.snackbar = snackbar;
        this.cplApi = cplApi;
        this.busySvc = busySvc;
        this.metadata = metadata;
        this.entityService = entityService;
        this.data = data;
        this.busy = false;
        this.completed = false;
        this.actions = [];
        this.entitlements = [];
        this.entitlementsLoseAlso = [];
        this.selectedEntitlements = [];
        this.uidActions = [];
        this.LdsChangesQueued = '#LDS#Your changes have been successfully saved. It may take some time for the changes to take effect.';
        this.LdsLoseEntitlements = '#LDS#The identity will lose the following entitlements when the selected actions take effect. Check the list to avoid unintentional loss of access. To change the selection, go back to the previous page.';
        this.LdsNoPermissions = '#LDS#No entitlements were found. The cause for the violation may has already been resolved. You may close this wizard.';
        this.LdsContributingPermissions = '#LDS#The following entitlements contribute to this rule violation. Select the entitlements to be removed from the identity.';
        this.LdsNoLoseAdditional = '#LDS#The identity will not lose any additional entitlements.';
        this.LdsActionList = '#LDS#The following actions will be performed to remove the selected entitlements from the identity.';
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.reasonCdr = new BaseCdr(this.entityService.createLocalEntityColumn({
                ColumnName: 'ReasonHead',
                Type: ValType.Text,
                IsMultiLine: true
            }), '#LDS#Reason for unsubscribing');
            this.busy = true;
            // load entitlements contributing to the rule violation
            this.selectedEntitlements = [];
            try {
                this.entitlements = yield this.cplApi.client.portal_rules_violations_entitlements_get(this.data.uidPerson, this.data.uidNonCompliance);
                yield this.enhanceWithTypeDisplay(this.entitlements);
            }
            finally {
                this.busy = false;
            }
        });
    }
    enhanceWithTypeDisplay(obj) {
        return __awaiter(this, void 0, void 0, function* () {
            obj.forEach(element => {
                element.Key = DbObjectKey.FromXml(element.ObjectKeyEntitlement);
            });
            yield this.metadata.updateNonExisting(obj.map(i => i.Key.TableName));
            obj.forEach(element => {
                element.TypeDisplay = this.metadata.tables[element.Key.TableName].DisplaySingular;
            });
        });
    }
    selectedStepChanged(event) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.completed)
                return;
            if (event.selectedIndex === 1 && event.previouslySelectedIndex === 0) {
                yield this.LoadActions();
            }
            else if (event.selectedIndex === 2 && event.previouslySelectedIndex === 1) {
                yield this.LoadEntitlementsLoseAlso();
            }
        });
    }
    LoadActions() {
        return __awaiter(this, void 0, void 0, function* () {
            // load actions
            this.actions = [];
            this.uidActions = [];
            this.busy = true;
            try {
                this.actions = yield this.cplApi.client.portal_rules_violations_actions_post(this.data.uidPerson, this.data.uidNonCompliance, {
                    ObjectKeys: this.selectedEntitlements
                });
                this.uidActions = this.actions.filter(a => a.IsActive).map(a => a.Id);
                // do we have any unsubscribe actions?
                if (this.actions.filter(a => a.Id.endsWith(".Unsubscribe")).length > 0) {
                    // allow the user to enter a reason
                    this.cdrs = [this.reasonCdr];
                }
                else {
                    this.cdrs = [];
                }
            }
            finally {
                this.busy = false;
            }
        });
    }
    LoadEntitlementsLoseAlso() {
        return __awaiter(this, void 0, void 0, function* () {
            // load the entitlements that will also be lost if the selected actions are run
            this.entitlementsLoseAlso = [];
            this.busy = true;
            try {
                this.entitlementsLoseAlso = yield this.cplApi.client.portal_rules_violations_analyzeloss_post(this.data.uidPerson, this.data.uidNonCompliance, {
                    ObjectKeys: this.selectedEntitlements,
                    ActionIds: this.uidActions
                });
                yield this.enhanceWithTypeDisplay(this.entitlementsLoseAlso);
            }
            finally {
                this.busy = false;
            }
        });
    }
    Execute() {
        return __awaiter(this, void 0, void 0, function* () {
            const b = this.busySvc.show();
            try {
                yield this.cplApi.client.portal_rules_violations_result_post(this.data.uidPerson, this.data.uidNonCompliance, {
                    ReasonText: this.reasonCdr.column.GetValue(),
                    ObjectKeys: this.selectedEntitlements,
                    ActionIds: this.uidActions
                });
                this.completed = true;
                this.sidesheetRef.close(true);
                this.snackbar.open({ key: this.LdsChangesQueued });
            }
            finally {
                this.busySvc.hide(b);
            }
        });
    }
}
ResolveComponent.ɵfac = function ResolveComponent_Factory(t) { return new (t || ResolveComponent)(i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(ApiService), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(i2.EntityService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
ResolveComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ResolveComponent, selectors: [["ng-component"]], decls: 13, vars: 16, consts: [["orientation", "vertical", 3, "linear", "selectionChange"], [3, "label"], [4, "ngIf"], ["type", "info", 3, "condensed", "colored", 4, "ngIf"], [3, "ngModel", "ngModelChange", 4, "ngIf"], [1, "imx-step-button"], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-1-next", "color", "primary", "matStepperNext", "", 3, "disabled"], ["type", "info", 3, "condensed", "colored"], [3, "ngModel", "ngModelChange"], ["checkboxPosition", "before", 3, "value", 4, "ngFor", "ngForOf"], ["checkboxPosition", "before", 3, "value"], [1, "subtext"], ["checkboxPosition", "before", 3, "value", "disabled", 4, "ngFor", "ngForOf"], [3, "cdr", 4, "ngFor", "ngForOf"], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-2-back", "matStepperPrevious", ""], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-2-next", "color", "primary", "matStepperNext", "", 3, "disabled"], ["checkboxPosition", "before", 3, "value", "disabled"], [3, "cdr"], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-3-back", "matStepperPrevious", ""], ["mat-stroked-button", "", "data-imx-identifier", "resolve-step-3-next", "color", "primary", "matStepperNext", "", 3, "click"], ["type", "warning", 3, "condensed", "colored"], ["class", "entllose", 4, "ngFor", "ngForOf"], [1, "entllose"]], template: function ResolveComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-stepper", 0);
            i0.ɵɵlistener("selectionChange", function ResolveComponent_Template_mat_stepper_selectionChange_0_listener($event) { return ctx.selectedStepChanged($event); });
            i0.ɵɵelementStart(1, "mat-step", 1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵtemplate(3, ResolveComponent_mat_spinner_3_Template, 1, 0, "mat-spinner", 2);
            i0.ɵɵtemplate(4, ResolveComponent_ng_container_4_Template, 8, 7, "ng-container", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-step", 1);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵtemplate(7, ResolveComponent_mat_spinner_7_Template, 1, 0, "mat-spinner", 2);
            i0.ɵɵtemplate(8, ResolveComponent_ng_container_8_Template, 14, 15, "ng-container", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(9, "mat-step", 1);
            i0.ɵɵpipe(10, "translate");
            i0.ɵɵtemplate(11, ResolveComponent_mat_spinner_11_Template, 1, 0, "mat-spinner", 2);
            i0.ɵɵtemplate(12, ResolveComponent_ng_container_12_Template, 10, 8, "ng-container", 2);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵproperty("linear", true);
            i0.ɵɵadvance(1);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(2, 10, "#LDS#Select permissions for removal"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.busy);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.busy);
            i0.ɵɵadvance(1);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(6, 12, "#LDS#Verify actions"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.busy);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.busy);
            i0.ɵɵadvance(1);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(10, 14, "#LDS#Check loss of entitlements"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.busy);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.busy);
        }
    }, dependencies: [i2.CdrEditorComponent, i5.NgForOf, i5.NgIf, i3$1.EuiAlertComponent, i6.MatButton, i5$2.MatSelectionList, i5$2.MatListOption, i7.MatProgressSpinner, i8$1.MatStep, i8$1.MatStepper, i8$1.MatStepperNext, i8$1.MatStepperPrevious, i2$1.NgControlStatus, i2$1.NgModel, i4.TranslatePipe], styles: ["eui-alert[_ngcontent-%COMP%]{margin-bottom:1em;display:block}.item[_ngcontent-%COMP%]{flex-grow:1;padding-top:1em}.subtext[_ngcontent-%COMP%]{font-size:small;font-style:italic;color:#919799;margin-bottom:10px}.imx-step-button[_ngcontent-%COMP%], .imx-step-button-save[_ngcontent-%COMP%]{margin-top:10px}.imx-step-button[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:not(:last-child), .imx-step-button-save[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:not(:last-child){margin-right:10px}li.entllose[_ngcontent-%COMP%]{list-style-type:initial}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ResolveComponent, [{
            type: Component,
            args: [{ template: "<mat-stepper orientation=\"vertical\" [linear]=\"true\" (selectionChange)=\"selectedStepChanged($event)\">\r\n  <mat-step label=\"{{ '#LDS#Select permissions for removal' | translate }}\">\r\n    <mat-spinner *ngIf=\"busy\"></mat-spinner>\r\n\r\n    <ng-container *ngIf=\"!busy\">\r\n      <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"info\" *ngIf=\"entitlements.length > 0\">\r\n        {{ LdsContributingPermissions | translate }}\r\n      </eui-alert>\r\n\r\n      <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"info\" *ngIf=\"entitlements.length == 0\"> {{ LdsNoPermissions | translate }}</eui-alert>\r\n\r\n      <mat-selection-list [(ngModel)]=\"selectedEntitlements\" *ngIf=\"entitlements.length > 0\">\r\n        <mat-list-option\r\n          checkboxPosition=\"before\"\r\n          *ngFor=\"let entl of entitlements\"\r\n          [value]=\"entl.ObjectKeyEntitlement\"\r\n          [attr.data-imx-identifier]=\"'multi-select-entitlement-' + entl.ObjectKeyEntitlement\"\r\n        >\r\n          <div>{{ entl.Display }}</div>\r\n          <div class=\"subtext\">{{ entl.TypeDisplay }}</div>\r\n        </mat-list-option>\r\n      </mat-selection-list>\r\n\r\n      <div class=\"imx-step-button\">\r\n        <button mat-stroked-button data-imx-identifier=\"resolve-step-1-next\" color=\"primary\" matStepperNext [disabled]=\"selectedEntitlements.length < 1\">\r\n          {{ '#LDS#Next' | translate }}\r\n        </button>\r\n      </div>\r\n    </ng-container>\r\n  </mat-step>\r\n\r\n  <mat-step label=\"{{ '#LDS#Verify actions' | translate }}\">\r\n    <mat-spinner *ngIf=\"busy\"></mat-spinner>\r\n\r\n    <ng-container *ngIf=\"!busy\">\r\n      <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"info\"> {{ LdsActionList | translate }}</eui-alert>\r\n\r\n      <mat-selection-list [(ngModel)]=\"uidActions\">\r\n        <mat-list-option\r\n          checkboxPosition=\"before\"\r\n          *ngFor=\"let action of actions\"\r\n          [value]=\"action.Id\"\r\n          [disabled]=\"!action.CanExecute\"\r\n          [attr.data-imx-identifier]=\"'multi-select-action-' + action.Id\"\r\n        >\r\n          <div>{{ action.Display }}</div>\r\n          <div class=\"subtext\">{{ action.ObjectDisplay }}</div>\r\n        </mat-list-option>\r\n      </mat-selection-list>\r\n\r\n      <imx-cdr-editor *ngFor=\"let cdr of cdrs; let i = index\" [cdr]=\"cdr\" [attr.data-imx-identifier]=\"'resolve-cdr-' + cdr.column.ColumnName + '-' + i\"> </imx-cdr-editor>\r\n\r\n      <div class=\"imx-step-button\">\r\n        <button mat-stroked-button data-imx-identifier=\"resolve-step-2-back\" matStepperPrevious>{{ '#LDS#Back' | translate }}</button>\r\n        <button mat-stroked-button data-imx-identifier=\"resolve-step-2-next\" color=\"primary\" matStepperNext [disabled]=\"uidActions.length < 1\">\r\n          {{ '#LDS#Next' | translate }}\r\n        </button>\r\n      </div>\r\n    </ng-container>\r\n  </mat-step>\r\n  <mat-step label=\"{{ '#LDS#Check loss of entitlements' | translate }}\">\r\n    <mat-spinner *ngIf=\"busy\"></mat-spinner>\r\n\r\n    <ng-container *ngIf=\"!busy\">\r\n      <eui-alert [condensed]=\"true\" [colored]=\"true\" *ngIf=\"0 === entitlementsLoseAlso.length\" type=\"info\"> {{ LdsNoLoseAdditional | translate }}</eui-alert>\r\n\r\n      <ng-container *ngIf=\"0 < entitlementsLoseAlso.length\">\r\n        <eui-alert [condensed]=\"true\" [colored]=\"true\" type=\"warning\"> {{ LdsLoseEntitlements | translate }}</eui-alert>\r\n\r\n        <ul>\r\n          <li class=\"entllose\" *ngFor=\"let entl of entitlementsLoseAlso\">\r\n            <div>{{ entl.Display }}</div>\r\n            <div class=\"subtext\">{{ entl.TypeDisplay }}</div>\r\n          </li>\r\n        </ul>\r\n      </ng-container>\r\n\r\n      <div class=\"imx-step-button\">\r\n        <button mat-stroked-button data-imx-identifier=\"resolve-step-3-back\" matStepperPrevious>{{ '#LDS#Back' | translate }}</button>\r\n        <button mat-stroked-button data-imx-identifier=\"resolve-step-3-next\" (click)=\"Execute()\" color=\"primary\" matStepperNext>{{ '#LDS#Next' | translate }}</button>\r\n      </div>\r\n    </ng-container>\r\n  </mat-step>\r\n</mat-stepper>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */eui-alert{margin-bottom:1em;display:block}.item{flex-grow:1;padding-top:1em}.subtext{font-size:small;font-style:italic;color:#919799;margin-bottom:10px}.imx-step-button,.imx-step-button-save{margin-top:10px}.imx-step-button>*:not(:last-child),.imx-step-button-save>*:not(:last-child){margin-right:10px}li.entllose{list-style-type:initial}\n"] }]
        }], function () {
        return [{ type: i3$1.EuiSidesheetRef }, { type: i2.SnackBarService }, { type: ApiService }, { type: i3$1.EuiLoadingService }, { type: i2.MetadataService }, { type: i2.EntityService }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }];
    }, null);
})();

/**
 * Service that handles the approve and deny of one or more rules violations.
 */
class RulesViolationsActionService {
    constructor(justification, cplClient, sidesheet, busyService, translate, snackBar, userService, entityService) {
        this.justification = justification;
        this.cplClient = cplClient;
        this.sidesheet = sidesheet;
        this.busyService = busyService;
        this.translate = translate;
        this.snackBar = snackBar;
        this.userService = userService;
        this.entityService = entityService;
        this.applied = new Subject();
    }
    /**
     * Approve the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    approve(rulesViolations) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.makeDecisions(rulesViolations, true);
        });
    }
    /**
     * Deny the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    deny(rulesViolations) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.makeDecisions(rulesViolations, false);
        });
    }
    resolve(ruleViolation) {
        return __awaiter(this, void 0, void 0, function* () {
            const sidesheetRef = this.sidesheet.open(ResolveComponent, {
                title: yield this.translate.get('#LDS#Heading Resolve Rule Violation').toPromise(),
                subTitle: ruleViolation.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(600px, 60%)',
                testId: 'rulesviolations-resolve-sidesheet',
                data: {
                    uidPerson: ruleViolation.UID_Person.value,
                    uidNonCompliance: ruleViolation.UID_NonCompliance.value
                }
            });
            return sidesheetRef.afterClosed().toPromise();
        });
    }
    makeDecisions(rulesViolationsApprovals, approve) {
        return __awaiter(this, void 0, void 0, function* () {
            let justification;
            let busyIndicator;
            setTimeout(() => busyIndicator = this.busyService.show());
            try {
                justification = yield this.justification.createCdr(approve
                    ? JustificationType.approveRuleViolation
                    : JustificationType.denyRuleViolation);
            }
            finally {
                setTimeout(() => this.busyService.hide(busyIndicator));
            }
            const actionParameters = {
                justification,
                reason: this.createCdrReason({ display: justification ? '#LDS#Additional comments about your decision' : undefined }),
            };
            if (approve) {
                actionParameters.validUntil = this.createCdrValidUntil();
            }
            const sidesheetTitle = approve
                ? rulesViolationsApprovals.length > 1
                    ? '#LDS#Heading Grant Exceptions'
                    : '#LDS#Heading Grant Exception'
                : rulesViolationsApprovals.length > 1
                    ? '#LDS#Heading Deny Exceptions'
                    : '#LDS#Heading Deny Exception';
            return this.editAction({
                title: sidesheetTitle,
                data: { rulesViolationsApprovals, actionParameters, approve, },
                message: approve
                    ? '#LDS#Exceptions have been successfully granted for {0} rule violations.'
                    : '#LDS#Exceptions have been successfully denied for {0} rule violations.',
                apply: (rulesViolationsAction) => __awaiter(this, void 0, void 0, function* () {
                    var _a, _b, _c, _d;
                    return this.postDecision(rulesViolationsAction, {
                        Reason: actionParameters.reason.column.GetValue(),
                        UidJustification: (_b = (_a = actionParameters.justification) === null || _a === void 0 ? void 0 : _a.column) === null || _b === void 0 ? void 0 : _b.GetValue(),
                        ExceptionValidUntil: (_d = (_c = actionParameters.validUntil) === null || _c === void 0 ? void 0 : _c.column) === null || _d === void 0 ? void 0 : _d.GetValue(),
                        Decision: approve,
                    });
                })
            });
        });
    }
    /**
     * Opens the RulesViolationsActionComponent there the user can set the reason and/or standard reason
     * and the ExceptionValidUntil in the approve contest.
     * @param config the configuration for the sidesheet (title) and the corresponding rules violations data
     */
    editAction(config) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.sidesheet.open(RulesViolationsActionComponent, {
                title: yield this.translate.get(config.title).toPromise(),
                subTitle: config.data.rulesViolationsApprovals.length == 1
                    ? config.data.rulesViolationsApprovals[0].GetEntity().GetDisplay()
                    : '',
                panelClass: 'imx-sidesheet',
                padding: '0',
                width: '600px',
                testId: `rulesvioalations-action-sidesheet-${config.data.approve ? 'approve' : 'deny'}`,
                data: config.data
            }).afterClosed().toPromise();
            if (result) {
                let busyIndicator;
                setTimeout(() => busyIndicator = this.busyService.show());
                let success;
                try {
                    for (const rulesViolation of config.data.rulesViolationsApprovals) {
                        yield config.apply(rulesViolation);
                    }
                    success = true;
                    yield this.userService.reloadPendingItems();
                }
                finally {
                    setTimeout(() => this.busyService.hide(busyIndicator));
                }
                if (success) {
                    this.snackBar.open(config.getMessage ?
                        config.getMessage() :
                        { key: config.message, parameters: [config.data.rulesViolationsApprovals.length] });
                    this.applied.next();
                }
            }
            else {
                this.snackBar.open({ key: '#LDS#You have canceled the action.' });
            }
        });
    }
    /**
     * Approve or deny the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    postDecision(ruleViolationToApprove, input) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.cplClient.client.portal_rules_violations_post(ruleViolationToApprove.UID_Person.value, ruleViolationToApprove.UID_NonCompliance.value, input);
        });
    }
    /**
     * Creates a Cdr-Editor for the reason.
     */
    createCdrReason(metadata = {}) {
        return new BaseCdr(this.entityService.createLocalEntityColumn({
            ColumnName: 'ReasonHead',
            Type: ValType.Text,
            IsMultiLine: true,
            MinLen: metadata.mandatory ? 1 : 0
        }), metadata.display || '#LDS#Reason for your decision');
    }
    /**
     * Creates a Cdr-Editor for the ExceptionValidUntil value.
     */
    createCdrValidUntil() {
        const schema = this.cplClient.typedClient.PortalRulesViolations.GetSchema();
        const minDateUntil = new Date();
        minDateUntil.setDate(minDateUntil.getDate() + 1);
        const validUntilColumn = this.entityService.createLocalEntityColumn({
            ColumnName: schema.Columns.ExceptionValidUntil.ColumnName,
            Type: schema.Columns.ExceptionValidUntil.Type,
            IsMultiLine: schema.Columns.ExceptionValidUntil.IsMultiLine,
            MinLen: schema.Columns.ExceptionValidUntil.MinLen,
            Display: schema.Columns.ExceptionValidUntil.Display
        }, undefined, { ValueConstraint: { MinValue: minDateUntil } });
        return new BaseCdr(validUntilColumn);
    }
}
RulesViolationsActionService.ɵfac = function RulesViolationsActionService_Factory(t) { return new (t || RulesViolationsActionService)(i0.ɵɵinject(i1.JustificationService), i0.ɵɵinject(ApiService), i0.ɵɵinject(i3$1.EuiSidesheetService), i0.ɵɵinject(i3$1.EuiLoadingService), i0.ɵɵinject(i4.TranslateService), i0.ɵɵinject(i2.SnackBarService), i0.ɵɵinject(i1.UserModelService), i0.ɵɵinject(i2.EntityService)); };
RulesViolationsActionService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RulesViolationsActionService, factory: RulesViolationsActionService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsActionService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1.JustificationService }, { type: ApiService }, { type: i3$1.EuiSidesheetService }, { type: i3$1.EuiLoadingService }, { type: i4.TranslateService }, { type: i2.SnackBarService }, { type: i1.UserModelService }, { type: i2.EntityService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * Class thats extends the {@link PortalPersonMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
class PersonMitigatingControls extends PortalPersonMitigatingcontrols {
    constructor(editable, baseObject) {
        super(baseObject.GetEntity());
        this.editable = editable;
        this.baseObject = baseObject;
        this.formControl = new FormControl(undefined);
        this.cdrs = this.initPropertyInfo();
    }
    initPropertyInfo() {
        const properties = [this.UID_MitigatingControl, this.IsInActive];
        return properties.map((property) => new BaseCdr(property.Column));
    }
}

class MitigatingControlsPersonService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    get mitigationSchema() {
        return this.apiService.typedClient.PortalPersonMitigatingcontrols.GetSchema();
    }
    getControls(uidPerson, uidNonCompliance) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.typedClient.PortalPersonMitigatingcontrols.Get(uidPerson, uidNonCompliance);
        });
    }
    createControl(uidPerson, uidNonCompliance) {
        const newMControl = this.apiService.typedClient.PortalPersonMitigatingcontrols.createEntity({
            Columns: {
                UID_NonCompliance: { Value: uidNonCompliance },
                UID_Person: { Value: uidPerson },
                IsInActive: { Value: false },
            },
        });
        return new PersonMitigatingControls(true, newMControl);
    }
    postControl(uidPerson, uidNonCompliance, mControl) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.apiService.typedClient.PortalPersonMitigatingcontrols.Post(uidPerson, uidNonCompliance, mControl);
        });
    }
    postControlRequest(uidPerson, uidNonCompliance, uidPersonWantsOrg, uidMitigatinControl) {
        return __awaiter(this, void 0, void 0, function* () {
            const inter = (yield this.apiService.typedClient.PortalPersonMitigatingcontrolsInteractive.Get(uidPerson, uidNonCompliance)).Data[0];
            yield inter.UID_PersonWantsOrg.Column.PutValue(uidPersonWantsOrg);
            yield inter.UID_MitigatingControl.Column.PutValue(uidMitigatinControl);
            yield this.apiService.client.portal_person_mitigatingcontrols_interactive_forrequest_get(uidPerson, uidNonCompliance, inter.InteractiveEntityStateData.EntityId, { keys: inter.InteractiveEntityStateData.Keys, state: inter.InteractiveEntityStateData.State });
        });
    }
    deleteControl(mControl) {
        return __awaiter(this, void 0, void 0, function* () {
            yield mControl.GetEntity().MarkForDeletion();
            yield mControl.GetEntity().Commit();
        });
    }
    getCandidates(uid, uidNonCompliance, data, parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.client.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(uid, uidNonCompliance, data, parameter);
        });
    }
}
MitigatingControlsPersonService.ɵfac = function MitigatingControlsPersonService_Factory(t) { return new (t || MitigatingControlsPersonService)(i0.ɵɵinject(ApiService)); };
MitigatingControlsPersonService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: MitigatingControlsPersonService, factory: MitigatingControlsPersonService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsPersonService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: ApiService }]; }, null);
})();

function MitigatingControlsPersonComponent_ng_container_9_Template(rf, ctx) {
    if (rf & 1) {
        const _r4 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "mat-card", 5)(2, "imx-mitigating-control-container", 6);
        i0.ɵɵlistener("controlsRequested", function MitigatingControlsPersonComponent_ng_container_9_Template_imx_mitigating_control_container_controlsRequested_2_listener() { i0.ɵɵrestoreView(_r4); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.onCreateControl()); })("controlDeleted", function MitigatingControlsPersonComponent_ng_container_9_Template_imx_mitigating_control_container_controlDeleted_2_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.onDelete($event)); });
        i0.ɵɵelementEnd()();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("mControls", ctx_r0.mControls)("mitigatingCaption", ctx_r0.mitigatingCaption)("formArray", ctx_r0.formArray)("options", ctx_r0.options);
    }
}
function MitigatingControlsPersonComponent_mat_card_10_button_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r8 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 11);
        i0.ɵɵlistener("click", function MitigatingControlsPersonComponent_mat_card_10_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r8); const ctx_r7 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r7.onCreateControl()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Assign mitigating controls"), " ");
    }
}
function MitigatingControlsPersonComponent_mat_card_10_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 7)(1, "div", 8);
        i0.ɵɵelement(2, "eui-icon", 9);
        i0.ɵɵelementStart(3, "p");
        i0.ɵɵtext(4);
        i0.ɵɵpipe(5, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(6, MitigatingControlsPersonComponent_mat_card_10_button_6_Template, 3, 3, "button", 10);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(5, 2, ctx_r1.options.length > 0 ? "#LDS#There are currently no mitigating controls assigned to this rule violation." : "#LDS#There are currently no mitigating controls that can be assigned to this rule violation."), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r1.options.length > 0);
    }
}
function MitigatingControlsPersonComponent_mat_card_11_Template(rf, ctx) {
    if (rf & 1) {
        const _r10 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-card", 12)(1, "button", 13);
        i0.ɵɵlistener("click", function MitigatingControlsPersonComponent_mat_card_11_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r10); const ctx_r9 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r9.onSave()); });
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("disabled", ctx_r2.notSaveable);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Save"), " ");
    }
}
class MitigatingControlsPersonComponent {
    constructor(mControlService, formBuilder, cd, busyService, snackbarService, settingService, confirmationService) {
        this.mControlService = mControlService;
        this.formBuilder = formBuilder;
        this.cd = cd;
        this.busyService = busyService;
        this.snackbarService = snackbarService;
        this.settingService = settingService;
        this.confirmationService = confirmationService;
        this.subscriptions$ = [];
        this.options = [];
        this.mControls = [];
        this.mControlsToDelete = [];
        this.mitigatingCaption = mControlService.mitigationSchema.Columns.UID_MitigatingControl.Display;
        this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.formGroup.get('formArray');
    }
    get notSaveable() {
        if (this.mControlsToDelete.length !== 0) {
            this.formGroup.markAsDirty();
        }
        if (!this.formGroup.dirty || !this.formGroup.valid) {
            return true;
        }
        return (this.mControls.length > 0 &&
            this.mControls.every((ctrl) => {
                return !ctrl.editable || ctrl.UID_MitigatingControl.value === null || ctrl.UID_MitigatingControl.value === '';
            }) &&
            this.mControlsToDelete.length === 0);
    }
    get isDirty() {
        return this.formGroup.dirty || this.mControlsToDelete.length > 0;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.subscriptions$.push(this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
                if (!this.isDirty || (yield this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                    this.sidesheetRef.close();
                }
            })));
            yield this.loadMitigatingControls();
        });
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
    onSelectionChange(mcontrol, value) {
        return __awaiter(this, void 0, void 0, function* () {
            mcontrol.UID_MitigatingControl.value = value;
            this.formArray.updateValueAndValidity();
            this.cd.detectChanges();
            return;
        });
    }
    onOpenChange(isopen, mControl) {
        if (!isopen) {
            mControl.formControl.updateValueAndValidity({ onlySelf: true });
        }
    }
    getMControlId(mControl) {
        return mControl.GetEntity().GetColumn('UID_MitigatingControl').GetValue();
    }
    onCreateControl() {
        return __awaiter(this, void 0, void 0, function* () {
            const mControl = this.mControlService.createControl(this.uidPerson, this.uidNonCompliance);
            this.mControls.push(mControl);
            this.formArray.push(mControl.formControl);
            this.cd.detectChanges();
            mControl.formControl.setValidators([
                Validators.required,
                (control) => (this.isDuplicate(control) ? { duplicated: true } : null),
            ]);
            this.formGroup.markAsDirty();
        });
    }
    onDelete(mControl) {
        this.mControlsToDelete.push(mControl);
    }
    onSave() {
        return __awaiter(this, void 0, void 0, function* () {
            const overlay = this.busyService.show();
            try {
                yield this.handleSave();
            }
            finally {
                this.busyService.hide(overlay);
                this.snackbarService.open({
                    key: '#LDS#The mitigating controls have been successfully saved.',
                });
                if (this.closeOnSave) {
                    this.sidesheetRef.close();
                }
            }
        });
    }
    handleSave() {
        return __awaiter(this, void 0, void 0, function* () {
            for (const ctrl of this.mControlsToDelete) {
                yield this.mControlService.deleteControl(ctrl);
            }
            for (const ctrl of this.mControls.filter((elem) => elem.editable)) {
                yield this.mControlService.postControl(this.uidPerson, this.uidNonCompliance, ctrl);
            }
            if (!this.closeOnSave) {
                this.resetForm();
            }
        });
    }
    resetForm() {
        return __awaiter(this, void 0, void 0, function* () {
            // Since we must handle change detection manually, overwrite formgroup and get read-only mcontrols
            this.formGroup = new UntypedFormGroup({ formArray: this.formBuilder.array([]) });
            this.mControlsToDelete = [];
            yield this.loadMitigatingControls();
            this.cd.detectChanges();
        });
    }
    loadMitigatingControls() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.isMControlPerViolation) {
                this.mControls = [];
                return;
            }
            const overlay = this.busyService.show();
            try {
                //reload
                const data = yield this.mControlService.getControls(this.uidPerson, this.uidNonCompliance);
                this.mControls = data.Data.map((elem) => new PersonMitigatingControls(false, elem));
                this.mControls.forEach((elem) => this.formArray.push(elem.formControl));
                yield this.initOptions();
            }
            finally {
                this.busyService.hide(overlay);
            }
        });
    }
    isDuplicate(actrl) {
        const test = this.mControls.findIndex((ctrl) => ctrl.formControl != actrl && (ctrl === null || ctrl === void 0 ? void 0 : ctrl.UID_MitigatingControl.value) === actrl.value) !== -1;
        return test;
    }
    initOptions() {
        return __awaiter(this, void 0, void 0, function* () {
            const optionCandidates = yield this.mControlService.getCandidates(this.uidPerson, this.uidNonCompliance, {}, {
                PageSize: this.settingService.PageSizeForAllElements,
            });
            this.options = optionCandidates.Entities.map((elem) => ({ display: elem.Display, value: elem.Keys[0] }));
        });
    }
}
MitigatingControlsPersonComponent.ɵfac = function MitigatingControlsPersonComponent_Factory(t) { return new (t || MitigatingControlsPersonComponent)(i0.ɵɵdirectiveInject(MitigatingControlsPersonService), i0.ɵɵdirectiveInject(i2$1.UntypedFormBuilder), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
MitigatingControlsPersonComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsPersonComponent, selectors: [["imx-mitigating-controls-person"]], inputs: { uidPerson: "uidPerson", uidNonCompliance: "uidNonCompliance", sidesheetRef: "sidesheetRef", closeOnSave: "closeOnSave", isMControlPerViolation: "isMControlPerViolation" }, decls: 12, vars: 10, consts: [["eui-sidesheet-content", "", 1, "control-container"], ["type", "info", 1, "imx-helper-alert", 3, "colored"], [4, "ngIf"], ["class", "imx-no-mitigating-controls", 4, "ngIf"], ["eui-sidesheet-actions", "", 4, "ngIf"], [1, "imx-mitigating-control-content"], [3, "mControls", "mitigatingCaption", "formArray", "options", "controlsRequested", "controlDeleted"], [1, "imx-no-mitigating-controls"], [1, "imx-data-no-results"], ["icon", "table"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-person-button-add", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-person-button-add", 3, "click"], ["eui-sidesheet-actions", ""], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "mitigating-controls-person-button-save", 3, "disabled", "click"]], template: function MitigatingControlsPersonComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "eui-alert", 1)(2, "eui-alert-header");
            i0.ɵɵtext(3);
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "eui-alert-content")(6, "p");
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd()()();
            i0.ɵɵtemplate(9, MitigatingControlsPersonComponent_ng_container_9_Template, 3, 4, "ng-container", 2);
            i0.ɵɵtemplate(10, MitigatingControlsPersonComponent_mat_card_10_Template, 7, 4, "mat-card", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(11, MitigatingControlsPersonComponent_mat_card_11_Template, 4, 4, "mat-card", 4);
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("colored", true);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 6, "#LDS#Heading Mitigating Controls Can Be Assigned Individually"));
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 8, "#LDS#Here you can assign mitigating controls to the rule violation. NOTE: If no mitigating controls have been assigned to the violated compliance rule, you cannot assign any mitigating controls to the rule violation either."));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.mControls != null && ctx.mControls.length > 0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.isMControlPerViolation && ctx.options.length > 0);
        }
    }, dependencies: [i5.NgIf, i3$1.EuiAlertComponent, i3$1.EuiAlertContentDirective, i3$1.EuiAlertHeaderDirective, i3$1.EuiIconComponent, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i6.MatButton, i3$2.MatCard, MitigatingControlContainerComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{padding:16px 20px;display:flex;justify-content:flex-end}[_nghost-%COMP%]   .imx-helper-alert[_ngcontent-%COMP%]{margin-bottom:15px}[_nghost-%COMP%]   .control-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   .imx-delete-button[_ngcontent-%COMP%]{margin-top:15px;align-self:flex-start}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]   .mitigating-control-properties[_ngcontent-%COMP%]{display:flex;flex-direction:column;width:100%;margin-right:15px}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .imx-mitigating-control-content[_ngcontent-%COMP%]   .content[_ngcontent-%COMP%]{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]{text-align:center;margin:20px 0;justify-self:center}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .button-actions[_ngcontent-%COMP%]{display:flex;justify-content:space-between;margin-top:20px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#797e80}[_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-mitigating-controls[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .mitigating-control[_ngcontent-%COMP%]{border-bottom:1px solid #ffffff}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsPersonComponent, [{
            type: Component,
            args: [{ selector: 'imx-mitigating-controls-person', template: "<div class=\"control-container\" eui-sidesheet-content>\r\n  <eui-alert class=\"imx-helper-alert\" type=\"info\" [colored]=\"true\">\r\n    <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Can Be Assigned Individually' | translate }}</eui-alert-header>\r\n    <eui-alert-content>\r\n      <p>{{ '#LDS#Here you can assign mitigating controls to the rule violation. NOTE: If no mitigating controls have been assigned to the violated compliance rule, you cannot assign any mitigating controls to the rule violation either.' | translate }}</p>\r\n    </eui-alert-content>\r\n  </eui-alert>\r\n  <ng-container *ngIf=\"mControls != null && mControls.length > 0\">\r\n    <mat-card class=\"imx-mitigating-control-content\">\r\n      <imx-mitigating-control-container [mControls]=\"mControls\" [mitigatingCaption]=\"mitigatingCaption\" [formArray]=\"formArray\" [options]=\"options\" (controlsRequested)=\"onCreateControl()\" (controlDeleted)=\"onDelete($event)\"></imx-mitigating-control-container>\r\n    </mat-card>\r\n  </ng-container>\r\n\r\n  <mat-card class=\"imx-no-mitigating-controls\" *ngIf=\"!mControls || mControls.length == 0\">\r\n    <div class=\"imx-data-no-results\">\r\n      <eui-icon icon=\"table\"></eui-icon>\r\n      <p>\r\n        {{\r\n          (options.length > 0\r\n            ? '#LDS#There are currently no mitigating controls assigned to this rule violation.'\r\n            : '#LDS#There are currently no mitigating controls that can be assigned to this rule violation.'\r\n          ) | translate\r\n        }}\r\n      </p>\r\n      <button *ngIf=\"options.length > 0\" mat-stroked-button color=\"primary\" data-imx-identifier=\"mitigating-controls-person-button-add\" (click)=\"onCreateControl()\">\r\n        {{ '#LDS#Assign mitigating controls' | translate }}\r\n      </button>\r\n    </div>\r\n  </mat-card>\r\n</div>\r\n\r\n<mat-card eui-sidesheet-actions *ngIf=\"isMControlPerViolation && options.length > 0\">\r\n  <button mat-raised-button color=\"primary\" (click)=\"onSave()\" [disabled]=\"notSaveable\" data-imx-identifier=\"mitigating-controls-person-button-save\">\r\n    {{ '#LDS#Save' | translate }}\r\n  </button>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{height:100%;display:flex;flex-direction:column;justify-content:space-between}:host .eui-sidesheet-actions{padding:16px 20px;display:flex;justify-content:flex-end}:host .imx-helper-alert{margin-bottom:15px}:host .control-container{display:flex;flex-direction:column;overflow:auto}:host .mitigating-control{margin-bottom:15px;display:flex;justify-content:space-between;align-items:center}:host .mitigating-control .imx-delete-button{margin-top:15px;align-self:flex-start}:host .mitigating-control .mitigating-control-properties{display:flex;flex-direction:column;width:100%;margin-right:15px}:host .imx-no-mitigating-controls{flex:1 1 auto;margin:3px;display:flex;align-items:center;justify-content:center}:host .imx-mitigating-control-content{flex:1 1 auto;margin:3px;display:flex;flex-direction:column;overflow:hidden}:host .imx-mitigating-control-content .content{overflow:auto;display:flex;flex:1 1 auto;flex-direction:column}:host .imx-data-no-results{text-align:center;margin:20px 0;justify-self:center}:host .imx-data-no-results .eui-icon{font-size:100px}:host .imx-data-no-results p{margin:0;font-size:18px}:host .imx-data-no-results button{margin-top:10px}:host .button-actions{display:flex;justify-content:space-between;margin-top:20px}:host .imx-data-no-results .eui-icon{color:#dfe4e6}:host .imx-data-no-results p{color:#797e80}:host .imx-no-mitigating-controls{color:#797e80}:host .mitigating-control{border-bottom:1px solid #797e80}.eui-dark-theme :host .imx-data-no-results .eui-icon{color:#c4cacc}.eui-dark-theme :host .imx-data-no-results p{color:#dfe4e6}.eui-dark-theme :host .imx-no-mitigating-controls{color:#dfe4e6}.eui-dark-theme :host .mitigating-control{border-bottom:1px solid #dfe4e6}.eui-contrast-theme :host .imx-data-no-results .eui-icon{color:#dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}.eui-contrast-theme :host .imx-no-mitigating-controls{color:#fff}.eui-contrast-theme :host .mitigating-control{border-bottom:1px solid #ffffff}\n"] }]
        }], function () { return [{ type: MitigatingControlsPersonService }, { type: i2$1.UntypedFormBuilder }, { type: i0.ChangeDetectorRef }, { type: i3$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i2.SettingsService }, { type: i2.ConfirmationService }]; }, { uidPerson: [{
                type: Input
            }], uidNonCompliance: [{
                type: Input
            }], sidesheetRef: [{
                type: Input
            }], closeOnSave: [{
                type: Input
            }], isMControlPerViolation: [{
                type: Input
            }] });
})();

function RulesViolationsDetailsComponent_eui_badge_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-badge", 8);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("color", ctx_r0.data.selectedRulesViolation == null ? null : ctx_r0.data.selectedRulesViolation.stateBadge == null ? null : ctx_r0.data.selectedRulesViolation.stateBadge.color);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r0.data.selectedRulesViolation == null ? null : ctx_r0.data.selectedRulesViolation.stateBadge == null ? null : ctx_r0.data.selectedRulesViolation.stateBadge.caption, " ");
    }
}
function RulesViolationsDetailsComponent_imx_cdr_editor_8_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 9);
    }
    if (rf & 2) {
        const cdr_r6 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r6);
    }
}
function RulesViolationsDetailsComponent_imx_cdr_editor_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 9);
    }
    if (rf & 2) {
        const cdr_r7 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r7);
    }
}
function RulesViolationsDetailsComponent_div_10_Template(rf, ctx) {
    if (rf & 1) {
        const _r9 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 10)(1, "button", 11);
        i0.ɵɵlistener("click", function RulesViolationsDetailsComponent_div_10_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r9); const ctx_r8 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r8.resolve()); });
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "button", 12);
        i0.ɵɵlistener("click", function RulesViolationsDetailsComponent_div_10_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r9); const ctx_r10 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r10.approve()); });
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "button", 13);
        i0.ɵɵlistener("click", function RulesViolationsDetailsComponent_div_10_Template_button_click_7_listener() { i0.ɵɵrestoreView(_r9); const ctx_r11 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r11.deny()); });
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 3, "#LDS#Resolve rule violation"), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 5, "#LDS#Grant exception"), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 7, "#LDS#Deny exception"), " ");
    }
}
function RulesViolationsDetailsComponent_mat_tab_11_ng_template_1_eui_icon_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "eui-icon", 19);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
    }
}
function RulesViolationsDetailsComponent_mat_tab_11_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "span", 17);
        i0.ɵɵtext(1, "#LDS#Heading Mitigating Controls");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(2, RulesViolationsDetailsComponent_mat_tab_11_ng_template_1_eui_icon_2_Template, 2, 3, "eui-icon", 18);
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r13 = i0.ɵɵreference(3);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", _r13 == null ? null : _r13.isDirty);
    }
}
function RulesViolationsDetailsComponent_mat_tab_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab");
        i0.ɵɵtemplate(1, RulesViolationsDetailsComponent_mat_tab_11_ng_template_1_Template, 3, 1, "ng-template", 14);
        i0.ɵɵelement(2, "imx-mitigating-controls-person", 15, 16);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("isMControlPerViolation", ctx_r4.data.isMControlPerViolation)("uidPerson", ctx_r4.uidPerson)("closeOnSave", false)("uidNonCompliance", ctx_r4.uidNonCompliance)("sidesheetRef", ctx_r4.sidesheetRef);
    }
}
const _c0$6 = function (a0) { return { "data": a0 }; };
function RulesViolationsDetailsComponent_mat_tab_12_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 0);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelement(2, "imx-ext", 20);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext();
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 2, "#LDS#Heading SAP Functions"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("properties", i0.ɵɵpureFunction1(4, _c0$6, ctx_r5.data));
    }
}
class baseComplienceClass {
}
/**
 * A sidesheet component to show some information about the selected rules violation.
 */
class RulesViolationsDetailsComponent {
    constructor(data, sidesheetRef, actionService, extService, translateService) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.actionService = actionService;
        this.extService = extService;
        this.translateService = translateService;
        this.cdrList = [];
        this.ruleInfoCdrList = [];
        this.subscriptions$ = [];
        this.uidPerson = data.selectedRulesViolation.GetEntity().GetColumn('UID_Person').GetValue();
        this.uidNonCompliance = data.selectedRulesViolation.GetEntity().GetColumn('UID_NonCompliance').GetValue();
        this.cdrList = data.selectedRulesViolation.propertyInfo;
        if (this.data.complianceRule)
            this.ruleInfoCdrList.push(new BaseCdr(this.data.complianceRule.Description.Column, this.translateService.instant('#LDS#Description')), new BaseCdr(this.data.complianceRule.RuleNumber.Column));
    }
    ngOnInit() {
        this.subscriptions$.push(this.sidesheetRef.componentInstance.onOpen().subscribe(() => {
            // Recalculates header
            this.matTabGroup.updatePagination();
        }));
    }
    /**
     * Opens the Approve-Sidesheet for the current selected rules violations and closes the sidesheet afterwards.
     */
    approve() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.actionService.approve([this.data.selectedRulesViolation]);
            return this.sidesheetRef.close(true);
        });
    }
    /**
     * Opens the Deny-Sidesheet for the current selected rules violations and closes the sidesheet afterwards.
     */
    deny() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.actionService.deny([this.data.selectedRulesViolation]);
            return this.sidesheetRef.close(true);
        });
    }
    resolve() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.actionService.resolve(this.data.selectedRulesViolation);
            return this.sidesheetRef.close(true);
        });
    }
    get showDynamicTab() {
        return this.extService.Registry['RuleViolationsTab'] && this.extService.Registry['RuleViolationsTab'].length > 0;
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
}
RulesViolationsDetailsComponent.ɵfac = function RulesViolationsDetailsComponent_Factory(t) { return new (t || RulesViolationsDetailsComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(RulesViolationsActionService), i0.ɵɵdirectiveInject(i2.ExtService), i0.ɵɵdirectiveInject(i4.TranslateService)); };
RulesViolationsDetailsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsDetailsComponent, selectors: [["imx-rules-violations-details"]], viewQuery: function RulesViolationsDetailsComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(MatTabGroup, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.matTabGroup = _t.first);
        }
    }, decls: 13, vars: 10, consts: [[3, "label"], ["eui-sidesheet-content", "", 1, "imx-mat-tab-container"], [1, "imx-state-caption"], [3, "color", 4, "ngIf"], [3, "cdr", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", "", 4, "ngIf"], [4, "ngIf"], [3, "label", 4, "ngIf"], [3, "color"], [3, "cdr"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "rules-violations-table-row-button-resolve", 3, "click"], ["mat-stroked-button", "", "data-imx-identifier", "rules-violations-table-row-button-approve", 3, "click"], ["mat-stroked-button", "", "data-imx-identifier", "rules-violations-table-row-button-deny", 3, "click"], ["mat-tab-label", ""], [3, "isMControlPerViolation", "uidPerson", "closeOnSave", "uidNonCompliance", "sidesheetRef"], ["mitig", ""], ["translate", ""], ["icon", "save", "class", "imx-dirty-indicator", "size", "s", 4, "ngIf"], ["icon", "save", "size", "s", 1, "imx-dirty-indicator"], ["id", "RuleViolationsTab", 3, "properties"]], template: function RulesViolationsDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group")(1, "mat-tab", 0);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementStart(3, "div", 1)(4, "mat-card")(5, "div", 2);
            i0.ɵɵtext(6);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, RulesViolationsDetailsComponent_eui_badge_7_Template, 2, 2, "eui-badge", 3);
            i0.ɵɵtemplate(8, RulesViolationsDetailsComponent_imx_cdr_editor_8_Template, 1, 1, "imx-cdr-editor", 4);
            i0.ɵɵtemplate(9, RulesViolationsDetailsComponent_imx_cdr_editor_9_Template, 1, 1, "imx-cdr-editor", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(10, RulesViolationsDetailsComponent_div_10_Template, 10, 9, "div", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(11, RulesViolationsDetailsComponent_mat_tab_11_Template, 4, 5, "mat-tab", 6);
            i0.ɵɵtemplate(12, RulesViolationsDetailsComponent_mat_tab_12_Template, 3, 6, "mat-tab", 7);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            let tmp_1_0;
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 8, "#LDS#Heading Information"));
            i0.ɵɵadvance(5);
            i0.ɵɵtextInterpolate1(" ", ctx.data.selectedRulesViolation == null ? null : ctx.data.selectedRulesViolation.State == null ? null : (tmp_1_0 = ctx.data.selectedRulesViolation.State.GetMetadata()) == null ? null : tmp_1_0.GetDisplay(), " ");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.selectedRulesViolation == null ? null : ctx.data.selectedRulesViolation.State == null ? null : ctx.data.selectedRulesViolation.State.value);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.ruleInfoCdrList);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.selectedRulesViolation == null ? null : ctx.data.selectedRulesViolation.CanUserDecide.value);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.isMControlPerViolation);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.showDynamicTab);
        }
    }, dependencies: [i2.CdrEditorComponent, i5.NgForOf, i5.NgIf, i3$1.EuiBadgeComponent, i3$1.EuiIconComponent, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i6.MatButton, i3$2.MatCard, i8$2.MatTabGroup, i8$2.MatTabLabel, i8$2.MatTab, i2.ExtComponent, i4.TranslateDirective, MitigatingControlsPersonComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]   .mat-tab-group[_ngcontent-%COMP%], [_nghost-%COMP%]     .mat-tab-body-wrapper{height:100%}[_nghost-%COMP%]     .mat-tab-body-content{display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .imx-mat-tab-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .eui-badge[_ngcontent-%COMP%]     .eui-badge-content{font-size:12px;line-height:12px;margin-bottom:20px}[_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{font-size:12px;padding-bottom:5px}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:10px}[_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{margin-left:5px}[_nghost-%COMP%]   imx-ext[_ngcontent-%COMP%]{height:100%}[_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{color:#e36a00}[_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{color:#919799}[_nghost-%COMP%]     .mat-tab-labels{background-color:#fff}.eui-dark-theme   [_nghost-%COMP%]     .mat-tab-labels{background-color:#444647}.eui-contrast-theme   [_nghost-%COMP%]     .mat-tab-labels{background-color:#000}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsDetailsComponent, [{
            type: Component,
            args: [{ selector: 'imx-rules-violations-details', template: "<mat-tab-group>\r\n  <mat-tab [label]=\"'#LDS#Heading Information' | translate\">\r\n    <div class=\"imx-mat-tab-container\" eui-sidesheet-content>\r\n      <mat-card>\r\n        <div class=\"imx-state-caption\">\r\n          {{ data.selectedRulesViolation?.State?.GetMetadata()?.GetDisplay() }}\r\n        </div>\r\n        <eui-badge [color]=\"data.selectedRulesViolation?.stateBadge?.color\" *ngIf=\"data.selectedRulesViolation?.State?.value\">\r\n          {{ data.selectedRulesViolation?.stateBadge?.caption }}\r\n        </eui-badge>\r\n        <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\r\n        <imx-cdr-editor *ngFor=\"let cdr of ruleInfoCdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\r\n      </mat-card>\r\n    </div>\r\n    <div eui-sidesheet-actions *ngIf=\"data.selectedRulesViolation?.CanUserDecide.value\" >\r\n      <button mat-stroked-button (click)=\"resolve()\" data-imx-identifier=\"rules-violations-table-row-button-resolve\">\r\n        {{ '#LDS#Resolve rule violation' | translate }}\r\n      </button>\r\n      <button mat-stroked-button (click)=\"approve()\" data-imx-identifier=\"rules-violations-table-row-button-approve\">\r\n        {{ '#LDS#Grant exception' | translate }}\r\n      </button>\r\n      <button mat-stroked-button (click)=\"deny()\" data-imx-identifier=\"rules-violations-table-row-button-deny\">\r\n        {{ '#LDS#Deny exception' | translate }}\r\n      </button>\r\n    </div>\r\n  </mat-tab>\r\n  <mat-tab *ngIf=\"data.isMControlPerViolation\">\r\n    <ng-template mat-tab-label>\r\n      <span translate>#LDS#Heading Mitigating Controls</span>\r\n      <eui-icon  *ngIf=\"mitig?.isDirty\" icon=\"save\" class=\"imx-dirty-indicator\" size=\"s\" [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"></eui-icon>\r\n    </ng-template>\r\n    <imx-mitigating-controls-person #mitig\r\n      [isMControlPerViolation]=\"data.isMControlPerViolation\"\r\n      [uidPerson]=\"uidPerson\"\r\n      [closeOnSave]=\"false\"\r\n      [uidNonCompliance]=\"uidNonCompliance\"\r\n      [sidesheetRef]=\"sidesheetRef\"\r\n    ></imx-mitigating-controls-person>\r\n  </mat-tab>\r\n  <mat-tab *ngIf=\"showDynamicTab\" [label]=\"'#LDS#Heading SAP Functions' | translate\">\r\n    <imx-ext id=\"RuleViolationsTab\" [properties]=\"{'data': data}\"></imx-ext>\r\n  </mat-tab>\r\n</mat-tab-group>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host .mat-tab-group,:host ::ng-deep .mat-tab-body-wrapper{height:100%}:host ::ng-deep .mat-tab-body-content{display:flex;flex-direction:column;justify-content:space-between}:host .imx-mat-tab-container{display:flex;flex-direction:column;overflow:auto}:host .eui-sidesheet-content{display:flex;flex-direction:column}:host .eui-badge ::ng-deep .eui-badge-content{font-size:12px;line-height:12px;margin-bottom:20px}:host .imx-state-caption{font-size:12px;padding-bottom:5px}:host .eui-sidesheet-actions button:not(:last-of-type){margin-right:10px}:host .imx-dirty-indicator{margin-left:5px}:host imx-ext{height:100%}:host .imx-dirty-indicator{color:#e36a00}:host .imx-state-caption{color:#919799}:host ::ng-deep .mat-tab-labels{background-color:#fff}.eui-dark-theme :host ::ng-deep .mat-tab-labels{background-color:#444647}.eui-contrast-theme :host ::ng-deep .mat-tab-labels{background-color:#000}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i3$1.EuiSidesheetRef }, { type: RulesViolationsActionService }, { type: i2.ExtService }, { type: i4.TranslateService }];
    }, { matTabGroup: [{
                type: ViewChild,
                args: [MatTabGroup]
            }] });
})();

/**
 * Class thats extends the {@link PortalRulesViolations} with some additional properties that are needed for
 * the components in the approval context.
 */
class RulesViolationsApproval extends PortalRulesViolations {
    constructor(baseObject, hasRiskIndex, translate) {
        super(baseObject.GetEntity());
        this.baseObject = baseObject;
        this.hasRiskIndex = hasRiskIndex;
        this.translate = translate;
        this.propertyInfo = this.initPropertyInfo();
        this.initStateBadge();
    }
    /**
     * The color and the caption depending on the value of the state of a {@link PortalRulesViolations}.
     */
    get stateBadge() {
        return {
            color: this.stateBadgeColor,
            caption: this.stateCaption,
        };
    }
    initPropertyInfo() {
        const properties = [this.UID_Person, this.UID_NonCompliance];
        if (this.hasRiskIndex) {
            properties.push([this.RiskIndexCalculated, this.RiskIndexReduced]);
        }
        if (this.State.value !== 'pending') {
            properties.push(this.DecisionDate, this.UID_PersonDecisionMade, this.DecisionReason, this.UID_QERJustification);
        }
        if (this.State.value === 'approved') {
            properties.push(this.ExceptionValidUntil);
        }
        return properties.filter((property) => property.value != null && property.value !== '').map((property) => new BaseCdr(property.Column));
    }
    initStateBadge() {
        return __awaiter(this, void 0, void 0, function* () {
            switch (this.State.value) {
                case 'approved':
                    this.stateBadgeColor = 'green';
                    this.stateCaption = yield this.translate.get('#LDS#Exception granted').toPromise();
                    break;
                case 'denied':
                    this.stateBadgeColor = 'orange';
                    this.stateCaption = yield this.translate.get('#LDS#Exception denied').toPromise();
                    break;
                default:
                    this.stateBadgeColor = 'blue';
                    this.stateCaption = yield this.translate.get('#LDS#Approval decision pending').toPromise();
            }
        });
    }
}

/**
 * Service that provides all rules violations, including schema, DataModel and GroupingInfo.
 */
class RulesViolationsService {
    constructor(cplClient, logger, busyService, translate, systemInfoService) {
        this.cplClient = cplClient;
        this.logger = logger;
        this.busyService = busyService;
        this.translate = translate;
        this.systemInfoService = systemInfoService;
        this.abortController = new AbortController();
        this.busyIndicatorCounter = 0;
    }
    featureConfig() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.cplClient.client.portal_compliance_config_get();
        });
    }
    /**
     * Provides the schema of {@link PortalRulesViolations}.
     */
    get rulesViolationsApproveSchema() {
        return this.cplClient.typedClient.PortalRulesViolations.GetSchema();
    }
    /**
     * Provides the data model of {@link PortalRulesViolations}.
     */
    getDataModel(filter) {
        return __awaiter(this, void 0, void 0, function* () {
            const options = { filter };
            return this.cplClient.client.portal_rules_violations_datamodel_get(options);
        });
    }
    /**
     * Provides the GroupInfo of {@link PortalRulesViolations}.
     */
    getGroupInfo(parameters = {}) {
        const { withProperties, OrderBy, search } = parameters, params = __rest(parameters, ["withProperties", "OrderBy", "search"]);
        return this.cplClient.client.portal_rules_violations_group_get(Object.assign(Object.assign({}, params), { withcount: true, approvable: true }));
    }
    /**
     * Retrieves all rule violations, that the current user can approve or deny.
     *
     * @returns a list of {@link PortalRulesViolations|PortalRulesViolationss}
     */
    getRulesViolationsApprove(parameters, requestOpts) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Retrieving all rule violations to approve`);
            this.logger.trace('Navigation state', parameters);
            const collection = yield this.cplClient.typedClient.PortalRulesViolations.Get(Object.assign({ approvable: true }, parameters), requestOpts);
            if (!collection) {
                return undefined;
            }
            const hasRiskIndex = (yield this.systemInfoService.get()).PreProps.includes('RISKINDEX');
            return {
                tableName: collection === null || collection === void 0 ? void 0 : collection.tableName,
                totalCount: collection === null || collection === void 0 ? void 0 : collection.totalCount,
                Data: collection === null || collection === void 0 ? void 0 : collection.Data.map((item) => new RulesViolationsApproval(item, hasRiskIndex, this.translate)),
            };
        });
    }
    exportRulesViolations(parameters) {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_rules_violations_get(Object.assign(Object.assign({}, parameters), { withProperties, PageSize, StartIndex: 0 }));
                }
                else {
                    method = factory.portal_rules_violations_get(Object.assign(Object.assign({}, parameters), { withProperties }));
                }
                return new MethodDefinition(method);
            },
        };
    }
    /**
     * Shows the busy indicator.
     */
    handleOpenLoader() {
        if (this.busyIndicatorCounter === 0) {
            setTimeout(() => (this.busyIndicator = this.busyService.show()));
        }
        this.busyIndicatorCounter++;
    }
    /**
     * Closes the busy indicator.
     */
    handleCloseLoader() {
        if (this.busyIndicatorCounter === 1) {
            setTimeout(() => {
                this.busyService.hide(this.busyIndicator);
                this.busyIndicator = undefined;
            });
        }
        this.busyIndicatorCounter--;
    }
    getComplianceRuleByUId(rulesViolationsApproval) {
        return __awaiter(this, void 0, void 0, function* () {
            const uidNonCompliance = rulesViolationsApproval.GetEntity().GetColumn('UID_NonCompliance').GetValue();
            const call = yield this.cplClient.typedClient.PortalRules.Get({
                filter: [
                    { ColumnName: 'UID_NonCompliance', CompareOp: CompareOperator.Equal, Type: FilterType.Compare, Value1: uidNonCompliance },
                    { ColumnName: 'IsWorkingCopy', CompareOp: CompareOperator.Equal, Type: FilterType.Compare, Value1: false },
                ],
            });
            return call.Data[0];
        });
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
}
RulesViolationsService.ɵfac = function RulesViolationsService_Factory(t) { return new (t || RulesViolationsService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i3$1.EuiLoadingService), i0.ɵɵinject(i4.TranslateService), i0.ɵɵinject(i2.SystemInfoService)); };
RulesViolationsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RulesViolationsService, factory: RulesViolationsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: ApiService }, { type: i2.ClassloggerService }, { type: i3$1.EuiLoadingService }, { type: i4.TranslateService }, { type: i2.SystemInfoService }]; }, null);
})();

function ViolationsPerRuleComponent_imx_data_table_column_12_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-data-table-column", 12);
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵproperty("entityColumn", ctx_r2.entitySchema.Columns.RiskIndexCalculated);
    }
}
function ViolationsPerRuleComponent_imx_data_table_column_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-data-table-column", 13);
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵproperty("entityColumn", ctx_r3.entitySchema.Columns.RiskIndexReduced);
    }
}
const _c0$5 = function () { return ["search", "filter", "groups"]; };
const _c1$1 = function () { return ["uid_compliancerule"]; };
class ViolationsPerRuleComponent {
    constructor(rulesViolationsService, translate, sidesheet, systemInfoService) {
        this.rulesViolationsService = rulesViolationsService;
        this.translate = translate;
        this.sidesheet = sidesheet;
        this.systemInfoService = systemInfoService;
        this.groupedData = {};
        this.hasRiskIndex = false;
    }
    ngOnInit() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            this.entitySchema = this.rulesViolationsService.rulesViolationsApproveSchema;
            this.hasRiskIndex = (_b = (_a = (yield this.systemInfoService.get()).PreProps) === null || _a === void 0 ? void 0 : _a.includes('RISKINDEX')) !== null && _b !== void 0 ? _b : false;
            const displayedColumns = [this.entitySchema.Columns.UID_Person, this.entitySchema.Columns.State];
            if (this.hasRiskIndex) {
                displayedColumns.push(this.entitySchema.Columns.RiskIndexCalculated, this.entitySchema.Columns.RiskIndexReduced);
            }
            this.dataModelWrapper = {
                dataModel: yield this.rulesViolationsService.getDataModel(),
                getGroupInfo: (parameters) => this.rulesViolationsService.getGroupInfo(parameters),
                groupingFilterOptions: ['state'],
            };
            this.dstWrapper = new DataSourceWrapper((state, requestOpts, isInitial) => isInitial
                ? Promise.resolve({ totalCount: 0, Data: [] })
                : this.rulesViolationsService.getRulesViolationsApprove(Object.assign(Object.assign({}, state), { uid_compliancerule: this.uidRule, approvable: undefined }), requestOpts), displayedColumns, this.entitySchema, this.dataModelWrapper);
            yield this.getData(undefined);
        });
    }
    /**
     * Handles grouping changes with reload
     * @param groupKey The key of the group
     */
    onGroupingChange(groupInfo) {
        return __awaiter(this, void 0, void 0, function* () {
            this.rulesViolationsService.handleOpenLoader();
            try {
                const groupedData = this.groupedData[groupInfo.key];
                groupedData.data = groupInfo.isInitial
                    ? { totalCount: 0, Data: [] }
                    : yield this.rulesViolationsService.getRulesViolationsApprove(groupedData.navigationState);
                groupedData.settings = {
                    displayedColumns: this.dstSettings.displayedColumns,
                    dataModel: this.dstSettings.dataModel,
                    dataSource: groupedData.data,
                    entitySchema: this.dstSettings.entitySchema,
                    navigationState: groupedData.navigationState,
                };
            }
            finally {
                this.rulesViolationsService.handleCloseLoader();
            }
        });
    }
    /**
     * Opens rules-violations-details sidesheet, where you can manage the selected rule.
     * @param rule The selected rule from the Rule Violations list
     */
    showRulesViolationsDetail(rule) {
        return __awaiter(this, void 0, void 0, function* () {
            const complianceRule = yield this.rulesViolationsService.getComplianceRuleByUId(rule);
            const config = yield this.rulesViolationsService.featureConfig();
            yield this.sidesheet
                .open(RulesViolationsDetailsComponent, {
                title: yield this.translate.get('#LDS#Heading View Rule Violation Details').toPromise(),
                subTitle: rule.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(1000px, 70%)',
                testId: 'rules-violations-informations-sidesheet',
                data: {
                    selectedRulesViolation: rule,
                    isMControlPerViolation: config.MitigatingControlsPerViolation,
                    complianceRule,
                },
            })
                .afterClosed()
                .toPromise();
        });
    }
    /**
     * Loads the dstSettings with load parameters
     * @param parameter Load parameter
     */
    getData(parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            this.rulesViolationsService.handleOpenLoader();
            try {
                const dstSettings = yield this.dstWrapper.getDstSettings(parameter, { signal: this.rulesViolationsService.abortController.signal });
                if (dstSettings) {
                    this.dstSettings = dstSettings;
                }
            }
            finally {
                this.rulesViolationsService.handleCloseLoader();
            }
        });
    }
    onSearch(keywords) {
        this.rulesViolationsService.abortCall();
        return this.getData({ search: keywords });
    }
}
ViolationsPerRuleComponent.ɵfac = function ViolationsPerRuleComponent_Factory(t) { return new (t || ViolationsPerRuleComponent)(i0.ɵɵdirectiveInject(RulesViolationsService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.SystemInfoService)); };
ViolationsPerRuleComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ViolationsPerRuleComponent, selectors: [["imx-violations-per-rule"]], inputs: { uidRule: "uidRule" }, decls: 15, vars: 18, consts: [[1, "mat-tab-content"], ["type", "info", 1, "imx-helper-alert", 3, "condensed", "colored"], ["data-imx-identifier", "violations-per-rule-dst", 3, "options", "settings", "hiddenFilters", "search", "navigationStateChanged"], ["dst", ""], [1, "imx-table-container"], ["mode", "manual", "data-imx-identifier", "violations-per-rule-datatable", 3, "dst", "detailViewVisible", "groupData", "highlightedEntityChanged", "groupDataChanged"], ["dataTable", ""], ["data-imx-identifier", "violations-per-rule-table-column-UidPerson", 3, "entityColumn"], ["data-imx-identifier", "violations-per-rule-table-column-state", 3, "entityColumn"], ["data-imx-identifier", "violations-per-rule-table-column-RiskIndexCalculated", 3, "entityColumn", 4, "ngIf"], ["data-imx-identifier", "violations-per-rule-table-column-RiskIndexReduced", 3, "entityColumn", 4, "ngIf"], ["data-imx-identifier", "violations-per-rule-paginator", 3, "dst"], ["data-imx-identifier", "violations-per-rule-table-column-RiskIndexCalculated", 3, "entityColumn"], ["data-imx-identifier", "violations-per-rule-table-column-RiskIndexReduced", 3, "entityColumn"]], template: function ViolationsPerRuleComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "eui-alert", 1);
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-card")(5, "imx-data-source-toolbar", 2, 3);
            i0.ɵɵlistener("search", function ViolationsPerRuleComponent_Template_imx_data_source_toolbar_search_5_listener($event) { return ctx.onSearch($event); })("navigationStateChanged", function ViolationsPerRuleComponent_Template_imx_data_source_toolbar_navigationStateChanged_5_listener($event) { return ctx.getData($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 4)(8, "imx-data-table", 5, 6);
            i0.ɵɵlistener("highlightedEntityChanged", function ViolationsPerRuleComponent_Template_imx_data_table_highlightedEntityChanged_8_listener($event) { return ctx.showRulesViolationsDetail($event); })("groupDataChanged", function ViolationsPerRuleComponent_Template_imx_data_table_groupDataChanged_8_listener($event) { return ctx.onGroupingChange($event); });
            i0.ɵɵelement(10, "imx-data-table-column", 7)(11, "imx-data-table-column", 8);
            i0.ɵɵtemplate(12, ViolationsPerRuleComponent_imx_data_table_column_12_Template, 1, 1, "imx-data-table-column", 9);
            i0.ɵɵtemplate(13, ViolationsPerRuleComponent_imx_data_table_column_13_Template, 1, 1, "imx-data-table-column", 10);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(14, "imx-data-source-paginator", 11);
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(6);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("condensed", true)("colored", true);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 14, "#LDS#Here you can get an overview of the violations of the compliance rule."), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("options", i0.ɵɵpureFunction0(16, _c0$5))("settings", ctx.dstSettings)("hiddenFilters", i0.ɵɵpureFunction0(17, _c1$1));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0)("detailViewVisible", false)("groupData", ctx.groupedData);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns.UID_Person);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns.State);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.hasRiskIndex);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.hasRiskIndex);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i5.NgIf, i3$1.EuiAlertComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i3$2.MatCard, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.mat-tab-content[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column}.mat-tab-content[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden;margin:2px}.imx-helper-alert[_ngcontent-%COMP%]{margin:0 0 20px auto;width:100%}.imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ViolationsPerRuleComponent, [{
            type: Component,
            args: [{ selector: 'imx-violations-per-rule', template: "<div class=\"mat-tab-content\">\r\n  <eui-alert class=\"imx-helper-alert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\">\r\n    {{ '#LDS#Here you can get an overview of the violations of the compliance rule.' | translate }}\r\n  </eui-alert>\r\n  <mat-card>\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      [options]=\"['search', 'filter', 'groups']\"\r\n      [settings]=\"dstSettings\"\r\n      (search)=\"onSearch($event)\"\r\n      (navigationStateChanged)=\"getData($event)\"\r\n      [hiddenFilters]=\"['uid_compliancerule']\"\r\n      data-imx-identifier=\"violations-per-rule-dst\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-table\r\n        #dataTable\r\n        [dst]=\"dst\"\r\n        [detailViewVisible]=\"false\"\r\n        mode=\"manual\"\r\n        [groupData]=\"groupedData\"\r\n        (highlightedEntityChanged)=\"showRulesViolationsDetail($event)\"\r\n        (groupDataChanged)=\"onGroupingChange($event)\"\r\n        data-imx-identifier=\"violations-per-rule-datatable\"\r\n      >\r\n        <imx-data-table-column data-imx-identifier=\"violations-per-rule-table-column-UidPerson\" [entityColumn]=\"entitySchema?.Columns.UID_Person\"> </imx-data-table-column>\r\n        <imx-data-table-column data-imx-identifier=\"violations-per-rule-table-column-state\" [entityColumn]=\"entitySchema?.Columns.State\"></imx-data-table-column>\r\n        <imx-data-table-column\r\n          *ngIf=\"hasRiskIndex\"\r\n          [entityColumn]=\"entitySchema.Columns.RiskIndexCalculated\"\r\n          data-imx-identifier=\"violations-per-rule-table-column-RiskIndexCalculated\"\r\n        >\r\n        </imx-data-table-column>\r\n        <imx-data-table-column *ngIf=\"hasRiskIndex\" [entityColumn]=\"entitySchema.Columns.RiskIndexReduced\" data-imx-identifier=\"violations-per-rule-table-column-RiskIndexReduced\">\r\n        </imx-data-table-column>\r\n      </imx-data-table>\r\n      <imx-data-source-paginator data-imx-identifier=\"violations-per-rule-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\r\n    </div>\r\n  </mat-card>\r\n</div>\r\n", styles: [":host{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}.mat-tab-content{height:100%;display:flex;flex-direction:column}.mat-tab-content .mat-card{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden;margin:2px}.imx-helper-alert{margin:0 0 20px auto;width:100%}.imx-table-container{display:flex;flex-direction:column;flex:1 1 auto;overflow:hidden}\n"] }]
        }], function () { return [{ type: RulesViolationsService }, { type: i4.TranslateService }, { type: i3$1.EuiSidesheetService }, { type: i2.SystemInfoService }]; }, { uidRule: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function RulesSidesheetComponent_ng_template_3_imx_cdr_editor_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 7);
    }
    if (rf & 2) {
        const cdr_r5 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r5);
    }
}
function RulesSidesheetComponent_ng_template_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 3)(1, "mat-card");
        i0.ɵɵtemplate(2, RulesSidesheetComponent_ng_template_3_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 4);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(3, "div", 5)(4, "button", 6);
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", ctx_r0.cdrList);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("euiDownload", ctx_r0.reportDownload);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 3, "#LDS#Download report"), " ");
    }
}
function RulesSidesheetComponent_mat_tab_4_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 8);
        i0.ɵɵelement(1, "imx-violations-per-rule", 9);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("uidRule", ctx_r6.data.selectedRule.GetEntity().GetKeys()[0])("isMControlPerViolation", ctx_r6.data.isMControlPerViolation);
    }
}
function RulesSidesheetComponent_mat_tab_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 0);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵtemplate(2, RulesSidesheetComponent_mat_tab_4_ng_template_2_Template, 2, 2, "ng-template", 1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Rule Violations"));
    }
}
function RulesSidesheetComponent_mat_tab_5_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-mitigating-controls-rules", 10);
    }
    if (rf & 2) {
        const ctx_r7 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("isMControlPerViolation", ctx_r7.data.isMControlPerViolation)("mControls", ctx_r7.data.mControls)("uidNonCompliance", ctx_r7.uidNonCompliance)("uidCompliance", ctx_r7.uidCompliance)("sidesheetRef", ctx_r7.sidesheetRef)("canEdit", ctx_r7.data.canEdit);
    }
}
function RulesSidesheetComponent_mat_tab_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 0);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵtemplate(2, RulesSidesheetComponent_mat_tab_5_ng_template_2_Template, 1, 6, "ng-template", 1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Mitigating Controls"));
    }
}
function RulesSidesheetComponent_ng_template_8_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 3);
        i0.ɵɵelement(1, "imx-object-hyperview", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        let tmp_0_0;
        let tmp_1_0;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("objectType", ctx_r3.data == null ? null : ctx_r3.data.selectedRule == null ? null : (tmp_0_0 = ctx_r3.data.selectedRule.GetEntity()) == null ? null : tmp_0_0.TypeName)("objectUid", ctx_r3.data == null ? null : ctx_r3.data.selectedRule == null ? null : (tmp_1_0 = ctx_r3.data.selectedRule.GetEntity()) == null ? null : tmp_1_0.GetKeys()[0]);
    }
}
class RulesSidesheetComponent {
    constructor(data, sidesheetRef, rulesProvider, elementalUiConfigService) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.rulesProvider = rulesProvider;
        this.subscriptions$ = [];
        this.uidNonCompliance = data.selectedRule.GetEntity().GetColumn('UID_NonCompliance').GetValue();
        this.uidCompliance = data.selectedRule.GetEntity().GetKeys().join(',');
        this.cdrList = [
            new BaseReadonlyCdr(this.data.selectedRule.GetEntity().GetColumn(DisplayColumns.DISPLAY_PROPERTYNAME)),
            new BaseReadonlyCdr(this.data.selectedRule.Description.Column),
            new BaseReadonlyCdr(this.data.selectedRule.RuleNumber.Column),
            data.hasRiskIndex ? new BaseReadonlyCdr(this.data.selectedRule.RiskIndex.Column) : null,
            data.hasRiskIndex && this.data.selectedRule.RiskIndex.value !== this.data.selectedRule.RiskIndexReduced.value
                ? new BaseReadonlyCdr(this.data.selectedRule.RiskIndexReduced.Column)
                : null,
            new BaseReadonlyCdr(this.data.selectedRule.IsInActive.Column),
            new BaseReadonlyCdr(this.data.selectedRule.CountOpen.Column),
            new BaseReadonlyCdr(this.data.selectedRule.CountClosed.Column),
        ].filter((elem) => elem != null);
        this.reportDownload = Object.assign(Object.assign({}, elementalUiConfigService.Config.downloadOptions), { url: this.rulesProvider.ruleReport(this.uidCompliance) });
    }
    get objectType() {
        return this.data.selectedRule.GetEntity().TypeName;
    }
    get objectUid() {
        return this.data.selectedRule.GetEntity().GetKeys().join(',');
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
}
RulesSidesheetComponent.ɵfac = function RulesSidesheetComponent_Factory(t) { return new (t || RulesSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(RulesService), i0.ɵɵdirectiveInject(i2.ElementalUiConfigService)); };
RulesSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesSidesheetComponent, selectors: [["imx-rules-sidesheet"]], decls: 9, vars: 8, consts: [[3, "label"], ["matTabContent", ""], [3, "label", 4, "ngIf"], ["eui-sidesheet-content", ""], [3, "cdr", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "rules-sidesheet-button-download-report", 1, "justify-start", 3, "euiDownload"], [3, "cdr"], [1, "imx-mat-tab-container"], [3, "uidRule", "isMControlPerViolation"], [3, "isMControlPerViolation", "mControls", "uidNonCompliance", "uidCompliance", "sidesheetRef", "canEdit"], [3, "objectType", "objectUid"]], template: function RulesSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group")(1, "mat-tab", 0);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵtemplate(3, RulesSidesheetComponent_ng_template_3_Template, 7, 5, "ng-template", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(4, RulesSidesheetComponent_mat_tab_4_Template, 3, 3, "mat-tab", 2);
            i0.ɵɵtemplate(5, RulesSidesheetComponent_mat_tab_5_Template, 3, 3, "mat-tab", 2);
            i0.ɵɵelementStart(6, "mat-tab", 0);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵtemplate(8, RulesSidesheetComponent_ng_template_8_Template, 2, 2, "ng-template", 1);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 4, "#LDS#Heading Information"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.data);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data == null ? null : ctx.data.hasRiskIndex);
            i0.ɵɵadvance(1);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(7, 6, "#LDS#Heading Hyperview"));
        }
    }, dependencies: [i5.NgForOf, i5.NgIf, i3$1.EuiDownloadDirective, i3$1.EuiSidesheetContentDirective, i3$1.EuiSidesheetActionsDirective, i2.CdrEditorComponent, i6.MatButton, i3$2.MatCard, i8$2.MatTabGroup, i8$2.MatTab, i8$2.MatTabContent, i1.ObjectHyperviewComponent, MitigatingControlsRulesComponent, ViolationsPerRuleComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]   .mat-tab-group[_ngcontent-%COMP%], [_nghost-%COMP%]     .mat-tab-body-wrapper{height:100%}[_nghost-%COMP%]     .mat-tab-body-content{display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .imx-mat-tab-container[_ngcontent-%COMP%]{padding:20px;display:flex;flex-direction:column;overflow:auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}[_nghost-%COMP%]     .mat-tab-labels{background-color:#fff}.eui-dark-theme   [_nghost-%COMP%]     .mat-tab-labels{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]     .mat-tab-labels{background-color:#000}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesSidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-rules-sidesheet', template: "<mat-tab-group>\r\n  <mat-tab [label]=\"'#LDS#Heading Information' | translate\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content>\r\n        <mat-card>\r\n          <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\r\n        </mat-card>\r\n      </div>\r\n\r\n      <div eui-sidesheet-actions>\r\n        <button mat-stroked-button [euiDownload]=\"reportDownload\" class=\"justify-start\" data-imx-identifier=\"rules-sidesheet-button-download-report\">\r\n          {{ '#LDS#Download report' | translate }}\r\n        </button>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab *ngIf=\"data\" [label]=\"'#LDS#Heading Rule Violations' | translate\">\r\n    <ng-template matTabContent>\r\n      <div class=\"imx-mat-tab-container\">\r\n        <imx-violations-per-rule [uidRule]=\"data.selectedRule.GetEntity().GetKeys()[0]\" [isMControlPerViolation]=\"data.isMControlPerViolation\"> </imx-violations-per-rule>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab *ngIf=\"data?.hasRiskIndex\" [label]=\"'#LDS#Heading Mitigating Controls' | translate\">\r\n    <ng-template matTabContent>\r\n      <imx-mitigating-controls-rules\r\n        [isMControlPerViolation]=\"data.isMControlPerViolation\"\r\n        [mControls]=\"data.mControls\"\r\n        [uidNonCompliance]=\"uidNonCompliance\"\r\n        [uidCompliance]=\"uidCompliance\"\r\n        [sidesheetRef]=\"sidesheetRef\"\r\n        [canEdit]=\"data.canEdit\"\r\n      ></imx-mitigating-controls-rules\r\n    ></ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content>\r\n        <imx-object-hyperview [objectType]=\"data?.selectedRule?.GetEntity()?.TypeName\" [objectUid]=\"data?.selectedRule?.GetEntity()?.GetKeys()[0]\"> </imx-object-hyperview>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n</mat-tab-group>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host .mat-tab-group,:host ::ng-deep .mat-tab-body-wrapper{height:100%}:host ::ng-deep .mat-tab-body-content{display:flex;flex-direction:column;justify-content:space-between}:host .imx-mat-tab-container{padding:20px;display:flex;flex-direction:column;overflow:auto}.eui-sidesheet-actions .justify-start{margin-right:auto}:host ::ng-deep .mat-tab-labels{background-color:#fff}.eui-dark-theme :host ::ng-deep .mat-tab-labels{background-color:#2f3233}.eui-contrast-theme :host ::ng-deep .mat-tab-labels{background-color:#000}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i3$1.EuiSidesheetRef }, { type: RulesService }, { type: i2.ElementalUiConfigService }];
    }, null);
})();

function RulesComponent_ng_template_12_eui_badge_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-badge", 14);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Deactivated"));
    }
}
function RulesComponent_ng_template_12_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 10)(1, "div")(2, "div", 11);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "div", 12);
        i0.ɵɵtext(5);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(6, RulesComponent_ng_template_12_eui_badge_6_Template, 3, 3, "eui-badge", 13);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r4 = ctx.$implicit;
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(item_r4.GetEntity().GetDisplay());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r4.Description.Column.GetDisplayValue());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", item_r4.IsInActive.value);
    }
}
function RulesComponent_ng_template_15_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
    }
    if (rf & 2) {
        const rule_r6 = ctx.$implicit;
        i0.ɵɵtextInterpolate1(" ", rule_r6.CountOpen.value + rule_r6.CountClosed.value, " ");
    }
}
function RulesComponent_imx_data_table_generic_column_17_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r10 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 16)(1, "button", 17);
        i0.ɵɵlistener("click", function RulesComponent_imx_data_table_generic_column_17_ng_template_1_Template_button_click_1_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r10); const rule_r8 = restoredCtx.$implicit; const ctx_r9 = i0.ɵɵnextContext(2); ctx_r9.recalculateRule(rule_r8); return i0.ɵɵresetView($event.stopPropagation()); });
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(2, 2, "#LDS#Recalculates the violations of this compliance rule"));
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 4, "#LDS#Recalculate"), " ");
    }
}
function RulesComponent_imx_data_table_generic_column_17_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-data-table-generic-column", 15);
        i0.ɵɵtemplate(1, RulesComponent_imx_data_table_generic_column_17_ng_template_1_Template, 5, 6, "ng-template");
        i0.ɵɵelementEnd();
    }
}
const _c0$4 = function () { return ["search", "sort", "filter", "settings"]; };
class RulesComponent {
    constructor(rulesProvider, viewConfigService, mControlsProvider, sideSheetService, systemInfoService, translate, permissionService) {
        this.rulesProvider = rulesProvider;
        this.viewConfigService = viewConfigService;
        this.mControlsProvider = mControlsProvider;
        this.sideSheetService = sideSheetService;
        this.systemInfoService = systemInfoService;
        this.translate = translate;
        this.permissionService = permissionService;
        this.DisplayColumns = DisplayColumns;
        this.busyService = new BusyService();
        this.displayedColumns = [];
        this.filterOptions = [];
        this.navigationState = {};
        this.canRecalculate = false;
        this.viewConfigPath = 'rules';
        this.ruleSchema = rulesProvider.ruleSchema;
        this.displayedColumns = [
            this.ruleSchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            {
                ColumnName: 'cases',
                Type: ValType.Int,
                untranslatedDisplay: '#LDS#Rule violations',
            },
            this.ruleSchema.Columns.CountOpen,
            {
                ColumnName: 'recalculate',
                Type: ValType.String,
                afterAdditionals: true,
                untranslatedDisplay: '#LDS#Recalculate',
            },
        ];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                this.dataModel = yield this.rulesProvider.getDataModel();
                this.filterOptions = this.dataModel.Filters;
                this.viewConfig = yield this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
                this.isMControlPerViolation = (yield this.rulesProvider.featureConfig()).MitigatingControlsPerViolation;
                // We will check the configs for default state only on init
                if (!this.viewConfigService.isDefaultConfigSet()) {
                    // If we have no default settings, we have a default
                    const indexActive = this.filterOptions.findIndex((elem) => elem.Name === 'active');
                    if (indexActive > -1) {
                        this.filterOptions[indexActive].InitialValue = '1';
                        this.navigationState.active = '1';
                    }
                }
                this.canRecalculate = yield this.permissionService.isRuleStatistics();
                if (!this.canRecalculate) {
                    this.displayedColumns.pop();
                }
                yield this.navigate({}, true);
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    updateConfig(config) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.putViewConfig(config);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    deleteConfigById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.deleteViewConfig(id);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    showDetails(selectedRule) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            this.rulesProvider.handleOpenLoader();
            const hasRiskIndex = (_a = (yield this.systemInfoService.get()).PreProps) === null || _a === void 0 ? void 0 : _a.includes('RISKINDEX');
            let mControls = [];
            try {
                if (hasRiskIndex) {
                    mControls = (yield this.mControlsProvider.getControls(selectedRule.GetEntity().GetColumn('UID_NonCompliance').GetValue())).Data;
                }
            }
            finally {
                this.rulesProvider.handleCloseLoader();
            }
            yield this.sideSheetService
                .open(RulesSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Compliance Rule Details').toPromise(),
                subTitle: selectedRule.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(1200px, 80%)',
                testId: 'rule-details-sidesheet',
                data: {
                    selectedRule,
                    isMControlPerViolation: this.isMControlPerViolation,
                    hasRiskIndex,
                    mControls,
                    canEdit: this.canRecalculate && false, // TODO: When API can handle permission Update canEdit or remove "&& false" PBI: 305793
                },
            })
                .afterClosed()
                .toPromise();
        });
    }
    recalculateRule(selectedRule) {
        return __awaiter(this, void 0, void 0, function* () {
            this.rulesProvider.handleOpenLoader();
            try {
                yield this.rulesProvider.recalculate(selectedRule.GetEntity().GetKeys().join(','));
                yield this.navigate(this.navigationState);
            }
            finally {
                this.rulesProvider.handleCloseLoader();
            }
        });
    }
    navigate(parameter, isInitialLoad = false) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState = Object.assign(Object.assign({}, this.navigationState), parameter);
            const isBusy = this.busyService.beginBusy();
            try {
                const data = isInitialLoad ? { totalCount: 0, Data: [] } : yield this.rulesProvider.getRules(this.navigationState);
                if (data) {
                    const exportMethod = this.rulesProvider.exportRules(this.navigationState);
                    exportMethod.initialColumns = this.displayedColumns.map((col) => col.ColumnName);
                    this.dstSettings = {
                        displayedColumns: this.displayedColumns,
                        dataSource: data,
                        dataModel: this.dataModel,
                        entitySchema: this.ruleSchema,
                        navigationState: this.navigationState,
                        filters: this.filterOptions,
                        viewConfig: this.viewConfig,
                        exportMethod,
                    };
                }
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    onSearch(keywords) {
        this.rulesProvider.abortCall();
        return this.navigate({ search: keywords });
    }
}
RulesComponent.ɵfac = function RulesComponent_Factory(t) { return new (t || RulesComponent)(i0.ɵɵdirectiveInject(RulesService), i0.ɵɵdirectiveInject(i1.ViewConfigService), i0.ɵɵdirectiveInject(MitigatingControlsRulesService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.SystemInfoService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(CplPermissionsService)); };
RulesComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesComponent, selectors: [["imx-rules"]], decls: 19, vars: 15, consts: [[1, "mat-headline"], [1, "imx-table-container"], [3, "settings", "options", "busyService", "search", "navigationStateChanged", "updateConfig", "deleteConfigById"], ["dst", ""], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "rules-table", 3, "dst", "highlightedEntityChanged"], ["data-imx-identifier", "rules-table-column-Display", 3, "entityColumn"], ["columnName", "cases", "data-imx-identifier", "rules-table-column-Count", 3, "columnLabel"], ["data-imx-identifier", "rules-table-column-CountOpen", 3, "entityColumn"], ["columnName", "recalculate", "data-imx-identifier", "rules-table-column-Recalculate", 3, "columnLabel", 4, "ngIf"], [3, "dst"], ["data-imx-identifier", "runs-button-show-details", 1, "imx-displayColumn"], ["data-imx-identifier", "rules-table-display"], ["subtitle", "", "data-imx-identifier", "rules-table-description"], ["class", "imx-badge", "color", "gray", 4, "ngIf"], ["color", "gray", 1, "imx-badge"], ["columnName", "recalculate", "data-imx-identifier", "rules-table-column-Recalculate", 3, "columnLabel"], [1, "imx-button-column"], ["mat-stroked-button", "", "data-imx-identifier", "runs-button-show-recalculate", 3, "title", "click"]], template: function RulesComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "h2", 0)(1, "span");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card")(6, "div", 1)(7, "imx-data-source-toolbar", 2, 3);
            i0.ɵɵlistener("search", function RulesComponent_Template_imx_data_source_toolbar_search_7_listener($event) { return ctx.onSearch($event); })("navigationStateChanged", function RulesComponent_Template_imx_data_source_toolbar_navigationStateChanged_7_listener($event) { return ctx.navigate($event); })("updateConfig", function RulesComponent_Template_imx_data_source_toolbar_updateConfig_7_listener($event) { return ctx.updateConfig($event); })("deleteConfigById", function RulesComponent_Template_imx_data_source_toolbar_deleteConfigById_7_listener($event) { return ctx.deleteConfigById($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(9, "div", 1)(10, "imx-data-table", 4);
            i0.ɵɵlistener("highlightedEntityChanged", function RulesComponent_Template_imx_data_table_highlightedEntityChanged_10_listener($event) { return ctx.showDetails($event); });
            i0.ɵɵelementStart(11, "imx-data-table-column", 5);
            i0.ɵɵtemplate(12, RulesComponent_ng_template_12_Template, 7, 3, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(13, "imx-data-table-generic-column", 6);
            i0.ɵɵpipe(14, "translate");
            i0.ɵɵtemplate(15, RulesComponent_ng_template_15_Template, 1, 1, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(16, "imx-data-table-column", 7);
            i0.ɵɵtemplate(17, RulesComponent_imx_data_table_generic_column_17_Template, 2, 0, "imx-data-table-generic-column", 8);
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(18, "imx-data-source-paginator", 9);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(8);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 10, "#LDS#Heading Compliance Rules"));
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(14, _c0$4))("busyService", ctx.busyService);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.ruleSchema == null ? null : ctx.ruleSchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("columnLabel", i0.ɵɵpipeBind1(14, 12, "#LDS#Rule violations"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("entityColumn", ctx.ruleSchema.Columns.CountOpen);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.canRecalculate);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i5.NgIf, i3$1.EuiBadgeComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i6.MatButton, i3$2.MatCard, i2.HelpContextualComponent, i4.TranslatePipe], styles: ["div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit}.mat-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:3px}.imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-button-column[_ngcontent-%COMP%]{display:flex;flex-direction:row;justify-content:flex-end}.imx-button-column[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]{margin-right:16px}.imx-button-column[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.imx-displayColumn[_ngcontent-%COMP%]{display:flex;flex-direction:row}.imx-displayColumn[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:first-child{flex:1 1 auto}.imx-displayColumn[_ngcontent-%COMP%]   .imx-badge[_ngcontent-%COMP%]{align-self:center;margin-left:15px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesComponent, [{
            type: Component,
            args: [{ selector: 'imx-rules', template: "<h2 class=\"mat-headline\">\r\n  <span>{{ '#LDS#Heading Compliance Rules' | translate }}</span>\r\n  <imx-help-contextual></imx-help-contextual>\r\n</h2>\r\n<mat-card>\r\n  <div class=\"imx-table-container\">\r\n    <imx-data-source-toolbar #dst [settings]=\"dstSettings\" [options]=\"['search', 'sort', 'filter', 'settings']\"\r\n      (search)=\"onSearch($event)\" [busyService]=\"busyService\" (navigationStateChanged)=\"navigate($event)\"\r\n      (updateConfig)=\"updateConfig($event)\" (deleteConfigById)=\"deleteConfigById($event)\">\r\n    </imx-data-source-toolbar>\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-table [dst]=\"dst\" detailViewVisible=\"false\" mode=\"manual\" data-imx-identifier=\"rules-table\"\r\n        (highlightedEntityChanged)=\"showDetails($event)\">\r\n        <imx-data-table-column [entityColumn]=\"ruleSchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\"\r\n          data-imx-identifier=\"rules-table-column-Display\">\r\n          <ng-template let-item>\r\n            <div class=\"imx-displayColumn\" data-imx-identifier=\"runs-button-show-details\">\r\n              <div>\r\n                <div data-imx-identifier=\"rules-table-display\">{{ item.GetEntity().GetDisplay() }}</div>\r\n                <div subtitle data-imx-identifier=\"rules-table-description\">{{ item.Description.Column.GetDisplayValue()\r\n                  }}</div>\r\n              </div>\r\n              <eui-badge class=\"imx-badge\" *ngIf=\"item.IsInActive.value\" color=\"gray\">{{ '#LDS#Deactivated' | translate\r\n                }}</eui-badge>\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n\r\n        <imx-data-table-generic-column columnName=\"cases\" data-imx-identifier=\"rules-table-column-Count\"\r\n          [columnLabel]=\"'#LDS#Rule violations' | translate\">\r\n          <ng-template let-rule>\r\n            {{ rule.CountOpen.value + rule.CountClosed.value }}\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n\r\n        <imx-data-table-column [entityColumn]=\"ruleSchema.Columns.CountOpen\"\r\n          data-imx-identifier=\"rules-table-column-CountOpen\"> </imx-data-table-column>\r\n\r\n        <imx-data-table-generic-column *ngIf=\"canRecalculate\" columnName=\"recalculate\" [columnLabel]=\"\"\r\n          data-imx-identifier=\"rules-table-column-Recalculate\">\r\n          <ng-template let-rule>\r\n            <div class=\"imx-button-column\">\r\n              <button mat-stroked-button data-imx-identifier=\"runs-button-show-recalculate\"\r\n                (click)=\"recalculateRule(rule); $event.stopPropagation()\"\r\n                title=\"{{ '#LDS#Recalculates the violations of this compliance rule' | translate }}\">\r\n                {{ '#LDS#Recalculate' | translate }}\r\n              </button>\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n      </imx-data-table>\r\n    </div>\r\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n  </div>\r\n</mat-card>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */div[subtitle]{font-size:smaller;color:#919799}:host{display:flex;flex-direction:column;overflow:hidden;height:inherit}.mat-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:3px}.imx-table-container{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-button-column{display:flex;flex-direction:row;justify-content:flex-end}.imx-button-column .mat-stroked-button{margin-right:16px}.imx-button-column .mat-stroked-button eui-icon{font-size:14px;margin-right:4px}.imx-displayColumn{display:flex;flex-direction:row}.imx-displayColumn :first-child{flex:1 1 auto}.imx-displayColumn .imx-badge{align-self:center;margin-left:15px}\n"] }]
        }], function () { return [{ type: RulesService }, { type: i1.ViewConfigService }, { type: MitigatingControlsRulesService }, { type: i3$1.EuiSidesheetService }, { type: i2.SystemInfoService }, { type: i4.TranslateService }, { type: CplPermissionsService }]; }, null);
})();

const _c0$3 = function () { return ["search"]; };
class IdentityRuleViolationsMitigationControlComponent {
    constructor(busy, data) {
        this.busy = busy;
        this.data = data;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.getData({});
        });
    }
    onSearch(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.getData({ StartIndex: 0, search: key });
        });
    }
    getData(param) {
        return __awaiter(this, void 0, void 0, function* () {
            let overlay;
            setTimeout(() => { overlay = this.busy.show(); });
            try {
                const dataSource = yield this.data.getData(param);
                this.dstSettings = {
                    displayedColumns: this.data.displayedColumns,
                    dataSource,
                    entitySchema: this.data.entitySchema,
                    navigationState: param
                };
            }
            finally {
                setTimeout(() => this.busy.hide(overlay));
            }
        });
    }
}
IdentityRuleViolationsMitigationControlComponent.ɵfac = function IdentityRuleViolationsMitigationControlComponent_Factory(t) { return new (t || IdentityRuleViolationsMitigationControlComponent)(i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
IdentityRuleViolationsMitigationControlComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IdentityRuleViolationsMitigationControlComponent, selectors: [["imx-identity-rule-violations-mitigation-control"]], decls: 6, vars: 5, consts: [["eui-sidesheet-content", ""], [3, "settings", "options", "navigationStateChanged", "search"], ["dst", ""], ["data-imx-identifier", "identity-rule-violations-mitigation-table", "mode", "auto", 3, "dst"], [3, "dst"]], template: function IdentityRuleViolationsMitigationControlComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "imx-data-source-toolbar", 1, 2);
            i0.ɵɵlistener("navigationStateChanged", function IdentityRuleViolationsMitigationControlComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { return ctx.getData($event); })("search", function IdentityRuleViolationsMitigationControlComponent_Template_imx_data_source_toolbar_search_2_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "imx-data-table", 3)(5, "imx-data-source-paginator", 4);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(3);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(4, _c0$3));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i3$1.EuiSidesheetContentDirective, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i3$2.MatCard] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityRuleViolationsMitigationControlComponent, [{
            type: Component,
            args: [{ selector: 'imx-identity-rule-violations-mitigation-control', template: "<div eui-sidesheet-content>\r\n  <mat-card>\r\n    <imx-data-source-toolbar #dst [settings]=\"dstSettings\" [options]=\"['search']\"\r\n      (navigationStateChanged)=\"getData($event)\" (search)=\"onSearch($event)\"></imx-data-source-toolbar>\r\n    <imx-data-table [dst]=\"dst\" data-imx-identifier=\"identity-rule-violations-mitigation-table\" mode=\"auto\">\r\n    </imx-data-table>\r\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n  </mat-card>\r\n</div>" }]
        }], function () {
        return [{ type: i3$1.EuiLoadingService }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }];
    }, null);
})();

class IdentityRuleViolationService {
    constructor(api) {
        this.api = api;
    }
    get nonComplianceSchema() {
        return this.api.typedClient.PortalPersonRolemembershipsNoncompliance.GetSchema();
    }
    get portalPersonMitigatingcontrols() {
        return this.api.typedClient.PortalPersonMitigatingcontrols.GetSchema();
    }
    get portalRulesMitigatingcontrols() {
        return this.api.typedClient.PortalRulesMitigatingcontrols.GetSchema();
    }
    getNonCompliance(uidPerson, parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalPersonRolemembershipsNoncompliance.Get(uidPerson, parameter);
        });
    }
    featureConfig() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.client.portal_compliance_config_get();
        });
    }
    getPersonMitigatingcontrols(uidComplianceRule, uidPerson, param) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalPersonMitigatingcontrols.Get(uidPerson, uidComplianceRule, param);
        });
    }
    getRulesMitigatingcontrols(uidComplianceRule, param) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalRulesMitigatingcontrols.Get(uidComplianceRule, param);
        });
    }
}
IdentityRuleViolationService.ɵfac = function IdentityRuleViolationService_Factory(t) { return new (t || IdentityRuleViolationService)(i0.ɵɵinject(ApiService)); };
IdentityRuleViolationService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: IdentityRuleViolationService, factory: IdentityRuleViolationService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityRuleViolationService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: ApiService }]; }, null);
})();

function IdentityRuleViolationsComponent_ng_template_7_div_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 11);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r4 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", item_r4.GetEntity().GetDisplayLong(), " ");
    }
}
function IdentityRuleViolationsComponent_ng_template_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(2, IdentityRuleViolationsComponent_ng_template_7_div_2_Template, 2, 1, "div", 10);
    }
    if (rf & 2) {
        const item_r4 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r4.GetEntity().GetDisplay());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", item_r4.GetEntity().GetDisplay() !== item_r4.GetEntity().GetDisplayLong());
    }
}
function IdentityRuleViolationsComponent_imx_data_table_column_8_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-data-table-column", 6);
    }
    if (rf & 2) {
        const displayColumn_r7 = ctx.$implicit;
        i0.ɵɵproperty("entityColumn", displayColumn_r7);
    }
}
function IdentityRuleViolationsComponent_ng_template_11_Template(rf, ctx) {
    if (rf & 1) {
        const _r10 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 12);
        i0.ɵɵlistener("click", function IdentityRuleViolationsComponent_ng_template_11_Template_button_click_0_listener() { const restoredCtx = i0.ɵɵrestoreView(_r10); const dataItem_r8 = restoredCtx.$implicit; const ctx_r9 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r9.onShowDetails(dataItem_r8)); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const dataItem_r8 = ctx.$implicit;
        i0.ɵɵproperty("disabled", !dataItem_r8.HasMitigation.value);
        i0.ɵɵattribute("data-imx-identifier", "identity-rule-violations-" + dataItem_r8.GetEntity().GetKeys().join(","));
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 3, "#LDS#View mitigating controls"));
    }
}
const _c0$2 = function () { return ["search"]; };
const _c1 = function () { return ["__Display", "actions"]; };
class IdentityRuleViolationsComponent {
    constructor(busyService, metadataService, roleMembershipsService, settingService, sidesheet, translate, dataProvider) {
        this.busyService = busyService;
        this.metadataService = metadataService;
        this.roleMembershipsService = roleMembershipsService;
        this.settingService = settingService;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.DisplayColumns = DisplayColumns;
        this.referrer = dataProvider.data;
        this.entitySchema = this.roleMembershipsService.nonComplianceSchema;
        this.navigationState = { PageSize: this.settingService.DefaultPageSize };
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchema.Columns.XOrigin,
            this.entitySchema.Columns.XDateInserted,
            { ColumnName: 'actions', Type: ValType.String, afterAdditionals: true, untranslatedDisplay: '#LDS#Actions' },
        ];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const overlay = this.busyService.show();
            try {
                yield this.metadataService.updateNonExisting([this.referrer.objecttable]);
            }
            finally {
                this.busyService.hide(overlay);
            }
            this.caption = this.metadataService.tables[this.referrer.objecttable].Display;
            return this.getData();
        });
    }
    onShowDetails(entity) {
        return __awaiter(this, void 0, void 0, function* () {
            const uidPerson = this.referrer.objectuid;
            const con = yield this.roleMembershipsService.featureConfig();
            const data = {
                getData: (param) => __awaiter(this, void 0, void 0, function* () {
                    return con.MitigatingControlsPerViolation
                        ? this.roleMembershipsService.getPersonMitigatingcontrols(entity.UID_NonCompliance.value, uidPerson, param)
                        : this.roleMembershipsService.getRulesMitigatingcontrols(entity.UID_NonCompliance.value, param);
                }),
                entitySchema: con.MitigatingControlsPerViolation
                    ? this.roleMembershipsService.portalPersonMitigatingcontrols
                    : this.roleMembershipsService.portalRulesMitigatingcontrols,
                displayedColumns: con.MitigatingControlsPerViolation
                    ? [
                        this.roleMembershipsService.portalPersonMitigatingcontrols.Columns.UID_MitigatingControl,
                        this.roleMembershipsService.portalPersonMitigatingcontrols.Columns.UID_PersonWantsOrg,
                        this.roleMembershipsService.portalPersonMitigatingcontrols.Columns.IsInActive,
                    ]
                    : [this.roleMembershipsService.portalRulesMitigatingcontrols.Columns.UID_MitigatingControl],
            };
            this.sidesheet.open(IdentityRuleViolationsMitigationControlComponent, {
                title: yield this.translate.get('#LDS#Heading View Mitigating Controls').toPromise(),
                subTitle: entity.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(600px,60%)',
                disableClose: false,
                testId: 'identity-rule-violation-mitigating-sidesheet',
                data,
            });
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.getData();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.getData();
        });
    }
    getData() {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => (overlayRef = this.busyService.show()));
            try {
                const dataSource = yield this.roleMembershipsService.getNonCompliance(this.referrer.objectuid, this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource,
                    entitySchema: this.entitySchema,
                    navigationState: this.navigationState,
                };
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
        });
    }
}
IdentityRuleViolationsComponent.ɵfac = function IdentityRuleViolationsComponent_Factory(t) { return new (t || IdentityRuleViolationsComponent)(i0.ɵɵdirectiveInject(i3$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.MetadataService), i0.ɵɵdirectiveInject(IdentityRuleViolationService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i2.DynamicTabDataProviderDirective)); };
IdentityRuleViolationsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: IdentityRuleViolationsComponent, selectors: [["ng-component"]], decls: 13, vars: 11, consts: [[1, "imx-content"], [1, "imx-rule-violation-table-container"], [3, "settings", "options", "navigationStateChanged", "search"], ["dst", ""], [1, "imx-rule-violation-table"], ["detailViewVisible", "false", "data-imx-identifier", "identity-rule-violations-table", "mode", "manual", 3, "dst"], [3, "entityColumn"], [3, "entityColumn", 4, "ngFor", "ngForOf"], ["columnName", "actions"], [3, "dst"], ["subtitle", "", 4, "ngIf"], ["subtitle", ""], ["mat-button", "", "color", "primary", 3, "disabled", "click"]], template: function IdentityRuleViolationsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card", 1)(2, "imx-data-source-toolbar", 2, 3);
            i0.ɵɵlistener("navigationStateChanged", function IdentityRuleViolationsComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function IdentityRuleViolationsComponent_Template_imx_data_source_toolbar_search_2_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "div", 4)(5, "imx-data-table", 5)(6, "imx-data-table-column", 6);
            i0.ɵɵtemplate(7, IdentityRuleViolationsComponent_ng_template_7_Template, 3, 2, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(8, IdentityRuleViolationsComponent_imx_data_table_column_8_Template, 1, 1, "imx-data-table-column", 7);
            i0.ɵɵpipe(9, "excludedColumns");
            i0.ɵɵelementStart(10, "imx-data-table-generic-column", 8);
            i0.ɵɵtemplate(11, IdentityRuleViolationsComponent_ng_template_11_Template, 3, 5, "ng-template");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(12, "imx-data-source-paginator", 9);
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(3);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(9, _c0$2));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", i0.ɵɵpipeBind2(9, 6, ctx.displayedColumns, i0.ɵɵpureFunction0(10, _c1)));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i5.NgForOf, i5.NgIf, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i6.MatButton, i3$2.MatCard, i2.ExcludedColumnsPipe, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-rule-violation-table[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}.imx-card-header[_ngcontent-%COMP%]{margin-top:10px;background-color:#fff;border-top-left-radius:4px;border-top-right-radius:4px;z-index:100;border:1px solid rgba(10,150,209,.6)}.imx-card-header[_ngcontent-%COMP%]   .imx-card-header-bg[_ngcontent-%COMP%]{border-top-left-radius:4px;border-top-right-radius:4px;background-color:#cbe8f2;padding:10px 24px;display:flex;align-items:center;justify-content:flex-start}.imx-card-header[_ngcontent-%COMP%]   .imx-card-header-bg[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#0a96d199;margin-right:10px}.imx-card-header[_ngcontent-%COMP%]   .imx-card-header-bg[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{font-size:20px}.imx-content[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto}.imx-content[_ngcontent-%COMP%]   .imx-rule-violation-table-container[_ngcontent-%COMP%]{overflow:hidden;display:flex;flex-direction:column;flex:1 1 auto}.eui-dark-theme   [_nghost-%COMP%]   .imx-card-header[_ngcontent-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .imx-card-header[_ngcontent-%COMP%]{background-color:#000}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityRuleViolationsComponent, [{
            type: Component,
            args: [{ template: "<div class=\"imx-content\">\r\n  <mat-card class=\"imx-rule-violation-table-container\">\r\n    <imx-data-source-toolbar #dst [settings]=\"dstSettings\" [options]=\"['search']\"\r\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\" (search)=\"onSearch($event)\"></imx-data-source-toolbar>\r\n    <div class=\"imx-rule-violation-table\">\r\n      <imx-data-table [dst]=\"dst\" detailViewVisible=\"false\" data-imx-identifier=\"identity-rule-violations-table\"\r\n        mode=\"manual\">\r\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n          <ng-template let-item>\r\n            <div>{{ item.GetEntity().GetDisplay() }}</div>\r\n            <div *ngIf=\"item.GetEntity().GetDisplay() !== item.GetEntity().GetDisplayLong()\" subtitle>\r\n              {{ item.GetEntity().GetDisplayLong() }}\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n        <imx-data-table-column *ngFor=\"let displayColumn of displayedColumns | excludedColumns:['__Display', 'actions']\" [entityColumn]=\"displayColumn\">\r\n        </imx-data-table-column>\r\n\r\n        <imx-data-table-generic-column columnName=\"actions\">\r\n          <ng-template let-dataItem>\r\n            <button mat-button color=\"primary\" [disabled]=\"!dataItem.HasMitigation.value\"\r\n              [attr.data-imx-identifier]=\"'identity-rule-violations-' + dataItem.GetEntity().GetKeys().join(',')\"\r\n              (click)=\"onShowDetails(dataItem)\">{{'#LDS#View mitigating controls' |translate}}</button>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n      </imx-data-table>\r\n      <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n    </div>\r\n  </mat-card>\r\n</div>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-rule-violation-table{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}.imx-card-header{margin-top:10px;background-color:#fff;border-top-left-radius:4px;border-top-right-radius:4px;z-index:100;border:1px solid rgba(10,150,209,.6)}.imx-card-header .imx-card-header-bg{border-top-left-radius:4px;border-top-right-radius:4px;background-color:#cbe8f2;padding:10px 24px;display:flex;align-items:center;justify-content:flex-start}.imx-card-header .imx-card-header-bg .eui-icon{color:#0a96d199;margin-right:10px}.imx-card-header .imx-card-header-bg>span{font-size:20px}.imx-content{height:100%;display:flex;flex-direction:column;flex:1 1 auto;overflow-y:auto}.imx-content .imx-rule-violation-table-container{overflow:hidden;display:flex;flex-direction:column;flex:1 1 auto}.eui-dark-theme :host .imx-card-header{background-color:#2f3233}.eui-contrast-theme :host .imx-card-header{background-color:#000}\n"] }]
        }], function () { return [{ type: i3$1.EuiLoadingService }, { type: i2.MetadataService }, { type: IdentityRuleViolationService }, { type: i2.SettingsService }, { type: i3$1.EuiSidesheetService }, { type: i4.TranslateService }, { type: i2.DynamicTabDataProviderDirective }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class IdentityRuleViolationsModule {
}
IdentityRuleViolationsModule.ɵfac = function IdentityRuleViolationsModule_Factory(t) { return new (t || IdentityRuleViolationsModule)(); };
IdentityRuleViolationsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: IdentityRuleViolationsModule });
IdentityRuleViolationsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        EuiCoreModule,
        DataSourceToolbarModule,
        DataTableModule,
        TranslateModule,
        MatButtonModule,
        MatCardModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(IdentityRuleViolationsModule, [{
            type: NgModule,
            args: [{
                    declarations: [IdentityRuleViolationsComponent, IdentityRuleViolationsMitigationControlComponent],
                    imports: [
                        CommonModule,
                        EuiCoreModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        TranslateModule,
                        MatButtonModule,
                        MatCardModule
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(IdentityRuleViolationsModule, { declarations: [IdentityRuleViolationsComponent, IdentityRuleViolationsMitigationControlComponent], imports: [CommonModule,
            EuiCoreModule,
            DataSourceToolbarModule,
            DataTableModule,
            TranslateModule,
            MatButtonModule,
            MatCardModule] });
})();

function RulesViolationsComponent_ng_template_16_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
    }
    if (rf & 2) {
        const item_r6 = ctx.$implicit;
        i0.ɵɵtextInterpolate1(" ", item_r6 == null ? null : item_r6.stateBadge == null ? null : item_r6.stateBadge.caption, " ");
    }
}
function RulesViolationsComponent_imx_data_table_column_17_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-data-table-column", 22);
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵproperty("entityColumn", ctx_r3.entitySchema.Columns.RiskIndexCalculated);
    }
}
function RulesViolationsComponent_imx_data_table_column_18_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-data-table-column", 23);
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext();
        i0.ɵɵproperty("entityColumn", ctx_r4.entitySchema.Columns.RiskIndexReduced);
    }
}
function RulesViolationsComponent_ng_template_20_Template(rf, ctx) {
    if (rf & 1) {
        const _r9 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 24)(1, "button", 25);
        i0.ɵɵlistener("click", function RulesViolationsComponent_ng_template_20_Template_button_click_1_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r9); const item_r7 = restoredCtx.$implicit; const ctx_r8 = i0.ɵɵnextContext(); $event.stopPropagation(); return i0.ɵɵresetView(ctx_r8.actionService.deny([item_r7])); });
        i0.ɵɵelement(2, "eui-icon", 19);
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "button", 26);
        i0.ɵɵlistener("click", function RulesViolationsComponent_ng_template_20_Template_button_click_5_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r9); const item_r7 = restoredCtx.$implicit; const ctx_r10 = i0.ɵɵnextContext(); $event.stopPropagation(); return i0.ɵɵresetView(ctx_r10.actionService.approve([item_r7])); });
        i0.ɵɵelement(6, "eui-icon", 21);
        i0.ɵɵtext(7);
        i0.ɵɵpipe(8, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "#LDS#Deny exception"), " ");
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 4, "#LDS#Grant exception"), " ");
    }
}
const _c0$1 = function () { return ["search", "sort", "filter", "groupBy", "settings"]; };
/**
 * Component that shows all rules violations that the user can approve or deny.
 * Therefore, the user can also view some information about the rules violations.
 *
 * Initially only the pending rules violations are shown.
 *
 */
class RulesViolationsComponent {
    constructor(rulesViolationsService, actionService, viewConfigService, mControlsProvider, sidesheet, translate, logger, systemInfoService, activatedRoute, elementalBusyService) {
        this.rulesViolationsService = rulesViolationsService;
        this.actionService = actionService;
        this.viewConfigService = viewConfigService;
        this.mControlsProvider = mControlsProvider;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.logger = logger;
        this.systemInfoService = systemInfoService;
        this.activatedRoute = activatedRoute;
        this.elementalBusyService = elementalBusyService;
        this.hasRiskIndex = false;
        this.selectedRulesViolations = [];
        this.groupedData = {};
        this.busyService = new BusyService();
        this.viewConfigPath = 'rules/violations';
        this.subscriptions = [];
        this.subscriptions.push(this.actionService.applied.subscribe(() => __awaiter(this, void 0, void 0, function* () {
            this.getData();
            this.table.clearSelection();
        })));
    }
    ngOnInit() {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const entitySchema = this.rulesViolationsService.rulesViolationsApproveSchema;
                this.entitySchema = entitySchema;
                // If this wasn't already set, then we need to get it from the config
                (_a = this.isMControlPerViolation) !== null && _a !== void 0 ? _a : (this.isMControlPerViolation = (yield this.rulesViolationsService.featureConfig()).MitigatingControlsPerViolation);
                this.hasRiskIndex = (_c = (_b = (yield this.systemInfoService.get()).PreProps) === null || _b === void 0 ? void 0 : _b.includes('RISKINDEX')) !== null && _c !== void 0 ? _c : false;
                const displayedColumns = [
                    entitySchema.Columns.UID_Person,
                    entitySchema.Columns.UID_NonCompliance,
                    entitySchema.Columns.State,
                ];
                if (this.hasRiskIndex) {
                    displayedColumns.push(entitySchema.Columns.RiskIndexCalculated, entitySchema.Columns.RiskIndexReduced);
                }
                displayedColumns.push({
                    ColumnName: 'decision',
                    Type: ValType.String,
                    afterAdditionals: true,
                    untranslatedDisplay: '#LDS#Approval decision',
                });
                this.dataModelWrapper = {
                    dataModel: yield this.rulesViolationsService.getDataModel(),
                    getGroupInfo: (parameters) => this.rulesViolationsService.getGroupInfo(parameters),
                    groupingFilterOptions: ['state'],
                };
                this.viewConfig = yield this.viewConfigService.getInitialDSTExtension(this.dataModelWrapper.dataModel, this.viewConfigPath);
                this.dstWrapper = new DataSourceWrapper((state, requestOpts, isInitial) => isInitial
                    ? Promise.resolve({ totalCount: 0, Data: [] })
                    : this.rulesViolationsService.getRulesViolationsApprove(state, requestOpts), displayedColumns, entitySchema, this.dataModelWrapper);
                this.subscriptions.push(this.activatedRoute.queryParams.subscribe((params) => this.updateFiltersFromRouteParams(params)));
            }
            finally {
                isBusy.endBusy();
            }
            yield this.getData(undefined, true);
        });
    }
    ngOnDestroy() {
        this.subscriptions.forEach((s) => s.unsubscribe());
    }
    updateConfig(config) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.putViewConfig(config);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    deleteConfigById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.deleteViewConfig(id);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    getData(parameter, isInitialLoad = false) {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const dstSettings = yield this.dstWrapper.getDstSettings(parameter, { signal: this.rulesViolationsService.abortController.signal }, isInitialLoad);
                if (dstSettings) {
                    this.dstSettings = dstSettings;
                    this.dstSettings.exportMethod = this.rulesViolationsService.exportRulesViolations(parameter);
                    this.dstSettings.viewConfig = this.viewConfig;
                }
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    onSearch(keywords) {
        this.rulesViolationsService.abortCall();
        return this.getData({ search: keywords });
    }
    onSelectionChanged(items) {
        this.logger.trace(this, 'selection changed', items);
        this.selectedRulesViolations = items;
    }
    /**
     * Opens the {@link RulesViolationsDetailsComponent} sidesheet thats shows some informations of the selected rules violation.
     * @param selectedRulesViolation the selected {@link RulesViolationsApproval}
     */
    viewDetails(selectedRulesViolation) {
        return __awaiter(this, void 0, void 0, function* () {
            let complianceRule;
            this.elementalBusyService.show();
            try {
                complianceRule = yield this.rulesViolationsService.getComplianceRuleByUId(selectedRulesViolation);
            }
            finally {
                this.elementalBusyService.hide();
            }
            if (!complianceRule) {
                return;
            }
            // TODO: Make API for mit conts
            const result = yield this.sidesheet
                .open(RulesViolationsDetailsComponent, {
                title: yield this.translate.get('#LDS#Heading View Rule Violation Details').toPromise(),
                subTitle: selectedRulesViolation.GetEntity().GetDisplay(),
                padding: '0px',
                panelClass: 'imx-sidesheet',
                disableClose: this.isMControlPerViolation,
                width: 'max(1200px, 80%)',
                testId: 'rules-violations-details-sidesheet',
                data: {
                    selectedRulesViolation,
                    isMControlPerViolation: this.isMControlPerViolation,
                    complianceRule,
                },
            })
                .afterClosed()
                .toPromise();
            if (result) {
                this.getData();
            }
        });
    }
    onGroupingChange(groupInfo) {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const groupedData = this.groupedData[groupInfo.key];
                groupedData.data = groupInfo.isInitial
                    ? { totalCount: 0, Data: [] }
                    : yield this.rulesViolationsService.getRulesViolationsApprove(groupedData.navigationState);
                groupedData.settings = {
                    displayedColumns: this.dstSettings.displayedColumns,
                    dataModel: this.dstSettings.dataModel,
                    dataSource: groupedData.data,
                    entitySchema: this.dstSettings.entitySchema,
                    navigationState: groupedData.navigationState,
                };
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    updateFiltersFromRouteParams(params) {
        if (this.viewConfigService.isDefaultConfigSet()) {
            // If we have a default config, we won't set our filters
            return;
        }
        let foundMatchingParam = false;
        for (const [key, value] of Object.entries(params)) {
            if (this.tryApplyFilter(key, value)) {
                foundMatchingParam = true;
            }
        }
        if (!foundMatchingParam) {
            this.applyDefaultFiltering();
        }
    }
    applyDefaultFiltering() {
        this.tryApplyFilter('state', 'pending');
    }
    tryApplyFilter(name, value) {
        const index = this.dataModelWrapper.dataModel.Filters.findIndex((elem) => elem.Name.toLowerCase() === name.toLowerCase());
        if (index > -1) {
            const filter = this.dataModelWrapper.dataModel.Filters[index];
            if (filter) {
                filter.InitialValue = value;
                filter.CurrentValue = value;
                return true;
            }
        }
        return false;
    }
}
RulesViolationsComponent.ɵfac = function RulesViolationsComponent_Factory(t) { return new (t || RulesViolationsComponent)(i0.ɵɵdirectiveInject(RulesViolationsService), i0.ɵɵdirectiveInject(RulesViolationsActionService), i0.ɵɵdirectiveInject(i1.ViewConfigService), i0.ɵɵdirectiveInject(MitigatingControlsPersonService), i0.ɵɵdirectiveInject(i3$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i2.SystemInfoService), i0.ɵɵdirectiveInject(i3.ActivatedRoute), i0.ɵɵdirectiveInject(i3$1.EuiLoadingService)); };
RulesViolationsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RulesViolationsComponent, selectors: [["imx-rules-violations"]], viewQuery: function RulesViolationsComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(DataTableComponent, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.table = _t.first);
        }
    }, inputs: { isMControlPerViolation: "isMControlPerViolation" }, decls: 33, vars: 27, consts: [[1, "imx-rules-violations-page"], [1, "heading-wrapper"], [1, "mat-headline"], [1, "imx-table-container"], ["data-imx-identifier", "rules-violations-dst", 3, "options", "settings", "busyService", "search", "navigationStateChanged", "updateConfig", "deleteConfigById"], ["dst", ""], ["mode", "manual", "data-imx-identifier", "rules-violations-datatable", 1, "imx-rules-violations-table", 3, "dst", "detailViewVisible", "selectable", "showSelectedItemsMenu", "groupData", "selectionChanged", "highlightedEntityChanged", "groupDataChanged"], ["dataTable", ""], ["data-imx-identifier", "rules-violations-table-column-UidPerson", 3, "entityColumn"], ["data-imx-identifier", "rules-violations-table-column-UID_NonCompliance", 3, "entityColumn"], ["data-imx-identifier", "rules-violations-table-column-state", 3, "entityColumn"], ["data-imx-identifier", "rules-violations-table-column-RiskIndexCalculated", 3, "entityColumn", 4, "ngIf"], ["data-imx-identifier", "rules-violations-table-column-RiskIndexReduced", 3, "entityColumn", 4, "ngIf"], ["columnName", "decision", "data-imx-identifier", "rules-violations-table-column-decision"], ["data-imx-identifier", "rules-violations-paginator", 3, "dst"], [1, "imx-button-bar"], [3, "selectedElements"], [1, "imx-menu-spacer"], ["color", "warn", "mat-raised-button", "", "data-imx-identifier", "rules-violations-button-deny", 3, "disabled", "click"], ["icon", "ignore"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "rules-violations-button-approve", 3, "disabled", "click"], ["icon", "check"], ["data-imx-identifier", "rules-violations-table-column-RiskIndexCalculated", 3, "entityColumn"], ["data-imx-identifier", "rules-violations-table-column-RiskIndexReduced", 3, "entityColumn"], [1, "imx-decision"], ["color", "warn", "mat-stroked-button", "", "data-imx-identifier", "rules-violations-table-row-button-deny", 3, "click"], ["color", "primary", "mat-stroked-button", "", "data-imx-identifier", "rules-violations-table-row-button-approve", 1, "imx-margin-right", 3, "click"]], template: function RulesViolationsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
            i0.ɵɵtext(4);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(6, "imx-help-contextual");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(7, "mat-card")(8, "div", 3)(9, "imx-data-source-toolbar", 4, 5);
            i0.ɵɵlistener("search", function RulesViolationsComponent_Template_imx_data_source_toolbar_search_9_listener($event) { return ctx.onSearch($event); })("navigationStateChanged", function RulesViolationsComponent_Template_imx_data_source_toolbar_navigationStateChanged_9_listener($event) { return ctx.getData($event); })("updateConfig", function RulesViolationsComponent_Template_imx_data_source_toolbar_updateConfig_9_listener($event) { return ctx.updateConfig($event); })("deleteConfigById", function RulesViolationsComponent_Template_imx_data_source_toolbar_deleteConfigById_9_listener($event) { return ctx.deleteConfigById($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(11, "imx-data-table", 6, 7);
            i0.ɵɵlistener("selectionChanged", function RulesViolationsComponent_Template_imx_data_table_selectionChanged_11_listener($event) { return ctx.onSelectionChanged($event); })("highlightedEntityChanged", function RulesViolationsComponent_Template_imx_data_table_highlightedEntityChanged_11_listener($event) { return ctx.viewDetails($event); })("groupDataChanged", function RulesViolationsComponent_Template_imx_data_table_groupDataChanged_11_listener($event) { return ctx.onGroupingChange($event); });
            i0.ɵɵelement(13, "imx-data-table-column", 8)(14, "imx-data-table-column", 9);
            i0.ɵɵelementStart(15, "imx-data-table-column", 10);
            i0.ɵɵtemplate(16, RulesViolationsComponent_ng_template_16_Template, 1, 1, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(17, RulesViolationsComponent_imx_data_table_column_17_Template, 1, 1, "imx-data-table-column", 11);
            i0.ɵɵtemplate(18, RulesViolationsComponent_imx_data_table_column_18_Template, 1, 1, "imx-data-table-column", 12);
            i0.ɵɵelementStart(19, "imx-data-table-generic-column", 13);
            i0.ɵɵtemplate(20, RulesViolationsComponent_ng_template_20_Template, 9, 6, "ng-template");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(21, "imx-data-source-paginator", 14);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(22, "div", 15);
            i0.ɵɵelement(23, "imx-selected-elements", 16)(24, "div", 17);
            i0.ɵɵelementStart(25, "button", 18);
            i0.ɵɵlistener("click", function RulesViolationsComponent_Template_button_click_25_listener() { return ctx.actionService.deny(ctx.selectedRulesViolations); });
            i0.ɵɵelement(26, "eui-icon", 19);
            i0.ɵɵtext(27);
            i0.ɵɵpipe(28, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(29, "button", 20);
            i0.ɵɵlistener("click", function RulesViolationsComponent_Template_button_click_29_listener() { return ctx.actionService.approve(ctx.selectedRulesViolations); });
            i0.ɵɵelement(30, "eui-icon", 21);
            i0.ɵɵtext(31);
            i0.ɵɵpipe(32, "translate");
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(10);
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 20, "#LDS#Heading Rule Violations"));
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("options", i0.ɵɵpureFunction0(26, _c0$1))("settings", ctx.dstSettings)("busyService", ctx.busyService);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0)("detailViewVisible", false)("selectable", true)("showSelectedItemsMenu", false)("groupData", ctx.groupedData);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns.UID_Person);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns.UID_NonCompliance);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns.State);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.hasRiskIndex);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.hasRiskIndex);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("selectedElements", ctx.selectedRulesViolations);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.selectedRulesViolations.length);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(28, 22, "#LDS#Deny exception"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.selectedRulesViolations.length);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(32, 24, "#LDS#Grant exception"), " ");
        }
    }, dependencies: [i5.NgIf, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i3$1.EuiIconComponent, i6.MatButton, i3$2.MatCard, i2.SelectedElementsComponent, i2.HelpContextualComponent, i4.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.heading-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex:0 0 auto}.heading-wrapper[_ngcontent-%COMP%]   .helper-alert[_ngcontent-%COMP%]{display:flex;margin-bottom:15px}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;max-width:100%}.imx-rules-violations-page[_ngcontent-%COMP%]{background-color:inherit;display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-rules-violations-page[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-rules-violations-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-rules-violations-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-rules-violations-table[_ngcontent-%COMP%]{flex-grow:1;overflow:auto}.imx-rules-violations-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-rules-violations-table[_ngcontent-%COMP%]   .imx-decision[_ngcontent-%COMP%]{display:flex;flex-direction:row;justify-content:flex-end}.imx-rules-violations-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-rules-violations-table[_ngcontent-%COMP%]   .imx-decision[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]{margin-right:16px}.imx-rules-violations-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-rules-violations-table[_ngcontent-%COMP%]   .imx-decision[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.imx-rules-violations-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-rules-violations-table[_ngcontent-%COMP%]   .imx-decision[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:5px}.imx-rules-violations-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-rules-violations-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:16px}.imx-rules-violations-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .imx-menu-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.imx-rules-violations-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%], .imx-rules-violations-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .mat-raised-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.imx-margin-right[_ngcontent-%COMP%]{margin-right:10px}@media screen and (max-width: 768px){.imx-rules-violations-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]{display:block}.imx-rules-violations-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]   .alert-wrapper[_ngcontent-%COMP%]{margin:0 0 20px;width:100%}}@media only screen and (max-width: 1024px){  .mat-column-decision{display:none}}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsComponent, [{
            type: Component,
            args: [{ selector: 'imx-rules-violations', template: "<div class=\"imx-rules-violations-page\">\r\n  <div class=\"heading-wrapper\">\r\n    <h2 class=\"mat-headline\">\r\n      <span>{{ '#LDS#Heading Rule Violations' | translate }}</span>\r\n      <imx-help-contextual></imx-help-contextual>\r\n    </h2>\r\n  </div>\r\n  <mat-card>\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-source-toolbar\r\n        #dst\r\n        [options]=\"['search', 'sort', 'filter', 'groupBy', 'settings']\"\r\n        [settings]=\"dstSettings\"\r\n        [busyService]=\"busyService\"\r\n        (search)=\"onSearch($event)\"\r\n        (navigationStateChanged)=\"getData($event)\"\r\n        (updateConfig)=\"updateConfig($event)\"\r\n        (deleteConfigById)=\"deleteConfigById($event)\"\r\n        data-imx-identifier=\"rules-violations-dst\"\r\n      >\r\n      </imx-data-source-toolbar>\r\n      <imx-data-table\r\n        #dataTable\r\n        [dst]=\"dst\"\r\n        class=\"imx-rules-violations-table\"\r\n        [detailViewVisible]=\"false\"\r\n        mode=\"manual\"\r\n        [selectable]=\"true\"\r\n        [showSelectedItemsMenu]=\"false\"\r\n        (selectionChanged)=\"onSelectionChanged($event)\"\r\n        (highlightedEntityChanged)=\"viewDetails($event)\"\r\n        [groupData]=\"groupedData\"\r\n        (groupDataChanged)=\"onGroupingChange($event)\"\r\n        data-imx-identifier=\"rules-violations-datatable\"\r\n      >\r\n        <imx-data-table-column data-imx-identifier=\"rules-violations-table-column-UidPerson\" [entityColumn]=\"entitySchema?.Columns.UID_Person\"> </imx-data-table-column>\r\n        <imx-data-table-column data-imx-identifier=\"rules-violations-table-column-UID_NonCompliance\" [entityColumn]=\"entitySchema?.Columns.UID_NonCompliance\">\r\n        </imx-data-table-column>\r\n        <imx-data-table-column data-imx-identifier=\"rules-violations-table-column-state\" [entityColumn]=\"entitySchema?.Columns.State\">\r\n          <ng-template let-item>\r\n            {{ item?.stateBadge?.caption }}\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n        <imx-data-table-column\r\n          *ngIf=\"hasRiskIndex\"\r\n          [entityColumn]=\"entitySchema.Columns.RiskIndexCalculated\"\r\n          data-imx-identifier=\"rules-violations-table-column-RiskIndexCalculated\"\r\n        >\r\n        </imx-data-table-column>\r\n        <imx-data-table-column *ngIf=\"hasRiskIndex\" [entityColumn]=\"entitySchema.Columns.RiskIndexReduced\" data-imx-identifier=\"rules-violations-table-column-RiskIndexReduced\">\r\n        </imx-data-table-column>\r\n        <imx-data-table-generic-column columnName=\"decision\" data-imx-identifier=\"rules-violations-table-column-decision\">\r\n          <ng-template let-item>\r\n            <div class=\"imx-decision\">\r\n              <button color=\"warn\" mat-stroked-button (click)=\"$event.stopPropagation(); actionService.deny([item])\" data-imx-identifier=\"rules-violations-table-row-button-deny\">\r\n                <eui-icon icon=\"ignore\"></eui-icon>\r\n                {{ '#LDS#Deny exception' | translate }}\r\n              </button>\r\n              <button\r\n                color=\"primary\"\r\n                mat-stroked-button\r\n                (click)=\"$event.stopPropagation(); actionService.approve([item])\"\r\n                data-imx-identifier=\"rules-violations-table-row-button-approve\"\r\n                class=\"imx-margin-right\"\r\n              >\r\n                <eui-icon icon=\"check\"></eui-icon>\r\n                {{ '#LDS#Grant exception' | translate }}\r\n              </button>\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n      </imx-data-table>\r\n      <imx-data-source-paginator data-imx-identifier=\"rules-violations-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\r\n    </div>\r\n  </mat-card>\r\n  <div class=\"imx-button-bar\">\r\n    <imx-selected-elements [selectedElements]=\"selectedRulesViolations\"></imx-selected-elements>\r\n    <div class=\"imx-menu-spacer\"></div>\r\n    <button\r\n      color=\"warn\"\r\n      mat-raised-button\r\n      (click)=\"actionService.deny(selectedRulesViolations)\"\r\n      data-imx-identifier=\"rules-violations-button-deny\"\r\n      [disabled]=\"!selectedRulesViolations.length\"\r\n    >\r\n      <eui-icon icon=\"ignore\"></eui-icon>\r\n      {{ '#LDS#Deny exception' | translate }}\r\n    </button>\r\n    <button\r\n      mat-raised-button\r\n      color=\"primary\"\r\n      (click)=\"actionService.approve(selectedRulesViolations)\"\r\n      data-imx-identifier=\"rules-violations-button-approve\"\r\n      [disabled]=\"!selectedRulesViolations.length\"\r\n    >\r\n      <eui-icon icon=\"check\"></eui-icon>\r\n      {{ '#LDS#Grant exception' | translate }}\r\n    </button>\r\n  </div>\r\n</div>\r\n", styles: [".eui-sidesheet-content{display:flex;flex-direction:column}.heading-wrapper{display:flex;flex-direction:row;flex:0 0 auto}.heading-wrapper .helper-alert{display:flex;margin-bottom:15px}:host{display:flex;flex-direction:column;overflow:hidden;height:inherit;max-width:100%}.imx-rules-violations-page{background-color:inherit;display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-rules-violations-page .mat-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-rules-violations-page div.imx-table-container{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-rules-violations-page div.imx-table-container .imx-rules-violations-table{flex-grow:1;overflow:auto}.imx-rules-violations-page div.imx-table-container .imx-rules-violations-table .imx-decision{display:flex;flex-direction:row;justify-content:flex-end}.imx-rules-violations-page div.imx-table-container .imx-rules-violations-table .imx-decision .mat-stroked-button{margin-right:16px}.imx-rules-violations-page div.imx-table-container .imx-rules-violations-table .imx-decision .mat-stroked-button eui-icon{font-size:14px;margin-right:4px}.imx-rules-violations-page div.imx-table-container .imx-rules-violations-table .imx-decision>button:not(:last-of-type){margin-right:5px}.imx-rules-violations-page .imx-button-bar{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-rules-violations-page .imx-button-bar>button:not(:last-of-type){margin-right:16px}.imx-rules-violations-page .imx-button-bar .imx-menu-spacer{flex:1 1 auto}.imx-rules-violations-page .imx-button-bar .mat-stroked-button eui-icon,.imx-rules-violations-page .imx-button-bar .mat-raised-button eui-icon{font-size:14px;margin-right:4px}.imx-margin-right{margin-right:10px}@media screen and (max-width: 768px){.imx-rules-violations-page .heading-wrapper{display:block}.imx-rules-violations-page .heading-wrapper .alert-wrapper{margin:0 0 20px;width:100%}}@media only screen and (max-width: 1024px){::ng-deep .mat-column-decision{display:none}}\n"] }]
        }], function () { return [{ type: RulesViolationsService }, { type: RulesViolationsActionService }, { type: i1.ViewConfigService }, { type: MitigatingControlsPersonService }, { type: i3$1.EuiSidesheetService }, { type: i4.TranslateService }, { type: i2.ClassloggerService }, { type: i2.SystemInfoService }, { type: i3.ActivatedRoute }, { type: i3$1.EuiLoadingService }]; }, { isMControlPerViolation: [{
                type: Input
            }], table: [{
                type: ViewChild,
                args: [DataTableComponent]
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class MitigatingControlContainerModule {
}
MitigatingControlContainerModule.ɵfac = function MitigatingControlContainerModule_Factory(t) { return new (t || MitigatingControlContainerModule)(); };
MitigatingControlContainerModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: MitigatingControlContainerModule });
MitigatingControlContainerModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, EuiCoreModule, EuiMaterialModule, CdrModule, TranslateModule.forChild()] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlContainerModule, [{
            type: NgModule,
            args: [{
                    declarations: [MitigatingControlContainerComponent],
                    imports: [CommonModule, EuiCoreModule, EuiMaterialModule, CdrModule, TranslateModule.forChild()],
                    exports: [MitigatingControlContainerComponent],
                }]
        }], null, null);
})();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(MitigatingControlContainerModule, { declarations: [MitigatingControlContainerComponent], imports: [CommonModule, EuiCoreModule, EuiMaterialModule, CdrModule, i4.TranslateModule], exports: [MitigatingControlContainerComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RulesViolationsModule {
    constructor(menuService, logger) {
        this.menuService = menuService;
        logger.info(this, '▶︝ RulesViolationsnModule loaded');
        this.setupMenu();
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features, projectConfig, groups) => {
            const items = [];
            if (preProps.includes('ITSHOP') && isExceptionAdmin(groups)) {
                items.push({
                    id: 'CPL_Compliance_RulesViolations',
                    navigationCommands: {
                        commands: ['compliance', 'rulesviolations', 'approve']
                    },
                    title: '#LDS#Menu Entry Rule violations',
                    description: '#LDS#Shows the rule violations for which you can grant or deny exceptions.',
                    sorting: '25-20',
                });
            }
            if (items.length === 0) {
                return null;
            }
            return {
                id: 'ROOT_Compliance',
                title: '#LDS#Compliance',
                sorting: '25',
                items
            };
        });
    }
}
RulesViolationsModule.ɵfac = function RulesViolationsModule_Factory(t) { return new (t || RulesViolationsModule)(i0.ɵɵinject(i2.MenuService), i0.ɵɵinject(i2.ClassloggerService)); };
RulesViolationsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RulesViolationsModule });
RulesViolationsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CdrModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        EuiMaterialModule,
        ExtModule,
        FormsModule,
        JustificationModule,
        MatCardModule,
        MatStepperModule,
        MatExpansionModule,
        ReactiveFormsModule,
        TranslateModule,
        SelectedElementsModule,
        MitigatingControlContainerModule,
        HelpContextualModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesViolationsModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        ResolveComponent,
                        RulesViolationsComponent,
                        RulesViolationsDetailsComponent,
                        RulesViolationsActionComponent,
                        RulesViolationsMultiActionComponent,
                        RulesViolationsSingleActionComponent,
                        MitigatingControlsPersonComponent
                    ],
                    imports: [
                        CdrModule,
                        CommonModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        ExtModule,
                        FormsModule,
                        JustificationModule,
                        MatCardModule,
                        MatStepperModule,
                        MatExpansionModule,
                        ReactiveFormsModule,
                        TranslateModule,
                        SelectedElementsModule,
                        MitigatingControlContainerModule,
                        HelpContextualModule,
                    ],
                    exports: [MitigatingControlsPersonComponent],
                    schemas: [CUSTOM_ELEMENTS_SCHEMA]
                }]
        }], function () { return [{ type: i2.MenuService }, { type: i2.ClassloggerService }]; }, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RulesViolationsModule, { declarations: [ResolveComponent,
            RulesViolationsComponent,
            RulesViolationsDetailsComponent,
            RulesViolationsActionComponent,
            RulesViolationsMultiActionComponent,
            RulesViolationsSingleActionComponent,
            MitigatingControlsPersonComponent], imports: [CdrModule,
            CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            EuiMaterialModule,
            ExtModule,
            FormsModule,
            JustificationModule,
            MatCardModule,
            MatStepperModule,
            MatExpansionModule,
            ReactiveFormsModule,
            TranslateModule,
            SelectedElementsModule,
            MitigatingControlContainerModule,
            HelpContextualModule], exports: [MitigatingControlsPersonComponent] });
})();

class ComplianceRulesGuardService {
    constructor(permissionService, appConfig, routeGuardService, router) {
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.routeGuardService = routeGuardService;
        this.router = router;
    }
    canActivate(route, state) {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.routeGuardService.canActivate(route, state)) {
                const userRuleStatistics = yield this.permissionService.isRuleStatistics();
                if (!userRuleStatistics) {
                    this.router.navigate([this.appConfig.Config.routeConfig.start]);
                }
                return userRuleStatistics;
            }
            this.router.navigate([this.appConfig.Config.routeConfig.login]);
            return false;
        });
    }
}
ComplianceRulesGuardService.ɵfac = function ComplianceRulesGuardService_Factory(t) { return new (t || ComplianceRulesGuardService)(i0.ɵɵinject(CplPermissionsService), i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i2.RouteGuardService), i0.ɵɵinject(i3.Router)); };
ComplianceRulesGuardService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ComplianceRulesGuardService, factory: ComplianceRulesGuardService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ComplianceRulesGuardService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: CplPermissionsService }, { type: i2.AppConfigService }, { type: i2.RouteGuardService }, { type: i3.Router }]; }, null);
})();

class RuleViolationsGuardService {
    constructor(permissionService, appConfig, routeGuardService, router) {
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.routeGuardService = routeGuardService;
        this.router = router;
    }
    canActivate(route, state) {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.routeGuardService.canActivate(route, state)) {
                const isExceptionAdmin = yield this.permissionService.isExceptionAdmin();
                if (!isExceptionAdmin) {
                    this.router.navigate([this.appConfig.Config.routeConfig.start]);
                }
                return isExceptionAdmin;
            }
            this.router.navigate([this.appConfig.Config.routeConfig.login]);
            return false;
        });
    }
}
RuleViolationsGuardService.ɵfac = function RuleViolationsGuardService_Factory(t) { return new (t || RuleViolationsGuardService)(i0.ɵɵinject(CplPermissionsService), i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i2.RouteGuardService), i0.ɵɵinject(i3.Router)); };
RuleViolationsGuardService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RuleViolationsGuardService, factory: RuleViolationsGuardService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RuleViolationsGuardService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: CplPermissionsService }, { type: i2.AppConfigService }, { type: i2.RouteGuardService }, { type: i3.Router }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestModule {
    constructor(logger) {
        logger.info(this, '▶️ RequestModule loaded');
    }
}
RequestModule.ɵfac = function RequestModule_Factory(t) { return new (t || RequestModule)(i0.ɵɵinject(i2.ClassloggerService)); };
RequestModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RequestModule });
RequestModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CdrModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        JustificationModule,
        MatCardModule,
        MatExpansionModule,
        ReactiveFormsModule,
        TranslateModule,
        MitigatingControlContainerModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RequestModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        MitigatingControlsRequestComponent,
                        EditMitigatingControlsComponent,
                        WorkflowViolationDetailsComponent,
                        ComplianceViolationDetailsComponent,
                        RequestMitigatingControlFilterPipe
                    ],
                    imports: [
                        CdrModule,
                        CommonModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        FormsModule,
                        JustificationModule,
                        MatCardModule,
                        MatExpansionModule,
                        ReactiveFormsModule,
                        TranslateModule,
                        MitigatingControlContainerModule
                    ],
                    exports: [MitigatingControlsRequestComponent]
                }]
        }], function () { return [{ type: i2.ClassloggerService }]; }, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RequestModule, { declarations: [MitigatingControlsRequestComponent,
            EditMitigatingControlsComponent,
            WorkflowViolationDetailsComponent,
            ComplianceViolationDetailsComponent,
            RequestMitigatingControlFilterPipe], imports: [CdrModule,
            CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            EuiMaterialModule,
            FormsModule,
            JustificationModule,
            MatCardModule,
            MatExpansionModule,
            ReactiveFormsModule,
            TranslateModule,
            MitigatingControlContainerModule], exports: [MitigatingControlsRequestComponent] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestRuleViolation {
    constructor() {
        this.subject = new Subject();
    }
    get inputData() {
        return this.dstSettings;
    }
    set inputData(dstSettings) {
        var _a, _b, _c, _d;
        this.dstSettings = dstSettings;
        if ((_a = this.dstSettings) === null || _a === void 0 ? void 0 : _a.extendedData) {
            for (let i = 0; i < this.dstSettings.dataSource.Data.length; i++) {
                const item = this.dstSettings.dataSource.Data[i];
                const workflowHistory = (_d = (_c = (_b = item.pwoData) === null || _b === void 0 ? void 0 : _b.WorkflowHistory) === null || _c === void 0 ? void 0 : _c.Entities) !== null && _d !== void 0 ? _d : [];
                item.complianceRuleViolation = workflowHistory.some((wh) => { var _a, _b; return ((_b = (_a = wh.Columns['UID_ComplianceRule']) === null || _a === void 0 ? void 0 : _a.Value) === null || _b === void 0 ? void 0 : _b.length) > 0; });
            }
        }
        this.subject.next(this.dstSettings);
    }
}
RequestRuleViolation.id = 'cpl.UID_ComplianceRule';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestRuleViolationDetail {
    constructor() {
        this.instance = ComplianceViolationDetailsComponent;
    }
}
RequestRuleViolationDetail.id = 'cpl.ruleViolationDetail';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RoleComplianceViolationTypedEntity extends TypedEntity {
    static GetEntitySchema() {
        const columns = {
            UID_ComplianceRule: { Type: ValType.String, ColumnName: 'UID_ComplianceRule' },
            RuleName: { Type: ValType.String, ColumnName: 'RuleName' },
            DbObjectKey: { Type: ValType.String, ColumnName: 'DbObjectKey' },
            ObjectDisplay: { Type: ValType.String, ColumnName: 'ObjectDisplay' },
            ObjectKeyElement: { Type: ValType.String, ColumnName: 'ObjectKeyElement' }
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        return { Columns: columns };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RoleComplianceViolationsWrapperService {
    constructor() {
        this.roleComplianceEntitySchema = RoleComplianceViolationTypedEntity.GetEntitySchema();
        this.builder = new TypedEntityBuilder(RoleComplianceViolationTypedEntity);
    }
    build(data) {
        const violations = {
            TotalCount: data.length,
            Entities: data.map(elem => this.buildEntityData(elem))
        };
        return this.builder.buildReadWriteEntities(violations, this.roleComplianceEntitySchema);
    }
    buildEntityData(data) {
        const ret = {};
        ret.UID_ComplianceRule = { Value: data.UID_ComplianceRule, IsReadOnly: true };
        ret.RuleName = { Value: data.RuleName, IsReadOnly: true };
        ret.DbObjectKey = { Value: data.DbObjectKey, IsReadOnly: true };
        ret.ObjectDisplay = { Value: data.ObjectDisplay, IsReadOnly: true };
        ret.ObjectKeyElement = { Value: data.ObjectKeyElement, IsReadOnly: true };
        return { Columns: ret };
    }
}
RoleComplianceViolationsWrapperService.ɵfac = function RoleComplianceViolationsWrapperService_Factory(t) { return new (t || RoleComplianceViolationsWrapperService)(); };
RoleComplianceViolationsWrapperService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RoleComplianceViolationsWrapperService, factory: RoleComplianceViolationsWrapperService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RoleComplianceViolationsWrapperService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], null, null);
})();

class RoleComplianceViolationsService {
    constructor(apiservice, busyService) {
        this.apiservice = apiservice;
        this.busyService = busyService;
    }
    getRoleComplianceViolations(table, uidRole) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.client.portal_roles_config_compliance_get(table, uidRole);
        });
    }
    handleOpenLoader() {
        if (!this.busyIndicator) {
            this.busyIndicator = this.busyService.show();
        }
    }
    handleCloseLoader() {
        if (this.busyIndicator) {
            setTimeout(() => {
                this.busyService.hide(this.busyIndicator);
                this.busyIndicator = undefined;
            });
        }
    }
}
RoleComplianceViolationsService.ɵfac = function RoleComplianceViolationsService_Factory(t) { return new (t || RoleComplianceViolationsService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i3$1.EuiLoadingService)); };
RoleComplianceViolationsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RoleComplianceViolationsService, factory: RoleComplianceViolationsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RoleComplianceViolationsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: ApiService }, { type: i3$1.EuiLoadingService }]; }, null);
})();

function RoleComplianceViolationsComponent_eui_alert_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r3 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-alert", 8);
        i0.ɵɵlistener("dismissed", function RoleComplianceViolationsComponent_eui_alert_2_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onHelperDismissed()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 4, ctx_r0.keyDescription), " ");
    }
}
const _c0 = function () { return []; };
class RoleComplianceViolationsComponent {
    constructor(dataProvider, entityService, roleComplianceViolationService, metaDataService) {
        var _a;
        this.entityService = entityService;
        this.roleComplianceViolationService = roleComplianceViolationService;
        this.metaDataService = metaDataService;
        this.DisplayColumns = DisplayColumns;
        this.showHelperAlert = true;
        this.displayedColumns = [];
        this.tablename = dataProvider.data.tablename;
        this.uidRole = dataProvider.data.entity.GetKeys()[0];
        this.entitySchema = this.entityService.roleComplianceEntitySchema;
        this.displayedColumns = [this.entitySchema.Columns.RuleName, this.entitySchema.Columns.ObjectDisplay];
        // tslint:disable:max-line-length
        switch (((_a = this.tablename) !== null && _a !== void 0 ? _a : '').toLowerCase()) {
            case 'aerole':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this application role that may violate a compliance rule.';
                break;
            case 'department':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this department that may violate a compliance rule.';
                break;
            case 'locality':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this location that may violate a compliance rule.';
                break;
            case 'profitcenter':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this cost center that may violate a compliance rule.';
                break;
            case 'eset':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this system role that may violate a compliance rule.';
                break;
            case 'org':
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this business role that may violate a compliance rule.';
                break;
            default:
                this.keyDescription =
                    '#LDS#Here you can get an overview of all entitlements assigned to this object that may violate a compliance rule.';
                break;
        }
        // tslint:enable:max-line-length
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.metaDataService.updateNonExisting([this.tablename]);
            yield this.getData();
        });
    }
    getData() {
        return __awaiter(this, void 0, void 0, function* () {
            this.roleComplianceViolationService.handleOpenLoader();
            try {
                const data = yield this.roleComplianceViolationService.getRoleComplianceViolations(this.tablename, this.uidRole);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: this.entityService.build(data.Violations),
                    entitySchema: this.entityService.roleComplianceEntitySchema,
                    navigationState: {},
                };
            }
            finally {
                this.roleComplianceViolationService.handleCloseLoader();
            }
        });
    }
    onHelperDismissed() {
        this.showHelperAlert = false;
    }
}
RoleComplianceViolationsComponent.ɵfac = function RoleComplianceViolationsComponent_Factory(t) { return new (t || RoleComplianceViolationsComponent)(i0.ɵɵdirectiveInject(i2.DynamicTabDataProviderDirective), i0.ɵɵdirectiveInject(RoleComplianceViolationsWrapperService), i0.ɵɵdirectiveInject(RoleComplianceViolationsService), i0.ɵɵdirectiveInject(i2.MetadataService)); };
RoleComplianceViolationsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: RoleComplianceViolationsComponent, selectors: [["ng-component"]], decls: 11, vars: 13, consts: [[1, "imx-tab-content"], [1, "imx-tab-body"], ["class", "imx-helper-alert", "type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [3, "settings", "options"], ["dst", ""], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "rules-table", 3, "dst"], ["data-imx-identifier", "violations-table-column-RuleName", 3, "columnLabel", "entityColumn"], ["data-imx-identifier", "violations-table-column-ObjectDisplay", 3, "columnLabel", "entityColumn"], ["type", "info", 1, "imx-helper-alert", 3, "condensed", "colored", "dismissable", "dismissed"]], template: function RoleComplianceViolationsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1);
            i0.ɵɵtemplate(2, RoleComplianceViolationsComponent_eui_alert_2_Template, 3, 6, "eui-alert", 2);
            i0.ɵɵelementStart(3, "mat-card");
            i0.ɵɵelement(4, "imx-data-source-toolbar", 3, 4);
            i0.ɵɵelementStart(6, "imx-data-table", 5);
            i0.ɵɵelement(7, "imx-data-table-column", 6);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelement(9, "imx-data-table-column", 7);
            i0.ɵɵpipe(10, "translate");
            i0.ɵɵelementEnd()()()();
        }
        if (rf & 2) {
            const _r1 = i0.ɵɵreference(5);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.showHelperAlert);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(12, _c0));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r1);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("columnLabel", i0.ɵɵpipeBind1(8, 8, "#LDS#Compliance rule"))("entityColumn", ctx.entitySchema.Columns.RuleName);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("columnLabel", i0.ɵɵpipeBind1(10, 10, "#LDS#Entitlement"))("entityColumn", ctx.entitySchema.Columns.ObjectDisplay);
        }
    }, dependencies: [i5.NgIf, i3$1.EuiAlertComponent, i2.DataSourceToolbarComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i3$2.MatCard, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;overflow:hidden}.imx-tab-body[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}.imx-helper-alert[_ngcontent-%COMP%]{margin-bottom:20px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RoleComplianceViolationsComponent, [{
            type: Component,
            args: [{ template: "<div class=\"imx-tab-content\">\r\n  <div class=\"imx-tab-body\">\r\n    <eui-alert *ngIf=\"showHelperAlert\" class=\"imx-helper-alert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\"\r\n    [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\r\n    {{ keyDescription | translate }}\r\n  </eui-alert>\r\n    <mat-card>\r\n      <imx-data-source-toolbar #dst [settings]=\"dstSettings\" [options]=\"[]\">\r\n      </imx-data-source-toolbar>\r\n      <imx-data-table [dst]=\"dst\" detailViewVisible=\"false\" mode=\"manual\" data-imx-identifier=\"rules-table\">\r\n        <imx-data-table-column [columnLabel]=\"'#LDS#Compliance rule' | translate\"\r\n          [entityColumn]=\"entitySchema.Columns.RuleName\" data-imx-identifier=\"violations-table-column-RuleName\">\r\n        </imx-data-table-column>\r\n        <imx-data-table-column [columnLabel]=\"'#LDS#Entitlement' | translate\"\r\n          [entityColumn]=\"entitySchema.Columns.ObjectDisplay\"\r\n          data-imx-identifier=\"violations-table-column-ObjectDisplay\">\r\n        </imx-data-table-column>\r\n      </imx-data-table>\r\n    </mat-card>\r\n  </div>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;height:100%}.imx-tab-content{display:flex;flex-direction:column;height:100%;overflow:hidden}.imx-tab-body{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}.imx-helper-alert{margin-bottom:20px}\n"] }]
        }], function () { return [{ type: i2.DynamicTabDataProviderDirective }, { type: RoleComplianceViolationsWrapperService }, { type: RoleComplianceViolationsService }, { type: i2.MetadataService }]; }, null);
})();

class InitService {
    constructor(extService, router, menuService, api, cplService, notificationService, validationDetailService, identityRoleMembershipService) {
        this.extService = extService;
        this.router = router;
        this.menuService = menuService;
        this.api = api;
        this.cplService = cplService;
        this.notificationService = notificationService;
        this.validationDetailService = validationDetailService;
        this.identityRoleMembershipService = identityRoleMembershipService;
        this.setupMenu();
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('Dashboard-SmallTiles', { instance: DashboardPluginComponent });
        this.extService.register(RequestRuleViolation.id, new RequestRuleViolation());
        this.extService.register(RequestRuleViolationDetail.id, new RequestRuleViolationDetail());
        this.extService.register('roleOverview', {
            instance: RoleComplianceViolationsComponent,
            inputData: {
                id: 'roleCompliance',
                label: '#LDS#Heading Rule Violations',
                checkVisibility: (ref) => __awaiter(this, void 0, void 0, function* () { return this.checkCompliances(ref); }),
            },
            sortOrder: 0,
        });
        this.extService.register('identitySidesheet', {
            instance: IdentityRuleViolationsComponent,
            inputData: {
                id: 'NonCompliance',
                label: '#LDS#Heading Rule Violations',
                checkVisibility: (_) => __awaiter(this, void 0, void 0, function* () { return true; })
            }, sortOrder: 20
        });
        this.validationDetailService.register(CartItemComplianceCheckComponent, 'CartItemComplianceCheck');
        // Register handler for compliance notifications
        this.notificationService.registerRedirectNotificationHandler({
            id: 'OpenNonCompliance',
            message: '#LDS#There are new rule violations for which you can grant or deny exceptions.',
            route: 'compliance/rulesviolations/approve'
        });
    }
    checkCompliances(referrer) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            this.cplService.handleOpenLoader();
            let violationCount = 0;
            try {
                violationCount =
                    ((_a = (yield this.cplService.getRoleComplianceViolations(referrer.tablename, referrer.entity.GetKeys()[0])).Violations) === null || _a === void 0 ? void 0 : _a.length) || 0;
            }
            finally {
                this.cplService.handleCloseLoader();
            }
            return violationCount > 0;
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features) => {
            if (!preProps.includes('COMPLIANCE') || !isRuleStatistics(features)) {
                return null;
            }
            const items = [];
            if (isRuleStatistics(features)) {
                items.push({
                    id: 'CPL_Compliance_Rules',
                    route: 'compliance/rules',
                    title: '#LDS#Menu Entry Compliance rules',
                    description: '#LDS#Shows an overview of compliance rules.',
                    sorting: '25-10',
                });
            }
            const menu = {
                id: 'ROOT_Compliance',
                title: '#LDS#Compliance',
                sorting: '25',
                items,
            };
            return menu;
        });
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i2.ExtService), i0.ɵɵinject(i3.Router), i0.ɵɵinject(i2.MenuService), i0.ɵɵinject(ApiService), i0.ɵɵinject(RoleComplianceViolationsService), i0.ɵɵinject(i1.NotificationRegistryService), i0.ɵɵinject(i1.ShoppingCartValidationDetailService), i0.ɵɵinject(i1.IdentityRoleMembershipsService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i2.ExtService }, { type: i3.Router }, { type: i2.MenuService }, { type: ApiService }, { type: RoleComplianceViolationsService }, { type: i1.NotificationRegistryService }, { type: i1.ShoppingCartValidationDetailService }, { type: i1.IdentityRoleMembershipsService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'compliance/rules',
        component: RulesComponent,
        canActivate: [ComplianceRulesGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.ComplianceRules
        }
    },
    {
        path: 'compliance/rulesviolations/approve',
        component: RulesViolationsComponent,
        canActivate: [RuleViolationsGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.ComplianceRulesViolationsApprove
        }
    },
];
class CplConfigModule {
    constructor(initializer, logger) {
        this.initializer = initializer;
        this.logger = logger;
        this.logger.info(this, '🔥 CPL loaded');
        this.initializer.onInit(routes);
        this.logger.info(this, '▶︝ CPL initialized');
    }
}
CplConfigModule.ɵfac = function CplConfigModule_Factory(t) { return new (t || CplConfigModule)(i0.ɵɵinject(InitService), i0.ɵɵinject(i2.ClassloggerService)); };
CplConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: CplConfigModule });
CplConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        CdrModule,
        EuiCoreModule,
        FormsModule,
        MatButtonModule,
        MatCardModule,
        MatExpansionModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),
        RulesViolationsModule,
        RequestModule,
        TilesModule,
        TranslateModule,
        EuiCoreModule,
        IdentityRuleViolationsModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CplConfigModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        DashboardPluginComponent,
                        CartItemComplianceCheckComponent,
                    ],
                    imports: [
                        CommonModule,
                        CdrModule,
                        EuiCoreModule,
                        FormsModule,
                        MatButtonModule,
                        MatCardModule,
                        MatExpansionModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatListModule,
                        ReactiveFormsModule,
                        RouterModule.forChild(routes),
                        RulesViolationsModule,
                        RequestModule,
                        TilesModule,
                        TranslateModule,
                        EuiCoreModule,
                        IdentityRuleViolationsModule
                    ],
                }]
        }], function () { return [{ type: InitService }, { type: i2.ClassloggerService }]; }, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(CplConfigModule, { declarations: [DashboardPluginComponent,
            CartItemComplianceCheckComponent], imports: [CommonModule,
            CdrModule,
            EuiCoreModule,
            FormsModule,
            MatButtonModule,
            MatCardModule,
            MatExpansionModule,
            MatFormFieldModule,
            MatIconModule,
            MatInputModule,
            MatListModule,
            ReactiveFormsModule, i3.RouterModule, RulesViolationsModule,
            RequestModule,
            TilesModule,
            TranslateModule,
            EuiCoreModule,
            IdentityRuleViolationsModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RulesModule {
}
RulesModule.ɵfac = function RulesModule_Factory(t) { return new (t || RulesModule)(); };
RulesModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RulesModule });
RulesModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        EuiCoreModule,
        TranslateModule,
        CdrModule,
        DataTableModule,
        DataSourceToolbarModule,
        MatButtonModule,
        MatCardModule,
        MatTabsModule,
        StatisticsModule,
        ObjectHyperviewModule,
        HelpContextualModule,
        ExtModule,
        RulesViolationsModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RulesModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        RulesComponent,
                        RulesSidesheetComponent,
                        MitigatingControlsRulesComponent,
                        ViolationsPerRuleComponent,
                    ],
                    imports: [
                        CommonModule,
                        EuiCoreModule,
                        TranslateModule,
                        CdrModule,
                        DataTableModule,
                        DataSourceToolbarModule,
                        MatButtonModule,
                        MatCardModule,
                        MatTabsModule,
                        StatisticsModule,
                        ObjectHyperviewModule,
                        HelpContextualModule,
                        ExtModule,
                        RulesViolationsModule
                    ],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RulesModule, { declarations: [RulesComponent,
            RulesSidesheetComponent,
            MitigatingControlsRulesComponent,
            ViolationsPerRuleComponent], imports: [CommonModule,
            EuiCoreModule,
            TranslateModule,
            CdrModule,
            DataTableModule,
            DataSourceToolbarModule,
            MatButtonModule,
            MatCardModule,
            MatTabsModule,
            StatisticsModule,
            ObjectHyperviewModule,
            HelpContextualModule,
            ExtModule,
            RulesViolationsModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RoleComplianceViolationsModule {
}
RoleComplianceViolationsModule.ɵfac = function RoleComplianceViolationsModule_Factory(t) { return new (t || RoleComplianceViolationsModule)(); };
RoleComplianceViolationsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RoleComplianceViolationsModule });
RoleComplianceViolationsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        EuiCoreModule,
        DataSourceToolbarModule,
        DataTableModule,
        MatCardModule,
        TranslateModule,
        LdsReplaceModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RoleComplianceViolationsModule, [{
            type: NgModule,
            args: [{
                    declarations: [RoleComplianceViolationsComponent],
                    imports: [
                        CommonModule,
                        EuiCoreModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        MatCardModule,
                        TranslateModule,
                        LdsReplaceModule
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RoleComplianceViolationsModule, { declarations: [RoleComplianceViolationsComponent], imports: [CommonModule,
            EuiCoreModule,
            DataSourceToolbarModule,
            DataTableModule,
            MatCardModule,
            TranslateModule,
            LdsReplaceModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of cpl
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiService, CplConfigModule, MitigatingControlsRulesService, RequestRuleViolation, RequestRuleViolationDetail, RoleComplianceViolationsModule, RulesModule };
//# sourceMappingURL=cpl.mjs.map
