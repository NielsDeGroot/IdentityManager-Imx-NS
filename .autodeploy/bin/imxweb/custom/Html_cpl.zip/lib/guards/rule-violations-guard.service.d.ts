import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { AppConfigService, RouteGuardService } from 'qbm';
import { CplPermissionsService } from '../rules/admin/cpl-permissions.service';
import * as i0 from "@angular/core";
export declare class RuleViolationsGuardService implements CanActivate {
    private readonly permissionService;
    private readonly appConfig;
    private readonly routeGuardService;
    private readonly router;
    constructor(permissionService: CplPermissionsService, appConfig: AppConfigService, routeGuardService: RouteGuardService, router: Router);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RuleViolationsGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RuleViolationsGuardService>;
}
