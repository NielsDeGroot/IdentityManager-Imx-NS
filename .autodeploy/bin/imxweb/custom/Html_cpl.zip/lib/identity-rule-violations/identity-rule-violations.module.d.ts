import * as i0 from "@angular/core";
import * as i1 from "./identity-rule-violations.component";
import * as i2 from "./identity-rule-violations-mitigation-control/identity-rule-violations-mitigation-control.component";
import * as i3 from "@angular/common";
import * as i4 from "@elemental-ui/core";
import * as i5 from "qbm";
import * as i6 from "@ngx-translate/core";
import * as i7 from "@angular/material/button";
import * as i8 from "@angular/material/card";
export declare class IdentityRuleViolationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentityRuleViolationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IdentityRuleViolationsModule, [typeof i1.IdentityRuleViolationsComponent, typeof i2.IdentityRuleViolationsMitigationControlComponent], [typeof i3.CommonModule, typeof i4.EuiCoreModule, typeof i5.DataSourceToolbarModule, typeof i5.DataTableModule, typeof i6.TranslateModule, typeof i7.MatButtonModule, typeof i8.MatCardModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IdentityRuleViolationsModule>;
}
