import { ComplianceFeatureConfig, PortalPersonMitigatingcontrols, PortalPersonRolemembershipsNoncompliance, PortalRulesMitigatingcontrols } from 'imx-api-cpl';
import { CollectionLoadParameters, EntitySchema, ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class IdentityRuleViolationService {
    private readonly api;
    constructor(api: ApiService);
    get nonComplianceSchema(): EntitySchema;
    get portalPersonMitigatingcontrols(): EntitySchema;
    get portalRulesMitigatingcontrols(): EntitySchema;
    getNonCompliance(uidPerson: string, parameter: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalPersonRolemembershipsNoncompliance, unknown>>;
    featureConfig(): Promise<ComplianceFeatureConfig>;
    getPersonMitigatingcontrols(uidComplianceRule: string, uidPerson: string, param: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalPersonMitigatingcontrols, unknown>>;
    getRulesMitigatingcontrols(uidComplianceRule: string, param: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalRulesMitigatingcontrols, unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IdentityRuleViolationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IdentityRuleViolationService>;
}
