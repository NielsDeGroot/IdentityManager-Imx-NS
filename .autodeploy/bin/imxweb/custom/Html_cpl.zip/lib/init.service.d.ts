import { Router, Route } from '@angular/router';
import { IdentityRoleMembershipsService, NotificationRegistryService, ShoppingCartValidationDetailService } from 'qer';
import { ExtService, MenuService } from 'qbm';
import { RoleComplianceViolationsService } from './role-compliance-violations/role-compliance-violations.service';
import { ApiService } from './api.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly extService;
    private readonly router;
    private readonly menuService;
    private readonly api;
    private readonly cplService;
    private readonly notificationService;
    private readonly validationDetailService;
    private readonly identityRoleMembershipService;
    constructor(extService: ExtService, router: Router, menuService: MenuService, api: ApiService, cplService: RoleComplianceViolationsService, notificationService: NotificationRegistryService, validationDetailService: ShoppingCartValidationDetailService, identityRoleMembershipService: IdentityRoleMembershipsService);
    onInit(routes: Route[]): void;
    private checkCompliances;
    private addRoutes;
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
