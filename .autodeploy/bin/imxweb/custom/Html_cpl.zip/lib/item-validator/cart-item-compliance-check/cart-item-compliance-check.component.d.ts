import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { ICartItemCheck } from 'imx-api-qer';
import * as i0 from "@angular/core";
export declare class CartItemComplianceCheckComponent {
    private readonly sidesheetService;
    private readonly translateService;
    check: ICartItemCheck;
    constructor(sidesheetService: EuiSidesheetService, translateService: TranslateService);
    onOpenDetails(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemComplianceCheckComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartItemComplianceCheckComponent, "imx-cart-item-compliance-check", never, {}, {}, never, never, false>;
}
