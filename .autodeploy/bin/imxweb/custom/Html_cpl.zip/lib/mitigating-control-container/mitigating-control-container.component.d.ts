import { ChangeDetectorRef, EventEmitter } from '@angular/core';
import { FormArray } from '@angular/forms';
import { EuiSelectOption } from '@elemental-ui/core';
import { ConfirmationService } from 'qbm';
import { MitigatingControlData } from '../request/compliance-violation-details/edit-mitigating-controls/mitigating-controls-request/mitigating-control-data.interface';
import { RequestMitigatingControls } from '../request/compliance-violation-details/edit-mitigating-controls/mitigating-controls-request/request-mitigating-controls';
import { PersonMitigatingControls } from '../rules-violations/mitigating-controls-person/person-mitigating-controls';
import * as i0 from "@angular/core";
export declare class MitigatingControlContainerComponent {
    private readonly cd;
    private readonly confirmationService;
    mControls: MitigatingControlData[] | PersonMitigatingControls[];
    mitigatingCaption: string;
    formArray: FormArray;
    options: EuiSelectOption[];
    controlDeleted: EventEmitter<PersonMitigatingControls | MitigatingControlData>;
    controlsRequested: EventEmitter<void>;
    constructor(cd: ChangeDetectorRef, confirmationService: ConfirmationService);
    onSelectionChange(mcontrol: RequestMitigatingControls | PersonMitigatingControls, value: string): Promise<void>;
    onOpenChange(isopen: boolean, mControl: RequestMitigatingControls | PersonMitigatingControls): void;
    onDelete(mControl: RequestMitigatingControls | PersonMitigatingControls | undefined, index: number): Promise<void>;
    onCreateControl(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MitigatingControlContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MitigatingControlContainerComponent, "imx-mitigating-control-container", never, { "mControls": "mControls"; "mitigatingCaption": "mitigatingCaption"; "formArray": "formArray"; "options": "options"; }, { "controlDeleted": "controlDeleted"; "controlsRequested": "controlsRequested"; }, never, never, false>;
}
