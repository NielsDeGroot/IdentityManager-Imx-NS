import { EuiSidesheetRef } from '@elemental-ui/core';
import * as i0 from "@angular/core";
export declare class EditMitigatingControlsComponent {
    sidesheetRef: EuiSidesheetRef;
    data: {
        uidPerson: string;
        uidNonCompliance: string;
        uidPersonWantsOrg: string;
        readOnly: boolean;
        isMControlPerViolation: boolean;
    };
    constructor(sidesheetRef: EuiSidesheetRef, data: {
        uidPerson: string;
        uidNonCompliance: string;
        uidPersonWantsOrg: string;
        readOnly: boolean;
        isMControlPerViolation: boolean;
    });
    static ɵfac: i0.ɵɵFactoryDeclaration<EditMitigatingControlsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditMitigatingControlsComponent, "ng-component", never, {}, {}, never, never, false>;
}
