import { FormControl } from '@angular/forms';
import { DeferredOperationMControlData } from 'imx-api-cpl';
import { ColumnDependentReference, EntityService } from 'qbm';
import { MitigatingControlData } from './mitigating-control-data.interface';
export declare class ExtendedDeferredOperationsData implements MitigatingControlData {
    private readonly deferred;
    formControl: FormControl<string>;
    cdrs: ColumnDependentReference[];
    isDeferredData: boolean;
    editable: boolean;
    get uidMitigatingControl(): string;
    get displayMitigatingControls(): string;
    isInActive: boolean;
    data: any;
    constructor(deferred: DeferredOperationMControlData, entiyService: EntityService);
}
