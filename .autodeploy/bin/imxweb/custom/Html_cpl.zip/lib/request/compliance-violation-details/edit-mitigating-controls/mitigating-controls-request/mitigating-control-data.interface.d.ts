import { FormControl } from "@angular/forms";
import { PortalPersonMitigatingcontrols } from "imx-api-cpl";
import { ColumnDependentReference } from "qbm";
export interface MitigatingControlData {
    cdrs: ColumnDependentReference[];
    editable: boolean;
    isDeferredData: boolean;
    isInActive: boolean;
    formControl: FormControl;
    uidMitigatingControl: string;
    displayMitigatingControls: string;
    data: PortalPersonMitigatingcontrols | undefined;
}
