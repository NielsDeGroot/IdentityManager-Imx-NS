import { PipeTransform } from '@angular/core';
import { MitigatingControlData } from './mitigating-control-data.interface';
import * as i0 from "@angular/core";
export declare class RequestMitigatingControlFilterPipe implements PipeTransform {
    transform(items: MitigatingControlData[], filter: 'active' | 'inactive' | 'deferred'): any;
    static getItems(items: MitigatingControlData[], filter: 'active' | 'inactive' | 'deferred'): MitigatingControlData[];
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestMitigatingControlFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<RequestMitigatingControlFilterPipe, "filtered", false>;
}
