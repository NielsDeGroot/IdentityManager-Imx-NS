import { FormControl } from '@angular/forms';
import { ColumnDependentReference } from 'qbm';
import { PortalPersonMitigatingcontrols } from 'imx-api-cpl';
import { MitigatingControlData } from './mitigating-control-data.interface';
/**
 * Class thats extends the {@link PortalPersonMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
export declare class RequestMitigatingControls extends PortalPersonMitigatingcontrols implements MitigatingControlData {
    editable: boolean;
    readonly baseObject: PortalPersonMitigatingcontrols;
    /**
     * The property list depending on the value of the state of a {@link PortalPersonMitigatingcontrols}.
     */
    cdrs: ColumnDependentReference[];
    formControl: FormControl<string>;
    constructor(editable: boolean, baseObject: PortalPersonMitigatingcontrols);
    readonly isDeferredData = false;
    get uidMitigatingControl(): string;
    set uidMitigatingControl(value: string);
    get displayMitigatingControls(): string;
    get isInActive(): boolean;
    get data(): PortalPersonMitigatingcontrols;
    private initPropertyInfo;
}
