import { IExtension } from "qbm";
import { ComplianceViolationDetailsComponent } from "./compliance-violation-details/compliance-violation-details.component";
export declare class RequestRuleViolationDetail implements IExtension {
    static readonly id = "cpl.ruleViolationDetail";
    instance: typeof ComplianceViolationDetailsComponent;
}
