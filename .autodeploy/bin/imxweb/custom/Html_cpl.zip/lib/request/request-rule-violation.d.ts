import { DataSourceToolbarSettings, IExtension } from 'qbm';
import { Subject } from 'rxjs';
export declare class RequestRuleViolation implements IExtension {
    static readonly id = "cpl.UID_ComplianceRule";
    subject: Subject<DataSourceToolbarSettings>;
    get inputData(): DataSourceToolbarSettings;
    set inputData(dstSettings: DataSourceToolbarSettings);
    private dstSettings;
}
