import { OnInit } from '@angular/core';
import { PwoData } from 'imx-api-qer';
import { EntityData } from 'imx-qbm-dbts';
import * as i0 from "@angular/core";
export declare class WorkflowViolationDetailsComponent implements OnInit {
    violations: EntityData[];
    pwoData: PwoData;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkflowViolationDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WorkflowViolationDetailsComponent, "imx-workflow-violation-details", never, { "pwoData": "pwoData"; }, {}, never, never, false>;
}
