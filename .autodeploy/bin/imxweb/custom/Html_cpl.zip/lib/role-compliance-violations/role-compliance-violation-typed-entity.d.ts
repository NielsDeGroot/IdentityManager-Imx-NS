import { TypedEntity, EntitySchema } from 'imx-qbm-dbts';
export declare class RoleComplianceViolationTypedEntity extends TypedEntity {
    static GetEntitySchema(): EntitySchema;
}
