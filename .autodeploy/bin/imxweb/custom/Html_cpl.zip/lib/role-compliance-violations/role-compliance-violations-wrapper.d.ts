import { RoleComplianceViolation } from 'imx-api-cpl';
import { TypedEntityCollectionData } from 'imx-qbm-dbts';
import { RoleComplianceViolationTypedEntity } from './role-compliance-violation-typed-entity';
import * as i0 from "@angular/core";
export declare class RoleComplianceViolationsWrapperService {
    readonly roleComplianceEntitySchema: import("imx-qbm-dbts").EntitySchema;
    private readonly builder;
    build(data: RoleComplianceViolation[]): TypedEntityCollectionData<RoleComplianceViolationTypedEntity>;
    private buildEntityData;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoleComplianceViolationsWrapperService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoleComplianceViolationsWrapperService>;
}
