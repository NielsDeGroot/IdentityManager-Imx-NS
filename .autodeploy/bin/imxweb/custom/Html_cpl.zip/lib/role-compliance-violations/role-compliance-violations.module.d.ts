import * as i0 from "@angular/core";
import * as i1 from "./role-compliance-violations.component";
import * as i2 from "@angular/common";
import * as i3 from "@elemental-ui/core";
import * as i4 from "qbm";
import * as i5 from "@angular/material/card";
import * as i6 from "@ngx-translate/core";
export declare class RoleComplianceViolationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RoleComplianceViolationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RoleComplianceViolationsModule, [typeof i1.RoleComplianceViolationsComponent], [typeof i2.CommonModule, typeof i3.EuiCoreModule, typeof i4.DataSourceToolbarModule, typeof i4.DataTableModule, typeof i5.MatCardModule, typeof i6.TranslateModule, typeof i4.LdsReplaceModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RoleComplianceViolationsModule>;
}
