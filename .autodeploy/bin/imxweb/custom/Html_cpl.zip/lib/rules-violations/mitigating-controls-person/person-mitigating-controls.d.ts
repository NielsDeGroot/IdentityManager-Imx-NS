import { ColumnDependentReference } from 'qbm';
import { PortalPersonMitigatingcontrols } from 'imx-api-cpl';
import { FormControl } from '@angular/forms';
/**
 * Class thats extends the {@link PortalPersonMitigatingcontrols} with some additional properties that are needed for
 * the components in the approval context.
 */
export declare class PersonMitigatingControls extends PortalPersonMitigatingcontrols {
    editable: boolean;
    readonly baseObject: PortalPersonMitigatingcontrols;
    /**
     * The property list depending on the value of the state of a {@link PortalPersonMitigatingcontrols}.
     */
    cdrs: ColumnDependentReference[];
    formControl: FormControl<string>;
    constructor(editable: boolean, baseObject: PortalPersonMitigatingcontrols);
    private initPropertyInfo;
}
