import { OnInit } from "@angular/core";
import { EuiLoadingService, EuiSidesheetRef } from "@elemental-ui/core";
import { ContributingEntitlement, UiActionData } from "imx-api-cpl";
import { BaseCdr, EntityService, MetadataService, SnackBarService } from "qbm";
import { DbObjectKey } from "imx-qbm-dbts";
import { ApiService } from "../../api.service";
import { StepperSelectionEvent } from "@angular/cdk/stepper";
import * as i0 from "@angular/core";
declare type ExtendedEntitlement = (ContributingEntitlement & {
    Key?: DbObjectKey;
    TypeDisplay?: string;
});
export declare class ResolveComponent implements OnInit {
    private readonly sidesheetRef;
    private readonly snackbar;
    private readonly cplApi;
    private readonly busySvc;
    private readonly metadata;
    private readonly entityService;
    private readonly data;
    constructor(sidesheetRef: EuiSidesheetRef, snackbar: SnackBarService, cplApi: ApiService, busySvc: EuiLoadingService, metadata: MetadataService, entityService: EntityService, data: {
        uidPerson: string;
        uidNonCompliance: string;
    });
    busy: boolean;
    completed: boolean;
    actions: UiActionData[];
    entitlements: ExtendedEntitlement[];
    entitlementsLoseAlso: ExtendedEntitlement[];
    selectedEntitlements: string[];
    uidActions: string[];
    private reasonCdr;
    cdrs: BaseCdr[];
    ngOnInit(): Promise<void>;
    private enhanceWithTypeDisplay;
    selectedStepChanged(event: StepperSelectionEvent): Promise<void>;
    private LoadActions;
    private LoadEntitlementsLoseAlso;
    Execute(): Promise<void>;
    LdsChangesQueued: string;
    LdsLoseEntitlements: string;
    LdsNoPermissions: string;
    LdsContributingPermissions: string;
    LdsNoLoseAdditional: string;
    LdsActionList: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResolveComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ResolveComponent, "ng-component", never, {}, {}, never, never, false>;
}
export {};
