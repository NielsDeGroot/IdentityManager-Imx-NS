import { ColumnDependentReference } from 'qbm';
export interface RulesViolationsActionParameters {
    reason: ColumnDependentReference;
    justification?: ColumnDependentReference;
    uidPerson?: ColumnDependentReference;
    validUntil?: ColumnDependentReference;
}
