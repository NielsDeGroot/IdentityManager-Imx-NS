import { RulesViolationsActionParameters } from './rules-violations-action-parameters.interface';
import { RulesViolationsApproval } from '../rules-violations-approval';
/**
 * Common View Model for making a decision for one or more rules violations.
 */
export interface RulesViolationsAction {
    /**
     * Parameters according to the type of decision.
     */
    actionParameters: RulesViolationsActionParameters;
    /**
     * The rules violations to make a decision for.
     */
    rulesViolationsApprovals: RulesViolationsApproval[];
    /**
     * Whether or not the decision is an approval.
     */
    approve?: boolean;
    /**
     * A description for the type of decision to be made.
     */
    description?: string;
}
