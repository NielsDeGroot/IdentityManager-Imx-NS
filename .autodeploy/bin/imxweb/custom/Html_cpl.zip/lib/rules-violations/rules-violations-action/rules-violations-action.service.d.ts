import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { SnackBarService, EntityService } from 'qbm';
import { JustificationService, UserModelService } from 'qer';
import { ApiService } from '../../api.service';
import { RulesViolationsApproval } from '../rules-violations-approval';
import * as i0 from "@angular/core";
/**
 * Service that handles the approve and deny of one or more rules violations.
 */
export declare class RulesViolationsActionService {
    private readonly justification;
    private readonly cplClient;
    private readonly sidesheet;
    private readonly busyService;
    private readonly translate;
    private readonly snackBar;
    private readonly userService;
    private readonly entityService;
    readonly applied: Subject<unknown>;
    constructor(justification: JustificationService, cplClient: ApiService, sidesheet: EuiSidesheetService, busyService: EuiLoadingService, translate: TranslateService, snackBar: SnackBarService, userService: UserModelService, entityService: EntityService);
    /**
     * Approve the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    approve(rulesViolations: RulesViolationsApproval[]): Promise<void>;
    /**
     * Deny the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    deny(rulesViolations: RulesViolationsApproval[]): Promise<void>;
    resolve(ruleViolation: RulesViolationsApproval): Promise<void>;
    private makeDecisions;
    /**
     * Opens the RulesViolationsActionComponent there the user can set the reason and/or standard reason
     * and the ExceptionValidUntil in the approve contest.
     * @param config the configuration for the sidesheet (title) and the corresponding rules violations data
     */
    private editAction;
    /**
     * Approve or deny the rules violation
     * @param ruleViolationToApprove The rules violation
     * @param input reason and/or standard reason
     */
    private postDecision;
    /**
     * Creates a Cdr-Editor for the reason.
     */
    private createCdrReason;
    /**
     * Creates a Cdr-Editor for the ExceptionValidUntil value.
     */
    private createCdrValidUntil;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesViolationsActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RulesViolationsActionService>;
}
