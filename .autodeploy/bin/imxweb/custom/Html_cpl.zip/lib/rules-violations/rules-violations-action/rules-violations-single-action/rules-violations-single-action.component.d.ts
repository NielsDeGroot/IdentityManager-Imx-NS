import { OnInit } from '@angular/core';
import { AbstractControl, UntypedFormGroup } from '@angular/forms';
import { ColumnDependentReference } from 'qbm';
import { RulesViolationsAction } from '../rules-violations-action.interface';
import { RulesViolationsApproval } from '../../rules-violations-approval';
import * as i0 from "@angular/core";
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a single rules violation.
 * There is an alternative component for the case of a decision for multiple rules
 * violations as well: {@link RulesViolationsMultiActionComponent}.
 */
export declare class RulesViolationsSingleActionComponent implements OnInit {
    /**
     * @ignore since this is only an internal component.
     *
     * Data coming from the service about the rules violation.
     */
    data: RulesViolationsAction;
    /**
     * @ignore since this is only an internal component.
     *
     * The form group to which the necessary form fields will be added.
     */
    formGroup: UntypedFormGroup;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * The references depending on the columns of the rules violation that are displayed/edited during the decision.
     *
     */
    readonly columns: ColumnDependentReference[];
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * The single ruoes violation taken from {@link data}
     */
    rulesViolation: RulesViolationsApproval;
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit(): void;
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name: string, control: AbstractControl): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesViolationsSingleActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RulesViolationsSingleActionComponent, "imx-rules-violations-single-action", never, { "data": "data"; "formGroup": "formGroup"; }, {}, never, never, false>;
}
