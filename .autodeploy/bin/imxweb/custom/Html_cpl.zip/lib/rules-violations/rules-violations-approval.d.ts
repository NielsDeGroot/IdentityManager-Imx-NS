import { TranslateService } from '@ngx-translate/core';
import { PortalRulesViolations } from 'imx-api-cpl';
import { BaseCdr } from 'qbm';
/**
 * Class thats extends the {@link PortalRulesViolations} with some additional properties that are needed for
 * the components in the approval context.
 */
export declare class RulesViolationsApproval extends PortalRulesViolations {
    readonly baseObject: PortalRulesViolations;
    private readonly hasRiskIndex;
    private readonly translate;
    /**
     * The color and the caption depending on the value of the state of a {@link PortalRulesViolations}.
     */
    get stateBadge(): {
        color: 'blue' | 'orange' | 'green';
        caption: string;
    };
    /**
     * The property list depending on the value of the state of a {@link PortalRulesViolations}.
     */
    readonly propertyInfo: BaseCdr[];
    private stateBadgeColor;
    private stateCaption;
    constructor(baseObject: PortalRulesViolations, hasRiskIndex: boolean, translate: TranslateService);
    private initPropertyInfo;
    private initStateBadge;
}
