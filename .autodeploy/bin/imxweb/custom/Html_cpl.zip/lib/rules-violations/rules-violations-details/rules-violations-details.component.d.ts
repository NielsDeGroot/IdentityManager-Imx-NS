import { OnDestroy, OnInit, Type } from '@angular/core';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { MatTabGroup } from '@angular/material/tabs';
import { TranslateService } from '@ngx-translate/core';
import { PortalRules } from 'imx-api-cpl';
import { BaseCdr, ExtService, IExtension } from 'qbm';
import { RulesViolationsActionService } from '../rules-violations-action/rules-violations-action.service';
import { RulesViolationsApproval } from '../rules-violations-approval';
import * as i0 from "@angular/core";
export declare class baseComplienceClass {
    data: {
        selectedRulesViolation: RulesViolationsApproval;
    };
}
export interface DynamicTabItem extends IExtension {
    instance: Type<baseComplienceClass>;
}
/**
 * A sidesheet component to show some information about the selected rules violation.
 */
export declare class RulesViolationsDetailsComponent implements OnInit, OnDestroy {
    data: {
        selectedRulesViolation: RulesViolationsApproval;
        isMControlPerViolation: boolean;
        complianceRule: PortalRules;
    };
    sidesheetRef: EuiSidesheetRef;
    private readonly actionService;
    private readonly extService;
    private translateService;
    matTabGroup: MatTabGroup;
    cdrList: BaseCdr[];
    uidPerson: string;
    uidNonCompliance: string;
    uidCompliance: string;
    ruleInfoCdrList: BaseCdr[];
    private subscriptions$;
    constructor(data: {
        selectedRulesViolation: RulesViolationsApproval;
        isMControlPerViolation: boolean;
        complianceRule: PortalRules;
    }, sidesheetRef: EuiSidesheetRef, actionService: RulesViolationsActionService, extService: ExtService, translateService: TranslateService);
    ngOnInit(): void;
    /**
     * Opens the Approve-Sidesheet for the current selected rules violations and closes the sidesheet afterwards.
     */
    approve(): Promise<void>;
    /**
     * Opens the Deny-Sidesheet for the current selected rules violations and closes the sidesheet afterwards.
     */
    deny(): Promise<void>;
    resolve(): Promise<void>;
    get showDynamicTab(): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesViolationsDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RulesViolationsDetailsComponent, "imx-rules-violations-details", never, {}, {}, never, never, false>;
}
