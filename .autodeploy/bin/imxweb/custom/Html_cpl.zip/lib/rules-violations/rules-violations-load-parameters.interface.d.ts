import { CollectionLoadParameters } from 'imx-qbm-dbts';
/**
 * Extends the {@link CollectionLoadParameters} with some addtional parameters for the grouping API.
 */
export interface RulesViolationsLoadParameters extends CollectionLoadParameters {
    by?: string;
    def?: string;
    withcount?: boolean;
    state?: string;
}
