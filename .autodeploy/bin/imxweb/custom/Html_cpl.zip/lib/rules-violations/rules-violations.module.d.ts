import { ClassloggerService, MenuService } from 'qbm';
import * as i0 from "@angular/core";
import * as i1 from "./resolve/resolve.component";
import * as i2 from "./rules-violations.component";
import * as i3 from "./rules-violations-details/rules-violations-details.component";
import * as i4 from "./rules-violations-action/rules-violations-action.component";
import * as i5 from "./rules-violations-action/rules-violations-multi-action/rules-violations-multi-action.component";
import * as i6 from "./rules-violations-action/rules-violations-single-action/rules-violations-single-action.component";
import * as i7 from "./mitigating-controls-person/mitigating-controls-person.component";
import * as i8 from "qbm";
import * as i9 from "@angular/common";
import * as i10 from "@elemental-ui/core";
import * as i11 from "@angular/forms";
import * as i12 from "qer";
import * as i13 from "@angular/material/card";
import * as i14 from "@angular/material/stepper";
import * as i15 from "@angular/material/expansion";
import * as i16 from "@ngx-translate/core";
import * as i17 from "../mitigating-control-container/mitigating-control-container.module";
export declare class RulesViolationsModule {
    private readonly menuService;
    constructor(menuService: MenuService, logger: ClassloggerService);
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesViolationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulesViolationsModule, [typeof i1.ResolveComponent, typeof i2.RulesViolationsComponent, typeof i3.RulesViolationsDetailsComponent, typeof i4.RulesViolationsActionComponent, typeof i5.RulesViolationsMultiActionComponent, typeof i6.RulesViolationsSingleActionComponent, typeof i7.MitigatingControlsPersonComponent], [typeof i8.CdrModule, typeof i9.CommonModule, typeof i8.DataSourceToolbarModule, typeof i8.DataTableModule, typeof i10.EuiCoreModule, typeof i10.EuiMaterialModule, typeof i8.ExtModule, typeof i11.FormsModule, typeof i12.JustificationModule, typeof i13.MatCardModule, typeof i14.MatStepperModule, typeof i15.MatExpansionModule, typeof i11.ReactiveFormsModule, typeof i16.TranslateModule, typeof i8.SelectedElementsModule, typeof i17.MitigatingControlContainerModule, typeof i8.HelpContextualModule], [typeof i7.MitigatingControlsPersonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulesViolationsModule>;
}
