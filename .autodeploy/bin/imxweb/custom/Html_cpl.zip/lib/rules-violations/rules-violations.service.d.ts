import { EuiLoadingService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { ComplianceFeatureConfig, PortalRules } from 'imx-api-cpl';
import { ApiRequestOptions, CollectionLoadParameters, DataModel, EntitySchema, ExtendedTypedEntityCollection, FilterData, GroupInfoData } from 'imx-qbm-dbts';
import { ClassloggerService, DataSourceToolbarExportMethod, SystemInfoService } from 'qbm';
import { ApiService } from '../api.service';
import { RulesViolationsApproval } from './rules-violations-approval';
import { RulesViolationsLoadParameters } from './rules-violations-load-parameters.interface';
import * as i0 from "@angular/core";
/**
 * Service that provides all rules violations, including schema, DataModel and GroupingInfo.
 */
export declare class RulesViolationsService {
    private readonly cplClient;
    private readonly logger;
    private readonly busyService;
    private readonly translate;
    private readonly systemInfoService;
    abortController: AbortController;
    private busyIndicator;
    private busyIndicatorCounter;
    constructor(cplClient: ApiService, logger: ClassloggerService, busyService: EuiLoadingService, translate: TranslateService, systemInfoService: SystemInfoService);
    featureConfig(): Promise<ComplianceFeatureConfig>;
    /**
     * Provides the schema of {@link PortalRulesViolations}.
     */
    get rulesViolationsApproveSchema(): EntitySchema;
    /**
     * Provides the data model of {@link PortalRulesViolations}.
     */
    getDataModel(filter?: FilterData[]): Promise<DataModel>;
    /**
     * Provides the GroupInfo of {@link PortalRulesViolations}.
     */
    getGroupInfo(parameters?: RulesViolationsLoadParameters): Promise<GroupInfoData>;
    /**
     * Retrieves all rule violations, that the current user can approve or deny.
     *
     * @returns a list of {@link PortalRulesViolations|PortalRulesViolationss}
     */
    getRulesViolationsApprove(parameters?: CollectionLoadParameters, requestOpts?: ApiRequestOptions): Promise<ExtendedTypedEntityCollection<RulesViolationsApproval, unknown> | undefined>;
    exportRulesViolations(parameters: CollectionLoadParameters): DataSourceToolbarExportMethod;
    /**
     * Shows the busy indicator.
     */
    handleOpenLoader(): void;
    /**
     * Closes the busy indicator.
     */
    handleCloseLoader(): void;
    getComplianceRuleByUId(rulesViolationsApproval: RulesViolationsApproval): Promise<PortalRules>;
    abortCall(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesViolationsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RulesViolationsService>;
}
