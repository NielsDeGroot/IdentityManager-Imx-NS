import { UserModelService } from 'qer';
import * as i0 from "@angular/core";
export declare class CplPermissionsService {
    private readonly userService;
    constructor(userService: UserModelService);
    isExceptionAdmin(): Promise<boolean>;
    isRuleStatistics(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CplPermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CplPermissionsService>;
}
