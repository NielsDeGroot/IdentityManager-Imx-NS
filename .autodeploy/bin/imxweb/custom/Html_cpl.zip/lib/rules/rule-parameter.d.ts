import { CollectionLoadParameters } from 'imx-qbm-dbts';
export interface RuleParameter extends CollectionLoadParameters {
    active?: string;
}
