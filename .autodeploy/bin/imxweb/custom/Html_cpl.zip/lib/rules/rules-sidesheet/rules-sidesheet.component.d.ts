import { OnDestroy } from '@angular/core';
import { EuiDownloadOptions, EuiSidesheetRef } from '@elemental-ui/core';
import { Subscription } from 'rxjs';
import { PortalRules } from 'imx-api-cpl';
import { ColumnDependentReference, ElementalUiConfigService } from 'qbm';
import { RulesMitigatingControls } from '../mitigating-controls-rules/rules-mitigating-controls';
import { RulesService } from '../rules.service';
import * as i0 from "@angular/core";
export declare class RulesSidesheetComponent implements OnDestroy {
    data: {
        selectedRule: PortalRules;
        isMControlPerViolation: boolean;
        hasRiskIndex: boolean;
        mControls: RulesMitigatingControls[];
        canEdit: boolean;
    };
    sidesheetRef: EuiSidesheetRef;
    private readonly rulesProvider;
    reportDownload: EuiDownloadOptions;
    cdrList: ColumnDependentReference[];
    uidNonCompliance: string;
    uidCompliance: string;
    subscriptions$: Subscription[];
    constructor(data: {
        selectedRule: PortalRules;
        isMControlPerViolation: boolean;
        hasRiskIndex: boolean;
        mControls: RulesMitigatingControls[];
        canEdit: boolean;
    }, sidesheetRef: EuiSidesheetRef, rulesProvider: RulesService, elementalUiConfigService: ElementalUiConfigService);
    get objectType(): string;
    get objectUid(): string;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RulesSidesheetComponent, "imx-rules-sidesheet", never, {}, {}, never, never, false>;
}
