import * as i0 from "@angular/core";
import * as i1 from "./rules.component";
import * as i2 from "./rules-sidesheet/rules-sidesheet.component";
import * as i3 from "./mitigating-controls-rules/mitigating-controls-rules.component";
import * as i4 from "./rules-sidesheet/violations-per-rule/violations-per-rule.component";
import * as i5 from "@angular/common";
import * as i6 from "@elemental-ui/core";
import * as i7 from "@ngx-translate/core";
import * as i8 from "qbm";
import * as i9 from "@angular/material/button";
import * as i10 from "@angular/material/card";
import * as i11 from "@angular/material/tabs";
import * as i12 from "qer";
import * as i13 from "../rules-violations/rules-violations.module";
export declare class RulesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulesModule, [typeof i1.RulesComponent, typeof i2.RulesSidesheetComponent, typeof i3.MitigatingControlsRulesComponent, typeof i4.ViolationsPerRuleComponent], [typeof i5.CommonModule, typeof i6.EuiCoreModule, typeof i7.TranslateModule, typeof i8.CdrModule, typeof i8.DataTableModule, typeof i8.DataSourceToolbarModule, typeof i9.MatButtonModule, typeof i10.MatCardModule, typeof i11.MatTabsModule, typeof i12.StatisticsModule, typeof i12.ObjectHyperviewModule, typeof i8.HelpContextualModule, typeof i8.ExtModule, typeof i13.RulesViolationsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulesModule>;
}
