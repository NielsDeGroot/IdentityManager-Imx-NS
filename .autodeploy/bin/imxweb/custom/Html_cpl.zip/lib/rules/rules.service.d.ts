import { EuiLoadingService } from '@elemental-ui/core';
import { ComplianceFeatureConfig, PortalRules } from 'imx-api-cpl';
import { CollectionLoadParameters, DataModel, EntitySchema, ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { AppConfigService, DataSourceToolbarExportMethod } from 'qbm';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class RulesService {
    private apiservice;
    private busyService;
    private appConfig;
    abortController: AbortController;
    private busyIndicator;
    constructor(apiservice: ApiService, busyService: EuiLoadingService, appConfig: AppConfigService);
    get ruleSchema(): EntitySchema;
    featureConfig(): Promise<ComplianceFeatureConfig>;
    getRules(parameter?: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalRules, unknown>>;
    exportRules(parameter: CollectionLoadParameters): DataSourceToolbarExportMethod;
    getDataModel(): Promise<DataModel>;
    ruleReport(uidrule: string): string;
    recalculate(uidrule: string): Promise<void>;
    handleOpenLoader(): void;
    handleCloseLoader(): void;
    abortCall(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RulesService>;
}
