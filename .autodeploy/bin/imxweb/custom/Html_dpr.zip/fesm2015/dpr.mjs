import * as i5 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, Inject, Injectable, NgModule } from '@angular/core';
import * as i6 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i12 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i14 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i3 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i2 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i1 from 'qbm';
import { DataSourceToolbarModule, DataTableModule, SelectedElementsModule, LdsReplaceModule } from 'qbm';
import { __awaiter } from 'tslib';
import { OutstandingAction, V2Client, TypedClient } from 'imx-api-dpr';
import * as i3$1 from '@angular/material/button';
import * as i4 from '@angular/material/list';
import { TypedEntity, ReadOnlyEntity, ValType, DisplayColumns } from 'imx-qbm-dbts';
import * as i3$2 from '@angular/material/card';
import * as i7 from '@angular/material/core';
import * as i10 from '@angular/material/checkbox';
import * as i11 from '@angular/material/form-field';
import * as i13 from '@angular/material/select';

function DependenciesComponent_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 8)(1, "span", 7);
        i0.ɵɵtext(2, "#LDS#The following objects must also be added to the target system, as they depend on the objects to be added.");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵproperty("colored", true);
    }
}
function DependenciesComponent_eui_alert_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 9)(1, "span", 7);
        i0.ɵɵtext(2, "#LDS#The following objects must also be deleted, as they depend on the objects to be deleted.");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵproperty("colored", true);
    }
}
function DependenciesComponent_mat_list_item_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-list-item", 10);
        i0.ɵɵtext(1);
        i0.ɵɵelementStart(2, "span", 11);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const u_r3 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1("", u_r3.Display, " -\u00A0");
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(u_r3.ObjectType);
    }
}
class DependenciesComponent {
    constructor(data, sidesheetRef) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
    }
    save() {
        return __awaiter(this, void 0, void 0, function* () {
            this.sidesheetRef.close(true);
        });
    }
    isPublish() {
        return this.data.action === OutstandingAction.Publish;
    }
    isDelete() {
        return this.data.action === OutstandingAction.Delete;
    }
}
DependenciesComponent.ɵfac = function DependenciesComponent_Factory(t) { return new (t || DependenciesComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i3.EuiSidesheetRef)); };
DependenciesComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DependenciesComponent, selectors: [["ng-component"]], decls: 9, vars: 3, consts: [["eui-sidesheet-content", ""], ["class", "helper-alert", "type", "info", "condensed", "true", 3, "colored", 4, "ngIf"], ["class", "helper-alert", "type", "warning", "condensed", "true", 3, "colored", 4, "ngIf"], ["role", "list", 1, "helper-list"], ["role", "listitem", 4, "ngFor", "ngForOf"], ["eui-sidesheet-action", ""], ["data-imx-identifier", "dependencies-proceed", "mat-raised-button", "", "color", "primary", "type", "button", "form", "form", 3, "click"], ["translate", ""], ["type", "info", "condensed", "true", 1, "helper-alert", 3, "colored"], ["type", "warning", "condensed", "true", 1, "helper-alert", 3, "colored"], ["role", "listitem"], [1, "object-type"]], template: function DependenciesComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, DependenciesComponent_eui_alert_1_Template, 3, 1, "eui-alert", 1);
            i0.ɵɵtemplate(2, DependenciesComponent_eui_alert_2_Template, 3, 1, "eui-alert", 2);
            i0.ɵɵelementStart(3, "mat-list", 3);
            i0.ɵɵtemplate(4, DependenciesComponent_mat_list_item_4_Template, 4, 2, "mat-list-item", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "div", 5)(6, "button", 6);
            i0.ɵɵlistener("click", function DependenciesComponent_Template_button_click_6_listener() { return ctx.save(); });
            i0.ɵɵelementStart(7, "span", 7);
            i0.ɵɵtext(8, "#LDS#Proceed");
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.isPublish());
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.isDelete());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", ctx.data.dependencies);
        }
    }, dependencies: [i5.NgForOf, i5.NgIf, i3.EuiAlertComponent, i3.EuiSidesheetContentDirective, i3$1.MatButton, i4.MatList, i4.MatListItem, i2.TranslateDirective], styles: [".helper-alert[_ngcontent-%COMP%]{display:block}.helper-alert[_ngcontent-%COMP%], .helper-list[_ngcontent-%COMP%]{margin:1em}.object-type[_ngcontent-%COMP%]{font-style:italic}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DependenciesComponent, [{
            type: Component,
            args: [{ template: "<div eui-sidesheet-content>\r\n  <eui-alert class=\"helper-alert\" type=\"info\" condensed=\"true\" [colored]=\"true\" *ngIf=\"isPublish()\">\r\n    <span translate>#LDS#The following objects must also be added to the target system, as they depend on the objects to be added.</span>\r\n  </eui-alert>\r\n\r\n  <eui-alert class=\"helper-alert\" type=\"warning\" condensed=\"true\" [colored]=\"true\" *ngIf=\"isDelete()\">\r\n    <span translate>#LDS#The following objects must also be deleted, as they depend on the objects to be deleted.</span>\r\n  </eui-alert>\r\n\r\n  <mat-list class=\"helper-list\" role=\"list\">\r\n    <mat-list-item role=\"listitem\" *ngFor=\"let u of data.dependencies\"\r\n      >{{ u.Display }} -&nbsp;<span class=\"object-type\">{{ u.ObjectType }}</span>\r\n    </mat-list-item>\r\n  </mat-list>\r\n</div>\r\n\r\n<div eui-sidesheet-action>\r\n  <button data-imx-identifier=\"dependencies-proceed\" mat-raised-button color=\"primary\" type=\"button\" (click)=\"save()\" form=\"form\">\r\n    <span translate>#LDS#Proceed</span>\r\n  </button>\r\n</div>\r\n", styles: [".helper-alert{display:block}.helper-alert,.helper-list{margin:1em}.object-type{font-style:italic}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i3.EuiSidesheetRef }];
    }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class OutstandingObjectEntity extends TypedEntity {
    constructor() {
        super(...arguments);
        this.ObjectType = this.GetEntityValue('ObjectType');
        this.ObjectKey = this.GetEntityValue('ObjectKey');
        this.Display = this.GetEntityValue('Display');
        this.CanPublish = this.GetEntityValue('CanPublish');
        this.CanDelete = this.GetEntityValue('CanDelete');
        this.CanDeleteRestrictionReason = this.GetEntityValue("CanDeleteRestrictionReason");
        this.CanPublishRestrictionReason = this.GetEntityValue("CanPublishRestrictionReason");
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function SelectedItemsComponent_ng_template_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
        i0.ɵɵelementStart(1, "div", 9);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const data_r3 = ctx.$implicit;
        i0.ɵɵtextInterpolate1(" ", data_r3.Display.value, " ");
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(data_r3.ObjectType.value);
    }
}
const _c0$1 = function () { return ["search", "filter"]; };
class SelectedItemsComponent {
    constructor(data) {
        this.data = data;
        this.navigationState = {};
        this.displayedColumns = [
            data.schema.Columns.Display
        ];
        this.sortedEntities = data.objects.sort((a, b) => a.Display.value.localeCompare(b.Display.value));
        this.searchedEntities = [...this.sortedEntities];
    }
    ngOnInit() {
        this.getData({ StartIndex: 0, PageSize: 20 });
    }
    search(key) {
        if (key === '') {
            this.searchedEntities = [...this.sortedEntities];
        }
        else {
            this.searchedEntities = this.sortedEntities.filter(elem => elem.Display.value.toLocaleLowerCase().includes(key.toLocaleLowerCase()));
        }
        this.getData({ StartIndex: 0, search: key });
    }
    getData(state) {
        this.navigationState = Object.assign(Object.assign({}, this.navigationState), state);
        const data = this.searchedEntities
            .slice(this.navigationState.StartIndex, this.navigationState.StartIndex + this.navigationState.PageSize);
        this.dstSettings = {
            navigationState: this.navigationState,
            dataSource: {
                Data: data,
                totalCount: this.searchedEntities.length
            },
            entitySchema: this.data.schema,
            displayedColumns: this.displayedColumns
        };
    }
}
SelectedItemsComponent.ɵfac = function SelectedItemsComponent_Factory(t) { return new (t || SelectedItemsComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
SelectedItemsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SelectedItemsComponent, selectors: [["imx-selected-items"]], decls: 11, vars: 10, consts: [["eui-sidesheet-content", ""], [1, "imx-sidesheet-content"], [3, "settings", "options", "navigationStateChanged", "search"], ["dst", ""], [1, "imx-table-container"], ["mode", "manual", "data-imx-identifier", "outstanding-objects-table", 3, "dst", "detailViewVisible", "selectable"], ["dataTable", ""], ["columnName", "Display", 3, "columnLabel"], ["data-imx-identifier", "typed-entity-candidates-paginator", 3, "dst"], [1, "object-type"]], template: function SelectedItemsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card", 1)(2, "imx-data-source-toolbar", 2, 3);
            i0.ɵɵlistener("navigationStateChanged", function SelectedItemsComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { return ctx.getData($event); })("search", function SelectedItemsComponent_Template_imx_data_source_toolbar_search_2_listener($event) { return ctx.search($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "div", 4)(5, "imx-data-table", 5, 6)(7, "imx-data-table-generic-column", 7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵtemplate(9, SelectedItemsComponent_ng_template_9_Template, 3, 2, "ng-template");
            i0.ɵɵelementEnd()()();
            i0.ɵɵelement(10, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(3);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(9, _c0$1));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0)("detailViewVisible", false)("selectable", false);
            i0.ɵɵadvance(2);
            i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(8, 7, "#LDS#Display name"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i1.DataSourceToolbarComponent, i1.DataSourcePaginatorComponent, i1.DataTableComponent, i1.DataTableGenericColumnComponent, i3.EuiSidesheetContentDirective, i3$2.MatCard, i2.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}.eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.imx-sidesheet-content[_ngcontent-%COMP%]{overflow:hidden;display:flex;flex-direction:column}.imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;max-width:100%;flex-direction:1 1 auto}.object-type[_ngcontent-%COMP%]{font-style:italic;font-size:smaller}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SelectedItemsComponent, [{
            type: Component,
            args: [{ selector: 'imx-selected-items', template: "<div eui-sidesheet-content>\r\n  <mat-card class=\"imx-sidesheet-content\">\r\n    <imx-data-source-toolbar #dst [settings]=\"dstSettings\" (navigationStateChanged)=\"getData($event)\"\r\n      (search)=\"search($event)\" [options]=\"['search', 'filter']\">\r\n    </imx-data-source-toolbar>\r\n\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-table #dataTable [dst]=\"dst\" [detailViewVisible]=\"false\" [selectable]=\"false\"\r\n        mode=\"manual\" data-imx-identifier=\"outstanding-objects-table\">\r\n\r\n        <imx-data-table-generic-column columnName=\"Display\" columnLabel=\"{{ '#LDS#Display name' | translate }}\">\r\n          <ng-template let-data>\r\n            {{ data.Display.value }}\r\n            <div class=\"object-type\">{{ data.ObjectType.value }}</div>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n      </imx-data-table>\r\n    </div>\r\n    <imx-data-source-paginator [dst]=\"dst\" data-imx-identifier=\"typed-entity-candidates-paginator\">\r\n    </imx-data-source-paginator>\r\n  </mat-card>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;height:100%}.eui-sidesheet-content{display:flex;flex-direction:column;overflow:hidden}.imx-sidesheet-content{overflow:hidden;display:flex;flex-direction:column}.imx-table-container{display:flex;flex-direction:column;overflow:hidden;height:inherit;max-width:100%;flex-direction:1 1 auto}.object-type{font-style:italic;font-size:smaller}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }];
    }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing DPR API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
ApiService.ɵfac = function ApiService_Factory(t) { return new (t || ApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
ApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApiService, factory: ApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i1.ImxTranslationProviderService }]; }, null);
})();

class OutstandingService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    getNamespaces() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.typedClient.OpsupportNamespaces.Get({ PageSize: 1024 });
        });
    }
    getTableData(newNamespace) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.typedClient.OpsupportOutstandingTables.Get({ PageSize: 1024, namespace: newNamespace.Ident_DPRNameSpace.value });
        });
    }
    getDependencies(action, values) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.client.opsupport_outstanding_dependencies_post(action, values);
        });
    }
    getOutstandingTable(tableName, namespace, actionfilter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.client.opsupport_outstanding_table_get(tableName, {
                namespace: namespace,
                actionfilter: actionfilter
            });
        });
    }
    getOutstandingNamespace(namespace, actionfilter) {
        return this.apiService.client.opsupport_outstanding_namespace_get(namespace, { actionfilter: actionfilter });
    }
    processObjects(action, bulk, objects) {
        return this.apiService.client.opsupport_outstanding_process_post(action, objects, { bulk: bulk });
    }
}
OutstandingService.ɵfac = function OutstandingService_Factory(t) { return new (t || OutstandingService)(i0.ɵɵinject(ApiService)); };
OutstandingService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: OutstandingService, factory: OutstandingService.ɵfac });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OutstandingService, [{
            type: Injectable
        }], function () { return [{ type: ApiService }]; }, null);
})();

function OutstandingComponent_mat_spinner_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner");
    }
}
function OutstandingComponent_ng_container_1_eui_alert_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r10 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-alert", 22);
        i0.ɵɵlistener("dismissed", function OutstandingComponent_ng_container_1_eui_alert_4_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r10); const ctx_r9 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r9.onHelperDismissed()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("colored", true)("dismissable", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, ctx_r2.LdsOutstandingText), " ");
    }
}
function OutstandingComponent_ng_container_1_mat_option_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-option", 23);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const pr_r11 = ctx.$implicit;
        i0.ɵɵproperty("value", pr_r11);
        i0.ɵɵattribute("data-imx-identifier", "outstanding-namespace-option-" + pr_r11.GetEntity().GetDisplay());
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", pr_r11.GetEntity().GetDisplay(), " ");
    }
}
function OutstandingComponent_ng_container_1_mat_spinner_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner", 24);
    }
}
function OutstandingComponent_ng_container_1_mat_option_18_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-option", 23);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const pr_r12 = ctx.$implicit;
        i0.ɵɵproperty("value", pr_r12);
        i0.ɵɵattribute("data-imx-identifier", "outstanding-table-option-" + pr_r12.GetEntity().GetDisplay());
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate2(" ", pr_r12.GetEntity().GetDisplay(), " (", pr_r12.CountOutstanding.value, ") ");
    }
}
function OutstandingComponent_ng_container_1_mat_spinner_27_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner");
    }
}
function OutstandingComponent_ng_container_1_imx_data_table_28_ng_template_4_eui_badge_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-badge", 33);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const data_r15 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵproperty("matTooltip", data_r15.CanDeleteRestrictionReason.value);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Cannot delete"), " ");
    }
}
function OutstandingComponent_ng_container_1_imx_data_table_28_ng_template_4_eui_badge_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-badge", 33);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const data_r15 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵproperty("matTooltip", data_r15.CanPublishRestrictionReason.value);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Cannot add"), " ");
    }
}
function OutstandingComponent_ng_container_1_imx_data_table_28_ng_template_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 29)(1, "div", 30);
        i0.ɵɵtext(2);
        i0.ɵɵelementStart(3, "div", 31);
        i0.ɵɵtext(4);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(5, OutstandingComponent_ng_container_1_imx_data_table_28_ng_template_4_eui_badge_5_Template, 3, 4, "eui-badge", 32);
        i0.ɵɵtemplate(6, OutstandingComponent_ng_container_1_imx_data_table_28_ng_template_4_eui_badge_6_Template, 3, 4, "eui-badge", 32);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const data_r15 = ctx.$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", data_r15.Display.value, " ");
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(data_r15.ObjectType.value);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", data_r15.CanDeleteRestrictionReason.value);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", data_r15.CanPublishRestrictionReason.value);
    }
}
const _c0 = function (a0) { return { loadingtable: a0 }; };
function OutstandingComponent_ng_container_1_imx_data_table_28_Template(rf, ctx) {
    if (rf & 1) {
        const _r21 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-data-table", 25, 26);
        i0.ɵɵlistener("selectionChanged", function OutstandingComponent_ng_container_1_imx_data_table_28_Template_imx_data_table_selectionChanged_0_listener($event) { i0.ɵɵrestoreView(_r21); const ctx_r20 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r20.selectionChanged($event)); });
        i0.ɵɵelementStart(2, "imx-data-table-generic-column", 27);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵtemplate(4, OutstandingComponent_ng_container_1_imx_data_table_28_ng_template_4_Template, 7, 4, "ng-template");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(5, "imx-data-table-column", 28)(6, "imx-data-table-column", 28);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r6 = i0.ɵɵreference(25);
        const ctx_r8 = i0.ɵɵnextContext();
        i0.ɵɵproperty("dst", _r6)("detailViewVisible", false)("selectable", true)("showSelectedItemsMenu", false)("ngClass", i0.ɵɵpureFunction1(11, _c0, ctx_r8.busyLoadingTable))("noDataText", ctx_r8.getNoDataText());
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(3, 9, "#LDS#Display name"));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("entityColumn", ctx_r8.schema == null ? null : ctx_r8.schema.Columns.LastLogEntry);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r8.schema == null ? null : ctx_r8.schema.Columns.LastMethodRun);
    }
}
const _c1 = function () { return ["filter"]; };
function OutstandingComponent_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r23 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "h2", 1);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(4, OutstandingComponent_ng_container_1_eui_alert_4_Template, 3, 5, "eui-alert", 2);
        i0.ɵɵelementStart(5, "div", 3)(6, "mat-form-field", 4)(7, "mat-label");
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(10, "mat-select", 5);
        i0.ɵɵlistener("selectionChange", function OutstandingComponent_ng_container_1_Template_mat_select_selectionChange_10_listener($event) { i0.ɵɵrestoreView(_r23); const ctx_r22 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r22.optionSelected($event.value)); })("valueChange", function OutstandingComponent_ng_container_1_Template_mat_select_valueChange_10_listener($event) { i0.ɵɵrestoreView(_r23); const ctx_r24 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r24.selectedNamespace = $event); });
        i0.ɵɵtemplate(11, OutstandingComponent_ng_container_1_mat_option_11_Template, 2, 3, "mat-option", 6);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(12, "mat-form-field", 7);
        i0.ɵɵtemplate(13, OutstandingComponent_ng_container_1_mat_spinner_13_Template, 1, 0, "mat-spinner", 8);
        i0.ɵɵelementStart(14, "mat-label");
        i0.ɵɵtext(15);
        i0.ɵɵpipe(16, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(17, "mat-select", 9);
        i0.ɵɵlistener("selectionChange", function OutstandingComponent_ng_container_1_Template_mat_select_selectionChange_17_listener($event) { i0.ɵɵrestoreView(_r23); const ctx_r25 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r25.tableSelected($event.value)); })("valueChange", function OutstandingComponent_ng_container_1_Template_mat_select_valueChange_17_listener($event) { i0.ɵɵrestoreView(_r23); const ctx_r26 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r26.selectedTable = $event); });
        i0.ɵɵtemplate(18, OutstandingComponent_ng_container_1_mat_option_18_Template, 2, 4, "mat-option", 6);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(19, "mat-checkbox", 10);
        i0.ɵɵlistener("change", function OutstandingComponent_ng_container_1_Template_mat_checkbox_change_19_listener() { i0.ɵɵrestoreView(_r23); const ctx_r27 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r27.onShowAllData()); })("ngModelChange", function OutstandingComponent_ng_container_1_Template_mat_checkbox_ngModelChange_19_listener($event) { i0.ɵɵrestoreView(_r23); const ctx_r28 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r28.showAllData = $event); });
        i0.ɵɵtext(20);
        i0.ɵɵpipe(21, "ldsReplace");
        i0.ɵɵpipe(22, "translate");
        i0.ɵɵpipe(23, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(24, "imx-data-source-toolbar", 11, 12);
        i0.ɵɵlistener("navigationStateChanged", function OutstandingComponent_ng_container_1_Template_imx_data_source_toolbar_navigationStateChanged_24_listener($event) { i0.ɵɵrestoreView(_r23); const ctx_r29 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r29.getData($event)); });
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(26, "mat-card", 13);
        i0.ɵɵtemplate(27, OutstandingComponent_ng_container_1_mat_spinner_27_Template, 1, 0, "mat-spinner", 0);
        i0.ɵɵtemplate(28, OutstandingComponent_ng_container_1_imx_data_table_28_Template, 7, 13, "imx-data-table", 14);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(29, "div", 15);
        i0.ɵɵelement(30, "imx-selected-elements", 16)(31, "div", 17);
        i0.ɵɵelementStart(32, "mat-checkbox", 18);
        i0.ɵɵlistener("ngModelChange", function OutstandingComponent_ng_container_1_Template_mat_checkbox_ngModelChange_32_listener($event) { i0.ɵɵrestoreView(_r23); const ctx_r30 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r30.bulk = $event); });
        i0.ɵɵpipe(33, "translate");
        i0.ɵɵtext(34);
        i0.ɵɵpipe(35, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(36, "button", 19);
        i0.ɵɵlistener("click", function OutstandingComponent_ng_container_1_Template_button_click_36_listener() { i0.ɵɵrestoreView(_r23); const ctx_r31 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r31.deleteObjects()); });
        i0.ɵɵpipe(37, "translate");
        i0.ɵɵtext(38);
        i0.ɵɵpipe(39, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(40, "button", 20);
        i0.ɵɵlistener("click", function OutstandingComponent_ng_container_1_Template_button_click_40_listener() { i0.ɵɵrestoreView(_r23); const ctx_r32 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r32.resetObjects()); });
        i0.ɵɵpipe(41, "translate");
        i0.ɵɵtext(42);
        i0.ɵɵpipe(43, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(44, "button", 21);
        i0.ɵɵlistener("click", function OutstandingComponent_ng_container_1_Template_button_click_44_listener() { i0.ɵɵrestoreView(_r23); const ctx_r33 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r33.publishObjects()); });
        i0.ɵɵpipe(45, "translate");
        i0.ɵɵtext(46);
        i0.ɵɵpipe(47, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 31, "#LDS#Heading Outstanding Objects"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r1.showHelper);
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(9, 33, "#LDS#Target system type"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("value", ctx_r1.selectedNamespace);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r1.namespaces);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r1.loadingTableData);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(16, 35, "#LDS#Object type"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", ctx_r1.tabledata.length == 0)("value", ctx_r1.selectedTable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r1.tabledata);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngModel", ctx_r1.showAllData)("disabled", !ctx_r1.selectedNamespace || ctx_r1.loadingTableData);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", !!ctx_r1.selectedNamespaceTitle && !ctx_r1.loadingTableData ? i0.ɵɵpipeBind3(21, 37, i0.ɵɵpipeBind1(22, 41, "#LDS#Show all outstanding objects of {0} ({1})"), ctx_r1.selectedNamespaceTitle, ctx_r1.tableDataCount) : i0.ɵɵpipeBind1(23, 43, "#LDS#Show all outstanding objects of the target system type"), " ");
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("settings", ctx_r1.dstSettings)("options", i0.ɵɵpureFunction0(61, _c1))("hidden", ctx_r1.busyLoadingTable);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", ctx_r1.busyLoadingTable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r1.busyLoadingTable);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("selectedElements", ctx_r1.selected);
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(33, 45, "#LDS#If you activate bulk processing, the selected objects are processed in parallel. This speeds up the performed action. If an error occurs during processing, the action is stopped and all changes are discarded. To locate errors, deactivate bulk processing. Thus, the objects are processed sequentially. All changes made until the error occurred are saved."));
        i0.ɵɵproperty("ngModel", ctx_r1.bulk);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(35, 47, "#LDS#Bulk processing"), "");
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(37, 49, "#LDS#Deletes the selected objects in the database"));
        i0.ɵɵproperty("disabled", ctx_r1.selected.length === 0 || !ctx_r1.canDeleteAllSelected());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(39, 51, "#LDS#Delete"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(41, 53, "#LDS#Removes the Outstanding label for the selected objects"));
        i0.ɵɵproperty("disabled", ctx_r1.selected.length === 0);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(43, 55, "#LDS#Reset"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(45, 57, "#LDS#Adds the selected objects to the target system"));
        i0.ɵɵproperty("disabled", ctx_r1.selected.length === 0 || !ctx_r1.canPublishAllSelected());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(47, 59, "#LDS#Add to target system"), " ");
    }
}
class OutstandingComponent {
    constructor(apiService, translator, sidesheet, confirmationService, snackbar, translate, busyService) {
        this.apiService = apiService;
        this.translator = translator;
        this.sidesheet = sidesheet;
        this.confirmationService = confirmationService;
        this.snackbar = snackbar;
        this.translate = translate;
        this.busyService = busyService;
        this.namespaces = [];
        this.navigationState = {};
        this.tabledata = [];
        this.showHelper = true;
        this.bulk = true;
        this.selected = [];
        this.busyLoadingTable = false;
        this.loadingTableData = false;
        this.showAllData = false;
        this.tableDataCount = 0;
        this.LdsOutstandingText = '#LDS#Objects which do not exist in the target system are marked as outstanding. Here you can get an overview of outstanding objects, delete these objects in the database or add these objects to the target system again. Additionally, you can reset the status of these objects so that they are no longer marked as outstanding.';
        this.busy = false;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.busy = true;
            try {
                this.ldsPublishable = yield this.translator.get('#LDS#Addable objects').toPromise();
                this.ldsDeletable = yield this.translator.get('#LDS#Deletable objects').toPromise();
                this.ldsActionFilter = yield this.translator.get('#LDS#Performable actions').toPromise();
                this.schema = yield this.buildEntitySchema();
                this.buildDstSettings({ Data: [], totalCount: 0 });
                const typed = yield this.apiService.getNamespaces();
                this.namespaces = typed.Data;
            }
            finally {
                this.busy = false;
            }
        });
    }
    tableSelected(table) {
        return __awaiter(this, void 0, void 0, function* () {
            this.selectedTable = table;
            this.selected = [];
            this.showAllData = false;
            yield this.navigate();
        });
    }
    optionSelected(newNamespace) {
        return __awaiter(this, void 0, void 0, function* () {
            this.selectedNamespace = newNamespace;
            this.tabledata = [];
            this.selectedTable = null;
            this.selected = [];
            this.tableDataCount = 0;
            this.showAllData = false;
            this.buildDstSettings({ Data: [], totalCount: 0 });
            if (newNamespace) {
                this.loadingTableData = true;
                try {
                    this.tabledata = (yield this.apiService.getTableData(newNamespace)).Data
                        // remove tables without outstanding objects
                        .filter((m) => m.CountOutstanding.value > 0)
                        // count outstanding objects
                        .map((table => {
                        this.tableDataCount += table.CountOutstanding.value;
                        return table;
                    }));
                }
                finally {
                    this.loadingTableData = false;
                }
            }
        });
    }
    onShowAllData() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.showAllData && (!!this.selectedTable || this.dstSettings.dataSource.totalCount === 0)) {
                this.confirmationService
                    .confirm({
                    Title: '#LDS#Heading Show All Outstanding Objects',
                    Message: '#LDS#Displaying all outstanding objects may take some time. Are you sure you want to display all outstanding objects?',
                    identifier: 'outstanding-objects-show-all-data',
                })
                    .then((res) => {
                    if (res) {
                        this.selectedTable = null;
                        this.navigate();
                    }
                    else {
                        this.showAllData = false;
                    }
                });
            }
            else {
                this.buildDstSettings({ Data: [], totalCount: 0 });
            }
        });
    }
    selectionChanged(selected) {
        this.selected = selected;
    }
    getData(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState = newState;
            yield this.navigate();
        });
    }
    onHelperDismissed() {
        this.showHelper = false;
    }
    showSelected(objects) {
        return __awaiter(this, void 0, void 0, function* () {
            this.sidesheet.open(SelectedItemsComponent, {
                title: yield this.translate.get('#LDS#Heading Selected Items').toPromise(),
                padding: '0',
                width: 'max(550px, 55%)',
                data: { objects, schema: this.schema },
                testId: 'outstanding-objects-selected-elements-sidesheet',
            });
        });
    }
    confirmDependencies(action) {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => (overlayRef = this.busyService.show()));
            let dependencies;
            try {
                dependencies = yield this.apiService.getDependencies(action, this.selected.map((m) => m.ObjectKey.value));
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
            // no dependencies? don't show confirmation dialog
            if (dependencies.length === 0) {
                return true;
            }
            const sidesheetRef = this.sidesheet.open(DependenciesComponent, {
                title: yield this.translator.get('#LDS#Heading View Dependencies').toPromise(),
                subTitle: this.selected.length === 1 ? this.selected[0].GetEntity().GetDisplay() : '',
                padding: '0px',
                width: 'max(600px, 55%)',
                testId: 'outstanding-view-depedencies-sidesheet',
                data: {
                    dependencies,
                    action,
                },
            });
            const fromsidesheet = yield sidesheetRef.afterClosed().toPromise();
            return fromsidesheet;
        });
    }
    canPublishAllSelected() {
        return this.selected.every((elem) => elem.CanPublish.value);
    }
    canDeleteAllSelected() {
        return this.selected.every((elem) => elem.CanDelete.value);
    }
    deleteObjects() {
        return this.processWithConfirmation(OutstandingAction.Delete);
    }
    resetObjects() {
        return this.processWithConfirmation(OutstandingAction.DeleteState);
    }
    publishObjects() {
        return this.processWithConfirmation(OutstandingAction.Publish);
    }
    getNoDataText() {
        return this.selectedNamespace
            ? this.tabledata.length > 0
                ? '#LDS#Select an object type.'
                : '#LDS#There are currently no outstanding objects.'
            : '#LDS#Select a target system.';
    }
    buildDstSettings(data) {
        this.dstSettings = {
            navigationState: {},
            dataSource: data,
            entitySchema: this.schema,
            filters: [
                {
                    Description: this.ldsActionFilter,
                    Name: 'actionfilter',
                    Options: [
                        {
                            Display: this.ldsPublishable,
                            Value: 'publishable',
                        },
                        {
                            Display: this.ldsDeletable,
                            Value: 'deletable',
                        },
                    ],
                    CurrentValue: this.currentFilterValue,
                    Delimiter: ',',
                },
            ],
            displayedColumns: [this.schema.Columns.Display, this.schema.Columns.LastLogEntry],
        };
    }
    navigate() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.busyLoadingTable = true;
                yield this.navigateWithoutBusy();
            }
            finally {
                this.busyLoadingTable = false;
            }
        });
    }
    navigateWithoutBusy() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.selectedNamespace) {
                this.buildDstSettings({ Data: [], totalCount: 0 });
            }
            let baseObjects;
            this.currentFilterValue = this.navigationState.actionfilter;
            if (this.selectedTable) {
                baseObjects = yield this.apiService.getOutstandingTable(this.selectedTable.TableName.value, this.selectedNamespace.Ident_DPRNameSpace.value, this.currentFilterValue);
            }
            else {
                baseObjects = yield this.apiService.getOutstandingNamespace(this.selectedNamespace.Ident_DPRNameSpace.value, this.currentFilterValue);
            }
            const reduce = (m) => {
                if (!m || m.length == 0)
                    return null;
                return m.reduce((p, v) => p + ' ' + v);
            };
            const typedEntities = baseObjects.map((obj) => new OutstandingObjectEntity(new ReadOnlyEntity(this.dstSettings.entitySchema, {
                Keys: [obj.ObjectKey],
                Columns: {
                    ObjectKey: {
                        Value: obj.ObjectKey,
                    },
                    CanDelete: {
                        Value: obj.CanDelete,
                    },
                    CanPublish: {
                        Value: obj.CanPublish,
                    },
                    CanDeleteRestrictionReason: {
                        Value: reduce(obj.CanDeleteRestrictionReasons),
                    },
                    CanPublishRestrictionReason: {
                        Value: reduce(obj.CanPublishRestrictionReasons),
                    },
                    Display: {
                        Value: obj.Display,
                    },
                    LastLogEntry: {
                        Value: obj.LastLogEntry,
                    },
                    ObjectType: {
                        Value: obj.ObjectType,
                    },
                    LastMethodRun: {
                        Value: obj.LastMethodRun,
                    },
                },
            })));
            this.buildDstSettings({
                Data: typedEntities,
                totalCount: typedEntities.length,
            });
        });
    }
    processWithConfirmation(action) {
        return __awaiter(this, void 0, void 0, function* () {
            let canProceed = yield this.confirmationService.confirm({
                Title: this.getConfirmationTitle(action),
                Message: this.getConfirmationText(action),
                identifier: 'outstanding-objects-process-confirmation',
            });
            if (!canProceed) {
                return;
            }
            canProceed = yield this.confirmDependencies(action);
            if (!canProceed) {
                return;
            }
            return this.process(action);
        });
    }
    process(action) {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => (overlayRef = this.busyService.show()));
            try {
                yield this.apiService.processObjects(action, this.bulk, this.selected.map((k) => k.ObjectKey.value));
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
                this.snackbar.open({ key: this.getSnackbarText(action) });
            }
            // reload
            return this.navigate();
        });
    }
    getConfirmationTitle(action) {
        switch (action) {
            case OutstandingAction.Delete:
                return this.selected.length > 1 ? '#LDS#Heading Delete Objects' : '#LDS#Heading Delete Object';
            case OutstandingAction.DeleteState:
                return this.selected.length > 1 ? '#LDS#Heading Reset Objects' : '#LDS#Heading Reset Object';
            case OutstandingAction.Publish:
                return this.selected.length > 1 ? '#LDS#Heading Add Objects' : '#LDS#Heading Add Object';
        }
    }
    getConfirmationText(action) {
        switch (action) {
            case OutstandingAction.Delete:
                return this.selected.length > 1
                    ? '#LDS#Are you sure you want to delete the selected objects in the database?'
                    : '#LDS#Are you sure you want to delete the selected object in the database?';
            case OutstandingAction.DeleteState:
                return this.selected.length > 1
                    ? '#LDS#Are you sure you want to remove the Outstanding labels for the selected objects?'
                    : '#LDS#Are you sure you want to remove the Outstanding label for the selected object?';
            case OutstandingAction.Publish:
                return this.selected.length > 1
                    ? '#LDS#Are you sure you want to add the selected objects to the target system?'
                    : '#LDS#Are you sure you want to add the selected object to the target system?';
        }
    }
    getSnackbarText(action) {
        switch (action) {
            case OutstandingAction.Delete:
                return this.selected.length > 1
                    ? '#LDS#The objects have been successfully deleted in the database.'
                    : '#LDS#The object has been successfully deleted in the database.';
            case OutstandingAction.DeleteState:
                return this.selected.length > 1
                    ? '#LDS#The Outstanding labels have been successfully removed for the objects.'
                    : '#LDS#The Outstanding label has been successfully removed for the object.';
            case OutstandingAction.Publish:
                return this.selected.length > 1
                    ? '#LDS#The objects have been successfully added to the target system.'
                    : '#LDS#The object has been successfully added to the target system.';
        }
    }
    buildEntitySchema() {
        return __awaiter(this, void 0, void 0, function* () {
            const columns = {
                ObjectKey: {
                    ColumnName: 'ObjectKey',
                    Type: ValType.String,
                    IsReadOnly: true,
                },
                Display: {
                    ColumnName: 'Display',
                    Display: yield this.translator.get('#LDS#Object').toPromise(),
                    Type: ValType.String,
                    IsReadOnly: true,
                },
                LastMethodRun: {
                    ColumnName: 'LastMethodRun',
                    Display: yield this.translator.get('#LDS#Last method run').toPromise(),
                    Type: ValType.String,
                    IsReadOnly: true,
                },
                ObjectType: {
                    ColumnName: 'ObjectType',
                    Display: yield this.translator.get('#LDS#Object type').toPromise(),
                    Type: ValType.String,
                    IsReadOnly: true,
                },
                LastLogEntry: {
                    ColumnName: 'LastLogEntry',
                    Display: yield this.translator.get('#LDS#Last log entry').toPromise(),
                    Type: ValType.Date,
                    IsReadOnly: true,
                },
                CanPublish: {
                    ColumnName: 'CanPublish',
                    Type: ValType.Bool,
                    IsReadOnly: true,
                },
                CanDelete: {
                    ColumnName: 'CanDelete',
                    Type: ValType.Bool,
                    IsReadOnly: true,
                },
                CanPublishRestrictionReason: {
                    ColumnName: 'CanPublishRestrictionReason',
                    Type: ValType.String,
                    IsReadOnly: true,
                },
                CanDeleteRestrictionReason: {
                    ColumnName: 'CanDeleteRestrictionReason',
                    Type: ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'OutstandingObject', Columns: columns };
        });
    }
    get selectedNamespaceTitle() {
        var _a, _b;
        return (_b = (_a = this.selectedNamespace) === null || _a === void 0 ? void 0 : _a.GetEntity()) === null || _b === void 0 ? void 0 : _b.GetDisplayLong();
    }
}
OutstandingComponent.ɵfac = function OutstandingComponent_Factory(t) { return new (t || OutstandingComponent)(i0.ɵɵdirectiveInject(OutstandingService), i0.ɵɵdirectiveInject(i2.TranslateService), i0.ɵɵdirectiveInject(i3.EuiSidesheetService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(i1.SnackBarService), i0.ɵɵdirectiveInject(i2.TranslateService), i0.ɵɵdirectiveInject(i3.EuiLoadingService)); };
OutstandingComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OutstandingComponent, selectors: [["ng-component"]], decls: 2, vars: 2, consts: [[4, "ngIf"], [1, "mat-headline"], ["class", "helper-alert", "type", "info", "condensed", "true", 3, "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "filters"], [1, "namespace-selector"], ["required", "", "data-imx-identifier", "outstanding-namespace-select", 3, "value", "selectionChange", "valueChange"], [3, "value", 4, "ngFor", "ngForOf"], [1, "table-selector"], ["matPrefix", "", 4, "ngIf"], ["data-imx-identifier", "outstanding-table-select", 3, "disabled", "value", "selectionChange", "valueChange"], [3, "ngModel", "disabled", "change", "ngModelChange"], [3, "settings", "options", "hidden", "navigationStateChanged"], ["dst", ""], [1, "scroll-container"], ["mode", "manual", "data-imx-identifier", "outstanding-objects-table", 3, "dst", "detailViewVisible", "selectable", "showSelectedItemsMenu", "ngClass", "noDataText", "selectionChanged", 4, "ngIf"], [1, "imx-button-bar"], [3, "selectedElements"], [1, "imx-menu-spacer"], [1, "bulkmodecheckbox", 3, "matTooltip", "ngModel", "ngModelChange"], ["mat-raised-button", "", "color", "warn", "data-imx-identifier", "outstanding-delete-button", 3, "disabled", "matTooltip", "click"], ["mat-raised-button", "", "data-imx-identifier", "outstanding-reset-button", 3, "disabled", "matTooltip", "click"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "outstanding-publish-button", 3, "disabled", "matTooltip", "click"], ["type", "info", "condensed", "true", 1, "helper-alert", 3, "colored", "dismissable", "dismissed"], [3, "value"], ["matPrefix", ""], ["mode", "manual", "data-imx-identifier", "outstanding-objects-table", 3, "dst", "detailViewVisible", "selectable", "showSelectedItemsMenu", "ngClass", "noDataText", "selectionChanged"], ["dataTable", ""], ["columnName", "Display", 3, "columnLabel"], [3, "entityColumn"], [1, "first-cell"], [1, "first-col"], [1, "object-type"], [3, "matTooltip", 4, "ngIf"], [3, "matTooltip"]], template: function OutstandingComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, OutstandingComponent_mat_spinner_0_Template, 1, 0, "mat-spinner", 0);
            i0.ɵɵtemplate(1, OutstandingComponent_ng_container_1_Template, 48, 62, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.busy);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.dstSettings);
        }
    }, dependencies: [i5.NgClass, i5.NgForOf, i5.NgIf, i1.DataSourceToolbarComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i1.DataTableGenericColumnComponent, i3.EuiAlertComponent, i3.EuiBadgeComponent, i6.NgControlStatus, i6.NgModel, i7.MatOption, i3$1.MatButton, i3$2.MatCard, i10.MatCheckbox, i11.MatFormField, i11.MatLabel, i11.MatPrefix, i12.MatProgressSpinner, i13.MatSelect, i14.MatTooltip, i1.SelectedElementsComponent, i2.TranslatePipe, i1.LdsReplacePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}[_nghost-%COMP%]     .mat-form-field-prefix .mat-spinner, [_nghost-%COMP%]     .mat-form-field-prefix .mat-spinner svg{max-height:16px;max-width:16px}[_nghost-%COMP%]     .mat-form-field-prefix .mat-spinner{margin-right:10px}.filters[_ngcontent-%COMP%]{display:flex;flex-flow:wrap;align-items:center;gap:1em;margin-bottom:16px}.filters[_ngcontent-%COMP%]   .namespace-selector[_ngcontent-%COMP%], .filters[_ngcontent-%COMP%]   .table-selector[_ngcontent-%COMP%]{min-width:400px}.scroll-container[_ngcontent-%COMP%]{flex:1 1 auto;overflow:auto;display:flex}.scroll-container[_ngcontent-%COMP%]   mat-spinner[_ngcontent-%COMP%]{margin:auto}.helper-alert[_ngcontent-%COMP%]{margin-bottom:1em;display:flex;flex-direction:column}.helper-alert[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block}.imx-button-bar[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;margin-top:10px}.imx-button-bar[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:not(:first-child){margin-left:5px}.imx-button-bar[_ngcontent-%COMP%]   .imx-menu-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.imx-button-bar[_ngcontent-%COMP%]   imx-selected-elements[_ngcontent-%COMP%]{margin-left:10px}.object-type[_ngcontent-%COMP%]{font-style:italic;font-size:smaller}.bulkmodecheckbox[_ngcontent-%COMP%]{margin-right:1em;line-height:36px}.imx-justify-start[_ngcontent-%COMP%]{align-self:flex-start;flex:1 1 auto}mat-spinner[_ngcontent-%COMP%]{margin:auto}.first-cell[_ngcontent-%COMP%]{display:flex;flex-direction:row}.first-col[_ngcontent-%COMP%]{flex-grow:1}.loadingtable[_ngcontent-%COMP%]{visibility:hidden}.selected-objects[_ngcontent-%COMP%]{font-size:14px;color:#2f3233}.selected-objects[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#aab0b3;font-weight:700;margin-left:3px}.eui-dark-theme   [_nghost-%COMP%]   .selected-objects[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#aab0b3}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OutstandingComponent, [{
            type: Component,
            args: [{ template: "<mat-spinner *ngIf=\"busy\"></mat-spinner>\r\n\r\n<ng-container *ngIf=\"dstSettings\">\r\n  <h2 class=\"mat-headline\">{{ '#LDS#Heading Outstanding Objects' | translate }}</h2>\r\n  <eui-alert *ngIf=\"showHelper\" class=\"helper-alert\" type=\"info\" condensed=\"true\" [colored]=\"true\" [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\r\n    {{ LdsOutstandingText | translate }}\r\n  </eui-alert>\r\n\r\n  <div class=\"filters\">\r\n    <mat-form-field class=\"namespace-selector\">\r\n      <mat-label>{{ '#LDS#Target system type' | translate }}</mat-label>\r\n      <mat-select required (selectionChange)=\"optionSelected($event.value)\" [(value)]=\"selectedNamespace\" data-imx-identifier=\"outstanding-namespace-select\">\r\n        <mat-option *ngFor=\"let pr of namespaces\" [value]=\"pr\" [attr.data-imx-identifier]=\"'outstanding-namespace-option-' + pr.GetEntity().GetDisplay()\">\r\n          {{ pr.GetEntity().GetDisplay() }}\r\n        </mat-option>\r\n      </mat-select>\r\n    </mat-form-field>\r\n\r\n    <mat-form-field class=\"table-selector\">\r\n      <mat-spinner *ngIf=\"loadingTableData\" matPrefix></mat-spinner>\r\n      <mat-label>{{ '#LDS#Object type' | translate }}</mat-label>\r\n      <mat-select [disabled]=\"tabledata.length == 0\" (selectionChange)=\"tableSelected($event.value)\" [(value)]=\"selectedTable\" data-imx-identifier=\"outstanding-table-select\">\r\n        <mat-option *ngFor=\"let pr of tabledata\" [value]=\"pr\" [attr.data-imx-identifier]=\"'outstanding-table-option-' + pr.GetEntity().GetDisplay()\">\r\n          {{ pr.GetEntity().GetDisplay() }} ({{ pr.CountOutstanding.value }})\r\n        </mat-option>\r\n      </mat-select>\r\n    </mat-form-field>\r\n    <mat-checkbox (change)=\"onShowAllData()\" [(ngModel)]=\"showAllData\" [disabled]=\"!selectedNamespace || loadingTableData\">\r\n      {{\r\n        !!selectedNamespaceTitle && !loadingTableData\r\n          ? ('#LDS#Show all outstanding objects of {0} ({1})' | translate | ldsReplace : selectedNamespaceTitle : tableDataCount)\r\n          : ('#LDS#Show all outstanding objects of the target system type' | translate)\r\n      }}\r\n    </mat-checkbox>\r\n  </div>\r\n\r\n  <imx-data-source-toolbar #dst [settings]=\"dstSettings\" (navigationStateChanged)=\"getData($event)\" [options]=\"['filter']\" [hidden]=\"busyLoadingTable\"> </imx-data-source-toolbar>\r\n\r\n  <mat-card class=\"scroll-container\">\r\n    <mat-spinner *ngIf=\"busyLoadingTable\"></mat-spinner>\r\n    <imx-data-table\r\n      #dataTable\r\n      [dst]=\"dst\"\r\n      [detailViewVisible]=\"false\"\r\n      [selectable]=\"true\"\r\n      [showSelectedItemsMenu]=\"false\"\r\n      [ngClass]=\"{ loadingtable: busyLoadingTable }\"\r\n      (selectionChanged)=\"selectionChanged($event)\"\r\n      mode=\"manual\"\r\n      [noDataText]=\"getNoDataText()\"\r\n      data-imx-identifier=\"outstanding-objects-table\"\r\n      *ngIf=\"!busyLoadingTable\"\r\n    >\r\n      <imx-data-table-generic-column columnName=\"Display\" columnLabel=\"{{ '#LDS#Display name' | translate }}\">\r\n        <ng-template let-data>\r\n          <div class=\"first-cell\">\r\n            <div class=\"first-col\">\r\n              {{ data.Display.value }}\r\n              <div class=\"object-type\">{{ data.ObjectType.value }}</div>\r\n            </div>\r\n            <eui-badge *ngIf=\"data.CanDeleteRestrictionReason.value\" [matTooltip]=\"data.CanDeleteRestrictionReason.value\">\r\n              {{ '#LDS#Cannot delete' | translate }}\r\n            </eui-badge>\r\n            <eui-badge *ngIf=\"data.CanPublishRestrictionReason.value\" [matTooltip]=\"data.CanPublishRestrictionReason.value\">\r\n              {{ '#LDS#Cannot add' | translate }}\r\n            </eui-badge>\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-generic-column>\r\n      <imx-data-table-column [entityColumn]=\"schema?.Columns.LastLogEntry\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"schema?.Columns.LastMethodRun\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n  </mat-card>\r\n  <div class=\"imx-button-bar\">\r\n    <imx-selected-elements [selectedElements]=\"selected\"></imx-selected-elements>\r\n    <div class=\"imx-menu-spacer\"></div>\r\n    <mat-checkbox\r\n      class=\"bulkmodecheckbox\"\r\n      matTooltip=\"{{\r\n        '#LDS#If you activate bulk processing, the selected objects are processed in parallel. This speeds up the performed action. If an error occurs during processing, the action is stopped and all changes are discarded. To locate errors, deactivate bulk processing. Thus, the objects are processed sequentially. All changes made until the error occurred are saved.'\r\n          | translate\r\n      }}\"\r\n      [(ngModel)]=\"bulk\"\r\n    >\r\n      {{ '#LDS#Bulk processing' | translate }}</mat-checkbox\r\n    >\r\n\r\n    <button\r\n      mat-raised-button\r\n      color=\"warn\"\r\n      [disabled]=\"selected.length === 0 || !canDeleteAllSelected()\"\r\n      data-imx-identifier=\"outstanding-delete-button\"\r\n      matTooltip=\"{{ '#LDS#Deletes the selected objects in the database' | translate }}\"\r\n      (click)=\"deleteObjects()\"\r\n    >\r\n      {{ '#LDS#Delete' | translate }}\r\n    </button>\r\n    <button\r\n      mat-raised-button\r\n      [disabled]=\"selected.length === 0\"\r\n      data-imx-identifier=\"outstanding-reset-button\"\r\n      matTooltip=\"{{ '#LDS#Removes the Outstanding label for the selected objects' | translate }}\"\r\n      (click)=\"resetObjects()\"\r\n    >\r\n      {{ '#LDS#Reset' | translate }}\r\n    </button>\r\n    <button\r\n      mat-raised-button\r\n      [disabled]=\"selected.length === 0 || !canPublishAllSelected()\"\r\n      color=\"primary\"\r\n      data-imx-identifier=\"outstanding-publish-button\"\r\n      matTooltip=\"{{ '#LDS#Adds the selected objects to the target system' | translate }}\"\r\n      (click)=\"publishObjects()\"\r\n    >\r\n      {{ '#LDS#Add to target system' | translate }}\r\n    </button>\r\n  </div>\r\n</ng-container>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;height:100%}:host ::ng-deep .mat-form-field-prefix .mat-spinner,:host ::ng-deep .mat-form-field-prefix .mat-spinner svg{max-height:16px;max-width:16px}:host ::ng-deep .mat-form-field-prefix .mat-spinner{margin-right:10px}.filters{display:flex;flex-flow:wrap;align-items:center;gap:1em;margin-bottom:16px}.filters .namespace-selector,.filters .table-selector{min-width:400px}.scroll-container{flex:1 1 auto;overflow:auto;display:flex}.scroll-container mat-spinner{margin:auto}.helper-alert{margin-bottom:1em;display:flex;flex-direction:column}.helper-alert span{display:block}.imx-button-bar{display:flex;justify-content:flex-end;margin-top:10px}.imx-button-bar>*:not(:first-child){margin-left:5px}.imx-button-bar .imx-menu-spacer{flex:1 1 auto}.imx-button-bar imx-selected-elements{margin-left:10px}.object-type{font-style:italic;font-size:smaller}.bulkmodecheckbox{margin-right:1em;line-height:36px}.imx-justify-start{align-self:flex-start;flex:1 1 auto}mat-spinner{margin:auto}.first-cell{display:flex;flex-direction:row}.first-col{flex-grow:1}.loadingtable{visibility:hidden}.selected-objects{font-size:14px;color:#2f3233}.selected-objects span{color:#aab0b3;font-weight:700;margin-left:3px}.eui-dark-theme :host .selected-objects span{color:#aab0b3}\n"] }]
        }], function () { return [{ type: OutstandingService }, { type: i2.TranslateService }, { type: i3.EuiSidesheetService }, { type: i1.ConfirmationService }, { type: i1.SnackBarService }, { type: i2.TranslateService }, { type: i3.EuiLoadingService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class OutstandingModule {
}
OutstandingModule.ɵfac = function OutstandingModule_Factory(t) { return new (t || OutstandingModule)(); };
OutstandingModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: OutstandingModule });
OutstandingModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        OutstandingService
    ], imports: [CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        FormsModule,
        EuiMaterialModule,
        MatProgressSpinnerModule,
        MatTooltipModule,
        TranslateModule,
        SelectedElementsModule,
        LdsReplaceModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OutstandingModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        EuiCoreModule,
                        FormsModule,
                        EuiMaterialModule,
                        MatProgressSpinnerModule,
                        MatTooltipModule,
                        TranslateModule,
                        SelectedElementsModule,
                        LdsReplaceModule,
                    ],
                    providers: [
                        OutstandingService
                    ],
                    declarations: [
                        OutstandingComponent,
                        DependenciesComponent,
                        SelectedItemsComponent
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(OutstandingModule, { declarations: [OutstandingComponent,
            DependenciesComponent,
            SelectedItemsComponent], imports: [CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            FormsModule,
            EuiMaterialModule,
            MatProgressSpinnerModule,
            MatTooltipModule,
            TranslateModule,
            SelectedElementsModule,
            LdsReplaceModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OutstandingComponent, OutstandingModule };
//# sourceMappingURL=dpr.mjs.map
