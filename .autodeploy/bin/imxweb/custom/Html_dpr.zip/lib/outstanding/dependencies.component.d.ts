import { EuiSidesheetRef } from '@elemental-ui/core';
import { DependencyToConfirm, OutstandingAction } from 'imx-api-dpr';
import * as i0 from "@angular/core";
export declare class DependenciesComponent {
    data: {
        dependencies: DependencyToConfirm[];
        action: OutstandingAction;
    };
    private sidesheetRef;
    constructor(data: {
        dependencies: DependencyToConfirm[];
        action: OutstandingAction;
    }, sidesheetRef: EuiSidesheetRef);
    save(): Promise<void>;
    isPublish(): boolean;
    isDelete(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DependenciesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DependenciesComponent, "ng-component", never, {}, {}, never, never, false>;
}
