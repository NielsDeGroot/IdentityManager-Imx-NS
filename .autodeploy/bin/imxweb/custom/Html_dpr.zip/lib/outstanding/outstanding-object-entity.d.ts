import { IReadValue, TypedEntity } from 'imx-qbm-dbts';
export declare class OutstandingObjectEntity extends TypedEntity {
    readonly ObjectType: IReadValue<string>;
    readonly ObjectKey: IReadValue<string>;
    readonly Display: IReadValue<string>;
    readonly CanPublish: IReadValue<boolean>;
    readonly CanDelete: IReadValue<boolean>;
    readonly CanDeleteRestrictionReason: IReadValue<string>;
    readonly CanPublishRestrictionReason: IReadValue<string>;
}
