import * as i0 from "@angular/core";
import * as i1 from "./outstanding.component";
import * as i2 from "./dependencies.component";
import * as i3 from "./selected-items/selected-items.component";
import * as i4 from "@angular/common";
import * as i5 from "qbm";
import * as i6 from "@elemental-ui/core";
import * as i7 from "@angular/forms";
import * as i8 from "@angular/material/progress-spinner";
import * as i9 from "@angular/material/tooltip";
import * as i10 from "@ngx-translate/core";
export declare class OutstandingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OutstandingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OutstandingModule, [typeof i1.OutstandingComponent, typeof i2.DependenciesComponent, typeof i3.SelectedItemsComponent], [typeof i4.CommonModule, typeof i5.DataSourceToolbarModule, typeof i5.DataTableModule, typeof i6.EuiCoreModule, typeof i7.FormsModule, typeof i6.EuiMaterialModule, typeof i8.MatProgressSpinnerModule, typeof i9.MatTooltipModule, typeof i10.TranslateModule, typeof i5.SelectedElementsModule, typeof i5.LdsReplaceModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OutstandingModule>;
}
