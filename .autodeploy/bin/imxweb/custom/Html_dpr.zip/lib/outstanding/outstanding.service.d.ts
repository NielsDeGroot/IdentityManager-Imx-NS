import { DependencyToConfirm, OpsupportNamespaces, OpsupportOutstandingTables, OutstandingAction, OutstandingObject } from 'imx-api-dpr';
import { ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { ApiService } from '../api.service';
import * as i0 from "@angular/core";
export declare class OutstandingService {
    private apiService;
    constructor(apiService: ApiService);
    getNamespaces(): Promise<ExtendedTypedEntityCollection<OpsupportNamespaces, unknown>>;
    getTableData(newNamespace: OpsupportNamespaces): Promise<ExtendedTypedEntityCollection<OpsupportOutstandingTables, unknown>>;
    getDependencies(action: OutstandingAction, values: string[]): Promise<DependencyToConfirm[]>;
    getOutstandingTable(tableName: string, namespace: string, actionfilter: string): Promise<OutstandingObject[]>;
    getOutstandingNamespace(namespace: string, actionfilter: string): Promise<OutstandingObject[]>;
    processObjects(action: OutstandingAction, bulk: boolean, objects: string[]): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OutstandingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OutstandingService>;
}
