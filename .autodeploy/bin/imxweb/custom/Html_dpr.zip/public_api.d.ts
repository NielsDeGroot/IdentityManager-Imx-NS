export { OutstandingModule } from './lib/outstanding/outstanding.module';
export { OutstandingComponent } from './lib/outstanding/outstanding.component';
