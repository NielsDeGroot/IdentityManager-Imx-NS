import * as i0 from '@angular/core';
import { Injectable, Component, Inject, Input, NgModule } from '@angular/core';
import * as i1$2 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i4 from 'qbm';
import { BaseCdr, DynamicDataSource, HELP_CONTEXTUAL, BusyService, HelpContextualComponent, CdrModule, DataSourceToolbarModule, DataTableModule, LdsReplaceModule, FkAdvancedPickerModule, SidenavTreeModule, DataTreeWrapperModule, HelpContextualModule, RouteGuardService } from 'qbm';
import { __awaiter } from 'tslib';
import * as i1 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiDownloadDirective, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i2 from '@angular/forms';
import { UntypedFormGroup, FormGroup, FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i3 from 'qer';
import * as i6$1 from 'imx-api-hds';
import { V2Client, TypedClient, V2ApiClientMethodFactory } from 'imx-api-hds';
import * as i6 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i5 from '@angular/material/button';
import * as i4$1 from '@angular/material/card';
import * as i9 from '@angular/material/tabs';
import * as i2$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MethodDefinition, ValType } from 'imx-qbm-dbts';
import * as i1$1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as i6$2 from '@angular/material/form-field';
import * as i7 from '@angular/material/input';
import * as i4$2 from '@angular/common/http';
import * as i5$1 from '@angular/cdk/overlay';
import * as i11 from '@angular/material/progress-spinner';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class HdsApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
HdsApiService.ɵfac = function HdsApiService_Factory(t) { return new (t || HdsApiService)(i0.ɵɵinject(i4.AppConfigService), i0.ɵɵinject(i4.ClassloggerService), i0.ɵɵinject(i4.ImxTranslationProviderService)); };
HdsApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: HdsApiService, factory: HdsApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(HdsApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i4.AppConfigService }, { type: i4.ClassloggerService }, { type: i4.ImxTranslationProviderService }]; }, null);
})();

function CallsHistorySidesheetComponent_imx_cdr_editor_5_Template(rf, ctx) {
    if (rf & 1) {
        const _r3 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 5);
        i0.ɵɵlistener("controlCreated", function CallsHistorySidesheetComponent_imx_cdr_editor_5_Template_imx_cdr_editor_controlCreated_0_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r3); const cdr_r1 = restoredCtx.$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.detailsFormGroup.addControl(cdr_r1.column.ColumnName, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r1 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r1);
    }
}
class CallsHistorySidesheetComponent {
    constructor(portalCallsHistory, euiLoadingService, formBuilder) {
        this.portalCallsHistory = portalCallsHistory;
        this.euiLoadingService = euiLoadingService;
        this.formBuilder = formBuilder;
        this.cdrList = [];
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.setup();
        });
    }
    setup() {
        return __awaiter(this, void 0, void 0, function* () {
            let entity = this.portalCallsHistory.GetEntity();
            let columnNames = yield this.getColumnNames();
            columnNames.forEach(columnName => {
                let column = entity.GetColumn(columnName);
                if (column)
                    this.cdrList.push(new BaseCdr(column));
            });
        });
    }
    getColumnNames() {
        return __awaiter(this, void 0, void 0, function* () {
            let columnNames = [];
            columnNames.push('UID_TroubleTicket');
            columnNames.push('TroubleHistoryDate');
            columnNames.push('ActionHotline');
            columnNames.push('ObjectKeyPerson');
            columnNames.push('UID_TroubleCallState');
            columnNames.push('ObjectKeySupporter');
            return columnNames;
        });
    }
}
CallsHistorySidesheetComponent.ɵfac = function CallsHistorySidesheetComponent_Factory(t) { return new (t || CallsHistorySidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.UntypedFormBuilder)); };
CallsHistorySidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsHistorySidesheetComponent, selectors: [["imx-calls-history-sidesheet"]], decls: 6, vars: 2, consts: [[1, "calls-history-sidesheet"], [1, "calls-history-sidesheet__tab-content"], [1, "calls-history-sidesheet__tab-content-body"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [3, "cdr", "controlCreated"]], template: function CallsHistorySidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "mat-card")(4, "form", 3);
            i0.ɵɵtemplate(5, CallsHistorySidesheetComponent_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 4);
            i0.ɵɵelementEnd()()()()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("formGroup", ctx.detailsFormGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
        }
    }, dependencies: [i6.NgForOf, i2.ɵNgNoValidate, i2.NgControlStatusGroup, i2.FormGroupDirective, i4$1.MatCard, i4.CdrEditorComponent], styles: [".calls-history-sidesheet[_ngcontent-%COMP%]{background-color:#f9fbfc;height:100%;display:flex;flex-direction:column;overflow:hidden}.calls-history-sidesheet__tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%}.calls-history-sidesheet__tab-content-body[_ngcontent-%COMP%]{flex:1;padding:32px;overflow:auto}.calls-history-sidesheet__tab-content-body.no-padding[_ngcontent-%COMP%]{padding:0}.calls-history-sidesheet__tab-content-body[_ngcontent-%COMP%]   .helper-alert[_ngcontent-%COMP%]{display:flex;margin-bottom:20px}.calls-history-sidesheet__tab-content-body[_ngcontent-%COMP%]   .helper-alert[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block}.calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;background-color:#fff;padding:16px 32px;margin:16px 32px}.calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}.calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}.calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:disabled:hover{cursor:not-allowed}.calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]   .help-icon[_ngcontent-%COMP%]{color:#0a96d1;font-size:16px;margin-left:5px;cursor:auto}.calls-history-sidesheet[_ngcontent-%COMP%]     .mat-tab-group{height:100%}.calls-history-sidesheet[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-header{padding:0 32px;background-color:#fff}.calls-history-sidesheet[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-body-wrapper{height:100%}@media screen and (max-width: 480px){.calls-history-sidesheet__tab-content[_ngcontent-%COMP%]{display:block}.calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]{flex-direction:column-reverse}.calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{width:100%;margin-bottom:10px;margin-right:0}.calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:0}}.eui-dark-theme   [_nghost-%COMP%]   .calls-history-sidesheet[_ngcontent-%COMP%]{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .calls-history-sidesheet[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]{background-color:#444647}.eui-contrast-theme   [_nghost-%COMP%]   .calls-history-sidesheet[_ngcontent-%COMP%]{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .calls-history-sidesheet[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#16191a}.eui-contrast-theme   [_nghost-%COMP%]   .calls-history-sidesheet__action-buttons[_ngcontent-%COMP%]{background-color:#2f3233}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsHistorySidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-calls-history-sidesheet', template: "<div class=\"calls-history-sidesheet\">\r\n  <div class=\"calls-history-sidesheet__tab-content\">\r\n    <div class=\"calls-history-sidesheet__tab-content-body\">\r\n      <mat-card>\r\n        <form [formGroup]=\"detailsFormGroup\">\r\n          <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"\r\n            (controlCreated)=\"detailsFormGroup.addControl(cdr.column.ColumnName, $event)\"></imx-cdr-editor>\r\n        </form>\r\n      </mat-card>\r\n    </div>\r\n  </div>\r\n</div>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.calls-history-sidesheet{background-color:#f9fbfc;height:100%;display:flex;flex-direction:column;overflow:hidden}.calls-history-sidesheet__tab-content{display:flex;flex-direction:column;height:100%}.calls-history-sidesheet__tab-content-body{flex:1;padding:32px;overflow:auto}.calls-history-sidesheet__tab-content-body.no-padding{padding:0}.calls-history-sidesheet__tab-content-body .helper-alert{display:flex;margin-bottom:20px}.calls-history-sidesheet__tab-content-body .helper-alert span{display:block}.calls-history-sidesheet__action-buttons{display:flex;justify-content:flex-end;background-color:#fff;padding:16px 32px;margin:16px 32px}.calls-history-sidesheet__action-buttons .justify-start{margin-right:auto}.calls-history-sidesheet__action-buttons button:not(:last-of-type):not(.justify-start){margin-right:10px}.calls-history-sidesheet__action-buttons button:disabled:hover{cursor:not-allowed}.calls-history-sidesheet__action-buttons .help-icon{color:#0a96d1;font-size:16px;margin-left:5px;cursor:auto}.calls-history-sidesheet ::ng-deep .mat-tab-group{height:100%}.calls-history-sidesheet ::ng-deep .mat-tab-group .mat-tab-header{padding:0 32px;background-color:#fff}.calls-history-sidesheet ::ng-deep .mat-tab-group .mat-tab-body-wrapper{height:100%}@media screen and (max-width: 480px){.calls-history-sidesheet__tab-content{display:block}.calls-history-sidesheet__action-buttons{flex-direction:column-reverse}.calls-history-sidesheet__action-buttons button{width:100%;margin-bottom:10px;margin-right:0}.calls-history-sidesheet__action-buttons .justify-start{margin-right:0}}.eui-dark-theme :host .calls-history-sidesheet{background-color:#2f3233}.eui-dark-theme :host .calls-history-sidesheet ::ng-deep .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-dark-theme :host .calls-history-sidesheet__action-buttons{background-color:#444647}.eui-contrast-theme :host .calls-history-sidesheet{background-color:#000}.eui-contrast-theme :host .calls-history-sidesheet ::ng-deep .mat-tab-group .mat-tab-header{background-color:#16191a}.eui-contrast-theme :host .calls-history-sidesheet__action-buttons{background-color:#2f3233}\n"] }]
        }], function () {
        return [{ type: i6$1.PortalCallsHistory, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i1.EuiLoadingService }, { type: i2.UntypedFormBuilder }];
    }, null);
})();

const _c0$2 = function () { return ["search", "filter"]; };
const _c1$2 = function () { return ["namespace"]; };
class CallsHistoryComponent {
    constructor(sidesheet, translate, errorHandler, hdsApiService, settingsService, euiLoadingService) {
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.errorHandler = errorHandler;
        this.hdsApiService = hdsApiService;
        this.settingsService = settingsService;
        this.euiLoadingService = euiLoadingService;
        this.displayedColumns = [];
        this.filterOptions = [];
        this.collectionLoadParameters = { PageSize: this.settingsService.DefaultPageSize, StartIndex: 0 };
        this.entitySchema = this.hdsApiService.typedClient.PortalCallsHistory.GetSchema();
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.displayedColumns = [
                this.entitySchema.Columns['UID_TroubleTicket'],
                this.entitySchema.Columns['TroubleHistoryDate'],
                this.entitySchema.Columns['ObjectKeyPerson'],
                this.entitySchema.Columns['UID_TroubleCallState'],
                this.entitySchema.Columns['ObjectKeySupporter'],
            ];
            yield this.loadHistory();
        });
    }
    loadHistory() {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef = this.euiLoadingService.show();
            try {
                if (((_c = (_b = (_a = this.ticket) === null || _a === void 0 ? void 0 : _a.EntityKeysData) === null || _b === void 0 ? void 0 : _b.Keys) === null || _c === void 0 ? void 0 : _c.length) > 0) {
                    let history = yield this.hdsApiService.typedClient.PortalCallsHistory.Get(this.ticket.EntityKeysData.Keys[0], this.collectionLoadParameters);
                    this.dstSettings = {
                        displayedColumns: this.displayedColumns,
                        dataSource: history,
                        entitySchema: this.entitySchema,
                        navigationState: this.collectionLoadParameters,
                        filters: this.filterOptions,
                    };
                }
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                this.euiLoadingService.hide(overlayRef);
            }
        });
    }
    onNavigationStateChanged(collectionLoadParameters) {
        return __awaiter(this, void 0, void 0, function* () {
            if (collectionLoadParameters)
                this.collectionLoadParameters = collectionLoadParameters;
            yield this.loadHistory();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.collectionLoadParameters.StartIndex = 0;
            this.collectionLoadParameters.search = keywords;
            yield this.loadHistory();
        });
    }
    onSelected(history) {
        return __awaiter(this, void 0, void 0, function* () {
            if (history) {
                let title = yield this.translate.get('#LDS#Heading View Change Details').toPromise();
                let sidesheetRef = this.sidesheet.open(CallsHistorySidesheetComponent, {
                    testId: 'calls-history-sidesheet',
                    title: title,
                    padding: '0px',
                    width: 'max(400px, 40%)',
                    data: history,
                });
            }
        });
    }
}
CallsHistoryComponent.ɵfac = function CallsHistoryComponent_Factory(t) { return new (t || CallsHistoryComponent)(i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2$1.TranslateService), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(HdsApiService), i0.ɵɵdirectiveInject(i4.SettingsService), i0.ɵɵdirectiveInject(i1.EuiLoadingService)); };
CallsHistoryComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsHistoryComponent, selectors: [["imx-calls-history"]], inputs: { ticket: "ticket" }, decls: 11, vars: 15, consts: [["type", "info", "condensed", "true", 1, "helper-alert", 3, "colored", "dismissable"], ["data-imx-identifier", "calls-history-data-source-toolbar", 3, "settings", "options", "hiddenFilters", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], [1, "calls-history-data-table"], ["data-imx-identifier", "calls-history-data-table", "detailViewVisible", "false", 3, "dst", "highlightedEntityChanged"], ["data-imx-identifier", "calls-history-data-source-paginator", 3, "dst"]], template: function CallsHistoryComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "eui-alert", 0)(1, "span");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(4, "mat-card")(5, "imx-data-source-toolbar", 1, 2);
            i0.ɵɵlistener("navigationStateChanged", function CallsHistoryComponent_Template_imx_data_source_toolbar_navigationStateChanged_5_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function CallsHistoryComponent_Template_imx_data_source_toolbar_search_5_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(8, "div", 3)(9, "imx-data-table", 4);
            i0.ɵɵlistener("highlightedEntityChanged", function CallsHistoryComponent_Template_imx_data_table_highlightedEntityChanged_9_listener($event) { return ctx.onSelected($event); });
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(10, "imx-data-source-paginator", 5);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(6);
            i0.ɵɵproperty("colored", true)("dismissable", true);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 9, "#LDS#Here you can get an overview of all changes to this ticket."), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(13, _c0$2))("hiddenFilters", i0.ɵɵpureFunction0(14, _c1$2))("searchBoxText", i0.ɵɵpipeBind1(7, 11, "#LDS#Search"));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i1.EuiAlertComponent, i4$1.MatCard, i4.DataSourceToolbarComponent, i4.DataSourcePaginatorComponent, i4.DataTableComponent, i2$1.TranslatePipe], styles: [".helper-alert[_ngcontent-%COMP%]{display:flex;margin-bottom:20px}.helper-alert[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsHistoryComponent, [{
            type: Component,
            args: [{ selector: 'imx-calls-history', template: "\r\n<eui-alert class=\"helper-alert\" type=\"info\" condensed=\"true\" [colored]=\"true\" [dismissable]=\"true\">\r\n  <span> {{ '#LDS#Here you can get an overview of all changes to this ticket.' | translate }} </span>\r\n</eui-alert>\r\n<mat-card>\r\n  <imx-data-source-toolbar #dst data-imx-identifier=\"calls-history-data-source-toolbar\" [settings]=\"dstSettings\"\r\n    [options]=\"['search', 'filter']\" [hiddenFilters]=\"['namespace']\" [searchBoxText]=\"'#LDS#Search' | translate\"\r\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\" (search)=\"onSearch($event)\">\r\n  </imx-data-source-toolbar>\r\n  <div class=\"calls-history-data-table\">\r\n    <imx-data-table data-imx-identifier=\"calls-history-data-table\" [dst]=\"dst\"\r\n      (highlightedEntityChanged)=\"onSelected($event)\" detailViewVisible=\"false\">\r\n    </imx-data-table>\r\n  </div>\r\n  <imx-data-source-paginator data-imx-identifier=\"calls-history-data-source-paginator\" [dst]=\"dst\">\r\n  </imx-data-source-paginator>\r\n</mat-card>", styles: [".helper-alert{display:flex;margin-bottom:20px}.helper-alert span{display:block}\n"] }]
        }], function () { return [{ type: i1.EuiSidesheetService }, { type: i2$1.TranslateService }, { type: i0.ErrorHandler }, { type: HdsApiService }, { type: i4.SettingsService }, { type: i1.EuiLoadingService }]; }, { ticket: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
var CallsAttachmentType;
(function (CallsAttachmentType) {
    CallsAttachmentType[CallsAttachmentType["folder"] = 0] = "folder";
    CallsAttachmentType[CallsAttachmentType["file"] = 1] = "file";
})(CallsAttachmentType || (CallsAttachmentType = {}));
var CallsAttachmentActionType;
(function (CallsAttachmentActionType) {
    CallsAttachmentActionType[CallsAttachmentActionType["addFolder"] = 0] = "addFolder";
    CallsAttachmentActionType[CallsAttachmentActionType["deleteFile"] = 1] = "deleteFile";
    CallsAttachmentActionType[CallsAttachmentActionType["deleteFolder"] = 2] = "deleteFolder";
})(CallsAttachmentActionType || (CallsAttachmentActionType = {}));

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function CallsAttachmentDialogComponent_ng_container_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0, 9);
        i0.ɵɵelementStart(1, "mat-form-field", 10)(2, "mat-label");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(5, "input", 11);
        i0.ɵɵelementStart(6, "mat-error");
        i0.ɵɵtext(7);
        i0.ɵɵpipe(8, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("formGroup", ctx_r0.form);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 3, "#LDS#Folder name"));
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 5, "#LDS#Enter a name for the folder."), " ");
    }
}
function CallsAttachmentDialogComponent_button_14_Template(rf, ctx) {
    if (rf & 1) {
        const _r4 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 12);
        i0.ɵɵlistener("click", function CallsAttachmentDialogComponent_button_14_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.closeDialog("confirm", ctx_r3.form.controls.folderName.value)); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵproperty("disabled", ctx_r1.form.invalid);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Create"), " ");
    }
}
function CallsAttachmentDialogComponent_button_15_Template(rf, ctx) {
    if (rf & 1) {
        const _r6 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 13);
        i0.ɵɵlistener("click", function CallsAttachmentDialogComponent_button_15_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.closeDialog("confirm")); });
        i0.ɵɵelement(1, "eui-icon", 14);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Yes"), " ");
    }
}
class CallsAttachmentDialogComponent {
    constructor(matDialogRef, data) {
        this.matDialogRef = matDialogRef;
        this.data = data;
        this.form = new FormGroup({
            folderName: new FormControl(null, [Validators.required])
        });
    }
    ngOnInit() { }
    closeDialog(action, value) {
        this.matDialogRef.close({ action, value });
    }
    get dialogTitle() {
        if (this.data.actionType === CallsAttachmentActionType.addFolder) {
            return '#LDS#Heading Create Folder';
        }
        if (this.data.actionType === CallsAttachmentActionType.deleteFile) {
            return '#LDS#Heading Delete File';
        }
        return '#LDS#Heading Delete Folder';
    }
    get dialogSubHeading() {
        switch (this.data.actionType) {
            case CallsAttachmentActionType.addFolder:
                return '#LDS#Create new folder under: {0}';
            case CallsAttachmentActionType.deleteFolder:
                return '#LDS#Are you sure you want to delete the folder "{0}"?';
            default:
                return '#LDS#Are you sure you want to delete the file "{0}"?';
        }
    }
    get isActionAddFolder() {
        return this.data.actionType === CallsAttachmentActionType.addFolder;
    }
}
CallsAttachmentDialogComponent.ɵfac = function CallsAttachmentDialogComponent_Factory(t) { return new (t || CallsAttachmentDialogComponent)(i0.ɵɵdirectiveInject(i1$1.MatDialogRef), i0.ɵɵdirectiveInject(MAT_DIALOG_DATA)); };
CallsAttachmentDialogComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsAttachmentDialogComponent, selectors: [["imx-calls-attachment-dialog"]], decls: 16, vars: 15, consts: [[1, "dialog-container"], ["mat-dialog-title", "", 1, "dialog-title"], [1, "dialog-content"], [1, "dialog-subheading"], [3, "formGroup", 4, "ngIf"], [1, "dialog-actions"], ["mat-stroked-button", "", 3, "click"], ["mat-flat-button", "", "color", "primary", 3, "disabled", "click", 4, "ngIf"], ["mat-flat-button", "", "color", "warn", 3, "click", 4, "ngIf"], [3, "formGroup"], ["appearance", "fill"], ["matInput", "", "formControlName", "folderName"], ["mat-flat-button", "", "color", "primary", 3, "disabled", "click"], ["mat-flat-button", "", "color", "warn", 3, "click"], ["icon", "close", "size", "small"]], template: function CallsAttachmentDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1);
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-dialog-content", 2)(5, "div", 3);
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "ldsReplace");
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(9, CallsAttachmentDialogComponent_ng_container_9_Template, 9, 7, "ng-container", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "mat-dialog-actions", 5)(11, "button", 6);
            i0.ɵɵlistener("click", function CallsAttachmentDialogComponent_Template_button_click_11_listener() { return ctx.closeDialog(); });
            i0.ɵɵtext(12);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(14, CallsAttachmentDialogComponent_button_14_Template, 3, 4, "button", 7);
            i0.ɵɵtemplate(15, CallsAttachmentDialogComponent_button_15_Template, 4, 3, "button", 8);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 6, ctx.dialogTitle));
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind2(7, 8, i0.ɵɵpipeBind1(8, 11, ctx.dialogSubHeading), ctx.data.itemInfo));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.isActionAddFolder);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(13, 13, "#LDS#Cancel"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.isActionAddFolder);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.isActionAddFolder);
        }
    }, dependencies: [i6.NgIf, i2.DefaultValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.FormGroupDirective, i2.FormControlName, i1.EuiIconComponent, i5.MatButton, i1$1.MatDialogTitle, i1$1.MatDialogContent, i1$1.MatDialogActions, i6$2.MatError, i6$2.MatFormField, i6$2.MatLabel, i7.MatInput, i2$1.TranslatePipe, i4.LdsReplacePipe], styles: ["[_nghost-%COMP%]     .mat-dialog-content{margin:0 -30px;padding:0 16px;width:320px}[_nghost-%COMP%]     .mat-dialog-content .mat-form-field{width:100%}[_nghost-%COMP%]     .mat-dialog-content .dialog-subheading{font-size:14px;padding-bottom:10px}[_nghost-%COMP%]     .mat-dialog-title{margin:-30px -30px 0;padding:16px}[_nghost-%COMP%]     .mat-dialog-actions{margin:0 -30px -30px;padding:0 16px 16px;justify-content:end;min-height:auto}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsAttachmentDialogComponent, [{
            type: Component,
            args: [{ selector: 'imx-calls-attachment-dialog', template: "<div class=\"dialog-container\">\r\n  <h2 mat-dialog-title class=\"dialog-title\">{{ dialogTitle | translate }}</h2>\r\n  <mat-dialog-content class=\"dialog-content\">\r\n    <div class=\"dialog-subheading\">{{ dialogSubHeading | translate | ldsReplace: data.itemInfo }}</div>\r\n    <ng-container [formGroup]=\"form\" *ngIf=\"isActionAddFolder\">\r\n      <mat-form-field appearance=\"fill\" >\r\n        <mat-label>{{ \"#LDS#Folder name\" | translate }}</mat-label>\r\n        <input matInput formControlName=\"folderName\"/>\r\n        <mat-error>\r\n          {{ '#LDS#Enter a name for the folder.' | translate }}\r\n        </mat-error>\r\n      </mat-form-field>\r\n    </ng-container>\r\n  </mat-dialog-content>\r\n\r\n  <mat-dialog-actions class=\"dialog-actions\">\r\n    <button mat-stroked-button (click)=\"closeDialog()\">\r\n      {{ '#LDS#Cancel' | translate }}\r\n    </button>\r\n    <button mat-flat-button color=\"primary\" (click)=\"closeDialog('confirm', form.controls.folderName.value)\" [disabled]=\"form.invalid\" *ngIf=\"isActionAddFolder\">\r\n      {{ '#LDS#Create' | translate }}\r\n    </button>\r\n    <button mat-flat-button color=\"warn\" (click)=\"closeDialog('confirm')\" *ngIf=\"!isActionAddFolder\">\r\n      <eui-icon icon=\"close\" size=\"small\"></eui-icon>\r\n      {{ '#LDS#Yes' | translate }}\r\n    </button>\r\n  </mat-dialog-actions>\r\n</div>\r\n", styles: [":host ::ng-deep .mat-dialog-content{margin:0 -30px;padding:0 16px;width:320px}:host ::ng-deep .mat-dialog-content .mat-form-field{width:100%}:host ::ng-deep .mat-dialog-content .dialog-subheading{font-size:14px;padding-bottom:10px}:host ::ng-deep .mat-dialog-title{margin:-30px -30px 0;padding:16px}:host ::ng-deep .mat-dialog-actions{margin:0 -30px -30px;padding:0 16px 16px;justify-content:end;min-height:auto}\n"] }]
        }], function () {
        return [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [MAT_DIALOG_DATA]
                    }] }];
    }, null);
})();

class CallsAttachmentServiceService {
    constructor(hdsApiService, errorHandler, translator) {
        this.hdsApiService = hdsApiService;
        this.errorHandler = errorHandler;
        this.translator = translator;
    }
    getInitialData(callId) {
        return __awaiter(this, void 0, void 0, function* () {
            let initalFormatData = {
                name: 'Attachments',
                path: '',
                level: 0,
                isSelected: false,
                type: CallsAttachmentType.folder,
            };
            let initialData = yield this.hdsApiService.client.portal_calls_attachments_directory_get(callId);
            initalFormatData.children = this.formatData(initialData, 1, initalFormatData);
            return initalFormatData;
        });
    }
    getFilesOfDirectory(callId, parent) {
        return __awaiter(this, void 0, void 0, function* () {
            let data = yield this.hdsApiService.client.portal_calls_attachments_directory_bypath_get(callId, parent.path);
            let formatData = this.formatData(data, parent.level + 1, parent);
            return formatData;
        });
    }
    getCallsConfig() {
        return this.hdsApiService.client.portal_calls_configuration_get();
    }
    createDirectory(callId, path) {
        return this.hdsApiService.client.portal_calls_attachments_directory_bypath_post(callId, path);
    }
    deleteDirectory(callId, path) {
        return this.hdsApiService.client.portal_calls_attachments_directory_bypath_delete(callId, path);
    }
    deleteFile(callId, path) {
        return this.hdsApiService.client.portal_calls_attachments_file_delete(callId, path);
    }
    uploadFile(callId, path, file) {
        return this.hdsApiService.client.portal_calls_attachments_file_post(callId, path, file);
    }
    formatData(obj, level, parent) {
        let formattedData = [];
        obj.Directories.map((item) => {
            formattedData.push({
                name: item.Name,
                children: [],
                type: CallsAttachmentType.folder,
                path: !!parent && !!parent.path ? `${parent.path}/${item.Name}` : item.Name,
                level: level,
                isSelected: false,
                parent: parent,
            });
        });
        obj.Files.map((item) => {
            formattedData.push({
                name: item.Name,
                type: CallsAttachmentType.file,
                path: !!parent && !!parent.path ? `${parent.path}/${item.Name}` : item.Name,
                level: level,
                isSelected: false,
                parent: parent,
            });
        });
        return formattedData;
    }
}
CallsAttachmentServiceService.ɵfac = function CallsAttachmentServiceService_Factory(t) { return new (t || CallsAttachmentServiceService)(i0.ɵɵinject(HdsApiService), i0.ɵɵinject(i0.ErrorHandler), i0.ɵɵinject(i2$1.TranslateService)); };
CallsAttachmentServiceService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: CallsAttachmentServiceService, factory: CallsAttachmentServiceService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsAttachmentServiceService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: HdsApiService }, { type: i0.ErrorHandler }, { type: i2$1.TranslateService }]; }, null);
})();

function CallsAttachmentComponent_div_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 8);
        i0.ɵɵelement(1, "mat-spinner");
        i0.ɵɵelementEnd();
    }
}
function CallsAttachmentComponent_eui_alert_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r7 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-alert", 9);
        i0.ɵɵlistener("dismissed", function CallsAttachmentComponent_eui_alert_2_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r6 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r6.onAlertDismissed()); });
        i0.ɵɵelementStart(1, "span");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵproperty("dismissable", true);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, ctx_r1.alertText));
    }
}
function CallsAttachmentComponent_div_4_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r16 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "button", 14);
        i0.ɵɵlistener("click", function CallsAttachmentComponent_div_4_ng_container_1_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r16); const ctx_r15 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r15.onAddFolder(ctx_r15.selectedNode)); });
        i0.ɵɵelement(2, "eui-icon", 15);
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "button", 14);
        i0.ɵɵlistener("click", function CallsAttachmentComponent_div_4_ng_container_1_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r16); const _r14 = i0.ɵɵreference(10); return i0.ɵɵresetView(_r14.click()); });
        i0.ɵɵelement(6, "eui-icon", 16);
        i0.ɵɵtext(7);
        i0.ɵɵpipe(8, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(9, "input", 17, 18);
        i0.ɵɵlistener("change", function CallsAttachmentComponent_div_4_ng_container_1_Template_input_change_9_listener($event) { i0.ɵɵrestoreView(_r16); const ctx_r18 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r18.attachFile($event.target.files)); });
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r8 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 3, "#LDS#Create folder"));
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 5, "#LDS#Attach file"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", !ctx_r8.isNodeTypeFolder(ctx_r8.selectedNode));
    }
}
function CallsAttachmentComponent_div_4_ng_template_2_button_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r21 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 14);
        i0.ɵɵlistener("click", function CallsAttachmentComponent_div_4_ng_template_2_button_4_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r21); const ctx_r20 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r20.downloadFile(ctx_r20.selectedNode)); });
        i0.ɵɵelement(1, "eui-icon", 22);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, "#LDS#Download selected file"));
    }
}
function CallsAttachmentComponent_div_4_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "button", 19);
        i0.ɵɵelement(1, "eui-icon", 20);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(4, CallsAttachmentComponent_div_4_ng_template_2_button_4_Template, 4, 3, "button", 21);
    }
    if (rf & 2) {
        const ctx_r10 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("disabled", true);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 3, "#LDS#Create folder"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r10.selectedNode);
    }
}
function CallsAttachmentComponent_div_4_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r23 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "button", 23);
        i0.ɵɵlistener("click", function CallsAttachmentComponent_div_4_ng_container_4_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r23); const ctx_r22 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r22.onDeleteItem(ctx_r22.selectedNode)); });
        i0.ɵɵelement(2, "eui-icon", 24);
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 1, "#LDS#Delete selected item"));
    }
}
function CallsAttachmentComponent_div_4_ng_template_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "button", 25);
        i0.ɵɵelement(1, "eui-icon", 26);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵproperty("disabled", true);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Delete selected item"));
    }
}
function CallsAttachmentComponent_div_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 10);
        i0.ɵɵtemplate(1, CallsAttachmentComponent_div_4_ng_container_1_Template, 11, 7, "ng-container", 11);
        i0.ɵɵtemplate(2, CallsAttachmentComponent_div_4_ng_template_2_Template, 5, 5, "ng-template", null, 12, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵtemplate(4, CallsAttachmentComponent_div_4_ng_container_4_Template, 5, 3, "ng-container", 11);
        i0.ɵɵtemplate(5, CallsAttachmentComponent_div_4_ng_template_5_Template, 4, 4, "ng-template", null, 13, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const _r9 = i0.ɵɵreference(3);
        const _r12 = i0.ɵɵreference(6);
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r2.isNodeTypeFolder(ctx_r2.selectedNode))("ngIfElse", _r9);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", ctx_r2.isNodeDeletable(ctx_r2.selectedNode))("ngIfElse", _r12);
    }
}
const _c0$1 = function (a0) { return { "imx-tree-root--selected": a0 }; };
function CallsAttachmentComponent_ng_template_7_div_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 28)(1, "span");
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r28 = i0.ɵɵnextContext();
        const selected_r25 = ctx_r28.selected;
        const node_r24 = ctx_r28.$implicit;
        i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(2, _c0$1, selected_r25));
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(node_r24.name);
    }
}
function CallsAttachmentComponent_ng_template_7_div_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 28);
        i0.ɵɵelement(1, "eui-icon", 15);
        i0.ɵɵelementStart(2, "span");
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r29 = i0.ɵɵnextContext();
        const selected_r25 = ctx_r29.selected;
        const node_r24 = ctx_r29.$implicit;
        i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(2, _c0$1, selected_r25));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(node_r24.name);
    }
}
function CallsAttachmentComponent_ng_template_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, CallsAttachmentComponent_ng_template_7_div_0_Template, 3, 4, "div", 27);
        i0.ɵɵtemplate(1, CallsAttachmentComponent_ng_template_7_div_1_Template, 4, 4, "div", 27);
    }
    if (rf & 2) {
        const node_r24 = ctx.$implicit;
        const ctx_r4 = i0.ɵɵnextContext();
        i0.ɵɵproperty("ngIf", !ctx_r4.isNodeTypeFolder(node_r24));
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r4.isNodeTypeFolder(node_r24));
    }
}
function CallsAttachmentComponent_div_9_div_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 34)(1, "ul")(2, "li");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "li");
        i0.ɵɵtext(6);
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(8, "li");
        i0.ɵɵtext(9);
        i0.ɵɵpipe(10, "translate");
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        const ctx_r30 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 4, "#LDS#Here you can attach files to this ticket."));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(7, 6, "#LDS#Optionally, you can create folders and add files to these folders."));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate2("", i0.ɵɵpipeBind1(10, 8, "#LDS#The maximum file size is:"), " ", ctx_r30.convertedMaxAttachmentSize, "");
    }
}
function CallsAttachmentComponent_div_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 29)(1, "div", 30);
        i0.ɵɵelement(2, "eui-icon", 31);
        i0.ɵɵelementStart(3, "div")(4, "h2", 32);
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()()();
        i0.ɵɵtemplate(7, CallsAttachmentComponent_div_9_div_7_Template, 11, 10, "div", 33);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext();
        i0.ɵɵadvance(5);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 2, "#LDS#Upload file attachments"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r5.hasMaxAttachmentSize);
    }
}
const _c1$1 = function (a0) { return { "calls-attachment__attachments-tree--hidden": a0 }; };
class CallsAttachmentComponent {
    constructor(attachmentService, dialog, config, 
    // File download directive needs HttpClient, Injector, Overlay, ElementalUiConfigService
    http, injector, overlay, elementalUiConfigService, translator, errorHandler, ldsReplace) {
        this.attachmentService = attachmentService;
        this.dialog = dialog;
        this.config = config;
        this.http = http;
        this.injector = injector;
        this.overlay = overlay;
        this.elementalUiConfigService = elementalUiConfigService;
        this.translator = translator;
        this.errorHandler = errorHandler;
        this.ldsReplace = ldsReplace;
        this.callId = '';
        // Set FlatTreeControl node order and node expendable
        this.treeControl = new FlatTreeControl((node) => node.level, (node) => node.type === CallsAttachmentType.folder);
        this.attachmentTreeData = null;
        this.selectedNode = null;
        this.showAlert = false;
        this.alertText = '';
        this.loadingOverlay = false;
        this.noResultText = '#LDS#There are no attachments.';
    }
    // Setup apiControls and dynamicDataSource and get initial attachment tree data
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.apiControls = {
                setup: () => __awaiter(this, void 0, void 0, function* () {
                    try {
                        const rootNode = yield this.attachmentService.getInitialData(this.callId);
                        this.attachmentTreeData = rootNode;
                        this.initialized = true;
                        return { rootNode };
                    }
                    catch (_a) {
                        this.initialized = false;
                        throw new Error(this.translator.instant('#LDS#The attachments folder could not be found.'));
                    }
                }),
                getChildren: (node, onlyCheck = true) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        if (node.children && (node.children.length > 0) && onlyCheck) {
                            return node.children;
                        }
                        node.isLoading = true;
                        node.children = yield this.attachmentService.getFilesOfDirectory(this.callId, node);
                    }
                    finally {
                        node.isLoading = false;
                    }
                    return node.children;
                }),
                changeSelection: (data) => data,
            };
            this.dynamicDataSource = new DynamicDataSource(this.treeControl, this.apiControls);
            this.callsConfig = yield this.attachmentService.getCallsConfig();
            this.hasMaxAttachmentSize = this.callsConfig.AttachmentMaxSize > 0;
            if (this.hasMaxAttachmentSize)
                this.convertedMaxAttachmentSize = yield this.byteConverter(this.callsConfig.AttachmentMaxSize);
            try {
                this.changeLoadingOverlayStatus(true);
                yield this.dynamicDataSource.setup(true);
            }
            finally {
                this.changeLoadingOverlayStatus(false);
            }
        });
    }
    // Open attachment dialog and call createFolder action
    onAddFolder(node) {
        return __awaiter(this, void 0, void 0, function* () {
            this.dialog
                .open(CallsAttachmentDialogComponent, {
                data: {
                    actionType: CallsAttachmentActionType.addFolder,
                    itemInfo: node && (node === null || node === void 0 ? void 0 : node.path.length) ? node.path : yield this.translator.get('#LDS#Root folder').toPromise(),
                },
            })
                .afterClosed()
                .subscribe((dialogResult) => {
                if (!!dialogResult && !!dialogResult.action && !!dialogResult.value) {
                    this.createFolder(dialogResult.value, node);
                }
            });
        });
    }
    onDeleteItem(node) {
        if (node.type === CallsAttachmentType.file) {
            this.openDeleteFileDialog(node);
        }
        else {
            this.openDeleteFolderDialog(node);
        }
    }
    // Open attachment dialog and call deleteFile action
    openDeleteFileDialog(node) {
        this.dialog
            .open(CallsAttachmentDialogComponent, {
            data: {
                actionType: CallsAttachmentActionType.deleteFile,
                itemInfo: node.name,
            },
        })
            .afterClosed()
            .subscribe((dialogResult) => {
            if (!!(dialogResult === null || dialogResult === void 0 ? void 0 : dialogResult.action)) {
                this.deleteFile(node);
            }
        });
    }
    /**
     * Check the selected folder has any child elements.
     * If it is empty open confirmation dialog and call deleteFolder action
     * @param node Selected node
     */
    openDeleteFolderDialog(node) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!node.children || node.children.length == 0) {
                const children = yield this.attachmentService.getFilesOfDirectory(this.callId, node);
                if (children.length > 0) {
                    this.errorHandler.handleError(this.translator.instant('#LDS#You cannot delete the folder. The folder is not empty. First delete the contents of the folder and try again.'));
                    return;
                }
            }
            this.dialog
                .open(CallsAttachmentDialogComponent, {
                data: {
                    actionType: CallsAttachmentActionType.deleteFolder,
                    itemInfo: node.name,
                },
            })
                .afterClosed()
                .subscribe((dialogResult) => {
                if (!!(dialogResult === null || dialogResult === void 0 ? void 0 : dialogResult.action)) {
                    this.deleteFolder(node);
                }
            });
        });
    }
    // Attaching a file inside a folder or at parent level
    attachFile(val) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            if (!val) {
                return;
            }
            this.changeLoadingOverlayStatus(true);
            const fileToUpload = val[0];
            const fileExtension = fileToUpload === null || fileToUpload === void 0 ? void 0 : fileToUpload.name.split('.').pop();
            try {
                if (fileToUpload && this.callsConfig.AttachmentFileTypes.includes(`.${fileExtension}`)) {
                    const obj = { name: fileToUpload === null || fileToUpload === void 0 ? void 0 : fileToUpload.name, type: CallsAttachmentType.file, path: '', file: fileToUpload };
                    const blob = new Blob([fileToUpload], { type: fileToUpload.type });
                    if (this.hasMaxAttachmentSize && fileToUpload.size > ((_a = this.callsConfig) === null || _a === void 0 ? void 0 : _a.AttachmentMaxSize)) {
                        throw new Error(this.ldsReplace.transform(yield this.translator.get('#LDS#You cannot upload the file. The file is too big. You can upload files up to {0}.').toPromise(), this.convertedMaxAttachmentSize));
                    }
                    //when attaching inside a parent
                    if (this.selectedNode) {
                        obj.path = this.selectedNode.path + '/' + fileToUpload.name;
                        fileToUpload && this.uploadFile(obj.path, blob, this.selectedNode);
                        //when attaching it at root level
                    }
                    else {
                        obj.path = fileToUpload.name;
                        fileToUpload && this.uploadFile(obj.path, blob, this.attachmentTreeData);
                    }
                }
                else {
                    throw new Error(this.ldsReplace.transform(yield this.translator.get('#LDS#You cannot upload the file. The maximum number of files has been reached. You can attach a total of {0} files.').toPromise(), this.callsConfig.AttachmentFileTypes.join(", ")));
                }
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                this.changeLoadingOverlayStatus(false);
            }
        });
    }
    // Setup download directive and download file
    downloadFile(node) {
        return __awaiter(this, void 0, void 0, function* () {
            const def = new MethodDefinition(new V2ApiClientMethodFactory().portal_calls_attachments_file_get(this.callId, node.path));
            const directive = new EuiDownloadDirective(null /* no element */, this.http, this.overlay, this.injector);
            directive.downloadOptions = Object.assign(Object.assign({}, this.elementalUiConfigService.Config.downloadOptions), { fileMimeType: '', url: this.config.BaseUrl + def.path, disableElement: false, fileName: node.name });
            directive.onClick();
        });
    }
    onNodeSelection(node) {
        this.attachmentTreeData.isSelected = false;
        this.updateSelectionState(this.attachmentTreeData.children);
        if (this.selectedNode == node) {
            this.selectedNode = null;
        }
        else {
            this.selectedNode = node;
            node.isSelected = !node.isSelected;
        }
    }
    updateSelectionState(data) {
        data.forEach((element) => {
            element.isSelected = false;
            if (element.children)
                this.updateSelectionState(element.children);
        });
    }
    isDuplicateName(name, node) {
        let element = node.find((element) => name == element.name);
        let elementFound = element ? true : false;
        return elementFound;
    }
    hasChild(_, node) {
        return node.children;
    }
    onAlertDismissed() {
        this.showAlert = false;
        this.alertText = '';
    }
    // Attach file is only available in folder node
    isNodeTypeFolder(node) {
        return (node === null || node === void 0 ? void 0 : node.type) === CallsAttachmentType.folder || !node;
    }
    // If isLoading return true the progressbar next to the node will shown
    isLoading(node) {
        return node.isLoading;
    }
    // Only empty folders and files can be deleted
    isNodeDeletable(node) {
        return this.isNodeFolderEmpty(node) || this.isNodeFile(node);
    }
    // Show information instead of attachment file tree
    get showInformation() {
        var _a;
        return ((_a = this.attachmentTreeData) === null || _a === void 0 ? void 0 : _a.children.length) === 0;
    }
    uploadFile(path, blob, node) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.attachmentService.uploadFile(this.callId, path, blob);
                yield this.apiControls.getChildren(node, false);
                this.expandNode(node);
            }
            catch (_a) {
                this.errorHandler.handleError(this.translator.instant('#LDS#You cannot upload the file. You do not have permission to upload files.'));
            }
        });
    }
    byteConverter(byte) {
        return __awaiter(this, void 0, void 0, function* () {
            if (byte >= 1073741824)
                return this.ldsReplace.transform(yield this.translator.get('#LDS#{0} GB').toPromise(), this.getFlooredFixed(byte / Math.pow(1024, 3)));
            else if (byte >= 1048576)
                return this.ldsReplace.transform(yield this.translator.get('#LDS#{0} MB').toPromise(), this.getFlooredFixed(byte / Math.pow(1024, 2)));
            else if (byte >= 1024)
                return this.ldsReplace.transform(yield this.translator.get('#LDS#{0} kB').toPromise(), this.getFlooredFixed(byte / Math.pow(1024, 1)));
            else
                return this.ldsReplace.transform(yield this.translator.get('#LDS#{0} byte').toPromise(), byte);
        });
    }
    getFlooredFixed(value, fractionDigits = 2) {
        return (Math.floor(value * Math.pow(10, fractionDigits)) / Math.pow(10, fractionDigits)).toFixed(fractionDigits);
    }
    isNodeFolderEmpty(node) {
        return !!node && node.type === CallsAttachmentType.folder && (!node.children || node.children.length === 0);
    }
    isNodeFile(node) {
        return !!node && node.type === CallsAttachmentType.file;
    }
    deleteFolder(node) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.changeLoadingOverlayStatus(true);
                const parent = node.parent;
                yield this.attachmentService.deleteDirectory(this.callId, node.path);
                if (parent) {
                    yield this.apiControls.getChildren(parent, false);
                    this.expandNode(parent);
                }
                else {
                    this.attachmentTreeData.children = this.attachmentTreeData.children.filter((childNode) => childNode.name !== node.name);
                    this.expandNode(this.attachmentTreeData);
                }
            }
            catch (_a) {
                this.errorHandler.handleError(this.translator.instant('#LDS#You cannot delete the folder. You do not have permission to delete folders.'));
            }
            finally {
                this.changeLoadingOverlayStatus(false);
                this.selectedNode = null;
            }
        });
    }
    deleteFile(node) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.changeLoadingOverlayStatus(true);
                yield this.attachmentService.deleteFile(this.callId, node.path);
                if (node.parent) {
                    yield this.apiControls.getChildren(node.parent, false);
                    this.expandNode(node.parent);
                }
                this.selectedNode = null;
            }
            catch (_a) {
                this.errorHandler.handleError(this.translator.instant('#LDS#You cannot delete the attachment. You do not have permission to delete attachments.'));
            }
            finally {
                this.changeLoadingOverlayStatus(false);
            }
        });
    }
    createFolder(val, node) {
        return __awaiter(this, void 0, void 0, function* () {
            if (val) {
                let obj = {
                    name: val,
                    children: [],
                    type: CallsAttachmentType.folder,
                    path: '',
                    level: 1,
                    isSelected: false,
                    parent: node,
                };
                if (node) {
                    if (this.isDuplicateName(val, node.children)) {
                        this.showAlertMessage('#LDS#You cannot create the folder. A folder with the entered name already exists. Enter a different folder name.');
                    }
                    else {
                        obj.path = node.path + '/' + val;
                        obj.level = node.level + 1;
                        yield this.apiControls.getChildren(node);
                        yield this.attachmentService.createDirectory(this.callId, obj.path);
                        node.children.unshift(obj);
                        this.expandNode(node);
                    }
                }
                else {
                    if (this.isDuplicateName(val, this.attachmentTreeData.children)) {
                        this.showAlertMessage('#LDS#You cannot create the folder. A folder with the entered name already exists. Enter a different folder name.');
                    }
                    else {
                        obj.path = `${val}`;
                        yield this.attachmentService.createDirectory(this.callId, obj.path);
                        this.attachmentTreeData.children.unshift(obj);
                        this.expandNode(this.attachmentTreeData);
                    }
                }
            }
        });
    }
    expandNode(node) {
        this.treeControl.collapse(node);
        this.treeControl.expand(node);
    }
    showAlertMessage(error) {
        this.alertText = error;
        this.showAlert = true;
    }
    changeLoadingOverlayStatus(status) {
        this.loadingOverlay = status;
    }
}
CallsAttachmentComponent.ɵfac = function CallsAttachmentComponent_Factory(t) { return new (t || CallsAttachmentComponent)(i0.ɵɵdirectiveInject(CallsAttachmentServiceService), i0.ɵɵdirectiveInject(i1$1.MatDialog), i0.ɵɵdirectiveInject(i4.AppConfigService), i0.ɵɵdirectiveInject(i4$2.HttpClient), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i5$1.Overlay), i0.ɵɵdirectiveInject(i4.ElementalUiConfigService), i0.ɵɵdirectiveInject(i2$1.TranslateService), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i4.LdsReplacePipe)); };
CallsAttachmentComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsAttachmentComponent, selectors: [["imx-calls-attachment"]], inputs: { callId: "callId" }, decls: 10, vars: 17, consts: [[1, "calls-attachment"], ["class", "loading-overlay", 4, "ngIf"], ["type", "warning", "colored", "true", 3, "dismissable", "dismissed", 4, "ngIf"], ["class", "calls-attachment__new-folder", 4, "ngIf"], [1, "calls-attachment__attachments-tree", 3, "ngClass"], [3, "dynamicDataSource", "treeControl", "nodeContent", "hasChild", "isLoading", "expandWidth", "sideNavExpanded", "manageExpandedExternally", "showSidenavHeader", "noResultText", "selectedNode"], ["nodeContent", ""], ["class", "calls-attachment__information", 4, "ngIf"], [1, "loading-overlay"], ["type", "warning", "colored", "true", 3, "dismissable", "dismissed"], [1, "calls-attachment__new-folder"], [4, "ngIf", "ngIfElse"], ["fileNode", ""], ["deleteDisabled", ""], ["mat-button", "", "color", "primary", 3, "click"], ["icon", "folder"], ["icon", "add", "for", "root-file"], ["type", "file", "id", "root-file", 3, "disabled", "change"], ["fileInput", ""], ["mat-button", "", "color", "primary", 3, "disabled"], ["icon", "folder", 1, "eui-icon--disabled"], ["mat-button", "", "color", "primary", 3, "click", 4, "ngIf"], ["icon", "download"], ["mat-button", "", "color", "warn", 1, "deleteIcon", 3, "click"], ["icon", "delete"], ["mat-button", "", "color", "warn", 1, "deleteIcon", 3, "disabled"], ["icon", "delete", 1, "eui-icon--disabled"], ["class", "imx-tree-root", 3, "ngClass", 4, "ngIf"], [1, "imx-tree-root", 3, "ngClass"], [1, "calls-attachment__information"], [1, "static-text"], ["icon", "upload", "size", "xl"], [1, "strong"], ["class", "file-size", 4, "ngIf"], [1, "file-size"]], template: function CallsAttachmentComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, CallsAttachmentComponent_div_1_Template, 2, 0, "div", 1);
            i0.ɵɵtemplate(2, CallsAttachmentComponent_eui_alert_2_Template, 4, 4, "eui-alert", 2);
            i0.ɵɵelementStart(3, "mat-card");
            i0.ɵɵtemplate(4, CallsAttachmentComponent_div_4_Template, 7, 4, "div", 3);
            i0.ɵɵelementStart(5, "div", 4)(6, "imx-sidenav-tree", 5);
            i0.ɵɵlistener("selectedNode", function CallsAttachmentComponent_Template_imx_sidenav_tree_selectedNode_6_listener($event) { return ctx.onNodeSelection($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, CallsAttachmentComponent_ng_template_7_Template, 2, 2, "ng-template", null, 6, i0.ɵɵtemplateRefExtractor);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(9, CallsAttachmentComponent_div_9_Template, 8, 4, "div", 7);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r3 = i0.ɵɵreference(8);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.loadingOverlay);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.showAlert);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.initialized);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(15, _c1$1, ctx.showInformation));
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dynamicDataSource", ctx.dynamicDataSource)("treeControl", ctx.treeControl)("nodeContent", _r3)("hasChild", ctx.hasChild)("isLoading", ctx.isLoading)("expandWidth", "100%")("sideNavExpanded", true)("manageExpandedExternally", true)("showSidenavHeader", false)("noResultText", ctx.noResultText);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.showInformation);
        }
    }, dependencies: [i6.NgClass, i6.NgIf, i1.EuiAlertComponent, i1.EuiIconComponent, i5.MatButton, i4$1.MatCard, i11.MatProgressSpinner, i4.SidenavTreeComponent, i2$1.TranslatePipe], styles: [".calls-attachment[_ngcontent-%COMP%]{height:100%;position:relative;display:flex;flex-direction:column;gap:20px}.calls-attachment[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;gap:10px;border:1px solid rgba(0,0,0,.12)}.calls-attachment__information[_ngcontent-%COMP%]{display:flex;flex-direction:column;justify-content:center;height:100%;background-color:#f2fcff;border:1px solid #cbe8f2;border-radius:4px;gap:20px}.calls-attachment__information[_ngcontent-%COMP%]   .static-text[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;color:#8acbe3;opacity:.6;gap:20px}.calls-attachment__information[_ngcontent-%COMP%]   .static-text[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{width:310px;font-size:48px;font-weight:700}.calls-attachment__information[_ngcontent-%COMP%]   .static-text[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:200px!important;line-height:200px!important}.calls-attachment__information[_ngcontent-%COMP%]   .file-size[_ngcontent-%COMP%]{display:flex;justify-content:center;color:#0a96d1;font-size:14px}.calls-attachment__information[_ngcontent-%COMP%]   .file-size[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{list-style:disc}.calls-attachment__new-folder[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:10px}.calls-attachment__new-folder[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#0a96d1;cursor:pointer;font-size:20px;padding-right:4px}.calls-attachment__new-folder[_ngcontent-%COMP%]   .eui-icon--disabled[_ngcontent-%COMP%]{color:#aab0b3;cursor:default}.calls-attachment__new-folder[_ngcontent-%COMP%]   .deleteIcon[_ngcontent-%COMP%]{margin-left:auto}.calls-attachment__new-folder[_ngcontent-%COMP%]   .deleteIcon[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%], .calls-attachment__new-folder[_ngcontent-%COMP%]   .deleteIcon[_ngcontent-%COMP%]   .eui-icon--disabled[_ngcontent-%COMP%]{color:inherit}.calls-attachment__new-folder[_ngcontent-%COMP%]   input[type=file][_ngcontent-%COMP%]{display:none}.calls-attachment__new-folder[_ngcontent-%COMP%]   .mat-primary[_ngcontent-%COMP%]{color:#2f3233}.calls-attachment__attachments-tree[_ngcontent-%COMP%]{height:100%}.calls-attachment__attachments-tree--hidden[_ngcontent-%COMP%]{display:none}.calls-attachment[_ngcontent-%COMP%]   .strong[_ngcontent-%COMP%]{font-weight:600}.calls-attachment[_ngcontent-%COMP%]   imx-sidenav-tree[_ngcontent-%COMP%]   .snavigation[_ngcontent-%COMP%]{width:100%!important}.calls-attachment[_ngcontent-%COMP%]   .loading-overlay[_ngcontent-%COMP%]{position:absolute;z-index:999;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.32)}[_nghost-%COMP%]   .imx-tree-root[_ngcontent-%COMP%] > eui-icon[_ngcontent-%COMP%]{color:#0a96d1;margin-right:10px}[_nghost-%COMP%]   .imx-tree-root--selected[_ngcontent-%COMP%] > eui-icon[_ngcontent-%COMP%]{color:#e36a00}[_nghost-%COMP%]     .calls-attachment__new-folder button .mat-button-wrapper{display:flex;align-items:center}.eui-dark-theme   [_nghost-%COMP%]   .imx-tree-root[_ngcontent-%COMP%] > eui-icon[_ngcontent-%COMP%]{color:#8acbe3}.eui-dark-theme   [_nghost-%COMP%]   .imx-tree-root--selected[_ngcontent-%COMP%] > eui-icon[_ngcontent-%COMP%]{color:#edbe8e}.eui-dark-theme   [_nghost-%COMP%]   .calls-attachment__information[_ngcontent-%COMP%]{background-color:#00384d;border:1px solid #016b91}.eui-dark-theme   [_nghost-%COMP%]   .calls-attachment__information[_ngcontent-%COMP%]   .file-size[_ngcontent-%COMP%], .eui-dark-theme   [_nghost-%COMP%]   .calls-attachment__information[_ngcontent-%COMP%]   .static-text[_ngcontent-%COMP%]{color:#fff}.eui-dark-theme   [_nghost-%COMP%]   .calls-attachment__new-folder[_ngcontent-%COMP%]   .mat-primary[_ngcontent-%COMP%]{color:#fff}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsAttachmentComponent, [{
            type: Component,
            args: [{ selector: 'imx-calls-attachment', template: "<div class=\"calls-attachment\">\r\n  <div class=\"loading-overlay\" *ngIf=\"loadingOverlay\">\r\n    <mat-spinner></mat-spinner>\r\n  </div>\r\n  <eui-alert type=\"warning\" colored=\"true\" *ngIf=\"showAlert\" [dismissable]=\"true\" (dismissed)=\"onAlertDismissed()\">\r\n    <span>{{ alertText | translate }}</span>\r\n  </eui-alert>\r\n  <mat-card>\r\n    <div class=\"calls-attachment__new-folder\" *ngIf=\"initialized\">\r\n      <ng-container *ngIf=\"isNodeTypeFolder(selectedNode); else fileNode\">\r\n        <button mat-button color=\"primary\" (click)=\"onAddFolder(selectedNode)\"><eui-icon icon=\"folder\"></eui-icon>{{'#LDS#Create folder' | translate}}</button>\r\n        <button mat-button color=\"primary\" (click)=\"fileInput.click()\"><eui-icon icon=\"add\" for=\"root-file\" ></eui-icon>{{'#LDS#Attach file' | translate}}</button>\r\n        <input type=\"file\" id=\"root-file\" (change)=\"attachFile($event.target.files)\" [disabled]=\"!isNodeTypeFolder(selectedNode)\" #fileInput/>\r\n      </ng-container>\r\n      <ng-template #fileNode>\r\n        <button mat-button color=\"primary\" [disabled]=\"true\"><eui-icon icon=\"folder\" class=\"eui-icon--disabled\"></eui-icon>{{'#LDS#Create folder' | translate}}</button>\r\n        <button mat-button color=\"primary\" (click)=\"downloadFile(selectedNode)\" *ngIf=\"selectedNode\"><eui-icon icon=\"download\" ></eui-icon>{{'#LDS#Download selected file' | translate}}</button>\r\n      </ng-template>\r\n      <ng-container *ngIf=\"isNodeDeletable(selectedNode); else deleteDisabled\">\r\n        <button mat-button color=\"warn\" (click)=\"onDeleteItem(selectedNode)\"  class=\"deleteIcon\"><eui-icon icon=\"delete\" ></eui-icon>{{'#LDS#Delete selected item' | translate}}</button>\r\n      </ng-container>\r\n      <ng-template #deleteDisabled>\r\n        <button mat-button color=\"warn\" [disabled]=\"true\" class=\"deleteIcon\"><eui-icon icon=\"delete\" class=\"eui-icon--disabled\"></eui-icon>{{'#LDS#Delete selected item' | translate}}</button>\r\n      </ng-template>\r\n    </div>\r\n    <div class=\"calls-attachment__attachments-tree\" [ngClass]=\"{'calls-attachment__attachments-tree--hidden': showInformation}\">\r\n      <imx-sidenav-tree\r\n        [dynamicDataSource]=\"dynamicDataSource\"\r\n        [treeControl]=\"treeControl\"\r\n        [nodeContent]=\"nodeContent\"\r\n        [hasChild]=\"hasChild\"\r\n        [isLoading]=\"isLoading\"\r\n        [expandWidth]=\"'100%'\"\r\n        [sideNavExpanded]=\"true\"\r\n        [manageExpandedExternally]=\"true\"\r\n        [showSidenavHeader]=\"false\"\r\n        (selectedNode)=\"onNodeSelection($event)\"\r\n        [noResultText]=\"noResultText\"\r\n      ></imx-sidenav-tree>\r\n      <ng-template #nodeContent let-node let-selected=\"selected\">\r\n        <div class=\"imx-tree-root\" [ngClass]=\"{ 'imx-tree-root--selected': selected }\" *ngIf=\"!isNodeTypeFolder(node)\">\r\n          <span>{{ node.name }}</span>\r\n        </div>\r\n        <div class=\"imx-tree-root\" [ngClass]=\"{ 'imx-tree-root--selected': selected }\" *ngIf=\"isNodeTypeFolder(node)\">\r\n          <eui-icon icon=\"folder\"></eui-icon>\r\n          <span>{{ node.name }}</span>\r\n        </div>\r\n      </ng-template>\r\n    </div>\r\n    <div class=\"calls-attachment__information\" *ngIf=\"showInformation\">\r\n      <div class=\"static-text\">\r\n        <eui-icon icon=\"upload\" size=\"xl\"></eui-icon>\r\n        <div>\r\n          <h2 class=\"strong\">{{ '#LDS#Upload file attachments' | translate }}</h2>\r\n        </div>\r\n      </div>\r\n      <div class=\"file-size\" *ngIf=\"hasMaxAttachmentSize\">\r\n        <ul>\r\n          <li>{{ '#LDS#Here you can attach files to this ticket.' | translate }}</li>\r\n          <li>{{ '#LDS#Optionally, you can create folders and add files to these folders.' | translate }}</li>\r\n          <li>{{ '#LDS#The maximum file size is:' | translate }} {{convertedMaxAttachmentSize}}</li>\r\n        </ul>\r\n      </div>\r\n    </div>\r\n  </mat-card>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.calls-attachment{height:100%;position:relative;display:flex;flex-direction:column;gap:20px}.calls-attachment .mat-card{display:flex;flex-direction:column;height:100%;gap:10px;border:1px solid rgba(0,0,0,.12)}.calls-attachment__information{display:flex;flex-direction:column;justify-content:center;height:100%;background-color:#f2fcff;border:1px solid #cbe8f2;border-radius:4px;gap:20px}.calls-attachment__information .static-text{display:flex;align-items:center;justify-content:center;color:#8acbe3;opacity:.6;gap:20px}.calls-attachment__information .static-text h2{width:310px;font-size:48px;font-weight:700}.calls-attachment__information .static-text .eui-icon{font-size:200px!important;line-height:200px!important}.calls-attachment__information .file-size{display:flex;justify-content:center;color:#0a96d1;font-size:14px}.calls-attachment__information .file-size li{list-style:disc}.calls-attachment__new-folder{display:flex;align-items:flex-start;gap:10px}.calls-attachment__new-folder .eui-icon{color:#0a96d1;cursor:pointer;font-size:20px;padding-right:4px}.calls-attachment__new-folder .eui-icon--disabled{color:#aab0b3;cursor:default}.calls-attachment__new-folder .deleteIcon{margin-left:auto}.calls-attachment__new-folder .deleteIcon .eui-icon,.calls-attachment__new-folder .deleteIcon .eui-icon--disabled{color:inherit}.calls-attachment__new-folder input[type=file]{display:none}.calls-attachment__new-folder .mat-primary{color:#2f3233}.calls-attachment__attachments-tree{height:100%}.calls-attachment__attachments-tree--hidden{display:none}.calls-attachment .strong{font-weight:600}.calls-attachment imx-sidenav-tree .snavigation{width:100%!important}.calls-attachment .loading-overlay{position:absolute;z-index:999;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.32)}:host .imx-tree-root>eui-icon{color:#0a96d1;margin-right:10px}:host .imx-tree-root--selected>eui-icon{color:#e36a00}:host ::ng-deep .calls-attachment__new-folder button .mat-button-wrapper{display:flex;align-items:center}.eui-dark-theme :host .imx-tree-root>eui-icon{color:#8acbe3}.eui-dark-theme :host .imx-tree-root--selected>eui-icon{color:#edbe8e}.eui-dark-theme :host .calls-attachment__information{background-color:#00384d;border:1px solid #016b91}.eui-dark-theme :host .calls-attachment__information .file-size,.eui-dark-theme :host .calls-attachment__information .static-text{color:#fff}.eui-dark-theme :host .calls-attachment__new-folder .mat-primary{color:#fff}\n"] }]
        }], function () { return [{ type: CallsAttachmentServiceService }, { type: i1$1.MatDialog }, { type: i4.AppConfigService }, { type: i4$2.HttpClient }, { type: i0.Injector }, { type: i5$1.Overlay }, { type: i4.ElementalUiConfigService }, { type: i2$1.TranslateService }, { type: i0.ErrorHandler }, { type: i4.LdsReplacePipe }]; }, { callId: [{
                type: Input
            }] });
})();

function CallsSidesheetComponent_imx_help_contextual_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-help-contextual", 11);
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("contextId", ctx_r0.contexId)("title", "#LDS#Information about this tab:");
    }
}
function CallsSidesheetComponent_imx_cdr_editor_9_Template(rf, ctx) {
    if (rf & 1) {
        const _r8 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 12);
        i0.ɵɵlistener("controlCreated", function CallsSidesheetComponent_imx_cdr_editor_9_Template_imx_cdr_editor_controlCreated_0_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r8); const cdr_r6 = restoredCtx.$implicit; const ctx_r7 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r7.detailsFormGroup.addControl(cdr_r6.column.ColumnName, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r6 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r6);
    }
}
function CallsSidesheetComponent_span_12_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "span", 13);
        i0.ɵɵtext(1, "#LDS#Create");
        i0.ɵɵelementEnd();
    }
}
function CallsSidesheetComponent_span_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "span", 13);
        i0.ɵɵtext(1, "#LDS#Save");
        i0.ɵɵelementEnd();
    }
}
function CallsSidesheetComponent_mat_tab_14_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 1);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelementStart(2, "div", 2)(3, "div", 14);
        i0.ɵɵelement(4, "imx-calls-history", 15);
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext();
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 2, "#LDS#Heading History"));
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("ticket", ctx_r4.ticket);
    }
}
function CallsSidesheetComponent_mat_tab_15_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 1);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelementStart(2, "div", 2)(3, "div", 14);
        i0.ɵɵelement(4, "imx-calls-attachment", 16);
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext();
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 2, "#LDS#Heading Attachments"));
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("callId", ctx_r5.getTicketId);
    }
}
class CallsSidesheetComponent {
    constructor(sidesheetData, errorHandler, sidesheetRef, snackBarService, euiLoadingService, projectConfigurationService, formBuilder, confirmationService, hdsApiService) {
        this.sidesheetData = sidesheetData;
        this.errorHandler = errorHandler;
        this.sidesheetRef = sidesheetRef;
        this.snackBarService = snackBarService;
        this.euiLoadingService = euiLoadingService;
        this.projectConfigurationService = projectConfigurationService;
        this.formBuilder = formBuilder;
        this.confirmationService = confirmationService;
        this.hdsApiService = hdsApiService;
        this.cdrList = [];
        this.contextId = HELP_CONTEXTUAL.HelpDeskSupportTicketsEdit;
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
            if (!this.detailsFormGroup.dirty || (yield this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close();
            }
        }));
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.setup();
        });
    }
    setup() {
        return __awaiter(this, void 0, void 0, function* () {
            this.ticket = this.sidesheetData.ticket;
            let entity = this.sidesheetData.ticket.GetEntity();
            let columnNames = yield this.getColumnNames();
            columnNames.forEach(columnName => {
                let column = entity.GetColumn(columnName);
                if (column)
                    this.cdrList.push(new BaseCdr(column));
            });
        });
    }
    getColumnNames() {
        return __awaiter(this, void 0, void 0, function* () {
            let columnNames = [];
            let overlayRef = this.euiLoadingService.show();
            try {
                let config = yield this.projectConfigurationService.getConfig();
                if (this.sidesheetData.isNew)
                    columnNames = config.OwnershipConfig.PrimaryFields['TroubleTicket'];
                else
                    columnNames = config.OwnershipConfig.EditableFields['TroubleTicket'];
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                this.euiLoadingService.hide(overlayRef);
            }
            return columnNames;
        });
    }
    save() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.detailsFormGroup.valid) {
                let overlayRef = this.euiLoadingService.show();
                try {
                    yield this.sidesheetData.ticket.GetEntity().Commit(true).then(() => {
                        this.detailsFormGroup.markAsPristine();
                        this.sidesheetRef.close();
                        let textContainer;
                        if (this.sidesheetData.isNew)
                            textContainer = { key: '#LDS#The ticket with the number {0} has been successfully created.', parameters: [this.sidesheetData.ticket.CallNumber.value.toString()] };
                        else
                            textContainer = { key: '#LDS#The ticket has been successfully saved.', parameters: [this.sidesheetData.ticket.CallNumber.value.toString()] };
                        this.snackBarService.open(textContainer, '#LDS#Close', { duration: 6000 });
                    });
                }
                catch (error) {
                    this.errorHandler.handleError(error);
                }
                finally {
                    this.euiLoadingService.hide(overlayRef);
                }
            }
        });
    }
    cancel() {
        this.sidesheetRef.close();
    }
    get getTicketId() {
        return !!this.sidesheetData.ticket.EntityKeysData.Keys ? this.sidesheetData.ticket.EntityKeysData.Keys[0] : '';
    }
}
CallsSidesheetComponent.ɵfac = function CallsSidesheetComponent_Factory(t) { return new (t || CallsSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i4.SnackBarService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i3.ProjectConfigurationService), i0.ɵɵdirectiveInject(i2.UntypedFormBuilder), i0.ɵɵdirectiveInject(i4.ConfirmationService), i0.ɵɵdirectiveInject(HdsApiService)); };
CallsSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsSidesheetComponent, selectors: [["imx-calls-sidesheet"]], decls: 16, vars: 12, consts: [[1, "calls-sidesheet"], [3, "label"], [1, "calls-sidesheet__tab-content"], ["eui-sidesheet-content", "", 1, "calls-sidesheet__tab-content-body", 3, "ngClass"], [3, "contextId", "title", 4, "ngIf"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", "", 1, "calls-sidesheet__action-buttons"], ["data-imx-identifier", "create-ticket-button", "mat-flat-button", "", "color", "primary", 3, "disabled", "click"], ["translate", "", 4, "ngIf"], [3, "label", 4, "ngIf"], [3, "contextId", "title"], [3, "cdr", "controlCreated"], ["translate", ""], ["eui-sidesheet-content", "", 1, "calls-sidesheet__tab-content-body"], [3, "ticket"], [3, "callId"]], template: function CallsSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-tab-group")(2, "mat-tab", 1);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementStart(4, "div", 2)(5, "div", 3);
            i0.ɵɵtemplate(6, CallsSidesheetComponent_imx_help_contextual_6_Template, 1, 2, "imx-help-contextual", 4);
            i0.ɵɵelementStart(7, "mat-card")(8, "form", 5);
            i0.ɵɵtemplate(9, CallsSidesheetComponent_imx_cdr_editor_9_Template, 1, 1, "imx-cdr-editor", 6);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(10, "div", 7)(11, "button", 8);
            i0.ɵɵlistener("click", function CallsSidesheetComponent_Template_button_click_11_listener() { return ctx.save(); });
            i0.ɵɵtemplate(12, CallsSidesheetComponent_span_12_Template, 2, 0, "span", 9);
            i0.ɵɵtemplate(13, CallsSidesheetComponent_span_13_Template, 2, 0, "span", 9);
            i0.ɵɵelementEnd()()()();
            i0.ɵɵtemplate(14, CallsSidesheetComponent_mat_tab_14_Template, 5, 4, "mat-tab", 10);
            i0.ɵɵtemplate(15, CallsSidesheetComponent_mat_tab_15_Template, 5, 4, "mat-tab", 10);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(3, 10, "#LDS#Heading Details"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngClass", !ctx.sidesheetData.isNew ? "eui-sidesheet-content--no-padding-top" : "");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.sidesheetData.isNew);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.detailsFormGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.detailsFormGroup.pristine || ctx.detailsFormGroup.invalid);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.sidesheetData.isNew);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.sidesheetData.isNew);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !(ctx.sidesheetData == null ? null : ctx.sidesheetData.isNew));
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !(ctx.sidesheetData == null ? null : ctx.sidesheetData.isNew));
        }
    }, dependencies: [i6.NgClass, i6.NgForOf, i6.NgIf, i2.ɵNgNoValidate, i2.NgControlStatusGroup, i2.FormGroupDirective, i1.EuiSidesheetContentDirective, i1.EuiSidesheetActionsDirective, i5.MatButton, i4$1.MatCard, i9.MatTabGroup, i9.MatTab, i4.CdrEditorComponent, i2$1.TranslateDirective, i4.HelpContextualComponent, CallsHistoryComponent, CallsAttachmentComponent, i2$1.TranslatePipe], styles: [".calls-sidesheet[_ngcontent-%COMP%]{overflow:hidden;height:100%}.calls-sidesheet__tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%}.calls-sidesheet__tab-content-body[_ngcontent-%COMP%]   .helper-alert[_ngcontent-%COMP%]{display:flex;margin-bottom:20px}.calls-sidesheet[_ngcontent-%COMP%]     .mat-tab-group{height:100%}.calls-sidesheet[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-header{padding:0 20px}.calls-sidesheet[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-body-wrapper{height:100%}imx-help-contextual[_ngcontent-%COMP%]{justify-content:end}.eui-sidesheet-content.eui-sidesheet-content--no-padding-top[_ngcontent-%COMP%]{padding-top:0}@media screen and (max-width: 480px){.calls-sidesheet__tab-content[_ngcontent-%COMP%]{display:block}.calls-sidesheet__action-buttons[_ngcontent-%COMP%]{flex-direction:column-reverse}.calls-sidesheet__action-buttons[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{width:100%;margin-bottom:10px;margin-right:0}.calls-sidesheet__action-buttons[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:0}}.eui-dark-theme   [_nghost-%COMP%]   .calls-sidesheet[_ngcontent-%COMP%]{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .calls-sidesheet[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .calls-sidesheet__action-buttons[_ngcontent-%COMP%]{background-color:#444647}.eui-contrast-theme   [_nghost-%COMP%]   .calls-sidesheet[_ngcontent-%COMP%]{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .calls-sidesheet[_ngcontent-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .calls-sidesheet__action-buttons[_ngcontent-%COMP%]{background-color:#16191a}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsSidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-calls-sidesheet', template: "<div class=\"calls-sidesheet\">\r\n  <mat-tab-group>\r\n    <mat-tab [label]=\"'#LDS#Heading Details' | translate\">\r\n      <div class=\"calls-sidesheet__tab-content\">\r\n        <div eui-sidesheet-content class=\"calls-sidesheet__tab-content-body\" [ngClass]=\"!sidesheetData.isNew ? 'eui-sidesheet-content--no-padding-top' : ''\">\r\n          <imx-help-contextual [contextId]=\"contexId\" [title]=\"'#LDS#Information about this tab:'\" *ngIf=\"!sidesheetData.isNew\"></imx-help-contextual>\r\n          <mat-card>\r\n            <form [formGroup]=\"detailsFormGroup\">\r\n              <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"detailsFormGroup.addControl(cdr.column.ColumnName, $event)\"></imx-cdr-editor>\r\n            </form>\r\n          </mat-card>\r\n        </div>\r\n        <div eui-sidesheet-actions class=\"calls-sidesheet__action-buttons\">\r\n          <button data-imx-identifier=\"create-ticket-button\" mat-flat-button color=\"primary\" [disabled]=\"detailsFormGroup.pristine || detailsFormGroup.invalid\" (click)=\"save()\">\r\n            <span *ngIf=\"sidesheetData.isNew\" translate>#LDS#Create</span>\r\n            <span *ngIf=\"!sidesheetData.isNew\" translate>#LDS#Save</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </mat-tab>\r\n    <mat-tab *ngIf=\"!sidesheetData?.isNew\" [label]=\"'#LDS#Heading History' | translate\">\r\n      <div class=\"calls-sidesheet__tab-content\">\r\n        <div eui-sidesheet-content class=\"calls-sidesheet__tab-content-body\">\r\n          <imx-calls-history [ticket]=\"ticket\"></imx-calls-history>\r\n        </div>\r\n      </div>\r\n    </mat-tab>\r\n    <mat-tab *ngIf=\"!sidesheetData?.isNew\" [label]=\"'#LDS#Heading Attachments' | translate\">\r\n      <div class=\"calls-sidesheet__tab-content\">\r\n        <div eui-sidesheet-content class=\"calls-sidesheet__tab-content-body\">\r\n          <imx-calls-attachment [callId]=\"getTicketId\"></imx-calls-attachment>\r\n        </div>\r\n      </div>\r\n    </mat-tab>\r\n  </mat-tab-group>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.calls-sidesheet{overflow:hidden;height:100%}.calls-sidesheet__tab-content{display:flex;flex-direction:column;height:100%}.calls-sidesheet__tab-content-body .helper-alert{display:flex;margin-bottom:20px}.calls-sidesheet ::ng-deep .mat-tab-group{height:100%}.calls-sidesheet ::ng-deep .mat-tab-group .mat-tab-header{padding:0 20px}.calls-sidesheet ::ng-deep .mat-tab-group .mat-tab-body-wrapper{height:100%}imx-help-contextual{justify-content:end}.eui-sidesheet-content.eui-sidesheet-content--no-padding-top{padding-top:0}@media screen and (max-width: 480px){.calls-sidesheet__tab-content{display:block}.calls-sidesheet__action-buttons{flex-direction:column-reverse}.calls-sidesheet__action-buttons button{width:100%;margin-bottom:10px;margin-right:0}.calls-sidesheet__action-buttons .justify-start{margin-right:0}}.eui-dark-theme :host .calls-sidesheet{background-color:#2f3233}.eui-dark-theme :host .calls-sidesheet ::ng-deep .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-dark-theme :host .calls-sidesheet__action-buttons{background-color:#444647}.eui-contrast-theme :host .calls-sidesheet{background-color:#000}.eui-contrast-theme :host .calls-sidesheet ::ng-deep .mat-tab-group .mat-tab-header{background-color:#000}.eui-contrast-theme :host .calls-sidesheet__action-buttons{background-color:#16191a}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i0.ErrorHandler }, { type: i1.EuiSidesheetRef }, { type: i4.SnackBarService }, { type: i1.EuiLoadingService }, { type: i3.ProjectConfigurationService }, { type: i2.UntypedFormBuilder }, { type: i4.ConfirmationService }, { type: HdsApiService }];
    }, null);
})();

function CallsComponent_ng_template_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 14);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r3 = ctx.$implicit;
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵpropertyInterpolate("title", ctx_r1.getTicketItemValue(item_r3, "DescriptionHotline"));
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r1.getTicketItemValue(item_r3, "DescriptionHotline"), " ");
    }
}
function CallsComponent_ng_template_26_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 14);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r4 = ctx.$implicit;
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵpropertyInterpolate("title", ctx_r2.getTicketItemValue(item_r4, "ActionHotline"));
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", ctx_r2.getTicketItemValue(item_r4, "ActionHotline"), " ");
    }
}
const _c0 = function () { return ["search", "filter"]; };
const _c1 = function () { return ["namespace"]; };
class CallsComponent {
    constructor(errorHandler, sidesheet, translate, hdsApiService, euiLoadingService, settingsService, replacePipe, helpContextualService) {
        this.errorHandler = errorHandler;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.hdsApiService = hdsApiService;
        this.euiLoadingService = euiLoadingService;
        this.settingsService = settingsService;
        this.replacePipe = replacePipe;
        this.helpContextualService = helpContextualService;
        this.displayedColumns = [];
        this.filterOptions = [];
        this.busyService = new BusyService();
        this.collectionLoadParameters = { PageSize: this.settingsService.DefaultPageSize, StartIndex: 0, OrderBy: 'XDateInserted desc' };
        this.entitySchema = this.hdsApiService.typedClient.PortalCalls.GetSchema();
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                this.displayedColumns = [
                    this.entitySchema.Columns.CallNumber,
                    {
                        ColumnName: 'description',
                        Type: ValType.String,
                    },
                    this.entitySchema.Columns.IsClosed,
                    this.entitySchema.Columns.IsHistory,
                    this.entitySchema.Columns.IsHold,
                    this.entitySchema.Columns.UID_PersonHotline,
                    this.entitySchema.Columns.UID_PersonInTrouble,
                    this.entitySchema.Columns.UID_PersonInTroubleAdditional,
                    this.entitySchema.Columns.UID_TroubleCallState,
                    this.entitySchema.Columns.UID_TroubleEscalationLevel_E,
                    this.entitySchema.Columns.UID_TroubleProduct,
                    this.entitySchema.Columns.UID_TroubleSeverity,
                    this.entitySchema.Columns.UID_TroubleTypeHotline,
                    {
                        ColumnName: 'actionHotLine',
                        Type: ValType.String,
                    },
                ];
                yield this.setFilter();
                yield this.loadTickets(true);
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    createTicket() {
        return __awaiter(this, void 0, void 0, function* () {
            let ticket = yield this.getNewTicket();
            if (ticket)
                yield this.viewTicket(ticket, true);
        });
    }
    viewTicket(ticket, isNew) {
        return __awaiter(this, void 0, void 0, function* () {
            if (ticket) {
                let title = isNew
                    ? yield this.translate.get('#LDS#Heading Create Ticket').toPromise()
                    : yield this.translate.get('#LDS#Heading Edit Ticket').toPromise();
                let sidesheetData = {
                    isNew: isNew,
                    ticket: ticket,
                };
                let euiSidesheetConfig = {
                    testId: 'calls-sidesheet',
                    title: title,
                    padding: '0px',
                    width: 'max(600px, 60%)',
                    data: sidesheetData,
                    disableClose: true,
                    headerComponent: isNew ? HelpContextualComponent : undefined,
                };
                if (!isNew) {
                    euiSidesheetConfig.subTitle = this.replacePipe.transform(yield this.translate.get('#LDS#Heading Ticket Number: {0}').toPromise(), ticket.CallNumber.value.toString());
                    this.helpContextualService.setHelpContextId(HELP_CONTEXTUAL.HelpDeskSupportTicketsCreate);
                }
                let sidesheetRef = this.sidesheet.open(CallsSidesheetComponent, euiSidesheetConfig);
                sidesheetRef.afterClosed().subscribe(() => this.loadTickets());
            }
        });
    }
    getNewTicket() {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef = this.euiLoadingService.show();
            try {
                let tickets = (yield this.hdsApiService.typedClient.PortalCallsInteractive.Get()).Data;
                return tickets[0];
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                this.euiLoadingService.hide(overlayRef);
            }
        });
    }
    loadTickets(isInitialLoad = false) {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                let tickets = isInitialLoad
                    ? { totalCount: 0, Data: [] }
                    : yield this.hdsApiService.typedClient.PortalCalls.Get(this.collectionLoadParameters);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: tickets,
                    entitySchema: this.entitySchema,
                    navigationState: this.collectionLoadParameters,
                    filters: this.filterOptions,
                };
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    onNavigationStateChanged(collectionLoadParameters) {
        return __awaiter(this, void 0, void 0, function* () {
            if (collectionLoadParameters) {
                this.collectionLoadParameters = collectionLoadParameters;
            }
            yield this.loadTickets();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.collectionLoadParameters.StartIndex = 0;
            this.collectionLoadParameters.search = keywords;
            yield this.loadTickets();
        });
    }
    onSelected(ticket) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef = this.euiLoadingService.show();
            try {
                if (((_b = (_a = ticket.EntityKeysData) === null || _a === void 0 ? void 0 : _a.Keys) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                    let interactiveTickets = (yield this.hdsApiService.typedClient.PortalCallsInteractive.Get_byid(ticket.EntityKeysData.Keys[0])).Data;
                    if ((interactiveTickets === null || interactiveTickets === void 0 ? void 0 : interactiveTickets.length) > 0)
                        this.viewTicket(interactiveTickets[0], false);
                }
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                this.euiLoadingService.hide(overlayRef);
            }
        });
    }
    getTicketItemValue(ticket, column) {
        return ticket.GetEntity().GetColumn(column).GetValue();
    }
    setFilter() {
        return __awaiter(this, void 0, void 0, function* () {
            this.dataModel = yield this.getDataModel();
            this.filterOptions = this.dataModel.Filters;
            this.filterOptions.map((filter) => {
                if (filter.Name === 'callstate') {
                    filter.InitialValue = 'HDS-2B3E666A806E7CDC288CAE36AE8623DC';
                }
            });
        });
    }
    getDataModel(groupFilter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.hdsApiService.client.portal_calls_datamodel_get({
                filter: groupFilter,
            });
        });
    }
}
CallsComponent.ɵfac = function CallsComponent_Factory(t) { return new (t || CallsComponent)(i0.ɵɵdirectiveInject(i0.ErrorHandler), i0.ɵɵdirectiveInject(i1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2$1.TranslateService), i0.ɵɵdirectiveInject(HdsApiService), i0.ɵɵdirectiveInject(i1.EuiLoadingService), i0.ɵɵdirectiveInject(i4.SettingsService), i0.ɵɵdirectiveInject(i4.LdsReplacePipe), i0.ɵɵdirectiveInject(i4.HelpContextualService)); };
CallsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CallsComponent, selectors: [["imx-calls"]], decls: 34, vars: 29, consts: [[1, "mat-headline"], ["data-imx-identifier", "calls-data-source-toolbar", 3, "settings", "busyService", "options", "hiddenFilters", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], [1, "calls-data-table"], ["data-imx-identifier", "calls-data-table", 3, "dst", "mode", "highlightedEntityChanged"], [3, "entityColumn"], ["columnName", "description", "data-imx-identifier", "calls-table-column-ellipsis", 3, "columnLabel"], ["columnName", "actionHotLine", "data-imx-identifier", "calls-table-column-ellipsis", 3, "columnLabel"], ["data-imx-identifier", "calls-data-source-paginator", 3, "dst"], [1, "imx-button-bar"], [1, "imx-menu-spacer"], ["data-imx-identifier", "create-help-desk-support-call", "mat-raised-button", "", "color", "primary", 1, "mat-focus-indicator", "mat-raised-button", "mat-button-base", "mat-primary", "create-ticket-button", 3, "click"], ["icon", "add"], ["translate", ""], [1, "calls-table-column-ellipsis", 3, "title"]], template: function CallsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "h2", 0)(1, "span");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card")(6, "imx-data-source-toolbar", 1, 2);
            i0.ɵɵlistener("navigationStateChanged", function CallsComponent_Template_imx_data_source_toolbar_navigationStateChanged_6_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function CallsComponent_Template_imx_data_source_toolbar_search_6_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(9, "div", 3)(10, "imx-data-table", 4);
            i0.ɵɵlistener("highlightedEntityChanged", function CallsComponent_Template_imx_data_table_highlightedEntityChanged_10_listener($event) { return ctx.onSelected($event); });
            i0.ɵɵelement(11, "imx-data-table-column", 5);
            i0.ɵɵelementStart(12, "imx-data-table-generic-column", 6);
            i0.ɵɵtemplate(13, CallsComponent_ng_template_13_Template, 2, 2, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(14, "imx-data-table-column", 5)(15, "imx-data-table-column", 5)(16, "imx-data-table-column", 5)(17, "imx-data-table-column", 5)(18, "imx-data-table-column", 5)(19, "imx-data-table-column", 5)(20, "imx-data-table-column", 5)(21, "imx-data-table-column", 5)(22, "imx-data-table-column", 5)(23, "imx-data-table-column", 5)(24, "imx-data-table-column", 5);
            i0.ɵɵelementStart(25, "imx-data-table-generic-column", 7);
            i0.ɵɵtemplate(26, CallsComponent_ng_template_26_Template, 2, 2, "ng-template");
            i0.ɵɵelementEnd()()();
            i0.ɵɵelement(27, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(28, "div", 9);
            i0.ɵɵelement(29, "span", 10);
            i0.ɵɵelementStart(30, "button", 11);
            i0.ɵɵlistener("click", function CallsComponent_Template_button_click_30_listener() { return ctx.createTicket(); });
            i0.ɵɵelement(31, "eui-icon", 12);
            i0.ɵɵelementStart(32, "span", 13);
            i0.ɵɵtext(33, "#LDS#Create ticket");
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(7);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 23, "#LDS#Heading Tickets"));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("settings", ctx.dstSettings)("busyService", ctx.busyService)("options", i0.ɵɵpureFunction0(27, _c0))("hiddenFilters", i0.ɵɵpureFunction0(28, _c1))("searchBoxText", i0.ɵɵpipeBind1(8, 25, "#LDS#Search"));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dst", _r0)("mode", "manual");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.CallNumber);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("columnLabel", ctx.entitySchema.Columns.DescriptionHotline.Display);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.IsClosed);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.IsHistory);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.IsHold);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_PersonHotline);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_PersonInTrouble);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_PersonInTroubleAdditional);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_TroubleCallState);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_TroubleEscalationLevel_E);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_TroubleProduct);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_TroubleSeverity);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_TroubleTypeHotline);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("columnLabel", ctx.entitySchema.Columns.ActionHotline.Display);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i1.EuiIconComponent, i5.MatButton, i4$1.MatCard, i2$1.TranslateDirective, i4.DataSourceToolbarComponent, i4.DataSourcePaginatorComponent, i4.DataTableComponent, i4.DataTableColumnComponent, i4.DataTableGenericColumnComponent, i4.HelpContextualComponent, i2$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}[_nghost-%COMP%]   .mat-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.create-ticket-button[_ngcontent-%COMP%]{align-self:flex-start}[_nghost-%COMP%]     .calls-data-table .mat-table tbody .mat-row .mat-cell .calls-table-column-ellipsis{width:120px;display:block;white-space:nowrap;overflow-x:hidden;text-overflow:ellipsis}.calls-data-table[_ngcontent-%COMP%]{flex-grow:1;overflow:auto}.imx-button-bar[_ngcontent-%COMP%]{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-button-bar[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:16px}.imx-button-bar[_ngcontent-%COMP%]   .imx-menu-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.imx-button-bar[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%], .imx-button-bar[_ngcontent-%COMP%]   .mat-raised-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsComponent, [{
            type: Component,
            args: [{ selector: 'imx-calls', template: "<h2 class=\"mat-headline\">\r\n  <span>{{ '#LDS#Heading Tickets' | translate }}</span>\r\n  <imx-help-contextual></imx-help-contextual>\r\n</h2>\r\n\r\n<mat-card>\r\n  <imx-data-source-toolbar\r\n    #dst\r\n    data-imx-identifier=\"calls-data-source-toolbar\"\r\n    [settings]=\"dstSettings\"\r\n    [busyService]=\"busyService\"\r\n    [options]=\"['search', 'filter']\"\r\n    [hiddenFilters]=\"['namespace']\"\r\n    [searchBoxText]=\"'#LDS#Search' | translate\"\r\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n    (search)=\"onSearch($event)\"\r\n  >\r\n  </imx-data-source-toolbar>\r\n  <div class=\"calls-data-table\">\r\n    <imx-data-table data-imx-identifier=\"calls-data-table\" [dst]=\"dst\" (highlightedEntityChanged)=\"onSelected($event)\" [mode]=\"'manual'\">\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.CallNumber\"> </imx-data-table-column>\r\n      <imx-data-table-generic-column columnName=\"description\" data-imx-identifier=\"calls-table-column-ellipsis\" [columnLabel]=\"entitySchema.Columns.DescriptionHotline.Display\">\r\n        <ng-template let-item>\r\n          <div class=\"calls-table-column-ellipsis\" title=\"{{ getTicketItemValue(item, 'DescriptionHotline') }}\">\r\n            {{ getTicketItemValue(item, 'DescriptionHotline') }}\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-generic-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.IsClosed\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.IsHistory\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.IsHold\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_PersonHotline\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_PersonInTrouble\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_PersonInTroubleAdditional\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_TroubleCallState\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_TroubleEscalationLevel_E\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_TroubleProduct\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_TroubleSeverity\"> </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_TroubleTypeHotline\"> </imx-data-table-column>\r\n      <imx-data-table-generic-column columnName=\"actionHotLine\" data-imx-identifier=\"calls-table-column-ellipsis\" [columnLabel]=\"entitySchema.Columns.ActionHotline.Display\">\r\n        <ng-template let-item>\r\n          <div class=\"calls-table-column-ellipsis\" title=\"{{ getTicketItemValue(item, 'ActionHotline') }}\">\r\n            {{ getTicketItemValue(item, 'ActionHotline') }}\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-generic-column>\r\n    </imx-data-table>\r\n  </div>\r\n  <imx-data-source-paginator data-imx-identifier=\"calls-data-source-paginator\" [dst]=\"dst\"></imx-data-source-paginator>\r\n</mat-card>\r\n<div class=\"imx-button-bar\">\r\n  <span class=\"imx-menu-spacer\"></span>\r\n  <button\r\n    data-imx-identifier=\"create-help-desk-support-call\"\r\n    mat-raised-button\r\n    color=\"primary\"\r\n    class=\"mat-focus-indicator mat-raised-button mat-button-base mat-primary create-ticket-button\"\r\n    (click)=\"createTicket()\"\r\n  >\r\n    <eui-icon icon=\"add\"></eui-icon>\r\n    <span translate>#LDS#Create ticket</span>\r\n  </button>\r\n</div>\r\n", styles: [":host{display:flex;flex-direction:column;overflow:hidden;height:100%}:host .mat-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.create-ticket-button{align-self:flex-start}:host ::ng-deep .calls-data-table .mat-table tbody .mat-row .mat-cell .calls-table-column-ellipsis{width:120px;display:block;white-space:nowrap;overflow-x:hidden;text-overflow:ellipsis}.calls-data-table{flex-grow:1;overflow:auto}.imx-button-bar{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-button-bar>button:not(:last-of-type){margin-right:16px}.imx-button-bar .imx-menu-spacer{flex:1 1 auto}.imx-button-bar .mat-stroked-button eui-icon,.imx-button-bar .mat-raised-button eui-icon{font-size:14px;margin-right:4px}\n"] }]
        }], function () { return [{ type: i0.ErrorHandler }, { type: i1.EuiSidesheetService }, { type: i2$1.TranslateService }, { type: HdsApiService }, { type: i1.EuiLoadingService }, { type: i4.SettingsService }, { type: i4.LdsReplacePipe }, { type: i4.HelpContextualService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class CallsModule {
}
CallsModule.ɵfac = function CallsModule_Factory(t) { return new (t || CallsModule)(); };
CallsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: CallsModule });
CallsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule,
        LdsReplaceModule,
        FkAdvancedPickerModule,
        SidenavTreeModule,
        DataTreeWrapperModule,
        HelpContextualModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CallsModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        CallsComponent,
                        CallsSidesheetComponent,
                        CallsHistoryComponent,
                        CallsHistorySidesheetComponent,
                        CallsAttachmentComponent,
                        CallsAttachmentDialogComponent,
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        CdrModule,
                        TranslateModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        LdsReplaceModule,
                        FkAdvancedPickerModule,
                        SidenavTreeModule,
                        DataTreeWrapperModule,
                        HelpContextualModule,
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(CallsModule, { declarations: [CallsComponent,
            CallsSidesheetComponent,
            CallsHistoryComponent,
            CallsHistorySidesheetComponent,
            CallsAttachmentComponent,
            CallsAttachmentDialogComponent], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            CdrModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule,
            LdsReplaceModule,
            FkAdvancedPickerModule,
            SidenavTreeModule,
            DataTreeWrapperModule,
            HelpContextualModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    constructor(router, extService) {
        this.router = router;
        this.extService = extService;
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('mastHead', { instance: CallsComponent, inputData: {
                id: 'helpdeskTickets',
                label: '#LDS#Menu Entry Help desk tickets',
                url: 'help-desk-support/tickets'
            } });
        /*
        this.dataExplorerRegistryService.registerFactory(
          (preProps: string[], groups: string[]) => {
            if (!this.isRoleAdmin(groups)) {
              return;
            }
            return {
              instance: RolesOverviewComponent,
              data: {
                TableName: this.esetTag,
                Count: 0,
              },
              sortOrder: 8,
              name: 'systemroles',
              caption: '#LDS#Menu Entry System roles',
            };
          }
        );
        */
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach(route => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i1$2.Router), i0.ɵɵinject(i4.ExtService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i1$2.Router }, { type: i4.ExtService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'help-desk-support/tickets',
        component: CallsComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.HelpDeskSupportTickets
        }
    }
];
class HdsConfigModule {
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 HDS loaded');
        this.initializer.onInit(routes);
        console.log('▶️ HDS initialized');
    }
}
HdsConfigModule.ɵfac = function HdsConfigModule_Factory(t) { return new (t || HdsConfigModule)(i0.ɵɵinject(InitService)); };
HdsConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: HdsConfigModule });
HdsConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CallsModule,
        RouterModule.forChild(routes)] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(HdsConfigModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        CallsModule,
                        RouterModule.forChild(routes)
                    ]
                }]
        }], function () { return [{ type: InitService }]; }, null);
})();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(HdsConfigModule, { imports: [CallsModule, i1$2.RouterModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of hds
 */

/**
 * Generated bundle index. Do not edit.
 */

export { HdsConfigModule };
//# sourceMappingURL=hds.mjs.map
