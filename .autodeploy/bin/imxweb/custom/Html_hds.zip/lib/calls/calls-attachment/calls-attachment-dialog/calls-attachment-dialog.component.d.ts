import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { CallsAttachmentDialogData } from './../calls-attachment.model';
import { FormControl, FormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class CallsAttachmentDialogComponent implements OnInit {
    matDialogRef: MatDialogRef<CallsAttachmentDialogComponent>;
    data: CallsAttachmentDialogData;
    form: FormGroup<{
        folderName: FormControl<any>;
    }>;
    constructor(matDialogRef: MatDialogRef<CallsAttachmentDialogComponent>, data: CallsAttachmentDialogData);
    ngOnInit(): void;
    closeDialog(action?: string, value?: string): void;
    get dialogTitle(): string;
    get dialogSubHeading(): string;
    get isActionAddFolder(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CallsAttachmentDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CallsAttachmentDialogComponent, "imx-calls-attachment-dialog", never, {}, {}, never, never, false>;
}
