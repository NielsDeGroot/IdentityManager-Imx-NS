import { ErrorHandler } from '@angular/core';
import { HelpdeskConfig, StoredDirectoryInfo } from 'imx-api-hds';
import { HdsApiService } from '../../hds-api-client.service';
import { CallsAttachmentNode } from './calls-attachment.model';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class CallsAttachmentServiceService {
    private readonly hdsApiService;
    private readonly errorHandler;
    private readonly translator;
    constructor(hdsApiService: HdsApiService, errorHandler: ErrorHandler, translator: TranslateService);
    getInitialData(callId: string): Promise<CallsAttachmentNode>;
    getFilesOfDirectory(callId: string, parent: CallsAttachmentNode): Promise<CallsAttachmentNode[]>;
    getCallsConfig(): Promise<HelpdeskConfig>;
    createDirectory(callId: string, path: string): Promise<void>;
    deleteDirectory(callId: string, path: string): Promise<void>;
    deleteFile(callId: string, path: string): Promise<void>;
    uploadFile(callId: string, path: string, file: Blob): Promise<void>;
    formatData(obj: StoredDirectoryInfo, level: number, parent?: CallsAttachmentNode): CallsAttachmentNode[];
    static ɵfac: i0.ɵɵFactoryDeclaration<CallsAttachmentServiceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CallsAttachmentServiceService>;
}
