import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { ErrorHandler, Injector, OnInit } from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatDialog } from '@angular/material/dialog';
import { HelpdeskConfig } from 'imx-api-hds';
import { AppConfigService, DynamicDataApiControls, DynamicDataSource, ElementalUiConfigService, LdsReplacePipe } from 'qbm';
import { HttpClient } from '@angular/common/http';
import { CallsAttachmentNode } from './calls-attachment.model';
import { CallsAttachmentServiceService } from './calls-attachment-service.service';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class CallsAttachmentComponent implements OnInit {
    private attachmentService;
    private readonly dialog;
    private readonly config;
    private readonly http;
    private readonly injector;
    private readonly overlay;
    private readonly elementalUiConfigService;
    private readonly translator;
    private readonly errorHandler;
    private readonly ldsReplace;
    callId: string;
    treeControl: FlatTreeControl<CallsAttachmentNode, CallsAttachmentNode>;
    attachmentTreeData: CallsAttachmentNode;
    selectedNode: CallsAttachmentNode | null;
    showAlert: boolean;
    overlayRef: OverlayRef;
    alertText: string;
    apiControls: DynamicDataApiControls<CallsAttachmentNode>;
    dynamicDataSource: DynamicDataSource<CallsAttachmentNode>;
    loadingOverlay: boolean;
    callsConfig: HelpdeskConfig;
    hasMaxAttachmentSize: boolean;
    convertedMaxAttachmentSize: string;
    noResultText: string;
    initialized: boolean;
    constructor(attachmentService: CallsAttachmentServiceService, dialog: MatDialog, config: AppConfigService, http: HttpClient, injector: Injector, overlay: Overlay, elementalUiConfigService: ElementalUiConfigService, translator: TranslateService, errorHandler: ErrorHandler, ldsReplace: LdsReplacePipe);
    ngOnInit(): Promise<void>;
    onAddFolder(node: CallsAttachmentNode): Promise<void>;
    onDeleteItem(node: CallsAttachmentNode): void;
    openDeleteFileDialog(node: CallsAttachmentNode): void;
    /**
     * Check the selected folder has any child elements.
     * If it is empty open confirmation dialog and call deleteFolder action
     * @param node Selected node
     */
    openDeleteFolderDialog(node: CallsAttachmentNode): Promise<void>;
    attachFile(val: any): Promise<void>;
    downloadFile(node: CallsAttachmentNode): Promise<void>;
    onNodeSelection(node: CallsAttachmentNode): void;
    updateSelectionState(data: CallsAttachmentNode[]): void;
    isDuplicateName(name: any, node: any): boolean;
    hasChild(_: number, node: CallsAttachmentNode): CallsAttachmentNode[];
    onAlertDismissed(): void;
    isNodeTypeFolder(node: CallsAttachmentNode | null): boolean;
    isLoading(node: CallsAttachmentNode): boolean;
    isNodeDeletable(node: CallsAttachmentNode): boolean;
    get showInformation(): boolean;
    private uploadFile;
    private byteConverter;
    private getFlooredFixed;
    private isNodeFolderEmpty;
    private isNodeFile;
    private deleteFolder;
    private deleteFile;
    private createFolder;
    private expandNode;
    private showAlertMessage;
    private changeLoadingOverlayStatus;
    static ɵfac: i0.ɵɵFactoryDeclaration<CallsAttachmentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CallsAttachmentComponent, "imx-calls-attachment", never, { "callId": "callId"; }, {}, never, never, false>;
}
