import { OnInit } from '@angular/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { ColumnDependentReference } from 'qbm';
import { PortalCallsHistory } from 'imx-api-hds';
import * as i0 from "@angular/core";
export declare class CallsHistorySidesheetComponent implements OnInit {
    portalCallsHistory: PortalCallsHistory;
    private readonly euiLoadingService;
    formBuilder: UntypedFormBuilder;
    readonly detailsFormGroup: UntypedFormGroup;
    cdrList: ColumnDependentReference[];
    constructor(portalCallsHistory: PortalCallsHistory, euiLoadingService: EuiLoadingService, formBuilder: UntypedFormBuilder);
    ngOnInit(): Promise<void>;
    setup(): Promise<void>;
    getColumnNames(): Promise<string[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CallsHistorySidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CallsHistorySidesheetComponent, "imx-calls-history-sidesheet", never, {}, {}, never, never, false>;
}
