import { ErrorHandler, OnInit } from '@angular/core';
import { EuiLoadingService, EuiSidesheetRef } from '@elemental-ui/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { PortalCalls } from 'imx-api-hds';
import { ColumnDependentReference, SnackBarService, ConfirmationService } from 'qbm';
import { ProjectConfigurationService } from 'qer';
import { HdsApiService } from '../../hds-api-client.service';
import * as i0 from "@angular/core";
export interface CallsSidesheetData {
    isNew: boolean;
    ticket: PortalCalls;
}
export declare class CallsSidesheetComponent implements OnInit {
    sidesheetData: CallsSidesheetData;
    private readonly errorHandler;
    private readonly sidesheetRef;
    private readonly snackBarService;
    private readonly euiLoadingService;
    private projectConfigurationService;
    formBuilder: UntypedFormBuilder;
    private readonly confirmationService;
    private readonly hdsApiService;
    readonly detailsFormGroup: UntypedFormGroup;
    cdrList: ColumnDependentReference[];
    ticket: PortalCalls;
    contextId: "help-desk-support-tickets-edit";
    constructor(sidesheetData: CallsSidesheetData, errorHandler: ErrorHandler, sidesheetRef: EuiSidesheetRef, snackBarService: SnackBarService, euiLoadingService: EuiLoadingService, projectConfigurationService: ProjectConfigurationService, formBuilder: UntypedFormBuilder, confirmationService: ConfirmationService, hdsApiService: HdsApiService);
    ngOnInit(): Promise<void>;
    setup(): Promise<void>;
    getColumnNames(): Promise<string[]>;
    save(): Promise<void>;
    cancel(): void;
    private get getTicketId();
    static ɵfac: i0.ɵɵFactoryDeclaration<CallsSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CallsSidesheetComponent, "imx-calls-sidesheet", never, {}, {}, never, never, false>;
}
