import * as i0 from "@angular/core";
import * as i1 from "./calls.component";
import * as i2 from "./calls-sidesheet/calls-sidesheet.component";
import * as i3 from "./calls-history/calls-history.component";
import * as i4 from "./calls-history-sidesheet/calls-history-sidesheet.component";
import * as i5 from "./calls-attachment/calls-attachment.component";
import * as i6 from "./calls-attachment/calls-attachment-dialog/calls-attachment-dialog.component";
import * as i7 from "@angular/common";
import * as i8 from "@angular/forms";
import * as i9 from "@elemental-ui/core";
import * as i10 from "qbm";
import * as i11 from "@ngx-translate/core";
export declare class CallsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CallsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CallsModule, [typeof i1.CallsComponent, typeof i2.CallsSidesheetComponent, typeof i3.CallsHistoryComponent, typeof i4.CallsHistorySidesheetComponent, typeof i5.CallsAttachmentComponent, typeof i6.CallsAttachmentDialogComponent], [typeof i7.CommonModule, typeof i8.FormsModule, typeof i8.ReactiveFormsModule, typeof i9.EuiCoreModule, typeof i9.EuiMaterialModule, typeof i10.CdrModule, typeof i11.TranslateModule, typeof i10.DataSourceToolbarModule, typeof i10.DataTableModule, typeof i10.LdsReplaceModule, typeof i10.FkAdvancedPickerModule, typeof i10.SidenavTreeModule, typeof i10.DataTreeWrapperModule, typeof i10.HelpContextualModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CallsModule>;
}
