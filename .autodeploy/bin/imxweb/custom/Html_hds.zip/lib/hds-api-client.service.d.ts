import { V2Client, TypedClient } from 'imx-api-hds';
import { ApiClient } from 'imx-qbm-dbts';
import { AppConfigService, ClassloggerService, ImxTranslationProviderService } from 'qbm';
import * as i0 from "@angular/core";
export declare class HdsApiService {
    private readonly config;
    private readonly logger;
    private readonly translationProvider;
    private tc;
    get typedClient(): TypedClient;
    private c;
    get client(): V2Client;
    get apiClient(): ApiClient;
    constructor(config: AppConfigService, logger: ClassloggerService, translationProvider: ImxTranslationProviderService);
    static ɵfac: i0.ɵɵFactoryDeclaration<HdsApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HdsApiService>;
}
