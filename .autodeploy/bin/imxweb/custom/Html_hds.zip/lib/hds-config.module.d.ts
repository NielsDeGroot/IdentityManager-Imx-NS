import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "./calls/calls.module";
import * as i2 from "@angular/router";
export declare class HdsConfigModule {
    private readonly initializer;
    constructor(initializer: InitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<HdsConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HdsConfigModule, never, [typeof i1.CallsModule, typeof i2.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HdsConfigModule>;
}
