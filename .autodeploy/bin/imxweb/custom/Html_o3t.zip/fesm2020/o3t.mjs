import * as i5 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { NgModule, Injectable, Component, Inject, Input } from '@angular/core';
import * as i4 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i3 from '@elemental-ui/core';
import { EuiCoreModule, EUI_SIDESHEET_DATA, EuiMaterialModule } from '@elemental-ui/core';
import * as i2 from 'qbm';
import { BaseCdr, CdrModule, DataSourceToolbarModule, DataTableModule } from 'qbm';
import * as i12 from 'imx-api-o3t';
import { V2Client, TypedClient } from 'imx-api-o3t';
import { DisplayColumns } from 'imx-qbm-dbts';
import * as i1 from '@angular/forms';
import { UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i4$1 from 'tsb';
import { GroupSidesheetComponent } from 'tsb';
import * as i6 from '@angular/material/badge';
import * as i7 from '@angular/material/button';
import * as i8 from '@angular/material/card';
import * as i11 from '@angular/material/tabs';
import * as i10 from '@angular/material/tooltip';
import { RouterModule } from '@angular/router';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class O3TConfigModule {
    constructor(logger) {
        this.logger = logger;
        this.logger.info(this, '🔥 O3T loaded');
        this.logger.info(this, '▶️ O3T initialized');
    }
}
O3TConfigModule.ɵfac = function O3TConfigModule_Factory(t) { return new (t || O3TConfigModule)(i0.ɵɵinject(i2.ClassloggerService)); };
O3TConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: O3TConfigModule });
O3TConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        TranslateModule,
        EuiCoreModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(O3TConfigModule, [{
        type: NgModule,
        args: [{
                declarations: [],
                imports: [
                    CommonModule,
                    TranslateModule,
                    EuiCoreModule
                ]
            }]
    }], function () { return [{ type: i2.ClassloggerService }]; }, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(O3TConfigModule, { imports: [CommonModule,
        TranslateModule,
        EuiCoreModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing O3T API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
ApiService.ɵfac = function ApiService_Factory(t) { return new (t || ApiService)(i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ImxTranslationProviderService)); };
ApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApiService, factory: ApiService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i2.AppConfigService }, { type: i2.ClassloggerService }, { type: i2.ImxTranslationProviderService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TeamsService {
    constructor(o3tApiClient, busyService) {
        this.o3tApiClient = o3tApiClient;
        this.busyService = busyService;
    }
    get teamsSchema() {
        return this.o3tApiClient.typedClient.PortalTargetsystemTeams.GetSchema();
    }
    get teamChannelsSchema() {
        return this.o3tApiClient.typedClient.PortalTargetsystemTeamsChannels.GetSchema();
    }
    async getTeams(navigationState) {
        return this.o3tApiClient.typedClient.PortalTargetsystemTeams.Get(navigationState);
    }
    async getTeamChannels(uidO3tTeam, navigationState) {
        return this.o3tApiClient.typedClient.PortalTargetsystemTeamsChannels.Get(uidO3tTeam, navigationState);
    }
    handleOpenLoader() {
        if (!this.busyIndicator) {
            this.busyIndicator = this.busyService.show();
        }
    }
    handleCloseLoader() {
        if (this.busyIndicator) {
            setTimeout(() => {
                this.busyService.hide(this.busyIndicator);
                this.busyIndicator = undefined;
            });
        }
    }
}
TeamsService.ɵfac = function TeamsService_Factory(t) { return new (t || TeamsService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i3.EuiLoadingService)); };
TeamsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TeamsService, factory: TeamsService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: ApiService }, { type: i3.EuiLoadingService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function TeamChannelDetailsComponent_ng_template_3_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 12);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵproperty("matBadgeDescription", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
} }
function TeamChannelDetailsComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 10);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelementStart(2, "span", 8);
    i0.ɵɵtext(3, "#LDS#Heading Details");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, TeamChannelDetailsComponent_ng_template_3_span_4_Template, 2, 3, "span", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, ctx_r0.formGroup.dirty ? "#LDS#You have unsaved changes" : ""));
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("ngIf", ctx_r0.formGroup.dirty);
} }
function TeamChannelDetailsComponent_imx_cdr_editor_8_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 13);
    i0.ɵɵlistener("controlCreated", function TeamChannelDetailsComponent_imx_cdr_editor_8_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.formArray.push($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r3 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r3);
} }
class TeamChannelDetailsComponent {
    constructor(formBuilder, teamChannel, teamsService, sidesheetRef, snackbar) {
        this.teamChannel = teamChannel;
        this.teamsService = teamsService;
        this.sidesheetRef = sidesheetRef;
        this.snackbar = snackbar;
        this.cdrList = [];
        this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.formGroup.get('formArray');
    }
    ngOnInit() {
        this.setup();
    }
    async saveChanges() {
        this.teamsService.handleOpenLoader();
        try {
            await this.teamChannel.GetEntity().Commit(true);
            this.formGroup.markAsPristine();
            this.snackbar.open({ key: '#LDS#Your changes have been successfully saved.' });
        }
        finally {
            this.teamsService.handleCloseLoader();
        }
    }
    cancel() {
        this.sidesheetRef.close();
    }
    setup() {
        this.cdrList = [
            new BaseCdr(this.teamChannel.DisplayName.Column),
            new BaseCdr(this.teamChannel.Description.Column),
        ];
    }
}
TeamChannelDetailsComponent.ɵfac = function TeamChannelDetailsComponent_Factory(t) { return new (t || TeamChannelDetailsComponent)(i0.ɵɵdirectiveInject(i1.UntypedFormBuilder), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(TeamsService), i0.ɵɵdirectiveInject(i3.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.SnackBarService)); };
TeamChannelDetailsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TeamChannelDetailsComponent, selectors: [["imx-team-channel-details"]], decls: 16, vars: 3, consts: [[1, "governance-sidesheet"], ["mat-tab-label", ""], [1, "governance-sidesheet__tab-content"], [1, "governance-sidesheet__tab-content-body"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [1, "governance-sidesheet__action-buttons"], ["mat-button", "", "data-imx-identifier", "group-sidesheet-button-cancel", 3, "click"], ["translate", ""], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-save-group", 3, "disabled", "click"], [3, "matTooltip"], ["matBadge", "*", "matBadgePosition", "above after", "matBadgeSize", "small", 3, "matBadgeDescription", 4, "ngIf"], ["matBadge", "*", "matBadgePosition", "above after", "matBadgeSize", "small", 3, "matBadgeDescription"], [3, "cdr", "controlCreated"]], template: function TeamChannelDetailsComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "mat-tab-group")(2, "mat-tab");
        i0.ɵɵtemplate(3, TeamChannelDetailsComponent_ng_template_3_Template, 5, 4, "ng-template", 1);
        i0.ɵɵelementStart(4, "div", 2)(5, "div", 3)(6, "mat-card")(7, "form", 4);
        i0.ɵɵtemplate(8, TeamChannelDetailsComponent_imx_cdr_editor_8_Template, 1, 1, "imx-cdr-editor", 5);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(9, "mat-card", 6)(10, "button", 7);
        i0.ɵɵlistener("click", function TeamChannelDetailsComponent_Template_button_click_10_listener() { return ctx.cancel(); });
        i0.ɵɵelementStart(11, "span", 8);
        i0.ɵɵtext(12, "#LDS#Cancel");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(13, "button", 9);
        i0.ɵɵlistener("click", function TeamChannelDetailsComponent_Template_button_click_13_listener() { return ctx.saveChanges(); });
        i0.ɵɵelementStart(14, "span", 8);
        i0.ɵɵtext(15, "#LDS#Save");
        i0.ɵɵelementEnd()()()()()()();
    } if (rf & 2) {
        i0.ɵɵadvance(7);
        i0.ɵɵproperty("formGroup", ctx.formGroup);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx.cdrList);
        i0.ɵɵadvance(5);
        i0.ɵɵproperty("disabled", ctx.formGroup.pristine || ctx.formGroup.invalid);
    } }, dependencies: [i5.NgForOf, i5.NgIf, i1.ɵNgNoValidate, i1.NgControlStatusGroup, i1.FormGroupDirective, i6.MatBadge, i7.MatButton, i8.MatCard, i11.MatTabGroup, i11.MatTabLabel, i11.MatTab, i10.MatTooltip, i2.CdrEditorComponent, i4.TranslateDirective, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamChannelDetailsComponent, [{
        type: Component,
        args: [{ selector: 'imx-team-channel-details', template: "<div class=\"governance-sidesheet\">\r\n  <mat-tab-group>\r\n    <mat-tab>\r\n      <ng-template mat-tab-label>\r\n        <div [matTooltip]=\"(formGroup.dirty ? '#LDS#You have unsaved changes' : '') | translate\">\r\n          <span translate>#LDS#Heading Details</span>\r\n          <span *ngIf=\"formGroup.dirty\"\r\n            matBadge=\"*\" matBadgePosition=\"above after\" matBadgeSize=\"small\"\r\n            [matBadgeDescription]=\"'#LDS#You have unsaved changes.' | translate\">\r\n          </span>\r\n        </div>\r\n      </ng-template>\r\n      <div class=\"governance-sidesheet__tab-content\">\r\n        <div class=\"governance-sidesheet__tab-content-body\">\r\n          <mat-card>\r\n            <form [formGroup]=\"formGroup\">\r\n              <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"></imx-cdr-editor>\r\n            </form>\r\n          </mat-card>\r\n        </div>\r\n        <mat-card class=\"governance-sidesheet__action-buttons\">\r\n\r\n          <button mat-button (click)=\"cancel()\" data-imx-identifier=\"group-sidesheet-button-cancel\">\r\n            <span translate>#LDS#Cancel</span>\r\n          </button>\r\n\r\n          <button mat-flat-button color=\"primary\" data-imx-identifier=\"group-sidesheet-button-save-group\"\r\n            (click)=\"saveChanges()\"\r\n            [disabled]=\"formGroup.pristine || formGroup.invalid\">\r\n            <span translate>#LDS#Save</span>\r\n          </button>\r\n        </mat-card>\r\n      </div>\r\n    </mat-tab>\r\n\r\n  </mat-tab-group>\r\n\r\n</div>\r\n" }]
    }], function () { return [{ type: i1.UntypedFormBuilder }, { type: i12.PortalTargetsystemTeamsChannels, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: TeamsService }, { type: i3.EuiSidesheetRef }, { type: i2.SnackBarService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function TeamChannelsComponent_ng_template_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "a", 10);
    i0.ɵɵlistener("click", function TeamChannelsComponent_ng_template_10_Template_a_click_1_listener($event) { return $event.stopPropagation(); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("href", item_r3.WebUrl.Column.GetValue(), i0.ɵɵsanitizeUrl);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#View channel"));
} }
const _c0$1 = function () { return ["namespace"]; };
class TeamChannelsComponent {
    constructor(sideSheet, logger, settingsService, teamsService, translate) {
        this.sideSheet = sideSheet;
        this.logger = logger;
        this.teamsService = teamsService;
        this.translate = translate;
        this.filterOptions = [];
        this.DisplayColumns = DisplayColumns;
        this.displayedColumns = [];
        this.navigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaTeamChannels = this.teamsService.teamChannelsSchema;
    }
    async ngOnInit() {
        this.displayedColumns = [
            this.entitySchemaTeamChannels.Columns.DisplayName,
            this.entitySchemaTeamChannels.Columns.Description,
            this.entitySchemaTeamChannels.Columns.WebUrl,
        ];
        await this.navigate();
    }
    async onNavigationStateChanged(newState) {
        if (newState) {
            this.navigationState = newState;
        }
        await this.navigate();
    }
    async onSearch(keywords) {
        this.logger.debug(this, `Searching for: ${keywords}`);
        this.navigationState.StartIndex = 0;
        this.navigationState.search = keywords;
        await this.navigate();
    }
    async onTeamChannelChanged(channel) {
        this.logger.debug(this, `Selected channel changed`);
        this.logger.trace(this, `New channel selected`, channel);
        this.openDetailsSidesheet(channel);
    }
    async navigate() {
        this.teamsService.handleOpenLoader();
        try {
            const data = await this.teamsService.getTeamChannels(this.uidO3t, this.navigationState);
            this.dstSettings = {
                displayedColumns: this.displayedColumns,
                dataSource: data,
                entitySchema: this.entitySchemaTeamChannels,
                navigationState: this.navigationState,
                filters: this.filterOptions,
            };
            this.logger.debug(this, `Head at ${data.Data.length + this.navigationState.StartIndex} of ${data.totalCount} item(s)`);
        }
        finally {
            this.teamsService.handleCloseLoader();
        }
    }
    async openDetailsSidesheet(channel) {
        const sidesheetRef = this.sideSheet.open(TeamChannelDetailsComponent, {
            title: await this.translate.get('#LDS#Heading View Microsoft Teams Channel Details').toPromise(),
            subTitle: channel.GetEntity().GetDisplay(),
            padding: '0px',
            width: `max(650px, 60%)`,
            icon: 'usergroup',
            testId: 'teams-channel-view-team-channel-details',
            data: channel
        });
        // After the sidesheet closes, reload the current data to refresh any changes that might have been made
        sidesheetRef.afterClosed().subscribe(() => this.navigate());
    }
}
TeamChannelsComponent.ɵfac = function TeamChannelsComponent_Factory(t) { return new (t || TeamChannelsComponent)(i0.ɵɵdirectiveInject(i3.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(TeamsService), i0.ɵɵdirectiveInject(i4.TranslateService)); };
TeamChannelsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TeamChannelsComponent, selectors: [["imx-team-channels"]], inputs: { uidO3t: "uidO3t" }, decls: 12, vars: 13, consts: [[1, "data-explorer"], [3, "settings", "hiddenFilters", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], [1, "data-explorer-table"], ["mode", "manual", "detailViewVisible", "false", "data-imx-identifier", "team-channels-tabledata-table", "noDataText", "#LDS#There are currently no team channels.", 3, "dst", "selectable", "highlightedEntityChanged"], ["membersTable", ""], ["data-imx-identifier", "team-channels-table-column-display", 3, "entityColumn"], [3, "entityColumn"], ["alignHeader", "center", "alignContent", "center", 3, "columnName", "columnLabel"], [3, "dst"], ["data-imx-identifier", "team-channels-table-view-channel", "target", "_blank", 3, "href", "click"]], template: function TeamChannelsComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "imx-data-source-toolbar", 1, 2);
        i0.ɵɵlistener("navigationStateChanged", function TeamChannelsComponent_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function TeamChannelsComponent_Template_imx_data_source_toolbar_search_1_listener($event) { return ctx.onSearch($event); });
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "div", 3)(5, "imx-data-table", 4, 5);
        i0.ɵɵlistener("highlightedEntityChanged", function TeamChannelsComponent_Template_imx_data_table_highlightedEntityChanged_5_listener($event) { return ctx.onTeamChannelChanged($event); });
        i0.ɵɵelement(7, "imx-data-table-column", 6)(8, "imx-data-table-column", 7);
        i0.ɵɵelementStart(9, "imx-data-table-generic-column", 8);
        i0.ɵɵtemplate(10, TeamChannelsComponent_ng_template_10_Template, 4, 4, "ng-template");
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(11, "imx-data-source-paginator", 9);
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        const _r0 = i0.ɵɵreference(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("settings", ctx.dstSettings)("hiddenFilters", i0.ɵɵpureFunction0(12, _c0$1))("searchBoxText", i0.ɵɵpipeBind1(3, 10, "#LDS#Search"));
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("dst", _r0)("selectable", false);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchemaTeamChannels == null ? null : ctx.entitySchemaTeamChannels.Columns.DisplayName);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx.entitySchemaTeamChannels == null ? null : ctx.entitySchemaTeamChannels.Columns.Description);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("columnName", ctx.entitySchemaTeamChannels.Columns.WebUrl.ColumnName)("columnLabel", ctx.entitySchemaTeamChannels.Columns.WebUrl.Display);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r0);
    } }, dependencies: [i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamChannelsComponent, [{
        type: Component,
        args: [{ selector: 'imx-team-channels', template: "\r\n<div class=\"data-explorer\">\r\n\r\n\r\n  <imx-data-source-toolbar #dst\r\n    [settings]=\"dstSettings\"\r\n    [hiddenFilters]=\"['namespace']\"\r\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n    (search)=\"onSearch($event)\"\r\n    [searchBoxText]=\"'#LDS#Search' | translate\">\r\n  </imx-data-source-toolbar>\r\n\r\n  <div class=\"data-explorer-table\">\r\n    <imx-data-table #membersTable [dst]=\"dst\" mode=\"manual\" detailViewVisible=\"false\" data-imx-identifier=\"team-channels-tabledata-table\"\r\n      noDataText=\"#LDS#There are currently no team channels.\"\r\n      [selectable]=\"false\" (highlightedEntityChanged)=\"onTeamChannelChanged($event)\">\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaTeamChannels?.Columns.DisplayName\" data-imx-identifier=\"team-channels-table-column-display\">\r\n      </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaTeamChannels?.Columns.Description\">\r\n      </imx-data-table-column>\r\n      <imx-data-table-generic-column alignHeader=\"center\" alignContent=\"center\"\r\n        [columnName]=\"entitySchemaTeamChannels.Columns.WebUrl.ColumnName\"\r\n        [columnLabel]=\"entitySchemaTeamChannels.Columns.WebUrl.Display\">\r\n        <ng-template let-item>\r\n          <div>\r\n            <a data-imx-identifier=\"team-channels-table-view-channel\" (click)=\"$event.stopPropagation()\" [href]=\"item.WebUrl.Column.GetValue()\" target=\"_blank\">{{ '#LDS#View channel' | translate }}</a>\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-generic-column>\r\n    </imx-data-table>\r\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n  </div>\r\n\r\n</div>\r\n" }]
    }], function () { return [{ type: i3.EuiSidesheetService }, { type: i2.ClassloggerService }, { type: i2.SettingsService }, { type: TeamsService }, { type: i4.TranslateService }]; }, { uidO3t: [{
            type: Input
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function TeamDetailsComponent_ng_template_3_span_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 15);
    i0.ɵɵpipe(1, "translate");
} if (rf & 2) {
    i0.ɵɵproperty("matBadgeDescription", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
} }
function TeamDetailsComponent_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 13);
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelementStart(2, "span", 9);
    i0.ɵɵtext(3, "#LDS#Heading Details");
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(4, TeamDetailsComponent_ng_template_3_span_4_Template, 2, 3, "span", 14);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, ctx_r0.formGroup.dirty ? "#LDS#You have unsaved changes" : ""));
    i0.ɵɵadvance(4);
    i0.ɵɵproperty("ngIf", ctx_r0.formGroup.dirty);
} }
function TeamDetailsComponent_imx_cdr_editor_8_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "imx-cdr-editor", 16);
    i0.ɵɵlistener("controlCreated", function TeamDetailsComponent_imx_cdr_editor_8_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r7); const ctx_r6 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r6.formArray.push($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdr_r5 = ctx.$implicit;
    i0.ɵɵproperty("cdr", cdr_r5);
} }
function TeamDetailsComponent_button_10_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 17);
    i0.ɵɵlistener("click", function TeamDetailsComponent_button_10_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r9); const ctx_r8 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r8.viewGroup()); });
    i0.ɵɵelementStart(1, "span", 9);
    i0.ɵɵtext(2, "#LDS#View Office 365 group");
    i0.ɵɵelementEnd()();
} }
function TeamDetailsComponent_ng_template_19_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 2)(1, "div", 3);
    i0.ɵɵelement(2, "imx-team-channels", 18);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "mat-card", 6)(4, "button", 8);
    i0.ɵɵlistener("click", function TeamDetailsComponent_ng_template_19_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r10.cancel()); });
    i0.ɵɵelementStart(5, "span", 9);
    i0.ɵɵtext(6, "#LDS#Cancel");
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("uidO3t", ctx_r3.teamId);
} }
class TeamDetailsComponent {
    constructor(formBuilder, team, teamsService, sidesheet, sidesheetRef, groupsService, snackbar, translate) {
        this.team = team;
        this.teamsService = teamsService;
        this.sidesheet = sidesheet;
        this.sidesheetRef = sidesheetRef;
        this.groupsService = groupsService;
        this.snackbar = snackbar;
        this.translate = translate;
        this.cdrList = [];
        this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
    }
    get formArray() {
        return this.formGroup.get('formArray');
    }
    get teamId() {
        return this.team?.GetEntity().GetKeys().join('');
    }
    ngOnInit() {
        this.setup();
    }
    async saveChanges() {
        this.teamsService.handleOpenLoader();
        try {
            this.team.GetEntity().Commit(true);
            this.formGroup.markAsPristine();
            this.snackbar.open({ key: '#LDS#Your changes have been successfully saved.' });
        }
        finally {
            this.teamsService.handleCloseLoader();
        }
    }
    cancel() {
        this.sidesheetRef.close();
    }
    async viewGroup() {
        let data;
        this.teamsService.handleOpenLoader();
        try {
            const unsGroupDbObjectKey = { TableName: 'O3EUnifiedGroup', Keys: [this.team.UID_O3EUnifiedGroup.value] };
            const o3tGroup = await this.groupsService.getGroupDetails(unsGroupDbObjectKey);
            const uidAccProduct = o3tGroup?.GetEntity().GetColumn('UID_AccProduct').GetValue();
            const serviceItem = await this.groupsService.getGroupServiceItem(uidAccProduct);
            data = {
                uidAccProduct,
                unsGroupDbObjectKey,
                group: o3tGroup,
                groupServiceItem: serviceItem
            };
        }
        finally {
            this.teamsService.handleCloseLoader();
        }
        this.openGroupSidesheet(data);
    }
    async openGroupSidesheet(data) {
        this.sidesheet.open(GroupSidesheetComponent, {
            title: await this.translate.get('#LDS#Heading Edit System Entitlement').toPromise(),
            subTitle: this.team.GetEntity().GetDisplay(),
            padding: '0px',
            width: 'max(650px, 60%)',
            icon: 'usergroup',
            testId: 'teams-details-view-group-details',
            data
        });
    }
    setup() {
        this.cdrList = [
            new BaseCdr(this.team.tmsAllowDeleteChannels.Column),
            new BaseCdr(this.team.tmsAllowCreateUpdateRemoveTabs.Column),
            new BaseCdr(this.team.tmsAllowCreateUpdateRemoveConn.Column),
            new BaseCdr(this.team.tmsAllowCreateUpdateChannels.Column),
            new BaseCdr(this.team.tmsAllowAddRemoveApps.Column),
            new BaseCdr(this.team.msAllowUserEditMessages.Column),
            new BaseCdr(this.team.msAllowUserDeleteMessages.Column),
            new BaseCdr(this.team.msAllowTeamMentions.Column),
            new BaseCdr(this.team.msAllowOwnerDeleteMessages.Column),
            new BaseCdr(this.team.msAllowChannelMentions.Column),
            new BaseCdr(this.team.gsAllowDeleteChannels.Column),
            new BaseCdr(this.team.IsArchived.Column),
            new BaseCdr(this.team.gsAllowCreateUpdateChannels.Column),
            new BaseCdr(this.team.fsGiphyContentRating.Column),
            new BaseCdr(this.team.fsAllowStickersAndMemes.Column),
            new BaseCdr(this.team.fsAllowGiphy.Column),
            new BaseCdr(this.team.fsAllowCustomMemes.Column)
        ];
    }
}
TeamDetailsComponent.ɵfac = function TeamDetailsComponent_Factory(t) { return new (t || TeamDetailsComponent)(i0.ɵɵdirectiveInject(i1.UntypedFormBuilder), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(TeamsService), i0.ɵɵdirectiveInject(i3.EuiSidesheetService), i0.ɵɵdirectiveInject(i3.EuiSidesheetRef), i0.ɵɵdirectiveInject(i4$1.GroupsService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i4.TranslateService)); };
TeamDetailsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TeamDetailsComponent, selectors: [["imx-team-details"]], decls: 20, vars: 7, consts: [[1, "governance-sidesheet"], ["mat-tab-label", ""], [1, "governance-sidesheet__tab-content"], [1, "governance-sidesheet__tab-content-body"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [1, "governance-sidesheet__action-buttons"], ["mat-button", "", "class", "justify-start", "data-imx-identifier", "group-sidesheet-button-cancel", 3, "click", 4, "ngIf"], ["mat-button", "", "data-imx-identifier", "group-sidesheet-button-cancel", 3, "click"], ["translate", ""], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-save-group", 3, "disabled", "click"], [3, "label"], ["matTabContent", ""], [3, "matTooltip"], ["matBadge", "*", "matBadgePosition", "above after", "matBadgeSize", "small", 3, "matBadgeDescription", 4, "ngIf"], ["matBadge", "*", "matBadgePosition", "above after", "matBadgeSize", "small", 3, "matBadgeDescription"], [3, "cdr", "controlCreated"], ["mat-button", "", "data-imx-identifier", "group-sidesheet-button-cancel", 1, "justify-start", 3, "click"], [3, "uidO3t"]], template: function TeamDetailsComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "mat-tab-group")(2, "mat-tab");
        i0.ɵɵtemplate(3, TeamDetailsComponent_ng_template_3_Template, 5, 4, "ng-template", 1);
        i0.ɵɵelementStart(4, "div", 2)(5, "div", 3)(6, "mat-card")(7, "form", 4);
        i0.ɵɵtemplate(8, TeamDetailsComponent_imx_cdr_editor_8_Template, 1, 1, "imx-cdr-editor", 5);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(9, "mat-card", 6);
        i0.ɵɵtemplate(10, TeamDetailsComponent_button_10_Template, 3, 0, "button", 7);
        i0.ɵɵelementStart(11, "button", 8);
        i0.ɵɵlistener("click", function TeamDetailsComponent_Template_button_click_11_listener() { return ctx.cancel(); });
        i0.ɵɵelementStart(12, "span", 9);
        i0.ɵɵtext(13, "#LDS#Cancel");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(14, "button", 10);
        i0.ɵɵlistener("click", function TeamDetailsComponent_Template_button_click_14_listener() { return ctx.saveChanges(); });
        i0.ɵɵelementStart(15, "span", 9);
        i0.ɵɵtext(16, "#LDS#Save");
        i0.ɵɵelementEnd()()()()();
        i0.ɵɵelementStart(17, "mat-tab", 11);
        i0.ɵɵpipe(18, "translate");
        i0.ɵɵtemplate(19, TeamDetailsComponent_ng_template_19_Template, 7, 1, "ng-template", 12);
        i0.ɵɵelementEnd()()();
    } if (rf & 2) {
        i0.ɵɵadvance(7);
        i0.ɵɵproperty("formGroup", ctx.formGroup);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx.cdrList);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.team == null ? null : ctx.team.UID_O3EUnifiedGroup == null ? null : ctx.team.UID_O3EUnifiedGroup.value == null ? null : ctx.team.UID_O3EUnifiedGroup.value.length);
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("disabled", ctx.formGroup.pristine || ctx.formGroup.invalid);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(18, 5, "#LDS#Heading Channels"));
    } }, dependencies: [i5.NgForOf, i5.NgIf, i1.ɵNgNoValidate, i1.NgControlStatusGroup, i1.FormGroupDirective, i6.MatBadge, i7.MatButton, i8.MatCard, i11.MatTabGroup, i11.MatTabLabel, i11.MatTab, i11.MatTabContent, i10.MatTooltip, i2.CdrEditorComponent, i4.TranslateDirective, TeamChannelsComponent, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamDetailsComponent, [{
        type: Component,
        args: [{ selector: 'imx-team-details', template: "<div class=\"governance-sidesheet\">\r\n  <mat-tab-group>\r\n    <mat-tab>\r\n      <ng-template mat-tab-label>\r\n        <div [matTooltip]=\"(formGroup.dirty ? '#LDS#You have unsaved changes' : '') | translate\">\r\n          <span translate>#LDS#Heading Details</span>\r\n          <span *ngIf=\"formGroup.dirty\"\r\n            matBadge=\"*\" matBadgePosition=\"above after\" matBadgeSize=\"small\"\r\n            [matBadgeDescription]=\"'#LDS#You have unsaved changes.' | translate\">\r\n          </span>\r\n        </div>\r\n      </ng-template>\r\n      <div class=\"governance-sidesheet__tab-content\">\r\n        <div class=\"governance-sidesheet__tab-content-body\">\r\n          <mat-card>\r\n            <form [formGroup]=\"formGroup\">\r\n              <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"></imx-cdr-editor>\r\n            </form>\r\n          </mat-card>\r\n        </div>\r\n        <mat-card class=\"governance-sidesheet__action-buttons\">\r\n\r\n          <button *ngIf=\"team?.UID_O3EUnifiedGroup?.value?.length\" mat-button class=\"justify-start\"\r\n            (click)=\"viewGroup()\" data-imx-identifier=\"group-sidesheet-button-cancel\">\r\n            <span translate>#LDS#View Office 365 group</span>\r\n          </button>\r\n\r\n          <button mat-button (click)=\"cancel()\" data-imx-identifier=\"group-sidesheet-button-cancel\">\r\n            <span translate>#LDS#Cancel</span>\r\n          </button>\r\n\r\n          <button mat-flat-button color=\"primary\" data-imx-identifier=\"group-sidesheet-button-save-group\"\r\n            (click)=\"saveChanges()\"\r\n            [disabled]=\"formGroup.pristine || formGroup.invalid\">\r\n            <span translate>#LDS#Save</span>\r\n          </button>\r\n        </mat-card>\r\n      </div>\r\n    </mat-tab>\r\n\r\n    <mat-tab [label]=\"'#LDS#Heading Channels' | translate\">\r\n      <ng-template matTabContent>\r\n        <div class=\"governance-sidesheet__tab-content\">\r\n          <div class=\"governance-sidesheet__tab-content-body\">\r\n              <imx-team-channels [uidO3t]=\"teamId\"></imx-team-channels>\r\n          </div>\r\n          <mat-card class=\"governance-sidesheet__action-buttons\">\r\n\r\n            <button mat-button (click)=\"cancel()\" data-imx-identifier=\"group-sidesheet-button-cancel\">\r\n              <span translate>#LDS#Cancel</span>\r\n            </button>\r\n\r\n          </mat-card>\r\n        </div>\r\n      </ng-template>\r\n    </mat-tab>\r\n\r\n  </mat-tab-group>\r\n\r\n</div>\r\n" }]
    }], function () { return [{ type: i1.UntypedFormBuilder }, { type: i12.PortalTargetsystemTeams, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: TeamsService }, { type: i3.EuiSidesheetService }, { type: i3.EuiSidesheetRef }, { type: i4$1.GroupsService }, { type: i2.SnackBarService }, { type: i4.TranslateService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function TeamsComponent_ng_template_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "a", 14);
    i0.ɵɵlistener("click", function TeamsComponent_ng_template_15_Template_a_click_1_listener($event) { return $event.stopPropagation(); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const item_r3 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("href", item_r3.WebUrl.Column.GetValue(), i0.ɵɵsanitizeUrl);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(3, 2, "#LDS#View team"), " ");
} }
const _c0 = function () { return ["search", "filter"]; };
const _c1 = function () { return ["namespace"]; };
class TeamsComponent {
    constructor(sideSheet, logger, settingsService, teamsService, translate) {
        this.sideSheet = sideSheet;
        this.logger = logger;
        this.teamsService = teamsService;
        this.translate = translate;
        this.sidesheetWidth = '65%';
        this.filterOptions = [];
        this.DisplayColumns = DisplayColumns;
        this.displayedColumns = [];
        this.navigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaTeams = this.teamsService.teamsSchema;
    }
    async ngOnInit() {
        this.displayedColumns = [
            this.entitySchemaTeams.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchemaTeams.Columns.UID_O3EUnifiedGroup,
            this.entitySchemaTeams.Columns.WebUrl,
        ];
        await this.navigate();
    }
    async onNavigationStateChanged(newState) {
        if (newState) {
            this.navigationState = newState;
        }
        await this.navigate();
    }
    async onSearch(keywords) {
        this.logger.debug(this, `Searching for: ${keywords}`);
        this.navigationState.StartIndex = 0;
        this.navigationState.search = keywords;
        await this.navigate();
    }
    async onTeamChanged(team) {
        this.logger.debug(this, `Selected team changed`);
        this.logger.trace(this, `New team selected`, team);
        this.openDetailsSidesheet(team);
    }
    async navigate() {
        this.teamsService.handleOpenLoader();
        try {
            const data = await this.teamsService.getTeams(this.navigationState);
            this.dstSettings = {
                displayedColumns: this.displayedColumns,
                dataSource: data,
                entitySchema: this.entitySchemaTeams,
                navigationState: this.navigationState,
                filters: this.filterOptions,
            };
            this.logger.debug(this, `Head at ${data.Data.length + this.navigationState.StartIndex} of ${data.totalCount} item(s)`);
        }
        finally {
            this.teamsService.handleCloseLoader();
        }
    }
    async openDetailsSidesheet(data) {
        const sidesheetRef = this.sideSheet.open(TeamDetailsComponent, {
            title: await this.translate.get('#LDS#Heading View Microsoft Teams Team Details').toPromise(),
            subTitle: data.GetEntity().GetDisplay(),
            padding: '0px',
            width: `max(650px, ${this.sidesheetWidth})`,
            icon: 'usergroup',
            testId: 'teams-view-team-details',
            data
        });
        sidesheetRef.afterClosed().subscribe(() => this.navigate());
    }
}
TeamsComponent.ɵfac = function TeamsComponent_Factory(t) { return new (t || TeamsComponent)(i0.ɵɵdirectiveInject(i3.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(TeamsService), i0.ɵɵdirectiveInject(i4.TranslateService)); };
TeamsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TeamsComponent, selectors: [["imx-o3t-teams"]], inputs: { sidesheetWidth: "sidesheetWidth" }, decls: 17, vars: 15, consts: [[1, "data-explorer", "data-explorer--groups"], [1, "data-explorer-card-header"], [1, "data-explorer-card-header-bg"], ["icon", "usergroup", "size", "28px"], ["translate", ""], [3, "settings", "options", "hiddenFilters", "searchBoxText", "navigationStateChanged", "search"], ["dst", ""], [1, "data-explorer-table"], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "teams-tabledata-table", 3, "dst", "selectable", "highlightedEntityChanged"], ["dataTable", ""], ["data-imx-identifier", "teams-table-column-display", 3, "entityColumn"], [3, "entityColumn"], ["alignHeader", "center", "alignContent", "center", 3, "columnName", "columnLabel"], [3, "dst"], ["data-imx-identifier", "teams-table-view-team", "target", "_blank", 3, "href", "click"]], template: function TeamsComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 0)(1, "div", 1)(2, "div", 2);
        i0.ɵɵelement(3, "eui-icon", 3);
        i0.ɵɵelementStart(4, "span", 4);
        i0.ɵɵtext(5, "#LDS#Heading Teams");
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(6, "imx-data-source-toolbar", 5, 6);
        i0.ɵɵlistener("navigationStateChanged", function TeamsComponent_Template_imx_data_source_toolbar_navigationStateChanged_6_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function TeamsComponent_Template_imx_data_source_toolbar_search_6_listener($event) { return ctx.onSearch($event); });
        i0.ɵɵpipe(8, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(9, "div", 7)(10, "imx-data-table", 8, 9);
        i0.ɵɵlistener("highlightedEntityChanged", function TeamsComponent_Template_imx_data_table_highlightedEntityChanged_10_listener($event) { return ctx.onTeamChanged($event); });
        i0.ɵɵelement(12, "imx-data-table-column", 10)(13, "imx-data-table-column", 11);
        i0.ɵɵelementStart(14, "imx-data-table-generic-column", 12);
        i0.ɵɵtemplate(15, TeamsComponent_ng_template_15_Template, 4, 4, "ng-template");
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(16, "imx-data-source-paginator", 13);
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        const _r0 = i0.ɵɵreference(7);
        i0.ɵɵadvance(6);
        i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(13, _c0))("hiddenFilters", i0.ɵɵpureFunction0(14, _c1))("searchBoxText", i0.ɵɵpipeBind1(8, 11, "#LDS#Search"));
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("dst", _r0)("selectable", false);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchemaTeams == null ? null : ctx.entitySchemaTeams.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx.entitySchemaTeams == null ? null : ctx.entitySchemaTeams.Columns.UID_O3EUnifiedGroup);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("columnName", ctx.entitySchemaTeams.Columns.WebUrl.ColumnName)("columnLabel", ctx.entitySchemaTeams.Columns.WebUrl.Display);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r0);
    } }, dependencies: [i3.EuiIconComponent, i8.MatCard, i4.TranslateDirective, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i4.TranslatePipe], encapsulation: 2 });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamsComponent, [{
        type: Component,
        args: [{ selector: 'imx-o3t-teams', template: "<mat-card class=\"data-explorer data-explorer--groups\">\r\n\r\n  <div class=\"data-explorer-card-header\">\r\n    <div class=\"data-explorer-card-header-bg\">\r\n      <eui-icon icon=\"usergroup\" size=\"28px\"></eui-icon>\r\n      <span translate>#LDS#Heading Teams</span>\r\n    </div>\r\n  </div>\r\n\r\n  <imx-data-source-toolbar #dst\r\n    [settings]=\"dstSettings\"\r\n    [options]=\"['search', 'filter']\"\r\n    [hiddenFilters]=\"['namespace']\"\r\n    [searchBoxText]=\"'#LDS#Search' | translate\"\r\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n    (search)=\"onSearch($event)\">\r\n  </imx-data-source-toolbar>\r\n\r\n  <div class=\"data-explorer-table\">\r\n    <imx-data-table #dataTable [dst]=\"dst\" (highlightedEntityChanged)=\"onTeamChanged($event)\" detailViewVisible=\"false\"\r\n      [selectable]=\"false\" mode=\"manual\"\r\n      data-imx-identifier=\"teams-tabledata-table\">\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaTeams?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\"\r\n        data-imx-identifier=\"teams-table-column-display\">\r\n      </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaTeams?.Columns.UID_O3EUnifiedGroup\">\r\n      </imx-data-table-column>\r\n      <imx-data-table-generic-column alignHeader=\"center\" alignContent=\"center\"\r\n        [columnName]=\"entitySchemaTeams.Columns.WebUrl.ColumnName\"\r\n        [columnLabel]=\"entitySchemaTeams.Columns.WebUrl.Display\">\r\n        <ng-template let-item>\r\n          <div>\r\n            <a data-imx-identifier=\"teams-table-view-team\" (click)=\"$event.stopPropagation()\" [href]=\"item.WebUrl.Column.GetValue()\" target=\"_blank\">{{ '#LDS#View team' | translate }} </a>\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-generic-column>\r\n    </imx-data-table>\r\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n  </div>\r\n\r\n\r\n</mat-card>\r\n" }]
    }], function () { return [{ type: i3.EuiSidesheetService }, { type: i2.ClassloggerService }, { type: i2.SettingsService }, { type: TeamsService }, { type: i4.TranslateService }]; }, { sidesheetWidth: [{
            type: Input
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TeamsModule {
}
TeamsModule.ɵfac = function TeamsModule_Factory(t) { return new (t || TeamsModule)(); };
TeamsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: TeamsModule });
TeamsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        TeamsService
    ], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        RouterModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamsModule, [{
        type: NgModule,
        args: [{
                declarations: [TeamsComponent, TeamDetailsComponent, TeamChannelsComponent, TeamChannelDetailsComponent],
                imports: [
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    CdrModule,
                    RouterModule,
                    TranslateModule,
                    DataSourceToolbarModule,
                    DataTableModule
                ],
                providers: [
                    TeamsService
                ],
                exports: [
                    TeamsComponent
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(TeamsModule, { declarations: [TeamsComponent, TeamDetailsComponent, TeamChannelsComponent, TeamChannelDetailsComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        RouterModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule], exports: [TeamsComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of o3t
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiService, O3TConfigModule, TeamsComponent, TeamsModule };
//# sourceMappingURL=o3t.mjs.map
