import { ClassloggerService } from 'qbm';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@ngx-translate/core";
import * as i3 from "@elemental-ui/core";
export declare class O3TConfigModule {
    private readonly logger;
    constructor(logger: ClassloggerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<O3TConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<O3TConfigModule, never, [typeof i1.CommonModule, typeof i2.TranslateModule, typeof i3.EuiCoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<O3TConfigModule>;
}
