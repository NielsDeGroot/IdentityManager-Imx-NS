import { OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { PortalTargetsystemTeamsChannels } from 'imx-api-o3t';
import { ColumnDependentReference, SnackBarService } from 'qbm';
import { TeamsService } from '../teams.service';
import * as i0 from "@angular/core";
export declare class TeamChannelDetailsComponent implements OnInit {
    teamChannel: PortalTargetsystemTeamsChannels;
    private teamsService;
    private readonly sidesheetRef;
    private readonly snackbar;
    readonly formGroup: UntypedFormGroup;
    cdrList: ColumnDependentReference[];
    constructor(formBuilder: UntypedFormBuilder, teamChannel: PortalTargetsystemTeamsChannels, teamsService: TeamsService, sidesheetRef: EuiSidesheetRef, snackbar: SnackBarService);
    get formArray(): UntypedFormArray;
    ngOnInit(): void;
    saveChanges(): Promise<void>;
    cancel(): void;
    private setup;
    static ɵfac: i0.ɵɵFactoryDeclaration<TeamChannelDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TeamChannelDetailsComponent, "imx-team-channel-details", never, {}, {}, never, never, false>;
}
