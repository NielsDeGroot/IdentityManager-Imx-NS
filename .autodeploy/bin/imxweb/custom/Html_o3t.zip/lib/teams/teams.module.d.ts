import * as i0 from "@angular/core";
import * as i1 from "./teams.component";
import * as i2 from "./team-details/team-details.component";
import * as i3 from "./team-channels/team-channels.component";
import * as i4 from "./team-channel-details/team-channel-details.component";
import * as i5 from "@angular/common";
import * as i6 from "@angular/forms";
import * as i7 from "@elemental-ui/core";
import * as i8 from "qbm";
import * as i9 from "@angular/router";
import * as i10 from "@ngx-translate/core";
export declare class TeamsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TeamsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TeamsModule, [typeof i1.TeamsComponent, typeof i2.TeamDetailsComponent, typeof i3.TeamChannelsComponent, typeof i4.TeamChannelDetailsComponent], [typeof i5.CommonModule, typeof i6.FormsModule, typeof i6.ReactiveFormsModule, typeof i7.EuiCoreModule, typeof i7.EuiMaterialModule, typeof i8.CdrModule, typeof i9.RouterModule, typeof i10.TranslateModule, typeof i8.DataSourceToolbarModule, typeof i8.DataTableModule], [typeof i1.TeamsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TeamsModule>;
}
