import { ApiService } from '../api.service';
import { PortalTargetsystemTeams, PortalTargetsystemTeamsChannels } from 'imx-api-o3t';
import { CollectionLoadParameters, EntitySchema, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { EuiLoadingService } from '@elemental-ui/core';
import * as i0 from "@angular/core";
export declare class TeamsService {
    private readonly o3tApiClient;
    private readonly busyService;
    private busyIndicator;
    constructor(o3tApiClient: ApiService, busyService: EuiLoadingService);
    get teamsSchema(): EntitySchema;
    get teamChannelsSchema(): EntitySchema;
    getTeams(navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemTeams>>;
    getTeamChannels(uidO3tTeam: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemTeamsChannels>>;
    handleOpenLoader(): void;
    handleCloseLoader(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TeamsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TeamsService>;
}
