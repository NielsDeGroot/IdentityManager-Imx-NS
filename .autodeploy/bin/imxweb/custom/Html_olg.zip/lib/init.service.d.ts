import { Route, Router } from '@angular/router';
import { ExtService } from 'qbm';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly extService;
    private readonly router;
    constructor(extService: ExtService, router: Router);
    onInit(routes: Route[]): void;
    private addRoutes;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
