import { ActivateFactorData, AuthFactors } from 'imx-api-olg';
export declare abstract class MfaService {
    abstract activateFactor(workflowActionId: string, deviceId: string): Promise<ActivateFactorData>;
    abstract verifyWithVerificationId(workflowActionId: string, verificationId: string, code: string): Promise<boolean>;
    abstract verify(workflowActionId: string, code: string): Promise<boolean>;
    abstract getFactors(): Promise<AuthFactors>;
}
