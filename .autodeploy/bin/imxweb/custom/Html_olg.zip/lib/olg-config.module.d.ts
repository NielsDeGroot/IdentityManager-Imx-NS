import { ClassloggerService } from 'qbm';
import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "./mfa/mfa.component";
import * as i2 from "./mfa-form-control/mfa-form-control.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "@angular/material/form-field";
import * as i6 from "@angular/material/input";
import * as i7 from "@angular/material/card";
import * as i8 from "@angular/material/button";
import * as i9 from "@angular/material/divider";
import * as i10 from "@angular/router";
import * as i11 from "@ngx-translate/core";
import * as i12 from "@elemental-ui/core";
import * as i13 from "qbm";
import * as i14 from "@angular/material/progress-spinner";
export declare class OlgConfigModule {
    private readonly initializer;
    private readonly logger;
    constructor(initializer: InitService, logger: ClassloggerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<OlgConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OlgConfigModule, [typeof i1.MfaComponent, typeof i2.MfaFormControlComponent], [typeof i3.CommonModule, typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i5.MatFormFieldModule, typeof i6.MatInputModule, typeof i7.MatCardModule, typeof i8.MatButtonModule, typeof i9.MatDividerModule, typeof i10.RouterModule, typeof i11.TranslateModule, typeof i12.EuiCoreModule, typeof i13.CdrModule, typeof i13.BusyIndicatorModule, typeof i14.MatProgressSpinnerModule], [typeof i2.MfaFormControlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OlgConfigModule>;
}
