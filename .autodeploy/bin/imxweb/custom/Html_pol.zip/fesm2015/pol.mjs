import * as i9 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, Input, Inject, Injectable, ViewChild, NgModule } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import * as i3$1 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import * as i3 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i4 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i2$2 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i3$2 from 'qbm';
import { BaseReadonlyCdr, BaseCdr, BusyService, createGroupData, DataTableComponent, BulkPropertyEditorModule, CdrModule, DataTableModule, DataSourceToolbarModule, SelectedElementsModule, HelpContextualModule, HELP_CONTEXTUAL, RouteGuardService } from 'qbm';
import * as i2 from 'qer';
import { JustificationType, JustificationModule, StatisticsModule, ObjectHyperviewModule, TilesModule } from 'qer';
import { __awaiter, __rest } from 'tslib';
import { MethodDefinition, ValType, DbObjectKey, DisplayColumns } from 'imx-qbm-dbts';
import { Subject } from 'rxjs';
import { PortalPoliciesViolationslist, V2Client, TypedClient, V2ApiClientMethodFactory, PortalPoliciesViolations } from 'imx-api-pol';
import * as i4$1 from '@angular/forms';
import { UntypedFormGroup, FormControl, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import * as i5 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i1 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i2$1 from '@angular/material/core';
import * as i6 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i7 from '@angular/material/select';
import * as i8$1 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i8 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';

function DashboardPluginComponent_imx_badge_tile_0_Template(rf, ctx) {
    if (rf & 1) {
        const _r2 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-badge-tile", 1);
        i0.ɵɵlistener("actionClick", function DashboardPluginComponent_imx_badge_tile_0_Template_imx_badge_tile_actionClick_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.router.navigate(["compliance", "policyviolations", "approve"])); });
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("caption", i0.ɵɵpipeBind1(1, 3, "#LDS#Heading Pending Policy Violations"))("value", ctx_r0.pendingItems == null ? null : ctx_r0.pendingItems.OpenQERPolicyHasObject)("identifier", "pol-rule-violation-approvals");
    }
}
class DashboardPluginComponent {
    constructor(router, dashboardService, userModelSvc) {
        this.router = router;
        this.dashboardService = dashboardService;
        this.userModelSvc = userModelSvc;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const busy = this.dashboardService.beginBusy();
            try {
                this.pendingItems = yield this.userModelSvc.getPendingItems();
            }
            finally {
                busy.endBusy();
            }
        });
    }
}
DashboardPluginComponent.ɵfac = function DashboardPluginComponent_Factory(t) { return new (t || DashboardPluginComponent)(i0.ɵɵdirectiveInject(i3.Router), i0.ɵɵdirectiveInject(i2.DashboardService), i0.ɵɵdirectiveInject(i2.UserModelService)); };
DashboardPluginComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DashboardPluginComponent, selectors: [["ng-component"]], decls: 1, vars: 1, consts: [["data-imx-identifier", "pol-dashboard--plugin-badge-tile-violations-approvals", 3, "caption", "value", "identifier", "actionClick", 4, "ngIf"], ["data-imx-identifier", "pol-dashboard--plugin-badge-tile-violations-approvals", 3, "caption", "value", "identifier", "actionClick"]], template: function DashboardPluginComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, DashboardPluginComponent_imx_badge_tile_0_Template, 2, 5, "imx-badge-tile", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", 0 < (ctx.pendingItems == null ? null : ctx.pendingItems.OpenQERPolicyHasObject));
        }
    }, dependencies: [i9.NgIf, i2.BadgeTileComponent, i4.TranslatePipe], encapsulation: 2 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DashboardPluginComponent, [{
            type: Component,
            args: [{ template: "<!-- todo: add dashboard tiles -->\r\n<imx-badge-tile data-imx-identifier=\"pol-dashboard--plugin-badge-tile-violations-approvals\"\r\n  [caption]=\"'#LDS#Heading Pending Policy Violations' | translate\" *ngIf=\"0 < pendingItems?.OpenQERPolicyHasObject\"\r\n  [value]=\"pendingItems?.OpenQERPolicyHasObject\" [identifier]=\"'pol-rule-violation-approvals'\"\r\n  (actionClick)=\"router.navigate(['compliance', 'policyviolations', 'approve'])\">\r\n</imx-badge-tile>" }]
        }], function () { return [{ type: i3.Router }, { type: i2.DashboardService }, { type: i2.UserModelService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PolicyViolationsActionMultiActionComponent_mat_list_item_17_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-list-item")(1, "div", 3);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const policyViolationApproval_r1 = ctx.$implicit;
        let tmp_0_0;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", policyViolationApproval_r1 == null ? null : (tmp_0_0 = policyViolationApproval_r1.GetEntity()) == null ? null : tmp_0_0.GetDisplay(), " ");
    }
}
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a multiple policy violations.
 * There is an alternative component for the case of a decision for a single policy violation as well
 * {@link  PolicyViolationsActionSingleActionComponent}
 */
class PolicyViolationsActionMultiActionComponent {
}
PolicyViolationsActionMultiActionComponent.ɵfac = function PolicyViolationsActionMultiActionComponent_Factory(t) { return new (t || PolicyViolationsActionMultiActionComponent)(); };
PolicyViolationsActionMultiActionComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsActionMultiActionComponent, selectors: [["imx-policy-violations-action-multi-action"]], inputs: { data: "data", formGroup: "formGroup" }, decls: 18, vars: 12, consts: [["data-imx-identifier", "policy-violation-property-reason", 3, "reasonStandard", "reasonFreetext", "controlCreated"], [1, "imx-selection-card"], [4, "ngFor", "ngForOf"], ["mat-line", ""]], template: function PolicyViolationsActionMultiActionComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-card-subtitle");
            i0.ɵɵtext(5);
            i0.ɵɵpipe(6, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-card-content")(8, "div")(9, "imx-decision-reason", 0);
            i0.ɵɵlistener("controlCreated", function PolicyViolationsActionMultiActionComponent_Template_imx_decision_reason_controlCreated_9_listener($event) { return ctx.formGroup.addControl("reason", $event); });
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(10, "mat-card", 1)(11, "mat-card-title");
            i0.ɵɵtext(12);
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(14, "mat-card-content")(15, "div")(16, "mat-list");
            i0.ɵɵtemplate(17, PolicyViolationsActionMultiActionComponent_mat_list_item_17_Template, 3, 1, "mat-list-item", 2);
            i0.ɵɵelementEnd()()()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 6, "#LDS#Heading General Settings"));
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(6, 8, "#LDS#Here you can make settings that are applied to each selected policy violation."), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("reasonStandard", ctx.data.actionParameters.justification)("reasonFreetext", ctx.data.actionParameters.reason);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(13, 10, "#LDS#Heading Selected Policy Violations"));
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("ngForOf", ctx.data == null ? null : ctx.data.policyViolations);
        }
    }, dependencies: [i1.MatCard, i1.MatCardContent, i1.MatCardTitle, i1.MatCardSubtitle, i2$1.MatLine, i3$1.MatList, i3$1.MatListItem, i9.NgForOf, i2.DecisionReasonComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]     .mat-list-base .mat-list-item .mat-list-item-content{padding-left:0%}[_nghost-%COMP%]     .mat-list-base .mat-list-item{height:auto;margin-bottom:16px}mat-card[_ngcontent-%COMP%]{margin-bottom:20px}mat-card-content[_ngcontent-%COMP%]{overflow:auto}.imx-selection-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}imx-bulk-editor[_ngcontent-%COMP%]{margin-top:20px}.mat-list-base[_ngcontent-%COMP%]   .mat-list-item[_ngcontent-%COMP%]   .mat-line[_ngcontent-%COMP%]{margin-left:0;overflow:auto;white-space:inherit;word-wrap:break-word;height:auto}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsActionMultiActionComponent, [{
            type: Component,
            args: [{ selector: 'imx-policy-violations-action-multi-action', template: "<mat-card>\r\n  <mat-card-title>{{ '#LDS#Heading General Settings' | translate }}</mat-card-title>\r\n  <mat-card-subtitle>{{ '#LDS#Here you can make settings that are applied to each selected policy violation.' | translate }}\r\n  </mat-card-subtitle>\r\n  <mat-card-content>\r\n    <div>\r\n      <imx-decision-reason [reasonStandard]=\"data.actionParameters.justification\"\r\n        [reasonFreetext]=\"data.actionParameters.reason\" (controlCreated)=\"formGroup.addControl('reason', $event)\"\r\n        data-imx-identifier=\"policy-violation-property-reason\">\r\n      </imx-decision-reason>\r\n    </div>\r\n  </mat-card-content>\r\n</mat-card>\r\n\r\n<mat-card class=\"imx-selection-card\">\r\n  <mat-card-title>{{ '#LDS#Heading Selected Policy Violations' | translate }}</mat-card-title>\r\n  <mat-card-content>\r\n    <div>\r\n      <mat-list>\r\n        <mat-list-item *ngFor=\"let policyViolationApproval of data?.policyViolations\">\r\n          <div mat-line>\r\n            {{ policyViolationApproval?.GetEntity()?.GetDisplay() }}\r\n          </div>\r\n        </mat-list-item>\r\n      </mat-list>\r\n    </div>\r\n  </mat-card-content>\r\n</mat-card>", styles: [":host{display:flex;flex-direction:column;overflow:hidden}:host ::ng-deep .mat-list-base .mat-list-item .mat-list-item-content{padding-left:0%}:host ::ng-deep .mat-list-base .mat-list-item{height:auto;margin-bottom:16px}mat-card{margin-bottom:20px}mat-card-content{overflow:auto}.imx-selection-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}imx-bulk-editor{margin-top:20px}.mat-list-base .mat-list-item .mat-line{margin-left:0;overflow:auto;white-space:inherit;word-wrap:break-word;height:auto}\n"] }]
        }], null, { data: [{
                type: Input
            }], formGroup: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/**
 * @ignore since this is only an internal component.
 *
 * Component for making a decision for a single policy violation.
 * There is an alternative component for the case of a decision for multiple policy violations as
 *  well: {@link PolicyViolationActionMultiActionComponent}.
 */
class PolicyViolationsActionSingleActionComponent {
    /**
     * @ignore since this is only an internal component
     *
     * Sets up the {@link columns} to be displayed/edited during OnInit lifecycle hook.
     */
    ngOnInit() {
        this.policyViolation = this.data.policyViolations[0];
    }
    /**
     * @ignore since this is only public because of databinding to the template
     *
     * Handles the event emitted when a cdr editor created a new form control.
     *
     * @param name The name of the form control
     * @param control The form control
     */
    onFormControlCreated(name, control) {
        // use setTimeout to make addControl asynchronous in order to avoid "NG0100: Expression has changed after it was checked"
        setTimeout(() => this.formGroup.addControl(name, control));
    }
}
PolicyViolationsActionSingleActionComponent.ɵfac = function PolicyViolationsActionSingleActionComponent_Factory(t) { return new (t || PolicyViolationsActionSingleActionComponent)(); };
PolicyViolationsActionSingleActionComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsActionSingleActionComponent, selectors: [["imx-policy-violations-action-single-action"]], inputs: { data: "data", formGroup: "formGroup" }, decls: 7, vars: 4, consts: [["data-imx-identifier", "policy-violation-property-reason", 3, "reasonStandard", "reasonFreetext", "controlCreated"]], template: function PolicyViolationsActionSingleActionComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card-subtitle");
            i0.ɵɵtext(4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card-content")(6, "imx-decision-reason", 0);
            i0.ɵɵlistener("controlCreated", function PolicyViolationsActionSingleActionComponent_Template_imx_decision_reason_controlCreated_6_listener($event) { return ctx.formGroup.addControl("reason", $event); });
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            let tmp_0_0;
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate((tmp_0_0 = ctx.policyViolation.GetEntity()) == null ? null : tmp_0_0.GetDisplay());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.policyViolation.State.Column.GetDisplayValue());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("reasonStandard", ctx.data.actionParameters.justification)("reasonFreetext", ctx.data.actionParameters.reason);
        }
    }, dependencies: [i1.MatCard, i1.MatCardContent, i1.MatCardTitle, i1.MatCardSubtitle, i2.DecisionReasonComponent], styles: ["mat-card-content[_ngcontent-%COMP%]{overflow:hidden}mat-card-title[_ngcontent-%COMP%]{font-size:16px}mat-card-subtitle[_ngcontent-%COMP%]{font-size:15px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsActionSingleActionComponent, [{
            type: Component,
            args: [{ selector: 'imx-policy-violations-action-single-action', template: "<mat-card>\r\n  <mat-card-title>{{ policyViolation.GetEntity()?.GetDisplay() }}</mat-card-title>\r\n  <mat-card-subtitle>{{ policyViolation.State.Column.GetDisplayValue() }}</mat-card-subtitle>\r\n  <mat-card-content>\r\n    <imx-decision-reason [reasonStandard]=\"data.actionParameters.justification\"\r\n      [reasonFreetext]=\"data.actionParameters.reason\" (controlCreated)=\"formGroup.addControl('reason', $event)\"\r\n      data-imx-identifier=\"policy-violation-property-reason\">\r\n    </imx-decision-reason>\r\n  </mat-card-content>\r\n</mat-card>", styles: ["mat-card-content{overflow:hidden}mat-card-title{font-size:16px}mat-card-subtitle{font-size:15px}\n"] }]
        }], null, { data: [{
                type: Input
            }], formGroup: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PolicyViolationsActionComponent_p_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "p");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, ctx_r0.data.description));
    }
}
function PolicyViolationsActionComponent_ng_container_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelement(1, "imx-policy-violations-action-multi-action", 5);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r1.formGroup)("data", ctx_r1.data);
    }
}
function PolicyViolationsActionComponent_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelement(1, "imx-policy-violations-action-single-action", 5);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r2.formGroup)("data", ctx_r2.data);
    }
}
function PolicyViolationsActionComponent_button_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r5 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 6);
        i0.ɵɵlistener("click", function PolicyViolationsActionComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r5); const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.sideSheetRef.close(true)); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵproperty("disabled", ctx_r3.formGroup.invalid);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Save"), " ");
    }
}
/**
 * Component displayed in a sidesheet to make a decision for one or more policy violations.
 *
 * Uses two alternate views
 * <ul>
 * <li>a) a simple view for a single policy violation</li>
 * <li>b) a complex view using bulk items for multiple policy violations.</li>
 * </ul>
 *
 * Therefore this component is not meant to be used directly but rather be called
 * from a service that does the pre-calculation and opens this component in a
 * sidesheet passing the pre-calculated values.
 *
 */
class PolicyViolationsActionComponent {
    /**
     * Creates a new PolicyViolationsActionComponent
     * @param data The pre-calculated data object.
     * @param sideSheetRef A reference to the sidesheet containing this component.
     */
    constructor(data, sideSheetRef) {
        this.data = data;
        this.sideSheetRef = sideSheetRef;
        /**
         * The form group to which the created form controls will be added.
         */
        this.formGroup = new UntypedFormGroup({});
    }
}
PolicyViolationsActionComponent.ɵfac = function PolicyViolationsActionComponent_Factory(t) { return new (t || PolicyViolationsActionComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetRef)); };
PolicyViolationsActionComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsActionComponent, selectors: [["ng-component"]], decls: 7, vars: 5, consts: [["eui-sidesheet-content", ""], [1, "imx-policy-violation-content", 3, "formGroup"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["data-imx-identifier", "policy-violation-action-button-save", "mat-raised-button", "", "color", "primary", 3, "disabled", "click", 4, "ngIf"], [3, "formGroup", "data"], ["data-imx-identifier", "policy-violation-action-button-save", "mat-raised-button", "", "color", "primary", 3, "disabled", "click"]], template: function PolicyViolationsActionComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "form", 1);
            i0.ɵɵtemplate(2, PolicyViolationsActionComponent_p_2_Template, 3, 3, "p", 2);
            i0.ɵɵtemplate(3, PolicyViolationsActionComponent_ng_container_3_Template, 2, 2, "ng-container", 2);
            i0.ɵɵtemplate(4, PolicyViolationsActionComponent_ng_container_4_Template, 2, 2, "ng-container", 2);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "div", 3);
            i0.ɵɵtemplate(6, PolicyViolationsActionComponent_button_6_Template, 3, 4, "button", 4);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("formGroup", ctx.formGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.description);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.policyViolations.length > 1);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.policyViolations.length === 1);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.formGroup);
        }
    }, dependencies: [i2$2.EuiSidesheetContentDirective, i2$2.EuiSidesheetActionsDirective, i5.MatButton, i9.NgIf, i4$1.ɵNgNoValidate, i4$1.NgControlStatusGroup, i4$1.FormGroupDirective, PolicyViolationsActionMultiActionComponent, PolicyViolationsActionSingleActionComponent, i4.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{padding:32px;overflow:hidden;height:100%;flex:1;display:flex;flex-direction:column}.eui-sidesheet-actions.mat-card[_ngcontent-%COMP%]{margin:16px 32px}.imx-policy-violation-content[_ngcontent-%COMP%]{overflow:hidden;display:flex;flex-direction:column}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsActionComponent, [{
            type: Component,
            args: [{ template: "<div eui-sidesheet-content >\r\n  <form [formGroup]=\"formGroup\" class=\"imx-policy-violation-content\">\r\n    <p *ngIf=\"data.description\">{{ data.description | translate }}</p>\r\n    <ng-container *ngIf=\"data.policyViolations.length > 1\">\r\n      <imx-policy-violations-action-multi-action [formGroup]=\"formGroup\" [data]=\"data\"></imx-policy-violations-action-multi-action>\r\n    </ng-container>\r\n    <ng-container *ngIf=\"data.policyViolations.length === 1\">\r\n      <imx-policy-violations-action-single-action [formGroup]=\"formGroup\" [data]=\"data\"></imx-policy-violations-action-single-action>\r\n    </ng-container>\r\n  </form>\r\n</div>\r\n<div eui-sidesheet-actions >\r\n  <button data-imx-identifier=\"policy-violation-action-button-save\" mat-raised-button color=\"primary\" (click)=\"sideSheetRef.close(true)\" *ngIf=\"formGroup\" [disabled]=\"formGroup.invalid\">\r\n    {{ '#LDS#Save' | translate }}\r\n  </button>\r\n</div>\r\n", styles: [".eui-sidesheet-content{padding:32px;overflow:hidden;height:100%;flex:1;display:flex;flex-direction:column}.eui-sidesheet-actions.mat-card{margin:16px 32px}.imx-policy-violation-content{overflow:hidden;display:flex;flex-direction:column}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i2$2.EuiSidesheetRef }];
    }, null);
})();

class PolicyViolation extends PortalPoliciesViolationslist {
    constructor(baseObject, extendedData) {
        super(baseObject.GetEntity());
        this.baseObject = baseObject;
        this.initPropertyInfo();
        this.initStateBadge();
        this.data = extendedData || [];
    }
    /**
     * The color and the caption depending on the value of the state of a {@link PortalPoliciesViolationslist}.
     */
    get stateBadge() {
        return {
            color: this.stateBadgeColor,
            caption: this.stateCaption
        };
    }
    ;
    get key() {
        return this.baseObject.GetEntity().GetKeys()[0];
    }
    initPropertyInfo() {
        const props = [
            this.UID_QERPolicy,
            this.Description,
            this.ObjectKey
        ];
        if (this.State.value.toLowerCase() !== 'pending') {
            props.push(...[
                this.UID_PersonDecisionMade,
                this.UID_QERJustification,
                this.DecisionReason,
                this.DecisionDate
            ]);
        }
        this.properties = props
            .filter(property => property.value != null && property.value !== '')
            .map(property => new BaseReadonlyCdr(property.Column));
    }
    initStateBadge() {
        return __awaiter(this, void 0, void 0, function* () {
            switch (this.State.value) {
                case 'approved':
                    this.stateBadgeColor = 'green';
                    this.stateCaption = '#LDS#Exception granted';
                    break;
                case 'denied':
                    this.stateBadgeColor = 'orange';
                    this.stateCaption = '#LDS#Exception denied';
                    break;
                default:
                    this.stateBadgeColor = 'blue';
                    this.stateCaption = '#LDS#Approval decision pending';
            }
        });
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing POL API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
ApiService.ɵfac = function ApiService_Factory(t) { return new (t || ApiService)(i0.ɵɵinject(i3$2.AppConfigService), i0.ɵɵinject(i3$2.ClassloggerService), i0.ɵɵinject(i3$2.ImxTranslationProviderService)); };
ApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ApiService, factory: ApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i3$2.AppConfigService }, { type: i3$2.ClassloggerService }, { type: i3$2.ImxTranslationProviderService }]; }, null);
})();

class PolicyViolationsService {
    constructor(justificationService, api, busyService, entityService, translate, snackBar, userService, sideSheet) {
        this.justificationService = justificationService;
        this.api = api;
        this.busyService = busyService;
        this.entityService = entityService;
        this.translate = translate;
        this.snackBar = snackBar;
        this.userService = userService;
        this.sideSheet = sideSheet;
        this.abortController = new AbortController();
        this.applied = new Subject();
    }
    get policyViolationsSchema() {
        return this.api.typedClient.PortalPoliciesViolationslist.GetSchema();
    }
    get mitigationSchema() {
        return this.api.typedClient.PortalPoliciesViolations.GetSchema();
    }
    getConfig() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.client.portal_policy_config_get();
        });
    }
    getPolicyViolationsDataModel() {
        return this.api.client.portal_policies_violations_datamodel_get();
    }
    get(isApprovable, polDecisionParameters, reqestOpts) {
        return __awaiter(this, void 0, void 0, function* () {
            const collection = yield this.api.typedClient.PortalPoliciesViolationslist.Get_list(Object.assign({ approvable: isApprovable }, polDecisionParameters), reqestOpts);
            if (!collection) {
                return undefined;
            }
            return {
                tableName: collection.tableName,
                totalCount: collection.totalCount,
                Data: collection.Data.map((item, index) => {
                    var _a, _b;
                    const extendedData = ((_b = (_a = collection === null || collection === void 0 ? void 0 : collection.extendedData) === null || _a === void 0 ? void 0 : _a.RelatedObjects) === null || _b === void 0 ? void 0 : _b[index]) || [];
                    return new PolicyViolation(item, extendedData);
                }),
            };
        });
    }
    exportPolicyViolations(polDecisionParameters) {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_policies_violations_list_get(Object.assign(Object.assign({}, polDecisionParameters), { withProperties, PageSize, StartIndex: 0 }));
                }
                else {
                    method = factory.portal_policies_violations_list_get(Object.assign(Object.assign({}, polDecisionParameters), { withProperties }));
                }
                return new MethodDefinition(method);
            },
        };
    }
    getGroupInfo(parameters = {}) {
        const { withProperties, OrderBy, search } = parameters, params = __rest(parameters, ["withProperties", "OrderBy", "search"]);
        return this.api.client.portal_policies_violations_group_list_get(Object.assign(Object.assign({}, params), { withcount: true }));
    }
    // Methods for decision making
    approve(policyViolations) {
        return __awaiter(this, void 0, void 0, function* () {
            let justification;
            let busyIndicator;
            setTimeout(() => (busyIndicator = this.busyService.show()));
            try {
                justification = yield this.justificationService.createCdr(JustificationType.approvePolicyViolation);
            }
            finally {
                setTimeout(() => this.busyService.hide(busyIndicator));
            }
            const actionParameters = {
                justification,
                reason: this.createCdrReason(justification ? '#LDS#Additional comments about your decision' : undefined),
            };
            return this.editAction({
                title: '#LDS#Heading Grant Exception',
                message: '#LDS#Exceptions have been successfully granted for {0} policy violations.',
                discardChangesOnAbort: true,
                data: {
                    policyViolations,
                    approve: true,
                    actionParameters,
                },
                apply: (violation) => __awaiter(this, void 0, void 0, function* () {
                    var _a, _b;
                    yield this.makeDecision(violation, {
                        Reason: actionParameters.reason.column.GetValue(),
                        UidJustification: (_b = (_a = actionParameters.justification) === null || _a === void 0 ? void 0 : _a.column) === null || _b === void 0 ? void 0 : _b.GetValue(),
                        Decision: true,
                    });
                }),
            });
        });
    }
    deny(policyViolations) {
        return __awaiter(this, void 0, void 0, function* () {
            let justification;
            let busyIndicator;
            setTimeout(() => (busyIndicator = this.busyService.show()));
            try {
                justification = yield this.justificationService.createCdr(JustificationType.denyPolicyViolation);
            }
            finally {
                setTimeout(() => this.busyService.hide(busyIndicator));
            }
            const actionParameters = {
                justification,
                reason: this.createCdrReason(justification ? '#LDS#Additional comments about your decision' : undefined),
            };
            return this.editAction({
                title: '#LDS#Heading Deny Exception',
                message: '#LDS#Exceptions have been successfully denied for {0} policy violations.',
                discardChangesOnAbort: true,
                data: {
                    policyViolations,
                    actionParameters,
                    customValidation: undefined,
                },
                apply: (policyViolation) => __awaiter(this, void 0, void 0, function* () {
                    var _a, _b;
                    try {
                        yield policyViolation.GetEntity().Commit(true);
                        yield this.makeDecision(policyViolation, {
                            Reason: actionParameters.reason.column.GetValue(),
                            UidJustification: (_b = (_a = actionParameters.justification) === null || _a === void 0 ? void 0 : _a.column) === null || _b === void 0 ? void 0 : _b.GetValue(),
                            Decision: false,
                        });
                    }
                    catch (error) {
                        yield policyViolation.GetEntity().DiscardChanges();
                        throw error;
                    }
                }),
            });
        });
    }
    getMitigatingContols(uidObject) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalPoliciesViolations.Get(uidObject);
        });
    }
    getCandidates(uid, data, parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.client.portal_policies_violations_UID_MitigatingControl_candidates_post(uid, data, parameter);
        });
    }
    createMitigatingControl(uid) {
        const entity = this.api.typedClient.PortalPoliciesViolations.createEntity({
            Columns: {
                UID_QERPolicyHasObject: { Value: uid },
            },
        });
        return entity;
    }
    deleteMitigationControl(uidPolicaHasObject, uidMitigating) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.api.typedClient.PortalPoliciesViolations.Delete(uidPolicaHasObject, uidMitigating);
                return true;
            }
            catch (except) {
                return false;
            }
        });
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
    makeDecision(pwo, decision) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.api.client.portal_policies_violations_approve_post(pwo.GetEntity().GetKeys()[0], decision);
        });
    }
    createCdrReason(display) {
        const column = this.entityService.createLocalEntityColumn({
            ColumnName: 'ReasonHead',
            Type: ValType.Text,
            IsMultiLine: true,
        });
        return new BaseCdr(column, display || '#LDS#Reason for your decision');
    }
    editAction(config) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.sideSheet
                .open(PolicyViolationsActionComponent, {
                title: yield this.translate.get(config.title).toPromise(),
                subTitle: config.data.policyViolations.length === 1 ? config.data.policyViolations[0].GetEntity().GetDisplay() : '',
                padding: '0',
                width: '600px',
                testId: `policy-violations-action-${config.data.approve ? 'approve' : 'deny'}`,
                data: config.data,
            })
                .afterClosed()
                .toPromise();
            if (result) {
                let busyIndicator;
                setTimeout(() => (busyIndicator = this.busyService.show()));
                let success;
                try {
                    for (const policyViolation of config.data.policyViolations) {
                        yield config.apply(policyViolation);
                    }
                    success = true;
                    yield this.userService.reloadPendingItems();
                }
                finally {
                    setTimeout(() => this.busyService.hide(busyIndicator));
                }
                if (success) {
                    this.snackBar.open({
                        key: config.message,
                        parameters: [
                            config.data.policyViolations.length,
                            config.data.actionParameters.uidPerson ? config.data.actionParameters.uidPerson.column.GetDisplayValue() : '',
                        ],
                    });
                    this.applied.next();
                }
            }
            else {
                if (config.discardChangesOnAbort) {
                    for (const approval of config.data.policyViolations) {
                        yield approval.GetEntity().DiscardChanges();
                    }
                }
                this.snackBar.open({ key: '#LDS#You have canceled the action.' });
            }
        });
    }
}
PolicyViolationsService.ɵfac = function PolicyViolationsService_Factory(t) { return new (t || PolicyViolationsService)(i0.ɵɵinject(i2.JustificationService), i0.ɵɵinject(ApiService), i0.ɵɵinject(i2$2.EuiLoadingService), i0.ɵɵinject(i3$2.EntityService), i0.ɵɵinject(i4.TranslateService), i0.ɵɵinject(i3$2.SnackBarService), i0.ɵɵinject(i2.UserModelService), i0.ɵɵinject(i2$2.EuiSidesheetService)); };
PolicyViolationsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PolicyViolationsService, factory: PolicyViolationsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: i2.JustificationService }, { type: ApiService }, { type: i2$2.EuiLoadingService }, { type: i3$2.EntityService }, { type: i4.TranslateService }, { type: i3$2.SnackBarService }, { type: i2.UserModelService }, { type: i2$2.EuiSidesheetService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PolicyViolationExtended extends PortalPoliciesViolations {
    constructor(editable, original) {
        super(original.GetEntity());
        this.editable = editable;
        this.original = original;
        this.formControl = new FormControl(undefined);
        if (!editable) {
            this.mitigatingCdr = new BaseReadonlyCdr(original.UID_MitigatingControl.Column);
        }
    }
}

function MitigatingControlsComponent_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 8)(1, "eui-alert-header");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "eui-alert-content");
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Heading Mitigating Controls Can Be Assigned Individually"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Here you can assign mitigating controls to the policy violation. NOTE: If no mitigating controls have been assigned to the violated company policy, you cannot assign any mitigating controls to the policy violation either."));
    }
}
function MitigatingControlsComponent_div_3_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r6 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelement(1, "p", 12);
        i0.ɵɵelementStart(2, "button", 13);
        i0.ɵɵlistener("click", function MitigatingControlsComponent_div_3_ng_container_2_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r6); const ctx_r5 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r5.addMitigatingControl()); });
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("translate", "#LDS#There are currently no mitigating controls assigned to the policy violation.");
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#Assign mitigating controls"));
    }
}
function MitigatingControlsComponent_div_3_ng_container_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelement(1, "p", 12);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("translate", "#LDS#You cannot assign mitigating controls to the policy violation because no mitigating controls are assigned to the underlying company policy.");
    }
}
function MitigatingControlsComponent_div_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 9);
        i0.ɵɵelement(1, "eui-icon", 10);
        i0.ɵɵtemplate(2, MitigatingControlsComponent_div_3_ng_container_2_Template, 5, 4, "ng-container", 11);
        i0.ɵɵtemplate(3, MitigatingControlsComponent_div_3_ng_container_3_Template, 2, 1, "ng-container", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r1.options.length > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r1.options.length === 0);
    }
}
function MitigatingControlsComponent_form_4_div_1_eui_select_1_mat_error_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-error");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#This field is mandatory."), " ");
    }
}
function MitigatingControlsComponent_form_4_div_1_eui_select_1_mat_error_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-error");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once."), " ");
    }
}
function MitigatingControlsComponent_form_4_div_1_eui_select_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r16 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-select", 23);
        i0.ɵɵlistener("selectionChange", function MitigatingControlsComponent_form_4_div_1_eui_select_1_Template_eui_select_selectionChange_0_listener($event) { i0.ɵɵrestoreView(_r16); const mcontrol_r8 = i0.ɵɵnextContext().$implicit; const ctx_r14 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r14.onSelectionChange(mcontrol_r8, $event.value)); });
        i0.ɵɵtemplate(1, MitigatingControlsComponent_form_4_div_1_eui_select_1_mat_error_1_Template, 3, 3, "mat-error", 11);
        i0.ɵɵtemplate(2, MitigatingControlsComponent_form_4_div_1_eui_select_1_mat_error_2_Template, 3, 3, "mat-error", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r17 = i0.ɵɵnextContext();
        const mcontrol_r8 = ctx_r17.$implicit;
        const i_r9 = ctx_r17.index;
        const ctx_r10 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("label", ctx_r10.mitigatingCaption)("filterFunction", ctx_r10.filter)("options", ctx_r10.options)("inputControl", mcontrol_r8.formControl)("hideClearButton", true);
        i0.ɵɵattribute("data-imx-identifier", "mitigating-controls-" + i_r9 + "-select");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", mcontrol_r8.formControl.errors == null ? null : mcontrol_r8.formControl.errors["required"]);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", mcontrol_r8.formControl.errors == null ? null : mcontrol_r8.formControl.errors["duplicated"]);
    }
}
function MitigatingControlsComponent_form_4_div_1_imx_cdr_editor_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 24);
    }
    if (rf & 2) {
        const ctx_r18 = i0.ɵɵnextContext();
        const mcontrol_r8 = ctx_r18.$implicit;
        const i_r9 = ctx_r18.index;
        i0.ɵɵproperty("cdr", mcontrol_r8.mitigatingCdr);
        i0.ɵɵattribute("data-imx-identifier", "mitigating-controls-" + i_r9 + "-readOnly");
    }
}
function MitigatingControlsComponent_form_4_div_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r20 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 18);
        i0.ɵɵtemplate(1, MitigatingControlsComponent_form_4_div_1_eui_select_1_Template, 3, 8, "eui-select", 19);
        i0.ɵɵtemplate(2, MitigatingControlsComponent_form_4_div_1_imx_cdr_editor_2_Template, 1, 2, "imx-cdr-editor", 20);
        i0.ɵɵelementStart(3, "button", 21);
        i0.ɵɵlistener("click", function MitigatingControlsComponent_form_4_div_1_Template_button_click_3_listener() { const restoredCtx = i0.ɵɵrestoreView(_r20); const i_r9 = restoredCtx.index; const ctx_r19 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r19.delete(i_r9)); });
        i0.ɵɵelement(4, "eui-icon", 22);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const mcontrol_r8 = ctx.$implicit;
        const i_r9 = ctx.index;
        const ctx_r7 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", mcontrol_r8.editable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !mcontrol_r8.editable);
        i0.ɵɵadvance(1);
        i0.ɵɵattribute("aria-label", ctx_r7.deleteText)("data-imx-identifier", "mitigating-controls-" + i_r9 + "-delete");
    }
}
function MitigatingControlsComponent_form_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r22 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "form", 14);
        i0.ɵɵtemplate(1, MitigatingControlsComponent_form_4_div_1_Template, 5, 4, "div", 15);
        i0.ɵɵelementStart(2, "button", 16);
        i0.ɵɵlistener("click", function MitigatingControlsComponent_form_4_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r22); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.addMitigatingControl()); });
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelement(5, "eui-icon", 17);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵproperty("formGroup", ctx_r2.mitigatingForm);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r2.mControls);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(3, 4, "#LDS#Assigns a mitigating control"));
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(4, 6, "#LDS#Assign mitigating control"));
    }
}
class MitigatingControlsComponent {
    constructor(violationService, loadingService, confirmationService, cd, snackbar, formBuilder) {
        this.violationService = violationService;
        this.loadingService = loadingService;
        this.confirmationService = confirmationService;
        this.cd = cd;
        this.snackbar = snackbar;
        this.subscriptions$ = [];
        this.options = [];
        this.controlsToDelete = [];
        this.filter = (option, searchInputValue) => option.value.toString().toUpperCase() === searchInputValue.toUpperCase();
        this.mitigatingForm = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.mitigatingCaption = violationService.mitigationSchema.Columns.UID_MitigatingControl.Display;
    }
    get formArray() {
        return this.mitigatingForm.get('formArray');
    }
    get notSaveable() {
        if (this.controlsToDelete.length !== 0) {
            this.mitigatingForm.markAsDirty();
        }
        if (!this.mitigatingForm.dirty || !this.mitigatingForm.valid) {
            return true;
        }
        return (this.mControls.length > 0 &&
            this.mControls.every((ctrl) => {
                return !ctrl.editable || ctrl.UID_MitigatingControl.value === null || ctrl.UID_MitigatingControl.value === '';
            }) &&
            this.controlsToDelete.length === 0);
    }
    get isDirty() {
        return this.mitigatingForm.dirty || this.controlsToDelete.length > 0;
    }
    onSelectionChange(mcontrol, value) {
        return __awaiter(this, void 0, void 0, function* () {
            mcontrol.UID_MitigatingControl.value = value;
            this.formArray.updateValueAndValidity();
            this.cd.detectChanges();
            return;
        });
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.sidesheetRef.componentInstance.disableClose = true;
            this.subscriptions$.push(this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
                if (!this.isDirty || (yield this.confirmationService.confirmLeaveWithUnsavedChanges())) {
                    this.sidesheetRef.close();
                }
            })));
            return this.loadMitigationControls();
        });
    }
    isDuplicate(actrl) {
        const test = this.mControls.findIndex((ctrl) => ctrl.formControl != actrl && (ctrl === null || ctrl === void 0 ? void 0 : ctrl.UID_MitigatingControl.value) === actrl.value) !== -1;
        return test;
    }
    canDelete(index) {
        var _a;
        return (((_a = this.mControls[index]) === null || _a === void 0 ? void 0 : _a.UID_MitigatingControl.Column.GetMetadata().CanEdit()) || this.mControls[index].GetEntity().GetKeys() == null);
    }
    delete(index) {
        return __awaiter(this, void 0, void 0, function* () {
            const elem = this.mControls[index];
            if (elem.UID_MitigatingControl.value !== '' && !(yield this.confirmationService.confirmDelete())) {
                return;
            }
            if (elem.GetEntity().GetKeys() != null) {
                this.controlsToDelete.push(elem);
            }
            //Remove the controls and update ui
            this.mControls.splice(index, 1);
            this.formArray.controls.splice(index, 1);
            this.formArray.controls.forEach((elem) => elem.updateValueAndValidity());
            this.cd.detectChanges();
        });
    }
    addMitigatingControl() {
        return __awaiter(this, void 0, void 0, function* () {
            const newControl = new PolicyViolationExtended(true, this.violationService.createMitigatingControl(this.uidViolation));
            this.mControls.push(newControl);
            this.formArray.push(newControl.formControl);
            newControl.formControl.setValidators([
                Validators.required,
                (control) => (this.isDuplicate(control) ? { duplicated: true } : null),
            ]);
            this.cd.detectChanges();
        });
    }
    save() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const overlay = this.loadingService.show();
            try {
                for (const ctrl of this.controlsToDelete) {
                    yield this.violationService.deleteMitigationControl(this.uidViolation, ctrl.UID_MitigatingControl.value);
                }
                for (const ctrl of this.mControls.filter((elem) => elem.editable)) {
                    yield ctrl.GetEntity().Commit(false);
                }
            }
            finally {
                this.loadingService.hide(overlay);
                this.snackbar.open({
                    key: '#LDS#The mitigating controls have been successfully saved.',
                    parameters: [(_a = this.sidesheetRef.componentInstance) === null || _a === void 0 ? void 0 : _a.config.subTitle],
                });
                this.sidesheetRef.close();
            }
        });
    }
    loadMitigationControls() {
        return __awaiter(this, void 0, void 0, function* () {
            const overlay = this.loadingService.show();
            try {
                //reload
                this.mControls = (yield this.violationService.getMitigatingContols(this.uidViolation)).Data.map((elem) => new PolicyViolationExtended(false, elem));
                this.mControls.forEach((elem) => this.formArray.push(elem.formControl));
                yield this.initOptions();
            }
            finally {
                this.loadingService.hide(overlay);
            }
        });
    }
    initOptions() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            this.options = (_a = (yield this.violationService.getCandidates(this.uidViolation, {}, {
                PageSize: 100000,
            })).Entities) === null || _a === void 0 ? void 0 : _a.map((elem) => ({ display: elem.Display, value: elem.Keys[0] }));
        });
    }
}
MitigatingControlsComponent.ɵfac = function MitigatingControlsComponent_Factory(t) { return new (t || MitigatingControlsComponent)(i0.ɵɵdirectiveInject(PolicyViolationsService), i0.ɵɵdirectiveInject(i2$2.EuiLoadingService), i0.ɵɵdirectiveInject(i3$2.ConfirmationService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$2.SnackBarService), i0.ɵɵdirectiveInject(i4$1.UntypedFormBuilder)); };
MitigatingControlsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsComponent, selectors: [["imx-mitigating-controls"]], inputs: { uidViolation: "uidViolation", isMControlPerViolation: "isMControlPerViolation", sidesheetRef: "sidesheetRef" }, decls: 10, vars: 7, consts: [[1, "imx-content"], ["class", "imx-helper-alert", "type", "info", "colored", "true", 4, "ngIf"], [1, "imx-mitigating-controls-card"], ["class", "imx-data-no-results", 4, "ngIf"], ["class", "imx-mitigating-form", 3, "formGroup", 4, "ngIf"], ["eui-sidesheet-actions", "", 1, "mat-elevation-z0"], [1, "imx-spacer"], ["data-imx-identifier", "mitigating-controls-button-save", "color", "primary", "mat-raised-button", "", 1, "imx-save-button", 3, "disabled", "click"], ["type", "info", "colored", "true", 1, "imx-helper-alert"], [1, "imx-data-no-results"], ["icon", "table"], [4, "ngIf"], [3, "translate"], ["data-imx-identifier", "mitigating-controls-button-add", "mat-stroked-button", "", "color", "primary", 3, "click"], [1, "imx-mitigating-form", 3, "formGroup"], ["class", "imx-mitigating-control", 4, "ngFor", "ngForOf"], ["data-imx-identifier", "mitigating-controls-button-add", "mat-button", "", 1, "mat-icon-button", 3, "matTooltip", "click"], ["icon", "add", 1, "add-icon"], [1, "imx-mitigating-control"], [3, "label", "filterFunction", "options", "inputControl", "hideClearButton", "selectionChange", 4, "ngIf"], [3, "cdr", 4, "ngIf"], ["mat-button", "", 1, "mat-icon-button", 3, "click"], ["icon", "delete", 1, "delete-icon"], [3, "label", "filterFunction", "options", "inputControl", "hideClearButton", "selectionChange"], [3, "cdr"]], template: function MitigatingControlsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, MitigatingControlsComponent_eui_alert_1_Template, 7, 6, "eui-alert", 1);
            i0.ɵɵelementStart(2, "mat-card", 2);
            i0.ɵɵtemplate(3, MitigatingControlsComponent_div_3_Template, 4, 2, "div", 3);
            i0.ɵɵtemplate(4, MitigatingControlsComponent_form_4_Template, 6, 8, "form", 4);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card", 5);
            i0.ɵɵelement(6, "div", 6);
            i0.ɵɵelementStart(7, "button", 7);
            i0.ɵɵlistener("click", function MitigatingControlsComponent_Template_button_click_7_listener() { return ctx.save(); });
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.isMControlPerViolation);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.mControls && ctx.mControls.length > 0);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("disabled", ctx.notSaveable);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 5, "#LDS#Save"), " ");
        }
    }, dependencies: [i2$2.EuiAlertComponent, i2$2.EuiAlertContentDirective, i2$2.EuiAlertHeaderDirective, i2$2.EuiIconComponent, i2$2.EuiSelectComponent, i2$2.EuiSidesheetActionsDirective, i5.MatButton, i1.MatCard, i6.MatError, i8.MatTooltip, i9.NgForOf, i9.NgIf, i4.TranslateDirective, i4$1.ɵNgNoValidate, i4$1.NgControlStatusGroup, i4$1.FormGroupDirective, i3$2.CdrEditorComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;flex:1 1 auto;height:100%}[_nghost-%COMP%]   mat-card[_ngcontent-%COMP%]{display:flex}[_nghost-%COMP%]   .imx-helper-alert[_ngcontent-%COMP%]{margin:20px}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]{display:flex;flex-direction:row;margin:3px 3px 10px}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:first-child{flex:1 1 auto}[_nghost-%COMP%]   .imx-mitigating-control[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .imx-mitigating-controls-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;margin:20px;align-items:center;overflow:hidden}[_nghost-%COMP%]   .imx-spacer[_ngcontent-%COMP%]{flex:1 1 auto}[_nghost-%COMP%]   .imx-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{margin:0}[_nghost-%COMP%]   .imx-save-button[_ngcontent-%COMP%]{align-self:flex-end}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]{text-align:center;flex:1 1 auto}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .imx-mitigating-form[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;align-self:flex-start;overflow:auto;max-height:100%;padding:2px}[_nghost-%COMP%]   .mat-error[_ngcontent-%COMP%]{margin-top:.6666666667em;margin-left:1em}[_nghost-%COMP%]   .delete-icon[_ngcontent-%COMP%]{color:#db2534}[_nghost-%COMP%]   .add-icon[_ngcontent-%COMP%]{color:#0a96d1}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}.eui-dark-theme   [_nghost-%COMP%]   .delete-icon[_ngcontent-%COMP%]{color:#f29d99}.eui-dark-theme   [_nghost-%COMP%]   .add-icon[_ngcontent-%COMP%]{color:#8acbe3}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .delete-icon[_ngcontent-%COMP%]{color:#db2534}.eui-contrast-theme   [_nghost-%COMP%]   .add-icon[_ngcontent-%COMP%]{color:#0a96d1}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsComponent, [{
            type: Component,
            args: [{ selector: 'imx-mitigating-controls', template: "<div class=\"imx-content\">\r\n  <eui-alert class=\"imx-helper-alert\" type=\"info\" colored=\"true\" *ngIf=\"isMControlPerViolation\">\r\n    <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Can Be Assigned Individually' | translate }}</eui-alert-header>\r\n    <eui-alert-content>{{ '#LDS#Here you can assign mitigating controls to the policy violation. NOTE: If no mitigating controls have been assigned to the violated company policy, you cannot assign any mitigating controls to the policy violation either.' | translate }}</eui-alert-content>\r\n  </eui-alert>\r\n\r\n  <mat-card class=\"imx-mitigating-controls-card\">\r\n    <div class=\"imx-data-no-results\" *ngIf=\"!mControls || mControls.length == 0\">\r\n      <eui-icon icon=\"table\"></eui-icon>\r\n      <ng-container *ngIf=\"options.length > 0\">\r\n        <p [translate]=\"'#LDS#There are currently no mitigating controls assigned to the policy violation.'\"></p>\r\n        <button data-imx-identifier=\"mitigating-controls-button-add\" mat-stroked-button color=\"primary\" (click)=\"addMitigatingControl()\">{{ '#LDS#Assign mitigating controls' | translate }}</button>\r\n      </ng-container>\r\n      <ng-container *ngIf=\"options.length === 0\">\r\n        <p [translate]=\"'#LDS#You cannot assign mitigating controls to the policy violation because no mitigating controls are assigned to the underlying company policy.'\"></p>\r\n      </ng-container>\r\n    </div>\r\n    <form class=\"imx-mitigating-form\" [formGroup]=\"mitigatingForm\" *ngIf=\"mControls && mControls.length > 0\">\r\n      <div *ngFor=\"let mcontrol of mControls; let i = index\" class=\"imx-mitigating-control\">\r\n        <eui-select\r\n          *ngIf=\"mcontrol.editable\"\r\n          (selectionChange)=\"onSelectionChange(mcontrol, $event.value)\"\r\n          [label]=\"mitigatingCaption\"\r\n          [filterFunction]=\"filter\"\r\n          [options]=\"options\"\r\n          [inputControl]=\"mcontrol.formControl\"\r\n          [hideClearButton]=\"true\"\r\n          [attr.data-imx-identifier]=\"'mitigating-controls-' + i + '-select'\"\r\n        >\r\n          <mat-error *ngIf=\"mcontrol.formControl.errors?.['required']\">\r\n            {{ '#LDS#This field is mandatory.' | translate }}\r\n          </mat-error>\r\n          <mat-error *ngIf=\"mcontrol.formControl.errors?.['duplicated']\">\r\n            {{ '#LDS#This mitigating control has already been assigned. You can assign a mitigating control only once.' | translate }}\r\n          </mat-error>\r\n        </eui-select>\r\n        <imx-cdr-editor *ngIf=\"!mcontrol.editable\" [cdr]=\"mcontrol.mitigatingCdr\" [attr.data-imx-identifier]=\"'mitigating-controls-' + i + '-readOnly'\"></imx-cdr-editor>\r\n        <button mat-button class=\"mat-icon-button\" [attr.aria-label]=\"deleteText\" [attr.data-imx-identifier]=\"'mitigating-controls-' + i + '-delete'\" (click)=\"delete(i)\">\r\n          <eui-icon class=\"delete-icon\" icon=\"delete\"></eui-icon>\r\n        </button>\r\n      </div>\r\n      <button [matTooltip]=\"'#LDS#Assigns a mitigating control' |translate\" data-imx-identifier=\"mitigating-controls-button-add\" [attr.aria-label]=\"'#LDS#Assign mitigating control' | translate\" mat-button class=\"mat-icon-button\" (click)=\"addMitigatingControl()\">\r\n        <eui-icon class=\"add-icon\" icon=\"add\"></eui-icon>\r\n      </button>\r\n    </form>\r\n  </mat-card>\r\n\r\n  <mat-card eui-sidesheet-actions class=\"mat-elevation-z0\">\r\n    <div class=\"imx-spacer\"></div>\r\n    <button data-imx-identifier=\"mitigating-controls-button-save\" class=\"imx-save-button\" color=\"primary\" [disabled]=\"notSaveable\" mat-raised-button (click)=\"save()\">\r\n      {{ '#LDS#Save' | translate }}\r\n    </button>\r\n  </mat-card>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;flex:1 1 auto;height:100%}:host mat-card{display:flex}:host .imx-helper-alert{margin:20px}:host .imx-mitigating-control{display:flex;flex-direction:row;margin:3px 3px 10px}:host .imx-mitigating-control :first-child{flex:1 1 auto}:host .imx-mitigating-control button{margin-top:10px}:host .imx-mitigating-controls-card{flex:1 1 auto;display:flex;margin:20px;align-items:center;overflow:hidden}:host .imx-spacer{flex:1 1 auto}:host .imx-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}:host .eui-sidesheet-actions{margin:0}:host .imx-save-button{align-self:flex-end}:host .imx-data-no-results{text-align:center;flex:1 1 auto}:host .imx-data-no-results .eui-icon{font-size:100px}:host .imx-data-no-results p{margin:0;font-size:18px}:host .imx-data-no-results button{margin-top:10px}:host .imx-mitigating-form{flex:1 1 auto;display:flex;flex-direction:column;align-self:flex-start;overflow:auto;max-height:100%;padding:2px}:host .mat-error{margin-top:.6666666667em;margin-left:1em}:host .delete-icon{color:#db2534}:host .add-icon{color:#0a96d1}:host .imx-data-no-results .eui-icon{color:#dfe4e6}:host .imx-data-no-results p{color:#797e80}.eui-dark-theme :host .delete-icon{color:#f29d99}.eui-dark-theme :host .add-icon{color:#8acbe3}.eui-dark-theme :host .imx-data-no-results .eui-icon{color:#c4cacc}.eui-dark-theme :host .imx-data-no-results p{color:#dfe4e6}.eui-contrast-theme :host .delete-icon{color:#db2534}.eui-contrast-theme :host .add-icon{color:#0a96d1}.eui-contrast-theme :host .imx-data-no-results .eui-icon{color:#dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}\n"] }]
        }], function () { return [{ type: PolicyViolationsService }, { type: i2$2.EuiLoadingService }, { type: i3$2.ConfirmationService }, { type: i0.ChangeDetectorRef }, { type: i3$2.SnackBarService }, { type: i4$1.UntypedFormBuilder }]; }, { uidViolation: [{
                type: Input
            }], isMControlPerViolation: [{
                type: Input
            }], sidesheetRef: [{
                type: Input
            }] });
})();

function PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_container_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_template_6_eui_icon_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "eui-icon", 12);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
    }
}
function PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_template_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "span");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(3, PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_template_6_eui_icon_3_Template, 2, 3, "eui-icon", 11);
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r10 = i0.ɵɵreference(8);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 2, "#LDS#Heading Mitigating Controls"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", _r10 == null ? null : _r10.isDirty);
    }
}
function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_mat_option_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-option", 19);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const relatedOption_r16 = ctx.$implicit;
        i0.ɵɵproperty("value", relatedOption_r16);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", relatedOption_r16.Display, " ");
    }
}
function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_imx_object_hyperview_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-object-hyperview", 20);
    }
    if (rf & 2) {
        const ctx_r15 = i0.ɵɵnextContext(4);
        i0.ɵɵproperty("objectType", ctx_r15.selectedHyperviewType)("objectUid", ctx_r15.selectedHyperviewUID);
    }
}
function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r18 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 14)(1, "mat-form-field", 15)(2, "mat-label");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "mat-select", 16);
        i0.ɵɵlistener("selectionChange", function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_Template_mat_select_selectionChange_5_listener() { i0.ɵɵrestoreView(_r18); const ctx_r17 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r17.onHyperviewOptionSelected()); })("valueChange", function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_Template_mat_select_valueChange_5_listener($event) { i0.ɵɵrestoreView(_r18); const ctx_r19 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r19.selectedOption = $event); });
        i0.ɵɵtemplate(6, PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_mat_option_6_Template, 2, 2, "mat-option", 17);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(7, PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_imx_object_hyperview_7_Template, 1, 2, "imx-object-hyperview", 18);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r13 = i0.ɵɵnextContext(3);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 4, "#LDS#Related objects"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("value", ctx_r13.selectedOption);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r13.relatedOptions);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !!ctx_r13.selectedOption);
    }
}
function PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 4);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵtemplate(2, PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_ng_template_2_Template, 8, 6, "ng-template", 13);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Hyperview"));
    }
}
function PolicyViolationsSidesheetComponent_mat_tab_group_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab-group")(1, "mat-tab", 4);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵtemplate(3, PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_container_3_Template, 1, 0, "ng-container", 5);
        i0.ɵɵtemplate(4, PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_container_4_Template, 1, 0, "ng-container", 5);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "mat-tab", 6);
        i0.ɵɵtemplate(6, PolicyViolationsSidesheetComponent_mat_tab_group_0_ng_template_6_Template, 4, 4, "ng-template", 7);
        i0.ɵɵelement(7, "imx-mitigating-controls", 8, 9);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(9, PolicyViolationsSidesheetComponent_mat_tab_group_0_mat_tab_9_Template, 3, 3, "mat-tab", 10);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        const _r3 = i0.ɵɵreference(4);
        const _r5 = i0.ɵɵreference(6);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 8, "#LDS#Heading Information"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngTemplateOutlet", _r3);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngTemplateOutlet", _r5);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("isMControlPerViolation", ctx_r0.data == null ? null : ctx_r0.data.isMControlPerViolation)("isReadOnly", ctx_r0.data == null ? null : ctx_r0.data.isReadOnly)("sidesheetRef", ctx_r0.sideSheetRef)("uidViolation", ctx_r0.data == null ? null : ctx_r0.data.policyViolation == null ? null : ctx_r0.data.policyViolation.GetEntity().GetKeys()[0]);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", (ctx_r0.relatedOptions == null ? null : ctx_r0.relatedOptions.length) > 1);
    }
}
function PolicyViolationsSidesheetComponent_ng_template_1_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function PolicyViolationsSidesheetComponent_ng_template_1_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function PolicyViolationsSidesheetComponent_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, PolicyViolationsSidesheetComponent_ng_template_1_ng_container_0_Template, 1, 0, "ng-container", 5);
        i0.ɵɵtemplate(1, PolicyViolationsSidesheetComponent_ng_template_1_ng_container_1_Template, 1, 0, "ng-container", 5);
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r3 = i0.ɵɵreference(4);
        const _r5 = i0.ɵɵreference(6);
        i0.ɵɵproperty("ngTemplateOutlet", _r3);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngTemplateOutlet", _r5);
    }
}
function PolicyViolationsSidesheetComponent_ng_template_3_eui_badge_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-badge", 25);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r22 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("color", ctx_r22.data == null ? null : ctx_r22.data.policyViolation == null ? null : ctx_r22.data.policyViolation.stateBadge == null ? null : ctx_r22.data.policyViolation.stateBadge.color);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, ctx_r22.data == null ? null : ctx_r22.data.policyViolation == null ? null : ctx_r22.data.policyViolation.stateBadge == null ? null : ctx_r22.data.policyViolation.stateBadge.caption), " ");
    }
}
function PolicyViolationsSidesheetComponent_ng_template_3_imx_cdr_editor_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 26);
    }
    if (rf & 2) {
        const cdr_r24 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r24);
    }
}
function PolicyViolationsSidesheetComponent_ng_template_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 21)(1, "mat-card")(2, "div", 22);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(4, PolicyViolationsSidesheetComponent_ng_template_3_eui_badge_4_Template, 3, 4, "eui-badge", 23);
        i0.ɵɵtemplate(5, PolicyViolationsSidesheetComponent_ng_template_3_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 24);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext();
        let tmp_0_0;
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", ctx_r4.data == null ? null : ctx_r4.data.policyViolation == null ? null : ctx_r4.data.policyViolation.State == null ? null : (tmp_0_0 = ctx_r4.data.policyViolation.State.GetMetadata()) == null ? null : tmp_0_0.GetDisplay(), " ");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r4.data == null ? null : ctx_r4.data.policyViolation == null ? null : ctx_r4.data.policyViolation.State == null ? null : ctx_r4.data.policyViolation.State.value);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r4.cdrList);
    }
}
function PolicyViolationsSidesheetComponent_ng_template_5_div_0_Template(rf, ctx) {
    if (rf & 1) {
        const _r27 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 28)(1, "button", 29);
        i0.ɵɵlistener("click", function PolicyViolationsSidesheetComponent_ng_template_5_div_0_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r27); const ctx_r26 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r26.approve()); });
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "button", 30);
        i0.ɵɵlistener("click", function PolicyViolationsSidesheetComponent_ng_template_5_div_0_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r27); const ctx_r28 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r28.deny()); });
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Grant exception"), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 4, "#LDS#Deny exception"), " ");
    }
}
function PolicyViolationsSidesheetComponent_ng_template_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, PolicyViolationsSidesheetComponent_ng_template_5_div_0_Template, 7, 6, "div", 27);
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext();
        i0.ɵɵproperty("ngIf", ctx_r6.isPending && !(ctx_r6.data == null ? null : ctx_r6.data.isReadOnly));
    }
}
class PolicyViolationsSidesheetComponent {
    constructor(data, policyViolationService, sideSheetRef) {
        this.data = data;
        this.policyViolationService = policyViolationService;
        this.sideSheetRef = sideSheetRef;
        this.cdrList = [];
        this.cdrList = this.data.policyViolation.properties;
    }
    get isPending() {
        var _a;
        return ((_a = this.data.policyViolation.State.value) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase()) === 'pending';
    }
    get objectType() {
        return this.data.policyViolation.GetEntity().TypeName;
    }
    get objectUid() {
        return this.data.policyViolation.GetEntity().GetKeys().join(',');
    }
    /**
     * Opens the Approve-Sidesheet for the current selected rules violations and closes the sidesheet afterwards.
     */
    approve() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.policyViolationService.approve([this.data.policyViolation]);
            return this.sideSheetRef.close(true);
        });
    }
    /**
     * Opens the Deny-Sidesheet for the current selected rules violations and closes the sidesheet afterwards.
     */
    deny() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.policyViolationService.deny([this.data.policyViolation]);
            return this.sideSheetRef.close(true);
        });
    }
    get relatedOptions() {
        return this.data.policyViolation.data || [];
    }
    setHyperviewObject(selectedRelatedObject) {
        const dbKey = DbObjectKey.FromXml(selectedRelatedObject.ObjectKey);
        this.selectedHyperviewType = dbKey.TableName;
        this.selectedHyperviewUID = dbKey.Keys.join(',');
    }
    onHyperviewOptionSelected() {
        this.setHyperviewObject(this.selectedOption);
    }
}
PolicyViolationsSidesheetComponent.ɵfac = function PolicyViolationsSidesheetComponent_Factory(t) { return new (t || PolicyViolationsSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(PolicyViolationsService), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetRef)); };
PolicyViolationsSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsSidesheetComponent, selectors: [["imx-policy-violations-sidesheet"]], decls: 7, vars: 2, consts: [[4, "ngIf", "ngIfElse"], ["singleElement", ""], ["singleContent", ""], ["actions", ""], [3, "label"], [4, "ngTemplateOutlet"], ["data-imx-identifier", "policy-violations-tab-mig-controls"], ["mat-tab-label", ""], [3, "isMControlPerViolation", "isReadOnly", "sidesheetRef", "uidViolation"], ["mitig", ""], [3, "label", 4, "ngIf"], ["icon", "save", "class", "imx-dirty-indicator", "size", "s", 4, "ngIf"], ["icon", "save", "size", "s", 1, "imx-dirty-indicator"], ["matTabContent", ""], ["eui-sidesheet-content", "", 1, "imx-policy-violations-hyperview"], ["appearance", "outline"], ["required", "", 3, "value", "selectionChange", "valueChange"], [3, "value", 4, "ngFor", "ngForOf"], [3, "objectType", "objectUid", 4, "ngIf"], [3, "value"], [3, "objectType", "objectUid"], ["eui-sidesheet-content", ""], [1, "imx-state-caption"], [3, "color", 4, "ngIf"], [3, "cdr", 4, "ngFor", "ngForOf"], [3, "color"], [3, "cdr"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "policy-violations-table-row-button-approve", 3, "click"], ["mat-stroked-button", "", "data-imx-identifier", "policy-violations-table-row-button-deny", 3, "click"]], template: function PolicyViolationsSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, PolicyViolationsSidesheetComponent_mat_tab_group_0_Template, 10, 10, "mat-tab-group", 0);
            i0.ɵɵtemplate(1, PolicyViolationsSidesheetComponent_ng_template_1_Template, 2, 2, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
            i0.ɵɵtemplate(3, PolicyViolationsSidesheetComponent_ng_template_3_Template, 6, 3, "ng-template", null, 2, i0.ɵɵtemplateRefExtractor);
            i0.ɵɵtemplate(5, PolicyViolationsSidesheetComponent_ng_template_5_Template, 1, 1, "ng-template", null, 3, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
            const _r1 = i0.ɵɵreference(2);
            i0.ɵɵproperty("ngIf", ctx.data == null ? null : ctx.data.isMControlPerViolation)("ngIfElse", _r1);
        }
    }, dependencies: [i2$2.EuiBadgeComponent, i2$2.EuiIconComponent, i2$2.EuiSidesheetContentDirective, i2$2.EuiSidesheetActionsDirective, i2$1.MatOption, i5.MatButton, i1.MatCard, i6.MatFormField, i6.MatLabel, i7.MatSelect, i8$1.MatTabGroup, i8$1.MatTabLabel, i8$1.MatTab, i8$1.MatTabContent, i9.NgForOf, i9.NgIf, i9.NgTemplateOutlet, i3$2.CdrEditorComponent, i2.ObjectHyperviewComponent, MitigatingControlsComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%}[_nghost-%COMP%]   .tab-group-wrapper[_ngcontent-%COMP%]{display:flex;overflow:auto;flex:1}[_nghost-%COMP%]   .tab-group-wrapper[_ngcontent-%COMP%]   .mat-tab-group[_ngcontent-%COMP%]{width:100%}[_nghost-%COMP%]   .tab-group-wrapper[_ngcontent-%COMP%]     .mat-tab-body-content{display:flex;flex-direction:column}[_nghost-%COMP%]   .tab-group-wrapper[_ngcontent-%COMP%]     .mat-tab-body-wrapper{flex:1}[_nghost-%COMP%]     .mat-tab-group{height:100%;flex-grow:1;overflow:auto}[_nghost-%COMP%]     .mat-tab-group .mat-tab-header{padding:0 32px}[_nghost-%COMP%]     .mat-tab-group   .mat-tab-body-wrapper{height:100%}[_nghost-%COMP%]     .mat-tab-group   .mat-tab-body-content{height:100%;display:flex;flex-direction:column}[_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{margin-left:5px}[_nghost-%COMP%]   .imx-content[_ngcontent-%COMP%]{display:flex;flex:1 1 auto;flex-direction:column}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]{margin-top:auto}[_nghost-%COMP%]   .eui-sidesheet-actions.mat-card[_ngcontent-%COMP%]{margin:16px 32px}[_nghost-%COMP%]   .eui-badge[_ngcontent-%COMP%]     .eui-badge-content{font-size:12px;line-height:12px;margin-bottom:20px}[_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{font-size:12px;padding-bottom:5px}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:10px}[_nghost-%COMP%]   .imx-policy-violations-hyperview[_ngcontent-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]     .mat-tab-header{background-color:#fff}[_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{color:#919799}[_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{color:#e36a00}.eui-dark-theme   [_nghost-%COMP%]     .mat-tab-header{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{color:#edbe8e}.eui-contrast-theme   [_nghost-%COMP%]     .mat-tab-header{background-color:#16191a}.eui-contrast-theme   [_nghost-%COMP%]   .imx-state-caption[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]   .imx-dirty-indicator[_ngcontent-%COMP%]{color:#e36a00}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsSidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-policy-violations-sidesheet', template: "<mat-tab-group *ngIf=\"data?.isMControlPerViolation; else singleElement\">\r\n  <mat-tab [label]=\"'#LDS#Heading Information' | translate\">\r\n    <ng-container *ngTemplateOutlet=\"singleContent\"></ng-container>\r\n    <ng-container *ngTemplateOutlet=\"actions\"></ng-container>\r\n  </mat-tab>\r\n\r\n  <mat-tab data-imx-identifier=\"policy-violations-tab-mig-controls\">\r\n    <ng-template mat-tab-label>\r\n      <span >{{'#LDS#Heading Mitigating Controls' | translate}}</span>\r\n      <eui-icon *ngIf=\"mitig?.isDirty\" icon=\"save\" class=\"imx-dirty-indicator\" size=\"s\" [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"></eui-icon>\r\n    </ng-template>\r\n    <imx-mitigating-controls #mitig [isMControlPerViolation]=\"data?.isMControlPerViolation\" [isReadOnly]=\"data?.isReadOnly\" [sidesheetRef]=\"sideSheetRef\" [uidViolation]=\"data?.policyViolation?.GetEntity().GetKeys()[0]\"></imx-mitigating-controls>\r\n  </mat-tab>\r\n  <mat-tab label=\"{{'#LDS#Heading Hyperview' | translate}}\" *ngIf=\"this.relatedOptions?.length > 1\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content class=\"imx-policy-violations-hyperview\">\r\n        <mat-form-field appearance=\"outline\" >\r\n          <mat-label>{{ '#LDS#Related objects' | translate }}</mat-label>\r\n          <mat-select required (selectionChange)=\"onHyperviewOptionSelected()\" [(value)]=\"selectedOption\">\r\n            <mat-option *ngFor=\"let relatedOption of relatedOptions\" [value]=\"relatedOption\">\r\n              {{ relatedOption.Display }}\r\n            </mat-option>\r\n          </mat-select>\r\n        </mat-form-field>\r\n        <imx-object-hyperview *ngIf=\"!!selectedOption\"\r\n          [objectType]=\"selectedHyperviewType\"\r\n          [objectUid]=\"selectedHyperviewUID\">\r\n        </imx-object-hyperview>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n</mat-tab-group>\r\n<ng-template #singleElement>\r\n  <ng-container *ngTemplateOutlet=\"singleContent\"></ng-container>\r\n  <ng-container *ngTemplateOutlet=\"actions\"></ng-container>\r\n</ng-template>\r\n\r\n<ng-template #singleContent>\r\n  <div eui-sidesheet-content>\r\n\r\n    <mat-card>\r\n      <div class=\"imx-state-caption\">\r\n        {{ data?.policyViolation?.State?.GetMetadata()?.GetDisplay() }}\r\n      </div>\r\n      <eui-badge [color]=\"data?.policyViolation?.stateBadge?.color\" *ngIf=\"data?.policyViolation?.State?.value\">\r\n        {{ data?.policyViolation?.stateBadge?.caption | translate }}\r\n      </eui-badge>\r\n      <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\r\n    </mat-card>\r\n  </div>\r\n</ng-template>\r\n\r\n<ng-template #actions>\r\n  <div eui-sidesheet-actions *ngIf=\"isPending && !data?.isReadOnly\">\r\n    <button mat-stroked-button (click)=\"approve()\" data-imx-identifier=\"policy-violations-table-row-button-approve\">\r\n      {{ '#LDS#Grant exception' | translate }}\r\n    </button>\r\n    <button mat-stroked-button (click)=\"deny()\" data-imx-identifier=\"policy-violations-table-row-button-deny\">\r\n      {{ '#LDS#Deny exception' | translate }}\r\n    </button>\r\n  </div>\r\n</ng-template>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;height:100%}:host .tab-group-wrapper{display:flex;overflow:auto;flex:1}:host .tab-group-wrapper .mat-tab-group{width:100%}:host .tab-group-wrapper ::ng-deep .mat-tab-body-content{display:flex;flex-direction:column}:host .tab-group-wrapper ::ng-deep .mat-tab-body-wrapper{flex:1}:host ::ng-deep .mat-tab-group{height:100%;flex-grow:1;overflow:auto}:host ::ng-deep .mat-tab-group .mat-tab-header{padding:0 32px}:host ::ng-deep .mat-tab-group ::ng-deep .mat-tab-body-wrapper{height:100%}:host ::ng-deep .mat-tab-group ::ng-deep .mat-tab-body-content{height:100%;display:flex;flex-direction:column}:host .imx-dirty-indicator{margin-left:5px}:host .imx-content{display:flex;flex:1 1 auto;flex-direction:column}:host .eui-sidesheet-actions{margin-top:auto}:host .eui-sidesheet-actions.mat-card{margin:16px 32px}:host .eui-badge ::ng-deep .eui-badge-content{font-size:12px;line-height:12px;margin-bottom:20px}:host .imx-state-caption{font-size:12px;padding-bottom:5px}:host .eui-sidesheet-actions button:not(:last-of-type){margin-right:10px}:host .imx-policy-violations-hyperview{display:flex;flex-direction:column}:host ::ng-deep .mat-tab-header{background-color:#fff}:host .imx-state-caption{color:#919799}:host .imx-dirty-indicator{color:#e36a00}.eui-dark-theme :host ::ng-deep .mat-tab-header{background-color:#2f3233}.eui-dark-theme :host .imx-state-caption{color:#dfe4e6}.eui-dark-theme :host .imx-dirty-indicator{color:#edbe8e}.eui-contrast-theme :host ::ng-deep .mat-tab-header{background-color:#16191a}.eui-contrast-theme :host .imx-state-caption{color:#fff}.eui-contrast-theme :host .imx-dirty-indicator{color:#e36a00}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: PolicyViolationsService }, { type: i2$2.EuiSidesheetRef }];
    }, null);
})();

function PolicyViolationsComponent_h2_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "h2", 13)(1, "span");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(4, "imx-help-contextual");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 1, "#LDS#Heading Policy Violations"));
    }
}
function PolicyViolationsComponent_ng_template_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 14)(1, "div");
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "div", 15);
        i0.ɵɵtext(4);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const item_r5 = ctx.$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r5.UID_QERPolicy.Column.GetDisplayValue());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r5.Description.Column.GetDisplayValue());
    }
}
function PolicyViolationsComponent_imx_data_table_generic_column_13_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r9 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 17)(1, "button", 18);
        i0.ɵɵlistener("click", function PolicyViolationsComponent_imx_data_table_generic_column_13_ng_template_1_Template_button_click_1_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r9); const item_r7 = restoredCtx.$implicit; const ctx_r8 = i0.ɵɵnextContext(2); ctx_r8.policyViolationsService.deny([item_r7]); return i0.ɵɵresetView($event.stopPropagation()); });
        i0.ɵɵelement(2, "eui-icon", 19);
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "button", 20);
        i0.ɵɵlistener("click", function PolicyViolationsComponent_imx_data_table_generic_column_13_ng_template_1_Template_button_click_5_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r9); const item_r7 = restoredCtx.$implicit; const ctx_r10 = i0.ɵɵnextContext(2); ctx_r10.policyViolationsService.approve([item_r7]); return i0.ɵɵresetView($event.stopPropagation()); });
        i0.ɵɵelement(6, "eui-icon", 21);
        i0.ɵɵtext(7);
        i0.ɵɵpipe(8, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "#LDS#Deny exception"), " ");
        i0.ɵɵadvance(4);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 4, "#LDS#Grant exception"), " ");
    }
}
function PolicyViolationsComponent_imx_data_table_generic_column_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-data-table-generic-column", 16);
        i0.ɵɵtemplate(1, PolicyViolationsComponent_imx_data_table_generic_column_13_ng_template_1_Template, 9, 6, "ng-template");
        i0.ɵɵelementEnd();
    }
}
function PolicyViolationsComponent_div_15_Template(rf, ctx) {
    if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 22);
        i0.ɵɵelement(1, "imx-selected-elements", 23)(2, "div", 24);
        i0.ɵɵelementStart(3, "button", 25);
        i0.ɵɵlistener("click", function PolicyViolationsComponent_div_15_Template_button_click_3_listener() { i0.ɵɵrestoreView(_r12); const ctx_r11 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r11.policyViolationsService.deny(ctx_r11.selectedViolations)); });
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelement(5, "eui-icon", 19);
        i0.ɵɵtext(6);
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(8, "button", 26);
        i0.ɵɵlistener("click", function PolicyViolationsComponent_div_15_Template_button_click_8_listener() { i0.ɵɵrestoreView(_r12); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.policyViolationsService.approve(ctx_r13.selectedViolations)); });
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelement(10, "eui-icon", 21);
        i0.ɵɵtext(11);
        i0.ɵɵpipe(12, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("selectedElements", ctx_r4.selectedViolations);
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(4, 7, "#LDS#Denies an exception for the selected policy violations"));
        i0.ɵɵproperty("disabled", !ctx_r4.selectedViolations.length);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 9, "#LDS#Deny exception"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(9, 11, "#LDS#Grants an exception for the selected policy violations"));
        i0.ɵɵproperty("disabled", !ctx_r4.selectedViolations.length);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 13, "#LDS#Grant exception"), " ");
    }
}
const _c0$1 = function () { return ["search", "sort", "filter", "settings"]; };
const _c1 = function () { return ["search", "sort", "filter", "groupBy", "settings"]; };
class PolicyViolationsComponent {
    constructor(policyViolationsService, viewConfigService, sidesheet, translate, actRoute) {
        this.policyViolationsService = policyViolationsService;
        this.viewConfigService = viewConfigService;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.actRoute = actRoute;
        this.DisplayColumns = DisplayColumns;
        this.selectedViolations = [];
        this.groupedData = {};
        this.busyService = new BusyService();
        this.filterOptions = [];
        this.displayedColumns = [];
        this.subscriptions = [];
        this.viewConfigPath = 'policies/violations';
        this.entitySchema = this.policyViolationsService.policyViolationsSchema;
        this.navigationState = {};
        this.subscriptions.push(this.policyViolationsService.applied.subscribe(() => __awaiter(this, void 0, void 0, function* () {
            this.getData();
            this.table.clearSelection();
        })));
    }
    ngOnInit() {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.selectedCompanyPolicy)
                this.approveOnly = this.actRoute.snapshot.url[this.actRoute.snapshot.url.length - 1].path === 'approve';
            this.displayedColumns = [
                ...(!this.selectedCompanyPolicy ? [(_a = this.entitySchema) === null || _a === void 0 ? void 0 : _a.Columns.UID_QERPolicy] : []),
                (_b = this.entitySchema) === null || _b === void 0 ? void 0 : _b.Columns.ObjectKey,
                (_c = this.entitySchema) === null || _c === void 0 ? void 0 : _c.Columns.State,
                ...(!this.selectedCompanyPolicy
                    ? [
                        {
                            ColumnName: 'actions',
                            Type: ValType.String,
                            afterAdditionals: true,
                            untranslatedDisplay: '#LDS#Approval decision',
                        },
                    ]
                    : []),
            ];
            const isBusy = this.busyService.beginBusy();
            try {
                this.dataModel = yield this.policyViolationsService.getPolicyViolationsDataModel();
                this.viewConfig = yield this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
                this.filterOptions = this.dataModel.Filters;
                // If this wasn't already set, then we need to get it from the config
                (_d = this.isMControlPerViolation) !== null && _d !== void 0 ? _d : (this.isMControlPerViolation = (yield this.policyViolationsService.getConfig()).MitigatingControlsPerViolation);
                this.subscriptions.push(this.actRoute.queryParams.subscribe((params) => this.updateFiltersFromRouteParams(params)));
                this.groupData = createGroupData(this.dataModel, (parameters) => this.policyViolationsService.getGroupInfo(Object.assign({
                    PageSize: this.navigationState.PageSize,
                    StartIndex: 0,
                }, parameters)), []);
            }
            finally {
                isBusy.endBusy();
            }
            return this.getData(undefined);
        });
    }
    viewDetails(selectedPolicyViolation) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.sidesheet
                .open(PolicyViolationsSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Policy Violation Details').toPromise(),
                subTitle: selectedPolicyViolation.GetEntity().GetDisplay(),
                panelClass: 'imx-sidesheet',
                padding: '0',
                width: '600px',
                testId: 'policy-violations-details-sidesheet',
                data: {
                    policyViolation: selectedPolicyViolation,
                    isMControlPerViolation: this.isMControlPerViolation,
                    isReadOnly: !!this.selectedCompanyPolicy,
                },
            })
                .afterClosed()
                .toPromise();
            if (result) {
                this.getData();
            }
        });
    }
    onSelectionChanged(cases) {
        this.selectedViolations = cases;
    }
    search(search) {
        return __awaiter(this, void 0, void 0, function* () {
            this.policyViolationsService.abortCall();
            return this.getData(Object.assign(Object.assign({}, this.navigationState), { search }));
        });
    }
    updateConfig(config) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.putViewConfig(config);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    deleteConfigById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.deleteViewConfig(id);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    onGroupingChange(groupInfo) {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const groupedData = this.groupedData[groupInfo.key];
                groupedData.data = groupInfo.isInitial
                    ? { totalCount: 0, Data: [] }
                    : yield this.policyViolationsService.get(this.approveOnly, groupedData.navigationState);
                groupedData.settings = {
                    displayedColumns: this.dstSettings.displayedColumns,
                    dataModel: this.dstSettings.dataModel,
                    dataSource: groupedData.data,
                    entitySchema: this.dstSettings.entitySchema,
                    navigationState: groupedData.navigationState,
                };
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    getData(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            const isBusy = this.busyService.beginBusy();
            try {
                if (this.selectedCompanyPolicy) {
                    const selectedCompanyPolicyKey = this.selectedCompanyPolicy.GetEntity().GetKeys()[0];
                    this.navigationState.uid_qerpolicy = selectedCompanyPolicyKey;
                    this.filterOptions = this.filterOptions.filter((filter) => filter.Name !== 'uid_qerpolicy');
                }
                const dataSource = yield this.policyViolationsService.get(this.approveOnly, this.navigationState);
                if (dataSource) {
                    const exportMethod = this.policyViolationsService.exportPolicyViolations(this.navigationState);
                    exportMethod.initialColumns = this.displayedColumns.map((col) => col.ColumnName);
                    this.dstSettings = {
                        dataSource,
                        entitySchema: this.entitySchema,
                        navigationState: this.navigationState,
                        filters: this.filterOptions,
                        dataModel: this.dataModel,
                        groupData: this.groupData,
                        viewConfig: this.viewConfig,
                        exportMethod,
                        displayedColumns: this.displayedColumns,
                    };
                }
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    updateFiltersFromRouteParams(params) {
        if (this.viewConfigService.isDefaultConfigSet()) {
            // If there is a default config, we will not use our defaults
            return;
        }
        this.navigationState.OrderBy = 'DecisionDate';
        let foundMatchingParam = false;
        for (const [key, value] of Object.entries(params)) {
            if (this.tryApplyFilter(key, value)) {
                foundMatchingParam = true;
            }
        }
    }
    tryApplyFilter(name, value) {
        const index = this.dataModel.Filters.findIndex((elem) => elem.Name.toLowerCase() === name.toLowerCase());
        if (index > -1) {
            const filter = this.dataModel.Filters[index];
            if (filter) {
                filter.InitialValue = value;
                filter.CurrentValue = value;
                this.navigationState[name] = value;
                return true;
            }
        }
        return false;
    }
}
PolicyViolationsComponent.ɵfac = function PolicyViolationsComponent_Factory(t) { return new (t || PolicyViolationsComponent)(i0.ɵɵdirectiveInject(PolicyViolationsService), i0.ɵɵdirectiveInject(i2.ViewConfigService), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i3.ActivatedRoute)); };
PolicyViolationsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PolicyViolationsComponent, selectors: [["imx-policy-violations"]], viewQuery: function PolicyViolationsComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(DataTableComponent, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.table = _t.first);
        }
    }, inputs: { selectedCompanyPolicy: "selectedCompanyPolicy", isMControlPerViolation: "isMControlPerViolation" }, decls: 16, vars: 20, consts: [[1, "imx-policyviolation-page"], ["class", "mat-headline", 4, "ngIf"], [1, "imx-table-container"], ["data-imx-identifier", "policy-violations-table-dst", 3, "options", "settings", "busyService", "navigationStateChanged", "search", "updateConfig", "deleteConfigById"], ["dst", ""], [1, "imx-policyviolation-table"], ["mode", "manual", "data-imx-identifier", "policy-violations-table", 3, "dst", "detailViewVisible", "selectable", "showSelectedItemsMenu", "groupData", "selectionChanged", "groupDataChanged", "highlightedEntityChanged"], ["data-imx-identifier", "policy-violations-table-column-UID_QERPolicy", 3, "entityColumn"], ["data-imx-identifier", "policy-violations-table-column-ObjectKey", 3, "entityColumn", "columnLabel"], ["data-imx-identifier", "policy-violations-table-column-State", 3, "entityColumn"], ["columnName", "actions", "data-imx-identifier", "policy-violations-table-column-edit", 4, "ngIf"], ["data-imx-identifier", "policy-violations-table-paginator", 3, "dst"], ["class", "imx-button-bar", 4, "ngIf"], [1, "mat-headline"], ["data-imx-identifier", "rules-violations-table-row-button-view-details", 1, "imx-main-column"], ["subtitle", ""], ["columnName", "actions", "data-imx-identifier", "policy-violations-table-column-edit"], [1, "imx-decision"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "policy-violations-table-deny-button", 3, "click"], ["icon", "ignore"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "policy-violations-table-approve-button", 3, "click"], ["icon", "check"], [1, "imx-button-bar"], [3, "selectedElements"], [1, "imx-menu-spacer"], ["mat-raised-button", "", "color", "warn", "data-imx-identifier", "policy-violations-table-button-deny", 3, "title", "disabled", "click"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "policy-violations-table-button-approve", 3, "title", "disabled", "click"]], template: function PolicyViolationsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, PolicyViolationsComponent_h2_1_Template, 5, 3, "h2", 1);
            i0.ɵɵelementStart(2, "mat-card")(3, "div", 2)(4, "imx-data-source-toolbar", 3, 4);
            i0.ɵɵlistener("navigationStateChanged", function PolicyViolationsComponent_Template_imx_data_source_toolbar_navigationStateChanged_4_listener($event) { return ctx.getData($event); })("search", function PolicyViolationsComponent_Template_imx_data_source_toolbar_search_4_listener($event) { return ctx.search($event); })("updateConfig", function PolicyViolationsComponent_Template_imx_data_source_toolbar_updateConfig_4_listener($event) { return ctx.updateConfig($event); })("deleteConfigById", function PolicyViolationsComponent_Template_imx_data_source_toolbar_deleteConfigById_4_listener($event) { return ctx.deleteConfigById($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(6, "div", 5)(7, "imx-data-table", 6);
            i0.ɵɵlistener("selectionChanged", function PolicyViolationsComponent_Template_imx_data_table_selectionChanged_7_listener($event) { return ctx.onSelectionChanged($event); })("groupDataChanged", function PolicyViolationsComponent_Template_imx_data_table_groupDataChanged_7_listener($event) { return ctx.onGroupingChange($event); })("highlightedEntityChanged", function PolicyViolationsComponent_Template_imx_data_table_highlightedEntityChanged_7_listener($event) { return ctx.viewDetails($event); });
            i0.ɵɵelementStart(8, "imx-data-table-column", 7);
            i0.ɵɵtemplate(9, PolicyViolationsComponent_ng_template_9_Template, 5, 2, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(10, "imx-data-table-column", 8);
            i0.ɵɵpipe(11, "translate");
            i0.ɵɵelement(12, "imx-data-table-column", 9);
            i0.ɵɵtemplate(13, PolicyViolationsComponent_imx_data_table_generic_column_13_Template, 2, 0, "imx-data-table-generic-column", 10);
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(14, "imx-data-source-paginator", 11);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(15, PolicyViolationsComponent_div_15_Template, 13, 15, "div", 12);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            const _r1 = i0.ɵɵreference(5);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.selectedCompanyPolicy);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("options", ctx.selectedCompanyPolicy ? i0.ɵɵpureFunction0(18, _c0$1) : i0.ɵɵpureFunction0(19, _c1))("settings", ctx.dstSettings)("busyService", ctx.busyService);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r1)("detailViewVisible", false)("selectable", !ctx.selectedCompanyPolicy)("showSelectedItemsMenu", false)("groupData", ctx.groupedData);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UID_QERPolicy);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.ObjectKey)("columnLabel", i0.ɵɵpipeBind1(11, 16, "#LDS#Violating object"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.State);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.selectedCompanyPolicy);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r1);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.selectedCompanyPolicy);
        }
    }, dependencies: [i2$2.EuiIconComponent, i5.MatButton, i1.MatCard, i9.NgIf, i3$2.DataTableComponent, i3$2.DataTableColumnComponent, i3$2.DataTableGenericColumnComponent, i3$2.DataSourceToolbarComponent, i3$2.DataSourcePaginatorComponent, i3$2.SelectedElementsComponent, i3$2.HelpContextualComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]   .imx-main-column[_ngcontent-%COMP%]{flex-direction:column}.eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.heading-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex:0 0 auto}.heading-wrapper[_ngcontent-%COMP%]   .helper-alert[_ngcontent-%COMP%]{display:flex;margin-bottom:15px}.heading-wrapper[_ngcontent-%COMP%]   .alert-wrapper[_ngcontent-%COMP%]{margin:0 0 0 auto;align-self:flex-end;width:50%}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;width:inherit;max-width:100%}.imx-policyviolation-page[_ngcontent-%COMP%]{background-color:inherit;flex-direction:column;overflow:hidden;display:flex;height:100%}.imx-policyviolation-page[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin-right:3px}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-policyviolation-table[_ngcontent-%COMP%]{flex-grow:1;overflow:auto}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-policyviolation-table[_ngcontent-%COMP%]   .imx-main-column[_ngcontent-%COMP%]{max-width:600px;margin-right:10px}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-policyviolation-table[_ngcontent-%COMP%]   .imx-decision[_ngcontent-%COMP%]{display:flex;flex-direction:row;justify-content:flex-end}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-policyviolation-table[_ngcontent-%COMP%]   .imx-decision[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]{margin-right:16px}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-policyviolation-table[_ngcontent-%COMP%]   .imx-decision[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.imx-policyviolation-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-policyviolation-table[_ngcontent-%COMP%]   .imx-decision[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:5px}.imx-policyviolation-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-policyviolation-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:16px}.imx-policyviolation-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .imx-menu-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.imx-policyviolation-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%], .imx-policyviolation-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .mat-raised-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}@media screen and (max-width: 768px){.imx-rules-violations-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]{display:block}.imx-rules-violations-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]   .alert-wrapper[_ngcontent-%COMP%]{margin:0 0 20px;width:100%}}@media only screen and (max-width: 1024px){  .mat-column-decision{display:none}}.eui-dark-theme   [_nghost-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]{color:#aab0b3}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsComponent, [{
            type: Component,
            args: [{ selector: 'imx-policy-violations', template: "<div class=\"imx-policyviolation-page\">\r\n  <h2 class=\"mat-headline\" *ngIf=\"!selectedCompanyPolicy\">\r\n    <span>{{ '#LDS#Heading Policy Violations' | translate }}</span>\r\n    <imx-help-contextual></imx-help-contextual>\r\n  </h2>\r\n  <mat-card>\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-source-toolbar\r\n        #dst\r\n        [options]=\"selectedCompanyPolicy ? ['search', 'sort', 'filter', 'settings'] : ['search', 'sort', 'filter', 'groupBy', 'settings']\"\r\n        [settings]=\"dstSettings\"\r\n        [busyService]=\"busyService\"\r\n        data-imx-identifier=\"policy-violations-table-dst\"\r\n        (navigationStateChanged)=\"getData($event)\"\r\n        (search)=\"search($event)\"\r\n        (updateConfig)=\"updateConfig($event)\"\r\n        (deleteConfigById)=\"deleteConfigById($event)\"\r\n      >\r\n      </imx-data-source-toolbar>\r\n      <div class=\"imx-policyviolation-table\">\r\n        <imx-data-table\r\n          [dst]=\"dst\"\r\n          [detailViewVisible]=\"false\"\r\n          mode=\"manual\"\r\n          [selectable]=\"!selectedCompanyPolicy\"\r\n          [showSelectedItemsMenu]=\"false\"\r\n          (selectionChanged)=\"onSelectionChanged($event)\"\r\n          data-imx-identifier=\"policy-violations-table\"\r\n          [groupData]=\"groupedData\"\r\n          (groupDataChanged)=\"onGroupingChange($event)\"\r\n          (highlightedEntityChanged)=\"viewDetails($event)\"\r\n        >\r\n          <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_QERPolicy\" data-imx-identifier=\"policy-violations-table-column-UID_QERPolicy\">\r\n            <ng-template let-item>\r\n              <div class=\"imx-main-column\" data-imx-identifier=\"rules-violations-table-row-button-view-details\">\r\n                <div>{{ item.UID_QERPolicy.Column.GetDisplayValue() }}</div>\r\n                <div subtitle>{{ item.Description.Column.GetDisplayValue() }}</div>\r\n              </div>\r\n            </ng-template>\r\n          </imx-data-table-column>\r\n          <imx-data-table-column\r\n            [entityColumn]=\"entitySchema.Columns.ObjectKey\"\r\n            [columnLabel]=\"'#LDS#Violating object' | translate\"\r\n            data-imx-identifier=\"policy-violations-table-column-ObjectKey\"\r\n          >\r\n          </imx-data-table-column>\r\n          <imx-data-table-column [entityColumn]=\"entitySchema.Columns.State\" data-imx-identifier=\"policy-violations-table-column-State\"> </imx-data-table-column>\r\n\r\n          <imx-data-table-generic-column columnName=\"actions\" data-imx-identifier=\"policy-violations-table-column-edit\" *ngIf=\"!selectedCompanyPolicy\">\r\n            <ng-template let-item>\r\n              <div class=\"imx-decision\">\r\n                <button\r\n                  mat-stroked-button\r\n                  color=\"warn\"\r\n                  (click)=\"policyViolationsService.deny([item]); $event.stopPropagation()\"\r\n                  data-imx-identifier=\"policy-violations-table-deny-button\"\r\n                >\r\n                  <eui-icon icon=\"ignore\"></eui-icon>\r\n                  {{ '#LDS#Deny exception' | translate }}\r\n                </button>\r\n                <button\r\n                  mat-stroked-button\r\n                  color=\"primary\"\r\n                  (click)=\"policyViolationsService.approve([item]); $event.stopPropagation()\"\r\n                  data-imx-identifier=\"policy-violations-table-approve-button\"\r\n                >\r\n                  <eui-icon icon=\"check\"></eui-icon>\r\n                  {{ '#LDS#Grant exception' | translate }}\r\n                </button>\r\n              </div>\r\n            </ng-template>\r\n          </imx-data-table-generic-column>\r\n        </imx-data-table>\r\n      </div>\r\n      <imx-data-source-paginator [dst]=\"dst\" data-imx-identifier=\"policy-violations-table-paginator\"> </imx-data-source-paginator>\r\n    </div>\r\n  </mat-card>\r\n  <div class=\"imx-button-bar\" *ngIf=\"!selectedCompanyPolicy\">\r\n    <imx-selected-elements [selectedElements]=\"selectedViolations\"></imx-selected-elements>\r\n    <div class=\"imx-menu-spacer\"></div>\r\n\r\n    <button\r\n      mat-raised-button\r\n      color=\"warn\"\r\n      data-imx-identifier=\"policy-violations-table-button-deny\"\r\n      title=\"{{ '#LDS#Denies an exception for the selected policy violations' | translate }}\"\r\n      (click)=\"policyViolationsService.deny(selectedViolations)\"\r\n      [disabled]=\"!selectedViolations.length\"\r\n    >\r\n      <eui-icon icon=\"ignore\"></eui-icon>\r\n      {{ '#LDS#Deny exception' | translate }}\r\n    </button>\r\n    <button\r\n      mat-raised-button\r\n      color=\"primary\"\r\n      data-imx-identifier=\"policy-violations-table-button-approve\"\r\n      title=\"{{ '#LDS#Grants an exception for the selected policy violations' | translate }}\"\r\n      (click)=\"policyViolationsService.approve(selectedViolations)\"\r\n      [disabled]=\"!selectedViolations.length\"\r\n    >\r\n      <eui-icon icon=\"check\"></eui-icon>\r\n      {{ '#LDS#Grant exception' | translate }}\r\n    </button>\r\n  </div>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host .imx-main-column{flex-direction:column}.eui-sidesheet-content{display:flex;flex-direction:column}.heading-wrapper{display:flex;flex-direction:row;flex:0 0 auto}.heading-wrapper .helper-alert{display:flex;margin-bottom:15px}.heading-wrapper .alert-wrapper{margin:0 0 0 auto;align-self:flex-end;width:50%}:host{display:flex;flex-direction:column;overflow:hidden;height:inherit;width:inherit;max-width:100%}.imx-policyviolation-page{background-color:inherit;flex-direction:column;overflow:hidden;display:flex;height:100%}.imx-policyviolation-page .mat-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin-right:3px}.imx-policyviolation-page div.imx-table-container{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto}.imx-policyviolation-page div.imx-table-container .imx-policyviolation-table{flex-grow:1;overflow:auto}.imx-policyviolation-page div.imx-table-container .imx-policyviolation-table .imx-main-column{max-width:600px;margin-right:10px}.imx-policyviolation-page div.imx-table-container .imx-policyviolation-table .imx-decision{display:flex;flex-direction:row;justify-content:flex-end}.imx-policyviolation-page div.imx-table-container .imx-policyviolation-table .imx-decision .mat-stroked-button{margin-right:16px}.imx-policyviolation-page div.imx-table-container .imx-policyviolation-table .imx-decision .mat-stroked-button eui-icon{font-size:14px;margin-right:4px}.imx-policyviolation-page div.imx-table-container .imx-policyviolation-table .imx-decision>button:not(:last-of-type){margin-right:5px}.imx-policyviolation-page .imx-button-bar{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-policyviolation-page .imx-button-bar>button:not(:last-of-type){margin-right:16px}.imx-policyviolation-page .imx-button-bar .imx-menu-spacer{flex:1 1 auto}.imx-policyviolation-page .imx-button-bar .mat-stroked-button eui-icon,.imx-policyviolation-page .imx-button-bar .mat-raised-button eui-icon{font-size:14px;margin-right:4px}@media screen and (max-width: 768px){.imx-rules-violations-page .heading-wrapper{display:block}.imx-rules-violations-page .heading-wrapper .alert-wrapper{margin:0 0 20px;width:100%}}@media only screen and (max-width: 1024px){::ng-deep .mat-column-decision{display:none}}.eui-dark-theme :host .imx-button-bar{color:#aab0b3}\n"] }]
        }], function () { return [{ type: PolicyViolationsService }, { type: i2.ViewConfigService }, { type: i2$2.EuiSidesheetService }, { type: i4.TranslateService }, { type: i3.ActivatedRoute }]; }, { selectedCompanyPolicy: [{
                type: Input
            }], isMControlPerViolation: [{
                type: Input
            }], table: [{
                type: ViewChild,
                args: [DataTableComponent]
            }] });
})();

class PoliciesService {
    constructor(apiservice, appConfig) {
        this.apiservice = apiservice;
        this.appConfig = appConfig;
        this.abortController = new AbortController();
    }
    get policySchema() {
        return this.apiservice.typedClient.PortalPolicies.GetSchema();
    }
    featureConfig() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.client.portal_policy_config_get();
        });
    }
    getPolicies(parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.typedClient.PortalPolicies.Get(parameter, { signal: this.abortController.signal });
        });
    }
    getDataModel() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.client.portal_policies_datamodel_get();
        });
    }
    policyReport(uidpolicy) {
        const path = `policies/${uidpolicy}/report`;
        return `${this.appConfig.BaseUrl}/portal/${path}`;
    }
    /**
     * Calls the api for the mitigating controls associated with a policy
     * @param uid policy uid
     * @returns a promise of the array of mitigating controls
     */
    getMitigatingControls(uid) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiservice.typedClient.PortalPoliciesMitigatingcontrols.Get(uid);
        });
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
}
PoliciesService.ɵfac = function PoliciesService_Factory(t) { return new (t || PoliciesService)(i0.ɵɵinject(ApiService), i0.ɵɵinject(i3$2.AppConfigService)); };
PoliciesService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PoliciesService, factory: PoliciesService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PoliciesService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: ApiService }, { type: i3$2.AppConfigService }]; }, null);
})();

function MitigatingControlsPolicyComponent_eui_alert_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 4)(1, "eui-alert-header");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "eui-alert-content");
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Heading Mitigating Controls Can Be Assigned Individually"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Here you can get an overview of the mitigating controls that can be assigned to a violation of this company policy."));
    }
}
function MitigatingControlsPolicyComponent_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 4)(1, "eui-alert-header");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "eui-alert-content");
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Heading Mitigating Controls Applied Globally"));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Here you can get an overview of the mitigating controls that are automatically applied to every violation of this company policy."));
    }
}
function MitigatingControlsPolicyComponent_div_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 5);
        i0.ɵɵelement(1, "eui-icon", 6);
        i0.ɵɵelementContainerStart(2);
        i0.ɵɵelement(3, "p", 7);
        i0.ɵɵelementContainerEnd();
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("translate", "#LDS#There are currently no mitigating controls assigned to this company policy.");
    }
}
function MitigatingControlsPolicyComponent_div_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵelement(1, "imx-cdr-editor", 8);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const mControl_r4 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("cdr", mControl_r4);
    }
}
/**
 * Used to get and display mitigating controls for each policy
 */
class MitigatingControlsPolicyComponent {
    /**
     * @ignore only for dep injection
     */
    constructor(apiService, busyService, cdrService) {
        this.apiService = apiService;
        this.busyService = busyService;
        this.cdrService = cdrService;
    }
    /**
     * Setup component with mitigating controls
     */
    ngOnInit() {
        this.getMitigatingControls();
    }
    /**
     * Calls the api and map the results into display cdrs
     */
    getMitigatingControls() {
        return __awaiter(this, void 0, void 0, function* () {
            this.busyService.show();
            try {
                this.mControls = (yield this.apiService.getMitigatingControls(this.objectUid)).Data.map((control) => this.cdrService.buildCdr(control.GetEntity(), control.UID_MitigatingControl.Column.ColumnName));
            }
            finally {
                this.busyService.hide();
            }
        });
    }
}
MitigatingControlsPolicyComponent.ɵfac = function MitigatingControlsPolicyComponent_Factory(t) { return new (t || MitigatingControlsPolicyComponent)(i0.ɵɵdirectiveInject(PoliciesService), i0.ɵɵdirectiveInject(i2$2.EuiLoadingService), i0.ɵɵdirectiveInject(i3$2.CdrFactoryService)); };
MitigatingControlsPolicyComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: MitigatingControlsPolicyComponent, selectors: [["imx-mitigating-controls-policy"]], inputs: { objectUid: "objectUid", isMControlPerViolation: "isMControlPerViolation" }, decls: 5, vars: 4, consts: [["class", "imx-helper-alert", "type", "info", "condensed", "true", "colored", "true", 4, "ngIf"], [1, "imx-mitigating-controls-card"], ["class", "imx-data-no-results", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["type", "info", "condensed", "true", "colored", "true", 1, "imx-helper-alert"], [1, "imx-data-no-results"], ["icon", "table"], [3, "translate"], [3, "cdr"]], template: function MitigatingControlsPolicyComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, MitigatingControlsPolicyComponent_eui_alert_0_Template, 7, 6, "eui-alert", 0);
            i0.ɵɵtemplate(1, MitigatingControlsPolicyComponent_eui_alert_1_Template, 7, 6, "eui-alert", 0);
            i0.ɵɵelementStart(2, "mat-card", 1);
            i0.ɵɵtemplate(3, MitigatingControlsPolicyComponent_div_3_Template, 4, 1, "div", 2);
            i0.ɵɵtemplate(4, MitigatingControlsPolicyComponent_div_4_Template, 2, 1, "div", 3);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.isMControlPerViolation);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.isMControlPerViolation);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", !ctx.mControls || ctx.mControls.length == 0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.mControls);
        }
    }, dependencies: [i9.NgForOf, i9.NgIf, i2$2.EuiAlertComponent, i2$2.EuiAlertContentDirective, i2$2.EuiAlertHeaderDirective, i2$2.EuiIconComponent, i4.TranslateDirective, i3$2.CdrEditorComponent, i1.MatCard, i4.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .imx-helper-alert[_ngcontent-%COMP%]{margin-bottom:20px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]{text-align:center;flex:1 1 auto}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-top:10px}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}[_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#797e80}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-data-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(MitigatingControlsPolicyComponent, [{
            type: Component,
            args: [{ selector: 'imx-mitigating-controls-policy', template: "<eui-alert class=\"imx-helper-alert\" type=\"info\" condensed=\"true\" colored=\"true\" *ngIf=\"isMControlPerViolation\">\r\n  <eui-alert-header>{{ '#LDS#Heading Mitigating Controls Can Be Assigned Individually' | translate }}</eui-alert-header>\r\n  <eui-alert-content>{{\r\n    '#LDS#Here you can get an overview of the mitigating controls that can be assigned to a violation of this company policy.' | translate\r\n  }}</eui-alert-content>\r\n</eui-alert>\r\n<eui-alert class=\"imx-helper-alert\" type=\"info\" condensed=\"true\" colored=\"true\" *ngIf=\"!isMControlPerViolation\">\r\n  <eui-alert-header>{{'#LDS#Heading Mitigating Controls Applied Globally' | translate}}</eui-alert-header>\r\n  <eui-alert-content>{{ '#LDS#Here you can get an overview of the mitigating controls that are automatically applied to every violation of this company policy.' | translate }}</eui-alert-content>\r\n</eui-alert>\r\n\r\n<mat-card class=\"imx-mitigating-controls-card\">\r\n  <div class=\"imx-data-no-results\" *ngIf=\"!mControls || mControls.length == 0\">\r\n    <eui-icon icon=\"table\"></eui-icon>\r\n    <ng-container>\r\n      <p [translate]=\"'#LDS#There are currently no mitigating controls assigned to this company policy.'\"></p>\r\n    </ng-container>\r\n  </div>\r\n  <div *ngFor=\"let mControl of mControls\">\r\n    <imx-cdr-editor [cdr]=\"mControl\"></imx-cdr-editor>\r\n  </div>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column}:host .imx-helper-alert{margin-bottom:20px}:host .imx-data-no-results{text-align:center;flex:1 1 auto}:host .imx-data-no-results .eui-icon{font-size:100px}:host .imx-data-no-results p{margin:0;font-size:18px}:host .imx-data-no-results button{margin-top:10px}:host .imx-data-no-results .eui-icon{color:#dfe4e6}:host .imx-data-no-results p{color:#797e80}.eui-dark-theme :host .imx-data-no-results .eui-icon{color:#c4cacc}.eui-dark-theme :host .imx-data-no-results p{color:#dfe4e6}.eui-contrast-theme :host .imx-data-no-results .eui-icon{color:#dfe4e6}.eui-contrast-theme :host .imx-data-no-results p{color:#fff}\n"] }]
        }], function () { return [{ type: PoliciesService }, { type: i2$2.EuiLoadingService }, { type: i3$2.CdrFactoryService }]; }, { objectUid: [{
                type: Input
            }], isMControlPerViolation: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function PoliciesSidesheetComponent_ng_template_3_imx_cdr_editor_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-cdr-editor", 8);
    }
    if (rf & 2) {
        const cdr_r6 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r6);
    }
}
function PoliciesSidesheetComponent_ng_template_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 4)(1, "mat-card");
        i0.ɵɵtemplate(2, PoliciesSidesheetComponent_ng_template_3_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 5);
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(3, "div", 6)(4, "button", 7);
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", ctx_r0.cdrList);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("euiDownload", ctx_r0.reportDownload);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 3, "#LDS#Download report"), " ");
    }
}
function PoliciesSidesheetComponent_ng_template_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 4);
        i0.ɵɵelement(1, "imx-policy-violations", 9);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("selectedCompanyPolicy", ctx_r1.data.selectedPolicy)("isMControlPerViolation", ctx_r1.data.isMControlPerViolation);
    }
}
function PoliciesSidesheetComponent_mat_tab_7_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 4);
        i0.ɵɵelement(1, "imx-mitigating-controls-policy", 10);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r7 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("objectUid", ctx_r7.objectUid)("isMControlPerViolation", ctx_r7.data.isMControlPerViolation);
    }
}
function PoliciesSidesheetComponent_mat_tab_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 0);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵtemplate(2, PoliciesSidesheetComponent_mat_tab_7_ng_template_2_Template, 2, 2, "ng-template", 1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Mitigating Controls"));
    }
}
function PoliciesSidesheetComponent_ng_template_10_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 4);
        i0.ɵɵelement(1, "imx-statistics-for-objects", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("objectType", ctx_r3.objectType)("objectUid", ctx_r3.objectUid);
    }
}
function PoliciesSidesheetComponent_ng_template_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 4);
        i0.ɵɵelement(1, "imx-object-hyperview", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext();
        let tmp_0_0;
        let tmp_1_0;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("objectType", ctx_r4.data == null ? null : ctx_r4.data.selectedPolicy == null ? null : (tmp_0_0 = ctx_r4.data.selectedPolicy.GetEntity()) == null ? null : tmp_0_0.TypeName)("objectUid", ctx_r4.data == null ? null : ctx_r4.data.selectedPolicy == null ? null : (tmp_1_0 = ctx_r4.data.selectedPolicy.GetEntity()) == null ? null : tmp_1_0.GetKeys()[0]);
    }
}
class PoliciesSidesheetComponent {
    constructor(data, sidesheetRef, policiesProvider, elementalUiConfigService) {
        this.data = data;
        this.sidesheetRef = sidesheetRef;
        this.policiesProvider = policiesProvider;
        this.subscriptions$ = [];
        this.uidCompliance = data.selectedPolicy.GetEntity().GetKeys().join(',');
        this.cdrList = [
            new BaseReadonlyCdr(this.data.selectedPolicy.GetEntity().GetColumn(DisplayColumns.DISPLAY_PROPERTYNAME)),
            new BaseReadonlyCdr(this.data.selectedPolicy.Description.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.IsExceptionAllowed.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.IsInActive.Column),
            data.hasRiskIndex ? new BaseReadonlyCdr(this.data.selectedPolicy.RiskIndex.Column) : null,
            new BaseReadonlyCdr(this.data.selectedPolicy.RuleSeverity.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.RuleViolationThreshold.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.SignificancyClass.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.TransparencyIndex.Column),
            new BaseReadonlyCdr(this.data.selectedPolicy.UID_QERPolicyGroup.Column),
        ].filter((elem) => elem != null);
        this.reportDownload = Object.assign(Object.assign({}, elementalUiConfigService.Config.downloadOptions), { url: this.policiesProvider.policyReport(this.uidCompliance) });
    }
    get objectType() {
        return this.data.selectedPolicy.GetEntity().TypeName;
    }
    get objectUid() {
        return this.data.selectedPolicy.GetEntity().GetKeys().join(',');
    }
    ngOnDestroy() {
        this.subscriptions$.map((sub) => sub.unsubscribe());
    }
}
PoliciesSidesheetComponent.ɵfac = function PoliciesSidesheetComponent_Factory(t) { return new (t || PoliciesSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetRef), i0.ɵɵdirectiveInject(PoliciesService), i0.ɵɵdirectiveInject(i3$2.ElementalUiConfigService)); };
PoliciesSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PoliciesSidesheetComponent, selectors: [["imx-policies-sidesheet"]], decls: 14, vars: 13, consts: [[3, "label"], ["matTabContent", ""], [3, "label", 4, "ngIf"], ["data-imx-identifier", "policies-sidesheet-tab-statistics", 3, "label"], ["eui-sidesheet-content", ""], [3, "cdr", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "data-imx-identifier", "policies-sidesheet-button-download-report", 1, "justify-start", 3, "euiDownload"], [3, "cdr"], [3, "selectedCompanyPolicy", "isMControlPerViolation"], [3, "objectUid", "isMControlPerViolation"], [3, "objectType", "objectUid"]], template: function PoliciesSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group")(1, "mat-tab", 0);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵtemplate(3, PoliciesSidesheetComponent_ng_template_3_Template, 7, 5, "ng-template", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-tab", 0);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵtemplate(6, PoliciesSidesheetComponent_ng_template_6_Template, 2, 2, "ng-template", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, PoliciesSidesheetComponent_mat_tab_7_Template, 3, 3, "mat-tab", 2);
            i0.ɵɵelementStart(8, "mat-tab", 3);
            i0.ɵɵpipe(9, "translate");
            i0.ɵɵtemplate(10, PoliciesSidesheetComponent_ng_template_10_Template, 2, 2, "ng-template", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(11, "mat-tab", 0);
            i0.ɵɵpipe(12, "translate");
            i0.ɵɵtemplate(13, PoliciesSidesheetComponent_ng_template_13_Template, 2, 2, "ng-template", 1);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 5, "#LDS#Heading Information"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(5, 7, "#LDS#Heading Policy Violations"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.data.hasRiskIndex);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(9, 9, "#LDS#Heading Statistics"));
            i0.ɵɵadvance(3);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(12, 11, "#LDS#Heading Hyperview"));
        }
    }, dependencies: [i9.NgForOf, i9.NgIf, i2$2.EuiDownloadDirective, i2$2.EuiSidesheetContentDirective, i2$2.EuiSidesheetActionsDirective, i3$2.CdrEditorComponent, i5.MatButton, i1.MatCard, i8$1.MatTabGroup, i8$1.MatTab, i8$1.MatTabContent, i2.StatisticsForObjectsComponent, i2.ObjectHyperviewComponent, PolicyViolationsComponent, MitigatingControlsPolicyComponent, i4.TranslatePipe], styles: ["[_nghost-%COMP%]   .mat-tab-group[_ngcontent-%COMP%], [_nghost-%COMP%]     .mat-tab-body-wrapper{height:100%}[_nghost-%COMP%]     .mat-tab-body-content{display:flex;flex-direction:column;justify-content:space-between}[_nghost-%COMP%]   .imx-mat-tab-container[_ngcontent-%COMP%]{padding:20px;display:flex;flex-direction:column;overflow:auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}[_nghost-%COMP%]     .mat-tab-labels{background-color:#fff}.eui-dark-theme   [_nghost-%COMP%]     .mat-tab-labels{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]     .mat-tab-labels{background-color:#000}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PoliciesSidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-policies-sidesheet', template: "<mat-tab-group>\r\n  <mat-tab [label]=\"'#LDS#Heading Information' | translate\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content>\r\n        <mat-card>\r\n          <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\"></imx-cdr-editor>\r\n        </mat-card>\r\n      </div>\r\n\r\n      <div eui-sidesheet-actions>\r\n        <button mat-stroked-button [euiDownload]=\"reportDownload\" class=\"justify-start\" data-imx-identifier=\"policies-sidesheet-button-download-report\">\r\n          {{ '#LDS#Download report' | translate }}\r\n        </button>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab [label]=\"'#LDS#Heading Policy Violations' | translate\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content>\r\n        <imx-policy-violations [selectedCompanyPolicy]=\"data.selectedPolicy\" [isMControlPerViolation]=\"data.isMControlPerViolation\"></imx-policy-violations>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab [label]=\"'#LDS#Heading Mitigating Controls' | translate\" *ngIf=\"data.hasRiskIndex\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content>\r\n        <imx-mitigating-controls-policy [objectUid]=\"objectUid\" [isMControlPerViolation]=\"data.isMControlPerViolation\"></imx-mitigating-controls-policy>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab data-imx-identifier=\"policies-sidesheet-tab-statistics\" [label]=\"'#LDS#Heading Statistics' | translate\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content>\r\n        <imx-statistics-for-objects [objectType]=\"objectType\" [objectUid]=\"objectUid\"></imx-statistics-for-objects>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content>\r\n        <imx-object-hyperview [objectType]=\"data?.selectedPolicy?.GetEntity()?.TypeName\" [objectUid]=\"data?.selectedPolicy?.GetEntity()?.GetKeys()[0]\"> </imx-object-hyperview>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n</mat-tab-group>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host .mat-tab-group,:host ::ng-deep .mat-tab-body-wrapper{height:100%}:host ::ng-deep .mat-tab-body-content{display:flex;flex-direction:column;justify-content:space-between}:host .imx-mat-tab-container{padding:20px;display:flex;flex-direction:column;overflow:auto}.eui-sidesheet-actions .justify-start{margin-right:auto}:host ::ng-deep .mat-tab-labels{background-color:#fff}.eui-dark-theme :host ::ng-deep .mat-tab-labels{background-color:#2f3233}.eui-contrast-theme :host ::ng-deep .mat-tab-labels{background-color:#000}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i2$2.EuiSidesheetRef }, { type: PoliciesService }, { type: i3$2.ElementalUiConfigService }];
    }, null);
})();

function PoliciesComponent_ng_template_12_eui_badge_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-badge", 13);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Deactivated"));
    }
}
function PoliciesComponent_ng_template_12_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 9)(1, "div")(2, "div", 10);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "div", 11);
        i0.ɵɵtext(5);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(6, PoliciesComponent_ng_template_12_eui_badge_6_Template, 3, 3, "eui-badge", 12);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r3 = ctx.$implicit;
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(item_r3.GetEntity().GetDisplay());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r3.Description.Column.GetDisplayValue());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", item_r3.IsInActive.value);
    }
}
function PoliciesComponent_ng_template_15_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
    }
    if (rf & 2) {
        const policy_r5 = ctx.$implicit;
        i0.ɵɵtextInterpolate1(" ", policy_r5.CountOpen.value + policy_r5.CountClosed.value, " ");
    }
}
const _c0 = function () { return ["search", "filter"]; };
class PoliciesComponent {
    constructor(policiesProvider, sideSheetService, systemInfoService, translate, euiBusysService) {
        this.policiesProvider = policiesProvider;
        this.sideSheetService = sideSheetService;
        this.systemInfoService = systemInfoService;
        this.translate = translate;
        this.euiBusysService = euiBusysService;
        this.DisplayColumns = DisplayColumns;
        this.busyService = new BusyService();
        this.displayedColumns = [];
        this.filterOptions = [];
        this.navigationState = {};
        this.policySchema = policiesProvider.policySchema;
        this.displayedColumns = [
            this.policySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            {
                ColumnName: 'cases',
                Type: ValType.Int,
            },
            this.policySchema.Columns.CountOpen,
        ];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.euiBusysService.show();
            try {
                this.filterOptions = (yield this.policiesProvider.getDataModel()).Filters || [];
                this.isMControlPerViolation = (yield this.policiesProvider.featureConfig()).MitigatingControlsPerViolation;
            }
            finally {
                this.euiBusysService.hide();
            }
            const indexActive = this.filterOptions.findIndex((elem) => elem.Name === 'active');
            if (indexActive > -1) {
                this.filterOptions[indexActive].InitialValue = '1';
                this.navigationState.active = '1';
            }
            yield this.navigate({}, true);
        });
    }
    showDetails(selectedPolicy) {
        return __awaiter(this, void 0, void 0, function* () {
            const hasRiskIndex = (yield this.systemInfoService.get()).PreProps.includes('RISKINDEX');
            yield this.sideSheetService
                .open(PoliciesSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Company Policy Details').toPromise(),
                subTitle: selectedPolicy.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(700px, 60%)',
                testId: 'policy-details-sidesheet',
                data: {
                    selectedPolicy,
                    hasRiskIndex,
                    isMControlPerViolation: this.isMControlPerViolation,
                },
            })
                .afterClosed()
                .toPromise();
        });
    }
    navigate(parameter, isInitialLoad = false) {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            this.navigationState = Object.assign(Object.assign({}, this.navigationState), parameter);
            try {
                const data = isInitialLoad ? { totalCount: 0, Data: [] } : yield this.policiesProvider.getPolicies(this.navigationState);
                if (data) {
                    this.dstSettings = {
                        displayedColumns: this.displayedColumns,
                        dataSource: data,
                        entitySchema: this.policySchema,
                        navigationState: this.navigationState,
                        filters: this.filterOptions,
                    };
                }
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.policiesProvider.abortCall();
            return this.navigate({ search: keywords });
        });
    }
}
PoliciesComponent.ɵfac = function PoliciesComponent_Factory(t) { return new (t || PoliciesComponent)(i0.ɵɵdirectiveInject(PoliciesService), i0.ɵɵdirectiveInject(i2$2.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$2.SystemInfoService), i0.ɵɵdirectiveInject(i4.TranslateService), i0.ɵɵdirectiveInject(i2$2.EuiLoadingService)); };
PoliciesComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: PoliciesComponent, selectors: [["imx-policies"]], decls: 18, vars: 14, consts: [[1, "mat-headline"], [1, "imx-table-container"], [3, "settings", "options", "busyService", "search", "navigationStateChanged"], ["dst", ""], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "policies-table", 3, "dst", "highlightedEntityChanged"], ["data-imx-identifier", "policies-table-column-Display", 3, "entityColumn"], ["columnName", "cases", "data-imx-identifier", "policies-table-column-Count", "width", "15%", 3, "columnLabel"], ["data-imx-identifier", "policies-table-column-CountOpen", "width", "15%", 3, "entityColumn"], [3, "dst"], ["data-imx-identifier", "runs-button-show-details", 1, "imx-display-column"], ["data-imx-identifier", "policies-table-display"], ["subtitle", "", "data-imx-identifier", "policies-table-description"], ["class", "imx-badge", "color", "gray", 4, "ngIf"], ["color", "gray", 1, "imx-badge"]], template: function PoliciesComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "h2", 0)(1, "span");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "mat-card")(6, "div", 1)(7, "imx-data-source-toolbar", 2, 3);
            i0.ɵɵlistener("search", function PoliciesComponent_Template_imx_data_source_toolbar_search_7_listener($event) { return ctx.onSearch($event); })("navigationStateChanged", function PoliciesComponent_Template_imx_data_source_toolbar_navigationStateChanged_7_listener($event) { return ctx.navigate($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(9, "div", 1)(10, "imx-data-table", 4);
            i0.ɵɵlistener("highlightedEntityChanged", function PoliciesComponent_Template_imx_data_table_highlightedEntityChanged_10_listener($event) { return ctx.showDetails($event); });
            i0.ɵɵelementStart(11, "imx-data-table-column", 5);
            i0.ɵɵtemplate(12, PoliciesComponent_ng_template_12_Template, 7, 3, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(13, "imx-data-table-generic-column", 6);
            i0.ɵɵpipe(14, "translate");
            i0.ɵɵtemplate(15, PoliciesComponent_ng_template_15_Template, 1, 1, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(16, "imx-data-table-column", 7);
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(17, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(8);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 9, "#LDS#Heading Company Policies"));
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(13, _c0))("busyService", ctx.busyService);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.policySchema == null ? null : ctx.policySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("columnLabel", i0.ɵɵpipeBind1(14, 11, "#LDS#Policy violations"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("entityColumn", ctx.policySchema.Columns.CountOpen);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i9.NgIf, i2$2.EuiBadgeComponent, i3$2.DataTableComponent, i3$2.DataTableColumnComponent, i3$2.DataTableGenericColumnComponent, i3$2.DataSourceToolbarComponent, i3$2.DataSourcePaginatorComponent, i1.MatCard, i3$2.HelpContextualComponent, i4.TranslatePipe], styles: ["div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit}[_nghost-%COMP%]   .mat-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:3px}.imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-display-column[_ngcontent-%COMP%]{display:flex;flex-direction:row}.imx-display-column[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:first-child{flex:1 1 auto}.imx-display-column[_ngcontent-%COMP%]   .imx-badge[_ngcontent-%COMP%]{align-self:flex-end}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PoliciesComponent, [{
            type: Component,
            args: [{ selector: 'imx-policies', template: "<h2 class=\"mat-headline\">\r\n  <span>{{ '#LDS#Heading Company Policies' | translate }}</span>\r\n  <imx-help-contextual></imx-help-contextual>\r\n</h2>\r\n<mat-card>\r\n  <div class=\"imx-table-container\">\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      [settings]=\"dstSettings\"\r\n      [options]=\"['search', 'filter']\"\r\n      [busyService]=\"busyService\"\r\n      (search)=\"onSearch($event)\"\r\n      (navigationStateChanged)=\"navigate($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-table [dst]=\"dst\" detailViewVisible=\"false\" mode=\"manual\" data-imx-identifier=\"policies-table\" (highlightedEntityChanged)=\"showDetails($event)\">\r\n        <imx-data-table-column [entityColumn]=\"policySchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\" data-imx-identifier=\"policies-table-column-Display\">\r\n          <ng-template let-item>\r\n            <div class=\"imx-display-column\" data-imx-identifier=\"runs-button-show-details\">\r\n              <div>\r\n                <div data-imx-identifier=\"policies-table-display\">{{ item.GetEntity().GetDisplay() }}</div>\r\n                <div subtitle data-imx-identifier=\"policies-table-description\">{{ item.Description.Column.GetDisplayValue() }}</div>\r\n              </div>\r\n              <eui-badge class=\"imx-badge\" *ngIf=\"item.IsInActive.value\" color=\"gray\">{{ '#LDS#Deactivated' | translate }}</eui-badge>\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n\r\n        <imx-data-table-generic-column columnName=\"cases\" data-imx-identifier=\"policies-table-column-Count\" [columnLabel]=\"'#LDS#Policy violations' | translate\" width=\"15%\">\r\n          <ng-template let-policy>\r\n            {{ policy.CountOpen.value + policy.CountClosed.value }}\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n\r\n        <imx-data-table-column [entityColumn]=\"policySchema.Columns.CountOpen\" data-imx-identifier=\"policies-table-column-CountOpen\" width=\"15%\"> </imx-data-table-column>\r\n      </imx-data-table>\r\n    </div>\r\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n  </div>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */div[subtitle]{font-size:smaller;color:#919799}:host{display:flex;flex-direction:column;overflow:hidden;height:inherit}:host .mat-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:3px}.imx-table-container{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.imx-display-column{display:flex;flex-direction:row}.imx-display-column :first-child{flex:1 1 auto}.imx-display-column .imx-badge{align-self:flex-end}\n"] }]
        }], function () { return [{ type: PoliciesService }, { type: i2$2.EuiSidesheetService }, { type: i3$2.SystemInfoService }, { type: i4.TranslateService }, { type: i2$2.EuiLoadingService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PolicyViolationsModule {
}
PolicyViolationsModule.ɵfac = function PolicyViolationsModule_Factory(t) { return new (t || PolicyViolationsModule)(); };
PolicyViolationsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: PolicyViolationsModule });
PolicyViolationsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [EuiCoreModule,
        EuiMaterialModule,
        MatButtonModule,
        MatCardModule,
        MatListModule,
        MatTabsModule,
        MatFormFieldModule,
        MatTooltipModule,
        CommonModule,
        TranslateModule,
        ReactiveFormsModule,
        BulkPropertyEditorModule,
        CdrModule,
        FormsModule,
        JustificationModule,
        DataTableModule,
        DataSourceToolbarModule,
        SelectedElementsModule,
        StatisticsModule,
        HelpContextualModule,
        ObjectHyperviewModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyViolationsModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        PolicyViolationsComponent,
                        PolicyViolationsActionComponent,
                        PolicyViolationsActionMultiActionComponent,
                        PolicyViolationsActionSingleActionComponent,
                        PolicyViolationsSidesheetComponent,
                        MitigatingControlsComponent
                    ],
                    imports: [
                        EuiCoreModule,
                        EuiMaterialModule,
                        MatButtonModule,
                        MatCardModule,
                        MatListModule,
                        MatTabsModule,
                        MatFormFieldModule,
                        MatTooltipModule,
                        CommonModule,
                        TranslateModule,
                        ReactiveFormsModule,
                        BulkPropertyEditorModule,
                        CdrModule,
                        FormsModule,
                        JustificationModule,
                        DataTableModule,
                        DataSourceToolbarModule,
                        SelectedElementsModule,
                        StatisticsModule,
                        HelpContextualModule,
                        ObjectHyperviewModule
                    ],
                    exports: [PolicyViolationsComponent]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(PolicyViolationsModule, { declarations: [PolicyViolationsComponent,
            PolicyViolationsActionComponent,
            PolicyViolationsActionMultiActionComponent,
            PolicyViolationsActionSingleActionComponent,
            PolicyViolationsSidesheetComponent,
            MitigatingControlsComponent], imports: [EuiCoreModule,
            EuiMaterialModule,
            MatButtonModule,
            MatCardModule,
            MatListModule,
            MatTabsModule,
            MatFormFieldModule,
            MatTooltipModule,
            CommonModule,
            TranslateModule,
            ReactiveFormsModule,
            BulkPropertyEditorModule,
            CdrModule,
            FormsModule,
            JustificationModule,
            DataTableModule,
            DataSourceToolbarModule,
            SelectedElementsModule,
            StatisticsModule,
            HelpContextualModule,
            ObjectHyperviewModule], exports: [PolicyViolationsComponent] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class PoliciesModule {
}
PoliciesModule.ɵfac = function PoliciesModule_Factory(t) { return new (t || PoliciesModule)(); };
PoliciesModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: PoliciesModule });
PoliciesModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        EuiCoreModule,
        TranslateModule,
        CdrModule,
        DataTableModule,
        DataSourceToolbarModule,
        MatButtonModule,
        MatCardModule,
        MatTabsModule,
        StatisticsModule,
        ObjectHyperviewModule,
        HelpContextualModule,
        PolicyViolationsModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PoliciesModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        PoliciesComponent,
                        PoliciesSidesheetComponent,
                        MitigatingControlsPolicyComponent,
                    ],
                    imports: [
                        CommonModule,
                        EuiCoreModule,
                        TranslateModule,
                        CdrModule,
                        DataTableModule,
                        DataSourceToolbarModule,
                        MatButtonModule,
                        MatCardModule,
                        MatTabsModule,
                        StatisticsModule,
                        ObjectHyperviewModule,
                        HelpContextualModule,
                        PolicyViolationsModule,
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(PoliciesModule, { declarations: [PoliciesComponent,
            PoliciesSidesheetComponent,
            MitigatingControlsPolicyComponent], imports: [CommonModule,
            EuiCoreModule,
            TranslateModule,
            CdrModule,
            DataTableModule,
            DataSourceToolbarModule,
            MatButtonModule,
            MatCardModule,
            MatTabsModule,
            StatisticsModule,
            ObjectHyperviewModule,
            HelpContextualModule,
            PolicyViolationsModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isQERPolicyAdmin(features) {
    return features.find(item => item === 'Portal_UI_QERPolicyAdmin') != null;
}
function isQERPolicyOwner(features) {
    return features.find(item => item === 'Portal_UI_QERPolicyOwner') != null;
}

class PermissionsService {
    constructor(userService) {
        this.userService = userService;
    }
    isQERPolicyAdmin() {
        return __awaiter(this, void 0, void 0, function* () {
            return isQERPolicyAdmin((yield this.userService.getFeatures()).Features);
        });
    }
    isQERPolicyOwner() {
        return __awaiter(this, void 0, void 0, function* () {
            return isQERPolicyOwner((yield this.userService.getFeatures()).Features);
        });
    }
}
PermissionsService.ɵfac = function PermissionsService_Factory(t) { return new (t || PermissionsService)(i0.ɵɵinject(i2.UserModelService)); };
PermissionsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PermissionsService, factory: PermissionsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PermissionsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i2.UserModelService }]; }, null);
})();

class PolicyAdminGuardService {
    constructor(permissionService, appConfig, routeGuardService, router) {
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.routeGuardService = routeGuardService;
        this.router = router;
    }
    canActivate(route, state) {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.routeGuardService.canActivate(route, state)) {
                const canApprovePolicyViolation = (yield this.permissionService.isQERPolicyAdmin()) || (yield this.permissionService.isQERPolicyOwner());
                if (!canApprovePolicyViolation) {
                    this.router.navigate([this.appConfig.Config.routeConfig.start]);
                }
                return canApprovePolicyViolation;
            }
            this.router.navigate([this.appConfig.Config.routeConfig.login]);
            return false;
        });
    }
}
PolicyAdminGuardService.ɵfac = function PolicyAdminGuardService_Factory(t) { return new (t || PolicyAdminGuardService)(i0.ɵɵinject(PermissionsService), i0.ɵɵinject(i3$2.AppConfigService), i0.ɵɵinject(i3$2.RouteGuardService), i0.ɵɵinject(i3.Router)); };
PolicyAdminGuardService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PolicyAdminGuardService, factory: PolicyAdminGuardService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolicyAdminGuardService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: PermissionsService }, { type: i3$2.AppConfigService }, { type: i3$2.RouteGuardService }, { type: i3.Router }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    constructor(extService, menuService, notificationService, router) {
        this.extService = extService;
        this.menuService = menuService;
        this.notificationService = notificationService;
        this.router = router;
        this.setupMenu();
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('Dashboard-SmallTiles', { instance: DashboardPluginComponent });
        // Register handler for policy notifications
        this.notificationService.registerRedirectNotificationHandler({
            id: 'OpenQERPolicyHasObject',
            message: '#LDS#There are new policy violations for which you can grant or deny exceptions.',
            route: 'compliance/policyviolations/approve'
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach(route => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features) => {
            if (!preProps.includes('COMPLIANCE') || (!isQERPolicyAdmin(features) && !isQERPolicyOwner(features))) {
                return null;
            }
            const menu = {
                id: 'ROOT_Compliance',
                title: '#LDS#Compliance',
                sorting: '25',
                items: [
                    {
                        id: 'POL_Policies',
                        route: 'compliance/policies',
                        title: '#LDS#Menu Entry Company policies',
                        sorting: '20-10',
                    },
                    {
                        id: 'POL_policy-violations',
                        route: 'compliance/policyviolations',
                        title: '#LDS#Menu Entry Policy violations',
                        sorting: '20-10',
                    }
                ]
            };
            return menu;
        });
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i3$2.ExtService), i0.ɵɵinject(i3$2.MenuService), i0.ɵɵinject(i2.NotificationRegistryService), i0.ɵɵinject(i3.Router)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i3$2.ExtService }, { type: i3$2.MenuService }, { type: i2.NotificationRegistryService }, { type: i3.Router }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'compliance/policyviolations/approve',
        component: PolicyViolationsComponent,
        canActivate: [PolicyAdminGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.CompliancePolicyViolations
        }
    },
    {
        path: 'compliance/policyviolations',
        component: PolicyViolationsComponent,
        canActivate: [PolicyAdminGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.CompliancePolicyViolations
        }
    },
    {
        path: 'compliance/policies',
        component: PoliciesComponent,
        canActivate: [PolicyAdminGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.CompanyPolicies
        }
    },
];
class PolConfigModule {
    constructor(initializer, logger) {
        this.initializer = initializer;
        this.logger = logger;
        this.logger.info(this, '🔥 POL loaded');
        this.initializer.onInit(routes);
        this.logger.info(this, '▶️ POL initialized');
    }
}
PolConfigModule.ɵfac = function PolConfigModule_Factory(t) { return new (t || PolConfigModule)(i0.ɵɵinject(InitService), i0.ɵɵinject(i3$2.ClassloggerService)); };
PolConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: PolConfigModule });
PolConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        TilesModule,
        RouterModule.forChild(routes),
        MatIconModule,
        MatListModule,
        TranslateModule,
        EuiCoreModule,
        PoliciesModule,
        PolicyViolationsModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PolConfigModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        DashboardPluginComponent,
                    ],
                    imports: [
                        CommonModule,
                        TilesModule,
                        RouterModule.forChild(routes),
                        MatIconModule,
                        MatListModule,
                        TranslateModule,
                        EuiCoreModule,
                        PoliciesModule,
                        PolicyViolationsModule,
                    ]
                }]
        }], function () { return [{ type: InitService }, { type: i3$2.ClassloggerService }]; }, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(PolConfigModule, { declarations: [DashboardPluginComponent], imports: [CommonModule,
            TilesModule, i3.RouterModule, MatIconModule,
            MatListModule,
            TranslateModule,
            EuiCoreModule,
            PoliciesModule,
            PolicyViolationsModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of pol
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiService, PermissionsService, PolConfigModule, PolicyAdminGuardService, PolicyViolationsComponent, PolicyViolationsModule };
//# sourceMappingURL=pol.mjs.map
