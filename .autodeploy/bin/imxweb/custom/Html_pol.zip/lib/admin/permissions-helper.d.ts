export declare function isQERPolicyAdmin(features: string[]): boolean;
export declare function isQERPolicyOwner(features: string[]): boolean;
