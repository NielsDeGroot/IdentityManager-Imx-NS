import { UserModelService } from 'qer';
import * as i0 from "@angular/core";
export declare class PermissionsService {
    private readonly userService;
    constructor(userService: UserModelService);
    isQERPolicyAdmin(): Promise<boolean>;
    isQERPolicyOwner(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionsService>;
}
