import { OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PendingItemsType, UserModelService } from 'qer';
import * as i0 from "@angular/core";
export declare class DashboardPluginComponent implements OnInit {
    readonly router: Router;
    private readonly userModelSvc;
    pendingItems: PendingItemsType;
    constructor(router: Router, userModelSvc: UserModelService);
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardPluginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardPluginComponent, "ng-component", never, {}, {}, never, never, false>;
}
