import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { AppConfigService, RouteGuardService } from 'qbm';
import { PermissionsService } from '../admin/permissions.service';
import * as i0 from "@angular/core";
export declare class PolicyAdminGuardService implements CanActivate {
    private readonly permissionService;
    private readonly appConfig;
    private readonly routeGuardService;
    private readonly router;
    constructor(permissionService: PermissionsService, appConfig: AppConfigService, routeGuardService: RouteGuardService, router: Router);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyAdminGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PolicyAdminGuardService>;
}
