import { OnInit } from '@angular/core';
import { PoliciesService } from '../policies.service';
import { EuiLoadingService } from '@elemental-ui/core';
import { CdrFactoryService, ColumnDependentReference } from 'qbm';
import * as i0 from "@angular/core";
/**
 * Used to get and display mitigating controls for each policy
 */
export declare class MitigatingControlsPolicyComponent implements OnInit {
    private apiService;
    private readonly busyService;
    private cdrService;
    readonly objectUid: string;
    isMControlPerViolation: boolean;
    mControls: ColumnDependentReference[];
    /**
     * @ignore only for dep injection
     */
    constructor(apiService: PoliciesService, busyService: EuiLoadingService, cdrService: CdrFactoryService);
    /**
     * Setup component with mitigating controls
     */
    ngOnInit(): void;
    /**
     * Calls the api and map the results into display cdrs
     */
    getMitigatingControls(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MitigatingControlsPolicyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MitigatingControlsPolicyComponent, "imx-mitigating-controls-policy", never, { "objectUid": "objectUid"; "isMControlPerViolation": "isMControlPerViolation"; }, {}, never, never, false>;
}
