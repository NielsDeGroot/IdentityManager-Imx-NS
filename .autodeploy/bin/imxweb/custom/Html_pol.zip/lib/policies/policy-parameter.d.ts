import { CollectionLoadParameters } from 'imx-qbm-dbts';
export interface PolicyParameter extends CollectionLoadParameters {
    active?: string;
}
