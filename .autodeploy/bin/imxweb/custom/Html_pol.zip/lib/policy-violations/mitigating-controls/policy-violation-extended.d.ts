import { FormControl } from '@angular/forms';
import { PortalPoliciesViolations } from 'imx-api-pol';
import { ColumnDependentReference } from 'qbm';
export declare class PolicyViolationExtended extends PortalPoliciesViolations {
    editable: any;
    readonly original: PortalPoliciesViolations;
    formControl: FormControl<string>;
    mitigatingCdr: ColumnDependentReference;
    constructor(editable: any, original: PortalPoliciesViolations);
}
