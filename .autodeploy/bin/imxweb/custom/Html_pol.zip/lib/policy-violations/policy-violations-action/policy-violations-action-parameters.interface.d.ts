import { ColumnDependentReference } from 'qbm';
/**
 * Defines the {@link ColumnDependentReference} for an action that can be performed on a policy violation
 */
export interface PolicyViolationsActionParameters {
    /**
     * A free text field for a reason
     */
    reason: ColumnDependentReference;
    /**
     * A FK-Editor for standard justifications
     */
    justification?: ColumnDependentReference;
}
