import { UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { PolicyViolationsAction } from './policy-violations-action.interface';
import * as i0 from "@angular/core";
/**
 * Component displayed in a sidesheet to make a decision for one or more policy violations.
 *
 * Uses two alternate views
 * <ul>
 * <li>a) a simple view for a single policy violation</li>
 * <li>b) a complex view using bulk items for multiple policy violations.</li>
 * </ul>
 *
 * Therefore this component is not meant to be used directly but rather be called
 * from a service that does the pre-calculation and opens this component in a
 * sidesheet passing the pre-calculated values.
 *
 */
export declare class PolicyViolationsActionComponent {
    readonly data: PolicyViolationsAction;
    readonly sideSheetRef: EuiSidesheetRef;
    /**
     * The form group to which the created form controls will be added.
     */
    readonly formGroup: UntypedFormGroup;
    /**
     * Creates a new PolicyViolationsActionComponent
     * @param data The pre-calculated data object.
     * @param sideSheetRef A reference to the sidesheet containing this component.
     */
    constructor(data: PolicyViolationsAction, sideSheetRef: EuiSidesheetRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyViolationsActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PolicyViolationsActionComponent, "ng-component", never, {}, {}, never, never, false>;
}
