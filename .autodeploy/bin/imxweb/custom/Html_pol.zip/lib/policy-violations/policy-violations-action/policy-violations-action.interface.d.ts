import { PolicyViolation } from '../policy-violation';
import { PolicyViolationsActionParameters } from './policy-violations-action-parameters.interface';
/**
 * Common View Model for making a decision for one or more policy violations.
 */
export interface PolicyViolationsAction {
    /**
     * Parameters according to the type of decision.
     */
    actionParameters: PolicyViolationsActionParameters;
    /**
     * The policy violations to make a decision for.
     */
    policyViolations: PolicyViolation[];
    /**
     * Whether or not the decision is an approval.
     */
    approve?: boolean;
    /**
     * A description for the type of decision to be made.
     */
    description?: string;
}
