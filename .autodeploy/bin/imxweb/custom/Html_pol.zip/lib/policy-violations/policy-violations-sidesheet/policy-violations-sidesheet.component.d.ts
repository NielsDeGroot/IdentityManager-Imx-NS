import { EuiSidesheetRef } from '@elemental-ui/core';
import { ColumnDependentReference } from 'qbm';
import { PolicyViolation } from '../policy-violation';
import { PolicyViolationsService } from '../policy-violations.service';
import { ObjectInfo } from 'imx-api-pol';
import * as i0 from "@angular/core";
export declare class PolicyViolationsSidesheetComponent {
    data: {
        policyViolation: PolicyViolation;
        isMControlPerViolation: boolean;
        isReadOnly: boolean;
    };
    private readonly policyViolationService;
    readonly sideSheetRef: EuiSidesheetRef;
    cdrList: ColumnDependentReference[];
    selectedHyperviewType: string;
    selectedHyperviewUID: string;
    selectedOption: ObjectInfo;
    get isPending(): boolean;
    get objectType(): string;
    get objectUid(): string;
    constructor(data: {
        policyViolation: PolicyViolation;
        isMControlPerViolation: boolean;
        isReadOnly: boolean;
    }, policyViolationService: PolicyViolationsService, sideSheetRef: EuiSidesheetRef);
    /**
     * Opens the Approve-Sidesheet for the current selected rules violations and closes the sidesheet afterwards.
     */
    approve(): Promise<void>;
    /**
     * Opens the Deny-Sidesheet for the current selected rules violations and closes the sidesheet afterwards.
     */
    deny(): Promise<void>;
    get relatedOptions(): ObjectInfo[];
    setHyperviewObject(selectedRelatedObject: ObjectInfo): void;
    onHyperviewOptionSelected(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyViolationsSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PolicyViolationsSidesheetComponent, "imx-policy-violations-sidesheet", never, {}, {}, never, never, false>;
}
