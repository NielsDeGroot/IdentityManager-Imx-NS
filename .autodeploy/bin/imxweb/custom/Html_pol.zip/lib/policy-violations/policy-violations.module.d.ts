import * as i0 from "@angular/core";
import * as i1 from "./policy-violations.component";
import * as i2 from "./policy-violations-action/policy-violations-action.component";
import * as i3 from "./policy-violations-action/policy-violations-action-multi-action/policy-violations-action-multi-action.component";
import * as i4 from "./policy-violations-action/policy-violations-action-single-action/policy-violations-action-single-action.component";
import * as i5 from "./policy-violations-sidesheet/policy-violations-sidesheet.component";
import * as i6 from "./mitigating-controls/mitigating-controls.component";
import * as i7 from "@elemental-ui/core";
import * as i8 from "@angular/material/button";
import * as i9 from "@angular/material/card";
import * as i10 from "@angular/material/list";
import * as i11 from "@angular/material/tabs";
import * as i12 from "@angular/material/form-field";
import * as i13 from "@angular/material/tooltip";
import * as i14 from "@angular/common";
import * as i15 from "@ngx-translate/core";
import * as i16 from "@angular/forms";
import * as i17 from "qbm";
import * as i18 from "qer";
export declare class PolicyViolationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PolicyViolationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PolicyViolationsModule, [typeof i1.PolicyViolationsComponent, typeof i2.PolicyViolationsActionComponent, typeof i3.PolicyViolationsActionMultiActionComponent, typeof i4.PolicyViolationsActionSingleActionComponent, typeof i5.PolicyViolationsSidesheetComponent, typeof i6.MitigatingControlsComponent], [typeof i7.EuiCoreModule, typeof i7.EuiMaterialModule, typeof i8.MatButtonModule, typeof i9.MatCardModule, typeof i10.MatListModule, typeof i11.MatTabsModule, typeof i12.MatFormFieldModule, typeof i13.MatTooltipModule, typeof i14.CommonModule, typeof i15.TranslateModule, typeof i16.ReactiveFormsModule, typeof i17.BulkPropertyEditorModule, typeof i17.CdrModule, typeof i16.FormsModule, typeof i18.JustificationModule, typeof i17.DataTableModule, typeof i17.DataSourceToolbarModule, typeof i17.SelectedElementsModule, typeof i18.StatisticsModule, typeof i17.HelpContextualModule, typeof i18.ObjectHyperviewModule], [typeof i1.PolicyViolationsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PolicyViolationsModule>;
}
