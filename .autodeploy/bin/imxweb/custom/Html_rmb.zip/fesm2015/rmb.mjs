import * as i0 from '@angular/core';
import { Injectable, Component, NgModule } from '@angular/core';
import * as i5 from '@angular/router';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import * as i2 from '@elemental-ui/core';
import { EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i3 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { __awaiter } from 'tslib';
import { V2Client, TypedClient, PortalAdminRoleOrg, V2ApiClientMethodFactory, PortalRespOrg, PortalPersonRolemembershipsOrg } from 'imx-api-rmb';
import { ReadOnlyEntity, MethodDefinition } from 'imx-qbm-dbts';
import * as i3$1 from 'qer';
import { RoleDetailComponent, RoleRecommendationsComponent, TilesModule, BaseMembership, BaseTreeRoleRestoreHandler, BaseTreeEntitlement, isRoleAdmin, isRoleStatistics, isAuditor, RolesOverviewComponent } from 'qer';
import * as i4 from 'qbm';
import { HELP_CONTEXTUAL } from 'qbm';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RmbApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing RMB API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
RmbApiService.ɵfac = function RmbApiService_Factory(t) { return new (t || RmbApiService)(i0.ɵɵinject(i4.AppConfigService), i0.ɵɵinject(i4.ClassloggerService), i0.ɵɵinject(i4.ImxTranslationProviderService)); };
RmbApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RmbApiService, factory: RmbApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RmbApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i4.AppConfigService }, { type: i4.ClassloggerService }, { type: i4.ImxTranslationProviderService }]; }, null);
})();

class TeamRoleComponent {
    constructor(rmbApiService, sidesheetService, translateService, roleService, dataManagementService, route, permissionService, roleEntitlementActionService) {
        this.rmbApiService = rmbApiService;
        this.sidesheetService = sidesheetService;
        this.translateService = translateService;
        this.roleService = roleService;
        this.dataManagementService = dataManagementService;
        this.route = route;
        this.permissionService = permissionService;
        this.roleEntitlementActionService = roleEntitlementActionService;
        this.loadingState = false;
        this.showTeamRole = false;
        this.orgTag = 'Org';
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.permissionService.isPersonManager()) {
                this.showTeamRole = true;
                yield this.getTeamRole();
            }
        });
    }
    /**
     * Load team role data and open details sidesheet
     */
    onManageTeamRole() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.loadingState = true;
                const roleItemCollection = yield this.roleService.targetMap.get(this.orgTag).interactiveResp.Get_byid(this.teamRole.Uid);
                const roleItem = roleItemCollection.Data[0].GetEntity();
                yield this.setRoleData(roleItem);
                yield this.dataManagementService.setInteractive();
                this.sidesheetService
                    .open(RoleDetailComponent, {
                    title: this.translateService.instant('#LDS#Heading Edit Team Role'),
                    subTitle: roleItem.GetDisplay(),
                    padding: '0px',
                    width: 'max(768px, 80%)',
                    disableClose: true,
                    testId: `${this.orgTag}-role-detail-sidesheet`,
                })
                    .afterClosed()
                    .subscribe(() => {
                    this.getTeamRole();
                });
            }
            finally {
                this.loadingState = false;
            }
        });
    }
    /**
     * Load recomenndation options and open sidesheet where you can select the options.
     */
    onCreateTeamRole() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.loadingState = true;
                const teamRoleRecommendOptions = yield this.rmbApiService.client.portal_resp_team_teamrole_recommendations_get();
                this.sidesheetService
                    .open(RoleRecommendationsComponent, {
                    title: this.translateService.instant('#LDS#Heading Create Team Role'),
                    padding: '0px',
                    width: 'max(650px, 65%)',
                    testId: 'role-recommendation-sidesheet',
                    data: {
                        recommendation: teamRoleRecommendOptions.Items || [],
                        canEdit: true,
                        infoText: '#LDS#Here you can create a team role. To do this, select the entitlements that are currently assigned individually to the members of your team. This team role will then be automatically assigned to all members of your team (along with the previously mentioned entitlements).',
                        selectionTitle: '#LDS#Selected entitlements',
                        submitButtonTitle: '#LDS#Create team role',
                        actionColumnTitle: '#LDS#Distribution among the team',
                        hideActionConfirmation: true,
                        applyWithoutSelection: true,
                    },
                })
                    .afterClosed()
                    .subscribe((result) => {
                    if (!!result) {
                        this.saveRecommendations(result.items);
                    }
                });
            }
            finally {
                this.loadingState = false;
            }
        });
    }
    /**
     * Check loaded team role data existence.
     * @returns boolean
     */
    get existTeamRole() {
        var _a;
        return !!((_a = this.teamRole) === null || _a === void 0 ? void 0 : _a.Uid);
    }
    /**
     * Loading team role.
     */
    getTeamRole() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.loadingState = true;
                this.teamRole = yield this.rmbApiService.client.portal_resp_team_teamrole_get();
            }
            finally {
                this.loadingState = false;
            }
        });
    }
    /**
     * This function is called after selected options of recommended team roles.
     * Save the selection and add recommendations to the cart.
     * @param resultItem
     */
    saveRecommendations(resultItem) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // It can take a moment for the team role to become visible over the ownerships API because of DBQUeue calculations.
                this.loadingState = true;
                const collectionData = yield this.rmbApiService.client.portal_resp_team_teamrole_post({
                    ObjectKeys: resultItem.map((item) => item.ObjectKey.value),
                });
                // This entity represents the new team role.
                const entity = new ReadOnlyEntity(PortalAdminRoleOrg.GetEntitySchema(), collectionData.Entities[0]);
                yield this.setRoleData(entity);
                yield this.roleEntitlementActionService.addRecommendation(entity, resultItem);
                this.getTeamRole();
            }
            finally {
                this.loadingState = false;
            }
        });
    }
    /**
     * Set role service sidesheet data with the required params.
     * @param IEntity
     */
    setRoleData(entity) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const isAdmin = ((_b = (_a = this.route.snapshot) === null || _a === void 0 ? void 0 : _a.url[0]) === null || _b === void 0 ? void 0 : _b.path) === 'admin';
            const isStructureAdmin = yield this.permissionService.isStructAdmin();
            this.roleService.setSidesheetData({
                ownershipInfo: {
                    TableName: this.orgTag,
                    Count: 0,
                },
                entity,
                isAdmin,
                canEdit: !isAdmin || (isAdmin && isStructureAdmin),
            });
        });
    }
}
TeamRoleComponent.ɵfac = function TeamRoleComponent_Factory(t) { return new (t || TeamRoleComponent)(i0.ɵɵdirectiveInject(RmbApiService), i0.ɵɵdirectiveInject(i2.EuiSidesheetService), i0.ɵɵdirectiveInject(i3.TranslateService), i0.ɵɵdirectiveInject(i3$1.RoleService), i0.ɵɵdirectiveInject(i3$1.DataManagementService), i0.ɵɵdirectiveInject(i5.ActivatedRoute), i0.ɵɵdirectiveInject(i3$1.QerPermissionsService), i0.ɵɵdirectiveInject(i3$1.RoleEntitlementActionService)); };
TeamRoleComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TeamRoleComponent, selectors: [["imx-team-role"]], decls: 0, vars: 0, template: function TeamRoleComponent_Template(rf, ctx) { }, styles: [".mat-button[_ngcontent-%COMP%]{text-transform:uppercase}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamRoleComponent, [{
            type: Component,
            args: [{ selector: 'imx-team-role', template: "<!-- US1151648 Remove Team Role for Managers tile\r\n<imx-icon-tile\r\n  data-imx-identifier=\"start-tile-team-role\"\r\n  [caption]=\"'#LDS#Heading Team Role' | translate\"\r\n  [subtitle]=\"\r\n    existTeamRole ? ('#LDS#Manage your team role, its memberships and entitlements.' | translate) : ('#LDS#Manage the entitlements required for your team using a team role.' | translate)\r\n  \"\r\n  [identifier]=\"'team-role'\"\r\n  [loadingState]=\"loadingState\"\r\n  *ngIf=\"showTeamRole\"\r\n>\r\n  <ng-template #ActionTemplate>\r\n    <ng-container *ngIf=\"existTeamRole; else noTeamRole\">\r\n      <button mat-button color=\"primary\" (click)=\"onManageTeamRole()\">\r\n        {{ '#LDS#Edit team role' | translate }}\r\n      </button>\r\n    </ng-container>\r\n    <ng-template #noTeamRole>\r\n      <button mat-button color=\"primary\" (click)=\"onCreateTeamRole()\">\r\n        {{ '#LDS#Create team role' | translate }}\r\n      </button>\r\n    </ng-template>\r\n  </ng-template>\r\n</imx-icon-tile>\r\n-->", styles: [".mat-button{text-transform:uppercase}\n"] }]
        }], function () { return [{ type: RmbApiService }, { type: i2.EuiSidesheetService }, { type: i3.TranslateService }, { type: i3$1.RoleService }, { type: i3$1.DataManagementService }, { type: i5.ActivatedRoute }, { type: i3$1.QerPermissionsService }, { type: i3$1.RoleEntitlementActionService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TeamRoleModule {
}
TeamRoleModule.ɵfac = function TeamRoleModule_Factory(t) { return new (t || TeamRoleModule)(); };
TeamRoleModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: TeamRoleModule });
TeamRoleModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        EuiCoreModule,
        EuiMaterialModule,
        TranslateModule,
        TilesModule,
        FormsModule,
        ReactiveFormsModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TeamRoleModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        TeamRoleComponent
                    ],
                    imports: [
                        CommonModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        TranslateModule,
                        TilesModule,
                        FormsModule,
                        ReactiveFormsModule,
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(TeamRoleModule, { declarations: [TeamRoleComponent], imports: [CommonModule,
            EuiCoreModule,
            EuiMaterialModule,
            TranslateModule,
            TilesModule,
            FormsModule,
            ReactiveFormsModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class OrgDataModel {
    constructor(api) {
        this.api = api;
    }
    getModel(filter, isAdmin) {
        return __awaiter(this, void 0, void 0, function* () {
            return isAdmin ?
                this.api.client.portal_admin_role_org_datamodel_get({ filter: filter })
                : this.api.client.portal_resp_org_datamodel_get({ filter: filter });
        });
    }
}

// do not inherit from BaseMembership because classes cannot inherit across modules :-(
class OrgMembership extends BaseMembership {
    constructor(api, session, translator) {
        super(api, session, translator);
        this.api = api;
        this.session = session;
        this.translator = translator;
        this.setRoleName('Org', 'UID_Org');
    }
    delete(role, identity) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.client.portal_roles_config_membership_Org_delete(role, identity);
        });
    }
    hasPrimaryMemberships() {
        return true;
    }
    getPrimaryMembers(uid, navigationstate) {
        return this.api.typedClient.PortalRolesConfigOrgPrimarymembers.Get(uid, navigationstate);
    }
    getPrimaryMembersSchema() {
        return this.api.typedClient.PortalRolesConfigOrgPrimarymembers.GetSchema();
    }
}

class InitService {
    constructor(router, api, qerApi, session, translator, dynamicMethodService, dataExplorerRegistryService, menuService, roleService, identityRoleMembershipService, myResponsibilitiesRegistryService, extService) {
        this.router = router;
        this.api = api;
        this.qerApi = qerApi;
        this.session = session;
        this.translator = translator;
        this.dynamicMethodService = dynamicMethodService;
        this.dataExplorerRegistryService = dataExplorerRegistryService;
        this.menuService = menuService;
        this.roleService = roleService;
        this.identityRoleMembershipService = identityRoleMembershipService;
        this.myResponsibilitiesRegistryService = myResponsibilitiesRegistryService;
        this.extService = extService;
        this.orgTag = 'Org';
        this.abortController = new AbortController();
    }
    onInit(routes) {
        this.addRoutes(routes);
        // wrapper class for interactive methods
        class ApiWrapper {
            constructor(getApi, getByIdApi) {
                this.getApi = getApi;
                this.getByIdApi = getByIdApi;
            }
            Get() {
                return this.getApi.Get();
            }
            GetSchema() {
                return this.getApi.GetSchema();
            }
            Get_byid(id) {
                return this.getByIdApi.Get_byid(id);
            }
        }
        const restore = new BaseTreeRoleRestoreHandler(() => this.api.client.portal_roles_Org_restore_get(), () => this.api.client.portal_resp_Org_restore_get(), (uid) => this.api.client.portal_roles_Org_restore_byid_get(uid), (uid) => this.api.client.portal_resp_Org_restore_byid_get(uid), (uidRole, actions) => this.api.client.portal_roles_Org_restore_byid_post(uidRole, actions), (uidRole, actions) => this.api.client.portal_resp_Org_restore_byid_post(uidRole, actions));
        this.roleService.targetMap.set(this.orgTag, {
            canBeSplitTarget: true,
            canBeSplitSource: true,
            table: this.orgTag,
            respType: PortalRespOrg,
            resp: this.api.typedClient.PortalRespOrg,
            adminType: PortalAdminRoleOrg,
            adminHasHierarchy: true,
            admin: {
                get: (parameter) => __awaiter(this, void 0, void 0, function* () {
                    if ((parameter === null || parameter === void 0 ? void 0 : parameter.search) !== undefined) {
                        // abort the request only while searching
                        this.abortCall();
                    }
                    return this.api.client.portal_admin_role_org_get(parameter, { signal: this.abortController.signal });
                }),
            },
            adminSchema: this.api.typedClient.PortalAdminRoleOrg.GetSchema(),
            dataModel: new OrgDataModel(this.api),
            interactiveResp: new ApiWrapper(this.api.typedClient.PortalRespOrgInteractive, this.api.typedClient.PortalRespOrgInteractive),
            interactiveAdmin: new ApiWrapper(this.api.typedClient.PortalAdminRoleOrgInteractive, this.api.typedClient.PortalAdminRoleOrgInteractive),
            adminCanCreate: true,
            respCanCreate: true,
            entitlements: new BaseTreeEntitlement(this.qerApi, this.session, this.dynamicMethodService, this.translator, this.orgTag, (e) => e.GetColumn('UID_OrgRoot').GetValue()),
            membership: new OrgMembership(this.api, this.session, this.translator),
            canUseRecommendations: true,
            restore,
            exportMethod: (navigationState, isAdmin) => {
                const factory = new V2ApiClientMethodFactory();
                return {
                    getMethod: (withProperties, PageSize) => {
                        let method;
                        if (PageSize) {
                            method = isAdmin
                                ? factory.portal_admin_role_org_get(Object.assign(Object.assign({}, navigationState), { withProperties, PageSize, StartIndex: 0 }))
                                : factory.portal_resp_org_get(Object.assign(Object.assign({}, navigationState), { withProperties, PageSize, StartIndex: 0 }));
                        }
                        else {
                            method = isAdmin
                                ? factory.portal_admin_role_org_get(Object.assign(Object.assign({}, navigationState), { withProperties }))
                                : factory.portal_resp_org_get(Object.assign(Object.assign({}, navigationState), { withProperties }));
                        }
                        return new MethodDefinition(method);
                    },
                };
            },
            translateKeys: {
                create: '#LDS#Create business role',
                createChild: '#LDS#Create child business role',
                createHeading: '#LDS#Heading Create Business Role',
                editHeading: '#LDS#Heading Edit Business Role',
                createSnackbar: '#LDS#The business role has been successfully created.',
            },
        });
        this.identityRoleMembershipService.addTarget({
            table: this.orgTag,
            type: PortalPersonRolemembershipsOrg,
            entitySchema: this.api.typedClient.PortalPersonRolemembershipsOrg.GetSchema(),
            controlInfo: {
                label: '#LDS#Menu Entry Business roles',
                index: 70,
            },
            get: (uidPerson, parameter) => __awaiter(this, void 0, void 0, function* () { return this.api.client.portal_person_rolememberships_Org_get(uidPerson, parameter); }),
            withAnalysis: true,
        });
        this.setupMenu();
        this.dataExplorerRegistryService.registerFactory((preProps, features, projectConfig, groups) => {
            if (!isRoleAdmin(features) && !isRoleStatistics(features) && !isAuditor(groups)) {
                return;
            }
            return {
                instance: RolesOverviewComponent,
                data: {
                    TableName: this.orgTag,
                    Count: 0,
                },
                contextId: HELP_CONTEXTUAL.DataExplorerBusinessRoles,
                sortOrder: 7,
                name: 'businessroles',
                caption: '#LDS#Menu Entry Business roles',
            };
        });
        this.myResponsibilitiesRegistryService.registerFactory((preProps, features) => ({
            instance: RolesOverviewComponent,
            sortOrder: 7,
            name: this.orgTag,
            caption: '#LDS#Menu Entry Business roles',
            data: {
                TableName: this.orgTag,
                Count: 0,
            },
            contextId: HELP_CONTEXTUAL.MyResponsibilitiesBusinessRoles,
        }));
        this.extService.register('Dashboard-MediumTiles', { instance: TeamRoleComponent });
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features, projectConfig, groups) => {
            if (!isRoleAdmin(features) && !isRoleStatistics(features) && !isAuditor(groups)) {
                return null;
            }
            const menu = {
                id: 'ROOT_Data',
                title: '#LDS#Data administration',
                sorting: '40',
                items: [
                    {
                        id: 'QER_DataExplorer',
                        navigationCommands: { commands: ['admin', 'dataexplorer'] },
                        title: '#LDS#Menu Entry Data Explorer',
                        sorting: '40-10',
                    },
                ],
            };
            return menu;
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i5.Router), i0.ɵɵinject(RmbApiService), i0.ɵɵinject(i3$1.QerApiService), i0.ɵɵinject(i4.imx_SessionService), i0.ɵɵinject(i4.ImxTranslationProviderService), i0.ɵɵinject(i4.DynamicMethodService), i0.ɵɵinject(i3$1.DataExplorerRegistryService), i0.ɵɵinject(i4.MenuService), i0.ɵɵinject(i3$1.RoleService), i0.ɵɵinject(i3$1.IdentityRoleMembershipsService), i0.ɵɵinject(i3$1.MyResponsibilitiesRegistryService), i0.ɵɵinject(i4.ExtService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i5.Router }, { type: RmbApiService }, { type: i3$1.QerApiService }, { type: i4.imx_SessionService }, { type: i4.ImxTranslationProviderService }, { type: i4.DynamicMethodService }, { type: i3$1.DataExplorerRegistryService }, { type: i4.MenuService }, { type: i3$1.RoleService }, { type: i3$1.IdentityRoleMembershipsService }, { type: i3$1.MyResponsibilitiesRegistryService }, { type: i4.ExtService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [];
class RmbConfigModule {
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 RMB loaded');
        this.initializer.onInit(routes);
        console.log('▶️ RMB initialized');
    }
}
RmbConfigModule.ɵfac = function RmbConfigModule_Factory(t) { return new (t || RmbConfigModule)(i0.ɵɵinject(InitService)); };
RmbConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RmbConfigModule });
RmbConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [RouterModule.forChild(routes),
        TeamRoleModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RmbConfigModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule.forChild(routes),
                        TeamRoleModule
                    ],
                }]
        }], function () { return [{ type: InitService }]; }, null);
})();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RmbConfigModule, { imports: [i5.RouterModule, TeamRoleModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of rmb
 */

/**
 * Generated bundle index. Do not edit.
 */

export { RmbConfigModule };
//# sourceMappingURL=rmb.mjs.map
