import { Route, Router } from '@angular/router';
import { DynamicMethodService, ImxTranslationProviderService, imx_SessionService, MenuService, ExtService } from 'qbm';
import { DataExplorerRegistryService, IdentityRoleMembershipsService, MyResponsibilitiesRegistryService, QerApiService, RoleService } from 'qer';
import { RmbApiService } from './rmb-api-client.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly router;
    private readonly api;
    private readonly qerApi;
    private readonly session;
    private readonly translator;
    private readonly dynamicMethodService;
    private readonly dataExplorerRegistryService;
    private readonly menuService;
    private readonly roleService;
    private readonly identityRoleMembershipService;
    private readonly myResponsibilitiesRegistryService;
    private readonly extService;
    protected readonly orgTag = "Org";
    private abortController;
    constructor(router: Router, api: RmbApiService, qerApi: QerApiService, session: imx_SessionService, translator: ImxTranslationProviderService, dynamicMethodService: DynamicMethodService, dataExplorerRegistryService: DataExplorerRegistryService, menuService: MenuService, roleService: RoleService, identityRoleMembershipService: IdentityRoleMembershipsService, myResponsibilitiesRegistryService: MyResponsibilitiesRegistryService, extService: ExtService);
    onInit(routes: Route[]): void;
    private setupMenu;
    private addRoutes;
    private abortCall;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
