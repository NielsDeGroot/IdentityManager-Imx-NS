import { FilterData, DataModel } from 'imx-qbm-dbts';
import { IRoleDataModel } from 'qer';
import { RmbApiService } from './rmb-api-client.service';
export declare class OrgDataModel implements IRoleDataModel {
    private readonly api;
    constructor(api: RmbApiService);
    getModel(filter: FilterData[], isAdmin: boolean): Promise<DataModel>;
}
