import { CollectionLoadParameters, ExtendedTypedEntityCollection, TypedEntity, EntityCollectionData, EntitySchema } from 'imx-qbm-dbts';
import { BaseMembership } from 'qer';
import { ImxTranslationProviderService, imx_SessionService } from 'qbm';
import { RmbApiService } from './rmb-api-client.service';
export declare class OrgMembership extends BaseMembership {
    private api;
    private session;
    private translator;
    constructor(api: RmbApiService, session: imx_SessionService, translator: ImxTranslationProviderService);
    delete(role: string, identity: string): Promise<EntityCollectionData>;
    hasPrimaryMemberships(): boolean;
    getPrimaryMembers(uid: string, navigationstate: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<TypedEntity, any>>;
    getPrimaryMembersSchema(): EntitySchema;
}
