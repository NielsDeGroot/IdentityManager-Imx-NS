import { OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { TeamRoleData } from 'imx-api-rmb';
import { DataManagementService, QerPermissionsService, RoleEntitlementActionService, RoleService } from 'qer';
import { RmbApiService } from '../rmb-api-client.service';
import * as i0 from "@angular/core";
export declare class TeamRoleComponent implements OnInit {
    private readonly rmbApiService;
    private readonly sidesheetService;
    private readonly translateService;
    private readonly roleService;
    private readonly dataManagementService;
    private readonly route;
    private readonly permissionService;
    private readonly roleEntitlementActionService;
    teamRole: TeamRoleData;
    loadingState: boolean;
    showTeamRole: boolean;
    private orgTag;
    constructor(rmbApiService: RmbApiService, sidesheetService: EuiSidesheetService, translateService: TranslateService, roleService: RoleService, dataManagementService: DataManagementService, route: ActivatedRoute, permissionService: QerPermissionsService, roleEntitlementActionService: RoleEntitlementActionService);
    ngOnInit(): Promise<void>;
    /**
     * Load team role data and open details sidesheet
     */
    onManageTeamRole(): Promise<void>;
    /**
     * Load recomenndation options and open sidesheet where you can select the options.
     */
    onCreateTeamRole(): Promise<void>;
    /**
     * Check loaded team role data existence.
     * @returns boolean
     */
    get existTeamRole(): boolean;
    /**
     * Loading team role.
     */
    private getTeamRole;
    /**
     * This function is called after selected options of recommended team roles.
     * Save the selection and add recommendations to the cart.
     * @param resultItem
     */
    private saveRecommendations;
    /**
     * Set role service sidesheet data with the required params.
     * @param IEntity
     */
    private setRoleData;
    static ɵfac: i0.ɵɵFactoryDeclaration<TeamRoleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TeamRoleComponent, "imx-team-role", never, {}, {}, never, never, false>;
}
