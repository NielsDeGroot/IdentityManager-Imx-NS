import * as i0 from "@angular/core";
import * as i1 from "./team-role.component";
import * as i2 from "@angular/common";
import * as i3 from "@elemental-ui/core";
import * as i4 from "@ngx-translate/core";
import * as i5 from "qer";
import * as i6 from "@angular/forms";
export declare class TeamRoleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TeamRoleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TeamRoleModule, [typeof i1.TeamRoleComponent], [typeof i2.CommonModule, typeof i3.EuiCoreModule, typeof i3.EuiMaterialModule, typeof i4.TranslateModule, typeof i5.TilesModule, typeof i6.FormsModule, typeof i6.ReactiveFormsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TeamRoleModule>;
}
