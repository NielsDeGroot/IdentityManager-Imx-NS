import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import { __awaiter } from 'tslib';
import { V2Client, TypedClient, V2ApiClientMethodFactory, PortalAdminRoleEset, PortalRespEset, PortalPersonRolemembershipsEset } from 'imx-api-rms';
import { FilterType, CompareOperator, WriteExtTypedEntity, MethodDefinition } from 'imx-qbm-dbts';
import * as i1 from 'qbm';
import { GenericTypedEntity, HELP_CONTEXTUAL } from 'qbm';
import * as i4 from 'qer';
import { BaseMembership, isRoleAdmin, isRoleStatistics, isAuditor, RolesOverviewComponent } from 'qer';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EsetDataModel {
    constructor(api) {
        this.api = api;
    }
    getModel(filter, isAdmin) {
        return __awaiter(this, void 0, void 0, function* () {
            return isAdmin ?
                this.api.client.portal_admin_role_eset_datamodel_get({ filter: filter })
                : this.api.client.portal_resp_eset_datamodel_get({ filter: filter });
        });
    }
}

class EsetEntitlements {
    constructor(api, translator) {
        this.api = api;
        this.translator = translator;
        this.entitlementFkName = 'Entitlement'; // column name in ESetHasEntitlement
    }
    getCollection(id, navigationState, objectKeyForFiltering) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalRolesConfigEntitlementsEset.Get(id, Object.assign(Object.assign({}, navigationState), { filter: objectKeyForFiltering ? [
                    {
                        ColumnName: 'Entitlement',
                        CompareOp: CompareOperator.Equal,
                        Type: FilterType.Compare,
                        Value1: objectKeyForFiltering,
                    },
                ] : undefined }));
        });
    }
    getEntitlementTypes(role) {
        return this.api.client.portal_roles_config_classes_ESet_get();
    }
    delete(roleId, entity) {
        return __awaiter(this, void 0, void 0, function* () {
            const esethasentl = entity.GetKeys()[0];
            yield this.api.client.portal_roles_config_entitlements_ESet_delete(roleId, esethasentl);
        });
    }
    createEntitlementAssignmentEntity(role) {
        const uidESet = role.GetKeys()[0];
        return this.api.typedClient.PortalRolesConfigEntitlementsEset.createEntity({ Columns: { UID_ESet: { Value: uidESet } } }).GetEntity();
    }
}

class EsetMembership extends BaseMembership {
    constructor(api, session, translator) {
        super(api, session, translator);
        this.api = api;
        this.session = session;
        this.translator = translator;
        this.supportsDynamicMemberships = false;
        this.setRoleName('ESet', 'UID_ESet');
    }
    delete(role, identity) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.client.portal_roles_config_membership_ESet_delete(role, identity);
        });
    }
    hasPrimaryMemberships() {
        return false;
    }
    getPrimaryMembers(uid, navigationstate) {
        throw new Error('System roles do not allow primary memberships.');
    }
    getPrimaryMembersSchema() {
        throw new Error('System roles do not allow primary memberships.');
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RequestableSystemRoleType {
    constructor(dynamicMethodService, rmsApi) {
        this.dynamicMethodService = dynamicMethodService;
        this.rmsApi = rmsApi;
        this.schema = this.createAssignmentEntity('dummy').GetEntity().GetSchema();
    }
    getTableName() {
        return "ESet";
    }
    getFkColumnName() {
        return "UID_ESet";
    }
    getSchema() {
        return this.schema;
    }
    addEntitlementSelections(shelfId, values) {
        const promises = [];
        values.forEach(value => {
            const e = this.createAssignmentEntity(shelfId).GetEntity();
            promises.push(e.GetColumn(this.getFkColumnName()).PutValue(value)
                .then(() => e.Commit()));
        });
        return Promise.all(promises);
    }
    createAssignmentEntity(shelfId) {
        const entityColl = this.dynamicMethodService.createEntity(this.rmsApi.apiClient, {
            path: '/portal/shop/config/entitlements/' + shelfId + '/' + this.getTableName(),
            type: GenericTypedEntity,
            schemaPath: 'portal/shop/config/entitlements/{UID_ITShopOrg}/' + this.getTableName(),
        }, {
            Columns: {
                "UID_ITShopOrg": {
                    Value: shelfId
                }
            }
        });
        return entityColl.Data[0];
    }
}

class RmsApiService {
    constructor(config, logger, entlTypeService, dynamicMethodService, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.entlTypeService = entlTypeService;
        this.dynamicMethodService = dynamicMethodService;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing RMS API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
            this.entlTypeService.Register(() => this.GetSystemRoleType());
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
    GetSystemRoleType() {
        return __awaiter(this, void 0, void 0, function* () {
            var types = [];
            types.push(new RequestableSystemRoleType(this.dynamicMethodService, this));
            return types;
        });
    }
}
RmsApiService.ɵfac = function RmsApiService_Factory(t) { return new (t || RmsApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i4.RequestableEntitlementTypeService), i0.ɵɵinject(i1.DynamicMethodService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
RmsApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RmsApiService, factory: RmsApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RmsApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i4.RequestableEntitlementTypeService }, { type: i1.DynamicMethodService }, { type: i1.ImxTranslationProviderService }]; }, null);
})();

class InitService {
    constructor(router, api, session, translator, dataExplorerRegistryService, menuService, roleService, identityRoleMembershipService, myResponsibilitiesRegistryService) {
        this.router = router;
        this.api = api;
        this.session = session;
        this.translator = translator;
        this.dataExplorerRegistryService = dataExplorerRegistryService;
        this.menuService = menuService;
        this.roleService = roleService;
        this.identityRoleMembershipService = identityRoleMembershipService;
        this.myResponsibilitiesRegistryService = myResponsibilitiesRegistryService;
        this.esetTag = 'ESet';
        this.abortController = new AbortController();
    }
    onInit(routes) {
        this.addRoutes(routes);
        // wrapper class for interactive methods
        // tslint:disable-next-line: max-classes-per-file
        class ApiWrapper {
            constructor(getByIdApi) {
                this.getByIdApi = getByIdApi;
            }
            Get() {
                return __awaiter(this, void 0, void 0, function* () {
                    if (!this.getByIdApi.Get) {
                        throw new Error('Creation of new system roles is not yet supported.');
                    }
                    const data = yield this.getByIdApi.Get();
                    const result = Object.assign(Object.assign({}, data), { Data: data.Data.map((d) => new WriteExtTypedEntity(d.GetEntity())) });
                    return result;
                });
            }
            GetSchema() {
                return this.getByIdApi.GetSchema();
            }
            Get_byid(id) {
                return __awaiter(this, void 0, void 0, function* () {
                    const data = yield this.getByIdApi.Get_byid(id);
                    const result = Object.assign(Object.assign({}, data), { Data: data.Data.map((d) => new WriteExtTypedEntity(d.GetEntity())) });
                    return result;
                });
            }
        }
        this.roleService.targetMap.set(this.esetTag, {
            canBeSplitTarget: false,
            canBeSplitSource: false,
            table: this.esetTag,
            respType: PortalRespEset,
            resp: this.api.typedClient.PortalRespEset,
            adminType: PortalAdminRoleEset,
            admin: {
                get: (parameter) => __awaiter(this, void 0, void 0, function* () {
                    if ((parameter === null || parameter === void 0 ? void 0 : parameter.search) !== undefined) {
                        // abort the request only while searching
                        this.abortCall();
                    }
                    return this.api.client.portal_admin_role_eset_get({
                        OrderBy: parameter.OrderBy,
                        StartIndex: parameter.StartIndex,
                        PageSize: parameter.PageSize,
                        filter: parameter.filter,
                        search: parameter.search,
                        risk: parameter.risk,
                        esettype: parameter.esettype,
                        withProperties: parameter.withProperties,
                    }, { signal: this.abortController.signal });
                }),
            },
            adminSchema: this.api.typedClient.PortalAdminRoleEset.GetSchema(),
            dataModel: new EsetDataModel(this.api),
            respCanCreate: false,
            adminCanCreate: true,
            interactiveResp: new ApiWrapper(this.api.typedClient.PortalRespEsetInteractive),
            interactiveAdmin: new ApiWrapper(this.api.typedClient.PortalAdminRoleEsetInteractive),
            entitlements: new EsetEntitlements(this.api, this.translator),
            membership: new EsetMembership(this.api, this.session, this.translator),
            canUseRecommendations: true,
            exportMethod: (navigationState, isAdmin) => {
                const factory = new V2ApiClientMethodFactory();
                return {
                    getMethod: (withProperties, PageSize) => {
                        let method;
                        if (PageSize) {
                            method = isAdmin
                                ? factory.portal_admin_role_eset_get(Object.assign(Object.assign({}, navigationState), { withProperties, PageSize, StartIndex: 0 }))
                                : factory.portal_resp_eset_get(Object.assign(Object.assign({}, navigationState), { withProperties, PageSize, StartIndex: 0 }));
                        }
                        else {
                            method = isAdmin
                                ? factory.portal_admin_role_eset_get(Object.assign(Object.assign({}, navigationState), { withProperties }))
                                : factory.portal_resp_eset_get(Object.assign(Object.assign({}, navigationState), { withProperties }));
                        }
                        return new MethodDefinition(method);
                    },
                };
            },
            translateKeys: {
                create: '#LDS#Create system role',
                createHeading: '#LDS#Heading Create System Role',
                editHeading: '#LDS#Heading Edit System Role',
                createSnackbar: '#LDS#The system role has been successfully created.',
            },
        });
        this.identityRoleMembershipService.addTarget({
            table: this.esetTag,
            type: PortalPersonRolemembershipsEset,
            entitySchema: this.api.typedClient.PortalPersonRolemembershipsEset.GetSchema(),
            controlInfo: {
                label: '#LDS#Menu Entry System roles',
                index: 80,
            },
            get: (uidPerson, parameter) => __awaiter(this, void 0, void 0, function* () { return this.api.client.portal_person_rolememberships_ESet_get(uidPerson, parameter); }),
            withAnalysis: true,
        });
        this.setupMenu();
        this.dataExplorerRegistryService.registerFactory((preProps, features, projectConfig, groups) => {
            if (!isRoleAdmin(features) && !isRoleStatistics(features) && !isAuditor(groups)) {
                return;
            }
            return {
                instance: RolesOverviewComponent,
                data: {
                    TableName: this.esetTag,
                    Count: 0,
                },
                contextId: HELP_CONTEXTUAL.DataExplorerSystemRoles,
                sortOrder: 8,
                name: 'systemroles',
                caption: '#LDS#Menu Entry System roles',
            };
        });
        this.myResponsibilitiesRegistryService.registerFactory((preProps, features) => ({
            instance: RolesOverviewComponent,
            sortOrder: 8,
            name: this.esetTag,
            caption: '#LDS#Menu Entry System roles',
            data: {
                TableName: this.esetTag,
                Count: 0,
            },
            contextId: HELP_CONTEXTUAL.MyResponsibilitiesSystemRoles,
        }));
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features, projectConfig, groups) => {
            if (!isRoleAdmin(features) && !isRoleStatistics(features) && !isAuditor(groups)) {
                return null;
            }
            return {
                id: 'ROOT_Data',
                title: '#LDS#Data administration',
                sorting: '40',
                items: [
                    {
                        id: 'QER_DataExplorer',
                        navigationCommands: { commands: ['admin', 'dataexplorer'] },
                        title: '#LDS#Menu Entry Data Explorer',
                        sorting: '40-10',
                    },
                ],
            };
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i1$1.Router), i0.ɵɵinject(RmsApiService), i0.ɵɵinject(i1.imx_SessionService), i0.ɵɵinject(i1.ImxTranslationProviderService), i0.ɵɵinject(i4.DataExplorerRegistryService), i0.ɵɵinject(i1.MenuService), i0.ɵɵinject(i4.RoleService), i0.ɵɵinject(i4.IdentityRoleMembershipsService), i0.ɵɵinject(i4.MyResponsibilitiesRegistryService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i1$1.Router }, { type: RmsApiService }, { type: i1.imx_SessionService }, { type: i1.ImxTranslationProviderService }, { type: i4.DataExplorerRegistryService }, { type: i1.MenuService }, { type: i4.RoleService }, { type: i4.IdentityRoleMembershipsService }, { type: i4.MyResponsibilitiesRegistryService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [];
class RmsConfigModule {
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 RMS loaded');
        this.initializer.onInit(routes);
        console.log('▶️ RMS initialized');
    }
}
RmsConfigModule.ɵfac = function RmsConfigModule_Factory(t) { return new (t || RmsConfigModule)(i0.ɵɵinject(InitService)); };
RmsConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RmsConfigModule });
RmsConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [RouterModule.forChild(routes)] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RmsConfigModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule.forChild(routes)
                    ]
                }]
        }], function () { return [{ type: InitService }]; }, null);
})();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RmsConfigModule, { imports: [i1$1.RouterModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of rms
 */

/**
 * Generated bundle index. Do not edit.
 */

export { RmsConfigModule };
//# sourceMappingURL=rms.mjs.map
