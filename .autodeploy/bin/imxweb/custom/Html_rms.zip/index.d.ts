/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="rms" />
export * from './public_api';
