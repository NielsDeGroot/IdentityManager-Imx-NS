import { FilterData, DataModel } from 'imx-qbm-dbts';
import { IRoleDataModel } from 'qer';
import { RmsApiService } from './rms-api-client.service';
export declare class EsetDataModel implements IRoleDataModel {
    private readonly api;
    constructor(api: RmsApiService);
    getModel(filter: FilterData[], isAdmin: boolean): Promise<DataModel>;
}
