import { CollectionLoadParameters, ExtendedTypedEntityCollection, TypedEntity, EntityCollectionData, EntitySchema } from 'imx-qbm-dbts';
import { BaseMembership } from 'qer';
import { ImxTranslationProviderService, imx_SessionService } from 'qbm';
import { RmsApiService } from './rms-api-client.service';
export declare class EsetMembership extends BaseMembership {
    private readonly api;
    readonly session: imx_SessionService;
    readonly translator: ImxTranslationProviderService;
    supportsDynamicMemberships: boolean;
    constructor(api: RmsApiService, session: imx_SessionService, translator: ImxTranslationProviderService);
    delete(role: string, identity: string): Promise<EntityCollectionData>;
    hasPrimaryMemberships(): boolean;
    getPrimaryMembers(uid: string, navigationstate: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<TypedEntity, any>>;
    getPrimaryMembersSchema(): EntitySchema;
}
