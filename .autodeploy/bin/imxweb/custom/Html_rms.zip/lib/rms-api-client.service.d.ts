import { V2Client, TypedClient } from 'imx-api-rms';
import { ApiClient } from 'imx-qbm-dbts';
import { AppConfigService, ClassloggerService, DynamicMethodService, ImxTranslationProviderService } from 'qbm';
import { RequestableEntitlementTypeService } from 'qer';
import * as i0 from "@angular/core";
export declare class RmsApiService {
    private readonly config;
    private readonly logger;
    private readonly entlTypeService;
    private readonly dynamicMethodService;
    private readonly translationProvider;
    private tc;
    get typedClient(): TypedClient;
    private c;
    get client(): V2Client;
    get apiClient(): ApiClient;
    constructor(config: AppConfigService, logger: ClassloggerService, entlTypeService: RequestableEntitlementTypeService, dynamicMethodService: DynamicMethodService, translationProvider: ImxTranslationProviderService);
    private GetSystemRoleType;
    static ɵfac: i0.ɵɵFactoryDeclaration<RmsApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RmsApiService>;
}
