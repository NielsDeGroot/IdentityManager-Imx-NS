export { RmsConfigModule } from './lib/rms-config.module';
