import * as i0 from '@angular/core';
import { EventEmitter, Injectable, forwardRef, Component, Input, Inject, ViewChild, NgModule } from '@angular/core';
import * as i1$2 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i1 from 'qbm';
import { BaseCdr, BusyService, createGroupData, DataSourceToolbarModule, DataTableModule, RouteGuardService, CdrModule, ConfirmationModule, LdsReplaceModule, MultiSelectFormcontrolModule, UserMessageModule, BusyIndicatorModule, BaseReadonlyCdr, SqlWizardComponent, DataSourceWrapper, HELP_CONTEXTUAL, HelpContextualComponent, OrderedListModule, SqlWizardModule, SelectedElementsModule, HelpContextualModule, SqlWizardApiService } from 'qbm';
import { ScrollingModule } from '@angular/cdk/scrolling';
import * as i3$1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i10 from '@angular/forms';
import { UntypedFormControl, NG_VALUE_ACCESSOR, UntypedFormArray, UntypedFormGroup, FormGroup, FormArray, FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i1$1 from '@elemental-ui/core';
import { EuiDownloadDirective, EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i3$2 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { __awaiter, __rest } from 'tslib';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
import { V2Client, TypedClient, V2ApiClientMethodFactory, PortalReports, PortalReportsEditInteractive } from 'imx-api-rps';
import { TypedEntityBuilder, MethodDefinition, DisplayColumns, ValType, isExpressionInvalid } from 'imx-qbm-dbts';
import * as i5 from 'qer';
import { ParameterContainer, RequestableEntitlementType } from 'qer';
import * as i3 from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import * as i4 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';
import * as i5$1 from '@angular/material/form-field';
import * as i6 from '@angular/material/input';
import * as i7 from '@angular/material/list';
import * as i8 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i4$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i9 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i9$1 from '@angular/material/radio';
import { BehaviorSubject } from 'rxjs';
import * as i5$2 from '@angular/material/stepper';
import * as i10$1 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import _ from 'lodash';
import { DragDropModule } from '@angular/cdk/drag-drop';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportParameterWrapper {
    constructor(translationService, logger, parameters, getFkProviderItems, typedEntity) {
        this.translationService = translationService;
        this.logger = logger;
        this.parameters = parameters;
        this.getFkProviderItems = getFkProviderItems;
        this.typedEntity = typedEntity;
        this.startWriteData = new EventEmitter();
        this.endWriteData = new EventEmitter();
        this.container = new ParameterContainer(this.translationService, this.getFkProviderItems, this.logger, this.typedEntity);
        this.container.updateExtendedDataTriggered.subscribe((columnName) => {
            this.logger.debug(this, 'Start writing');
            this.startWriteData.emit(columnName);
        });
        this.columns = this.createInteractiveParameterColumns();
    }
    unsubscribeEvents() {
        this.container.updateExtendedDataTriggered.unsubscribe();
    }
    /** Builds a set of entity columns for a simple array of parameters. */
    createInteractiveParameterColumns() {
        var _a, _b, _c;
        const columns = [];
        if ((_a = this.typedEntity) === null || _a === void 0 ? void 0 : _a.onChangeExtendedDataRead) {
            (_b = this.typedEntity) === null || _b === void 0 ? void 0 : _b.onChangeExtendedDataRead(() => {
                // new parameters from server --> sync local entity
                const newParameters = this.typedEntity.extendedDataRead[0];
                newParameters.forEach((parameter) => {
                    this.container.update(parameter.Property.ColumnName, parameter);
                    // TODO: remove parameters not returned by the server
                });
                this.logger.debug(this, 'End writing');
                this.endWriteData.emit();
            });
        }
        (_c = this.parameters) === null || _c === void 0 ? void 0 : _c.forEach((parameter) => {
            const extendedDataGenerator = (newValue) => [
                [
                    {
                        Name: parameter.Property.ColumnName,
                        Value: newValue,
                    },
                ],
            ];
            const column = this.container.add(parameter.Property.ColumnName, parameter, extendedDataGenerator);
            columns.push(column);
        });
        return columns;
    }
}

class ReportSubscription {
    constructor(subscription, translationService, getFkProviderItem, parameterDataService) {
        var _a, _b, _c, _d, _e;
        this.subscription = subscription;
        this.getFkProviderItem = getFkProviderItem;
        this.columnsWithParameterReload = ['UID_RPSReport'];
        this.parameterColumns = [];
        this.startWriteData = new EventEmitter();
        this.endWriteData = new EventEmitter();
        this.reportEntityWrapper = new ReportParameterWrapper(translationService, parameterDataService.logger, ((_b = (_a = this.subscription) === null || _a === void 0 ? void 0 : _a.extendedDataRead) === null || _b === void 0 ? void 0 : _b.length) ? this.subscription.extendedDataRead[0] : null, (parameterData) => this.getFkProviderItem(this.subscription, parameterData), this.subscription);
        this.hasParameter = ((_e = (_d = (_c = this.subscription) === null || _c === void 0 ? void 0 : _c.extendedDataRead) === null || _d === void 0 ? void 0 : _d[0]) === null || _e === void 0 ? void 0 : _e.length) > 0;
        this.parameterColumns = this.hasParameter ? this.reportEntityWrapper.columns : [];
        this.reportEntityWrapper.startWriteData.subscribe((elem) => this.startWriteData.emit(elem));
        this.reportEntityWrapper.endWriteData.subscribe(() => this.endWriteData.emit());
    }
    getCdrs(properties) {
        if (!this.subscription) {
            return [];
        }
        const columns = properties.length === 0
            ? [
                this.subscription.Ident_RPSSubscription.Column,
                this.subscription.UID_RPSReport.Column,
                this.subscription.UID_DialogSchedule.Column,
                this.subscription.ExportFormat.Column,
                this.subscription.AddtlSubscribers.Column,
            ]
            : properties.map((prop) => this.subscription.GetEntity().GetColumn(prop.ColumnName));
        return columns.map((col) => new BaseCdr(col));
    }
    getParameterCdr() {
        return this.parameterColumns.map((col) => new BaseCdr(col));
    }
    getParameterDictionary() {
        const ret = {};
        this.parameterColumns.forEach((elem) => (ret[elem.ColumnName] = elem.GetValue()));
        return ret;
    }
    getDisplayableColums() {
        return [
            this.subscription.Ident_RPSSubscription.Column,
            this.subscription.UID_RPSReport.Column,
            this.subscription.UID_DialogSchedule.Column,
            this.subscription.ExportFormat.Column,
            this.subscription.AddtlSubscribers.Column,
        ].concat(this.parameterColumns);
    }
    submit(reload = false) {
        return __awaiter(this, void 0, void 0, function* () {
            this.subscription.extendedData = [this.parameterColumns.map((col) => ({ Name: col.ColumnName, Value: col.GetValue() }))];
            return this.subscription.GetEntity().Commit(reload);
        });
    }
    unsubscribeEvents() {
        this.reportEntityWrapper.endWriteData.unsubscribe();
        this.reportEntityWrapper.startWriteData.unsubscribe();
        this.reportEntityWrapper.unsubscribeEvents();
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class RpsApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing RPS API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
RpsApiService.ɵfac = function RpsApiService_Factory(t) { return new (t || RpsApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
RpsApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RpsApiService, factory: RpsApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RpsApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i1.ImxTranslationProviderService }]; }, null);
})();

class ReportSubscriptionService {
    constructor(api, elementalUiConfigService, config, http, overlay, injector, translator, parameterDataService) {
        this.api = api;
        this.elementalUiConfigService = elementalUiConfigService;
        this.config = config;
        this.http = http;
        this.overlay = overlay;
        this.injector = injector;
        this.translator = translator;
        this.parameterDataService = parameterDataService;
        this.apiMethodFactory = new V2ApiClientMethodFactory();
    }
    get PortalSubscriptionInteractiveSchema() {
        return this.api.typedClient.PortalSubscriptionInteractive.GetSchema();
    }
    getReportCandidates(parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            const candidates = yield this.api.client.portal_subscription_interactive_UID_RPSReport_candidates_get(parameter);
            const reportBuilder = new TypedEntityBuilder(PortalReports);
            return reportBuilder.buildReadWriteEntities(candidates, this.api.typedClient.PortalReports.GetSchema());
        });
    }
    buildRpsSubscription(subscription) {
        return new ReportSubscription(subscription, this.translator, (entity, data) => this.getFkProvider(entity, data), this.parameterDataService);
    }
    createNewSubscription(uidReport) {
        return __awaiter(this, void 0, void 0, function* () {
            const subscription = yield this.api.typedClient.PortalSubscriptionInteractive.Get();
            yield subscription.Data[0].UID_RPSReport.Column.PutValue(uidReport);
            yield subscription.Data[0].Ident_RPSSubscription.Column.PutValue(subscription.Data[0].UID_RPSReport.Column.GetDisplayValue());
            const allowedFormats = subscription.Data[0].ExportFormat.Column.GetMetadata().GetLimitedValues();
            if (allowedFormats && allowedFormats.filter((f) => f.Value == 'PDF').length > 0) {
                yield subscription.Data[0].ExportFormat.Column.PutValue('PDF');
            }
            return this.buildRpsSubscription(subscription.Data[0]);
        });
    }
    downloadSubsciption(subscription) {
        const parameters = subscription.subscription.enrichMethodCallParameters();
        const def = new MethodDefinition(this.apiMethodFactory.portal_subscription_interactive_report_get(parameters.entityid, parameters));
        // not pretty, but the download directive does not support dynamic URLs
        const directive = new EuiDownloadDirective(null /* no element */, this.http, this.overlay, this.injector);
        directive.downloadOptions = Object.assign(Object.assign({}, this.elementalUiConfigService.Config.downloadOptions), { fileMimeType: '', url: this.config.BaseUrl + def.path, disableElement: false });
        // start the report download
        directive.onClick();
    }
    getFkProvider(subscription, parameterData) {
        var api = this.api;
        return new class {
            getProviderItem(_columnName, fkTableName) {
                if (parameterData.Property.FkRelation) {
                    return this.getFkProviderItem(subscription, parameterData.Property.ColumnName, parameterData.Property.FkRelation.ParentTableName);
                }
                if (parameterData.Property.ValidReferencedTables) {
                    const t = parameterData.Property.ValidReferencedTables.map((parentTableRef) => this.getFkProviderItem(subscription, parameterData.Property.ColumnName, parentTableRef.TableName)).filter(t => t.fkTableName == fkTableName);
                    if (t.length == 1)
                        return t[0];
                    return null;
                }
            }
            getFkProviderItem(subscription, columnName, fkTableName) {
                return {
                    columnName,
                    fkTableName,
                    parameterNames: ['OrderBy', 'StartIndex', 'PageSize', 'filter', 'withProperties', 'search'],
                    load: (__entity, parameters) => __awaiter(this, void 0, void 0, function* () {
                        return api.client.portal_subscription_interactive_parameter_candidates_post(columnName, fkTableName, subscription.InteractiveEntityWriteData, parameters);
                    }),
                    getDataModel: () => __awaiter(this, void 0, void 0, function* () { return ({}); }),
                    getFilterTree: (__entity, parentkey) => __awaiter(this, void 0, void 0, function* () {
                        return api.client.portal_subscription_interactive_parameter_candidates_filtertree_post(columnName, fkTableName, subscription.InteractiveEntityWriteData, { parentkey });
                    }),
                };
            }
        };
    }
}
ReportSubscriptionService.ɵfac = function ReportSubscriptionService_Factory(t) { return new (t || ReportSubscriptionService)(i0.ɵɵinject(RpsApiService), i0.ɵɵinject(i1.ElementalUiConfigService), i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i3.HttpClient), i0.ɵɵinject(i4.Overlay), i0.ɵɵinject(i0.Injector), i0.ɵɵinject(i1.ImxTranslationProviderService), i0.ɵɵinject(i5.ParameterDataService)); };
ReportSubscriptionService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ReportSubscriptionService, factory: ReportSubscriptionService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportSubscriptionService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: RpsApiService }, { type: i1.ElementalUiConfigService }, { type: i1.AppConfigService }, { type: i3.HttpClient }, { type: i4.Overlay }, { type: i0.Injector }, { type: i1.ImxTranslationProviderService }, { type: i5.ParameterDataService }]; }, null);
})();

function ReportSelectorComponent_mat_spinner_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner", 7);
    }
}
function ReportSelectorComponent_mat_list_option_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-list-option", 8)(1, "div", 9)(2, "div", 10);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "div", 11);
        i0.ɵɵtext(5);
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        const candidate_r2 = ctx.$implicit;
        const i_r3 = ctx.index;
        i0.ɵɵproperty("value", candidate_r2);
        i0.ɵɵattribute("data-imx-identifier", "report-selector-selectionList-element-" + i_r3);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(candidate_r2.GetEntity().GetDisplay());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(candidate_r2.Description.Column.GetDisplayValue());
    }
}
const _c0$4 = function (a0) { return { "height": a0 }; };
class ReportSelectorComponent {
    constructor(changeDetectorRef, settings, reportSubscriptionService) {
        this.changeDetectorRef = changeDetectorRef;
        this.settings = settings;
        this.reportSubscriptionService = reportSubscriptionService;
        this.loading = false;
        this.searchControl = new UntypedFormControl();
        this.subscribers = [];
        this.controlHeigth = 200;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.initSearchControl();
            yield this.loadReports({
                StartIndex: 0,
                PageSize: this.settings.PageSizeForAllElements,
                filter: undefined,
                search: undefined,
            });
            this.changeDetectorRef.detectChanges();
        });
    }
    writeValue(filter) {
        this.uidReport = filter;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouch = fn;
    }
    ngAfterViewInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.parameters = { PageSize: this.settings.PageSizeForAllElements, StartIndex: 0 };
            yield this.loadReports(this.parameters);
        });
    }
    ngOnDestroy() {
        this.subscribers.forEach((s) => s.unsubscribe());
    }
    updateSelected(elem) {
        // Only one can be selected
        const chosenElem = elem.options.find((ele) => ele.selected);
        this.writeValue(chosenElem.value.GetEntity().GetKeys()[0]);
        this.onChange(chosenElem.value.GetEntity().GetKeys()[0]);
    }
    loadReports(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.loading = true;
            try {
                this.parameters = Object.assign(Object.assign({}, this.parameters), newState);
                this.candidates = (yield this.reportSubscriptionService.getReportCandidates(this.parameters)).Data;
            }
            finally {
                this.loading = false;
            }
        });
    }
    initSearchControl() {
        this.searchControl.setValue('');
        this.subscribers.push(this.searchControl.valueChanges.pipe(distinctUntilChanged(), debounceTime(300)).subscribe((value) => __awaiter(this, void 0, void 0, function* () {
            yield this.loadReports({ StartIndex: 0, PageSize: this.settings.PageSizeForAllElements, search: value });
            this.changeDetectorRef.detectChanges();
        })));
    }
}
ReportSelectorComponent.ɵfac = function ReportSelectorComponent_Factory(t) { return new (t || ReportSelectorComponent)(i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i1.SettingsService), i0.ɵɵdirectiveInject(ReportSubscriptionService)); };
ReportSelectorComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportSelectorComponent, selectors: [["imx-report-selector"]], inputs: { controlHeigth: "controlHeigth" }, features: [i0.ɵɵProvidersFeature([
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ReportSelectorComponent),
                multi: true,
            },
        ])], decls: 12, vars: 14, consts: [[1, "imx-report-listing"], ["data-imx-identifier", "report-selector-eui-search", "size", "small", 1, "report-selector-eui-search", 3, "placeholder", "searchControl"], ["diameter", "16", 4, "ngIf"], ["appearance", "outline"], ["value", "_hidden", "matInput", "", "hidden", "", 3, "required"], ["data-imx-identifier", "report-selector-selectionList", 1, "imx-candidate-list", 3, "multiple", "ngStyle", "selectionChange"], ["class", "imx-candidate-option", 3, "value", 4, "ngFor", "ngForOf"], ["diameter", "16"], [1, "imx-candidate-option", 3, "value"], [1, "imx-candidate-content"], [1, "imx-candidate-display"], [1, "imx-candidate-longdisplay"]], template: function ReportSelectorComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "eui-search", 1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementStart(3, "div");
            i0.ɵɵtemplate(4, ReportSelectorComponent_mat_spinner_4_Template, 1, 0, "mat-spinner", 2);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "mat-form-field", 3)(6, "mat-label");
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(9, "input", 4);
            i0.ɵɵelementStart(10, "mat-selection-list", 5);
            i0.ɵɵlistener("selectionChange", function ReportSelectorComponent_Template_mat_selection_list_selectionChange_10_listener($event) { return ctx.updateSelected($event); });
            i0.ɵɵtemplate(11, ReportSelectorComponent_mat_list_option_11_Template, 6, 4, "mat-list-option", 6);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("placeholder", i0.ɵɵpipeBind1(2, 8, "#LDS#Search"))("searchControl", ctx.searchControl);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.loading);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 10, "#LDS#Report"));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("required", true);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("multiple", false)("ngStyle", i0.ɵɵpureFunction1(12, _c0$4, ctx.controlHeigth + "px"));
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.candidates);
        }
    }, dependencies: [i3$1.NgForOf, i3$1.NgIf, i3$1.NgStyle, i1$1.EuiSearchComponent, i5$1.MatFormField, i5$1.MatLabel, i6.MatInput, i7.MatSelectionList, i7.MatListOption, i8.MatProgressSpinner, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{flex:1;display:flex;flex-direction:column}.report-selector-eui-search[_ngcontent-%COMP%]{display:flex}.report-selector-eui-search[_ngcontent-%COMP%]   .eui-search[_ngcontent-%COMP%]{width:100%}.report-selector-eui-search[_ngcontent-%COMP%]     .eui-search.mat-form-field.mat-form-field-appearance-outline{min-width:280px;flex:1;margin-bottom:10px}.imx-candidate-list[_ngcontent-%COMP%]{overflow-y:auto;overflow-x:hidden}.imx-candidate-option[_ngcontent-%COMP%]{display:flex;height:auto;margin:10px 0}.imx-candidate-content[_ngcontent-%COMP%]{flex:1;overflow:hidden}.imx-candidate-display[_ngcontent-%COMP%]{font-size:14px;line-height:17px;text-overflow:ellipsis;overflow:hidden}.imx-candidate-longdisplay[_ngcontent-%COMP%]{color:#919799;font-size:12px;text-overflow:ellipsis;overflow:hidden;line-height:17px}.imx-report-listing[_ngcontent-%COMP%]{flex:1;display:grid;grid-template-columns:1fr 21px;margin-right:-21px}.mat-spinner[_ngcontent-%COMP%]{margin-top:15px;margin-left:5px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportSelectorComponent, [{
            type: Component,
            args: [{ selector: 'imx-report-selector', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ReportSelectorComponent),
                            multi: true,
                        },
                    ], template: "<div class=\"imx-report-listing\">\r\n  <eui-search class=\"report-selector-eui-search\" data-imx-identifier=\"report-selector-eui-search\"\r\n    [placeholder]=\"'#LDS#Search' | translate\" [searchControl]=\"searchControl\" size=\"small\">\r\n  </eui-search>\r\n  <div >\r\n    <mat-spinner diameter=\"16\" *ngIf=\"loading\"></mat-spinner>\r\n  </div>\r\n</div>\r\n<mat-form-field appearance=\"outline\">\r\n  <mat-label>{{ '#LDS#Report' | translate }}</mat-label>\r\n  <input value=\"_hidden\" matInput hidden [required]=\"true\">\r\n  <mat-selection-list class=\"imx-candidate-list\" [multiple]=\"false\" [ngStyle]=\"{'height': controlHeigth + 'px'}\" (selectionChange)=\"updateSelected($event)\" data-imx-identifier=\"report-selector-selectionList\">\r\n    <mat-list-option *ngFor=\"let candidate of candidates; index as i\" [value]=\"candidate\"\r\n      class=\"imx-candidate-option\" [attr.data-imx-identifier]=\"'report-selector-selectionList-element-' + i\">\r\n      <div class=\"imx-candidate-content\">\r\n        <div class=\"imx-candidate-display\">{{ candidate.GetEntity().GetDisplay() }}</div>\r\n        <div class=\"imx-candidate-longdisplay\">{{ candidate.Description.Column.GetDisplayValue() }}</div>\r\n      </div>\r\n    </mat-list-option>\r\n  </mat-selection-list>\r\n</mat-form-field>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{flex:1;display:flex;flex-direction:column}.report-selector-eui-search{display:flex}.report-selector-eui-search .eui-search{width:100%}.report-selector-eui-search ::ng-deep .eui-search.mat-form-field.mat-form-field-appearance-outline{min-width:280px;flex:1;margin-bottom:10px}.imx-candidate-list{overflow-y:auto;overflow-x:hidden}.imx-candidate-option{display:flex;height:auto;margin:10px 0}.imx-candidate-content{flex:1;overflow:hidden}.imx-candidate-display{font-size:14px;line-height:17px;text-overflow:ellipsis;overflow:hidden}.imx-candidate-longdisplay{color:#919799;font-size:12px;text-overflow:ellipsis;overflow:hidden;line-height:17px}.imx-report-listing{flex:1;display:grid;grid-template-columns:1fr 21px;margin-right:-21px}.mat-spinner{margin-top:15px;margin-left:5px}\n"] }]
        }], function () { return [{ type: i0.ChangeDetectorRef }, { type: i1.SettingsService }, { type: ReportSubscriptionService }]; }, { controlHeigth: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function SubscriptionPropertiesComponent_div_0_imx_cdr_editor_5_Template(rf, ctx) {
    if (rf & 1) {
        const _r8 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 5);
        i0.ɵɵlistener("valueChange", function SubscriptionPropertiesComponent_div_0_imx_cdr_editor_5_Template_imx_cdr_editor_valueChange_0_listener() { const restoredCtx = i0.ɵɵrestoreView(_r8); const cdr_r6 = restoredCtx.$implicit; const ctx_r7 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r7.valueHasChanged(cdr_r6.column.ColumnName)); })("controlCreated", function SubscriptionPropertiesComponent_div_0_imx_cdr_editor_5_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r9 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r9.addFormControl(ctx_r9.subscriptionPropertiesFormArray, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r6 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r6);
    }
}
function SubscriptionPropertiesComponent_div_0_div_10_imx_cdr_editor_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r13 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 7);
        i0.ɵɵlistener("controlCreated", function SubscriptionPropertiesComponent_div_0_div_10_imx_cdr_editor_1_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r13); const ctx_r12 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r12.addFormControl(ctx_r12.subscriptionParameterFormArray, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r11 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r11);
    }
}
function SubscriptionPropertiesComponent_div_0_div_10_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtemplate(1, SubscriptionPropertiesComponent_div_0_div_10_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 6);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r4.parameterCdrList);
    }
}
function SubscriptionPropertiesComponent_div_0_div_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#There are no parameters for this subscription."), " ");
    }
}
function SubscriptionPropertiesComponent_div_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 2)(1, "div")(2, "h4");
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(5, SubscriptionPropertiesComponent_div_0_imx_cdr_editor_5_Template, 1, 1, "imx-cdr-editor", 3);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(6, "div")(7, "h4");
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(10, SubscriptionPropertiesComponent_div_0_div_10_Template, 2, 1, "div", 4);
        i0.ɵɵtemplate(11, SubscriptionPropertiesComponent_div_0_div_11_Template, 3, 3, "div", 4);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 5, "#LDS#Heading Subscription Details"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngForOf", ctx_r0.cdrList);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 7, "#LDS#Heading Parameters"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r0.parameterCdrList.length > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.parameterCdrList.length === 0 && ctx_r0.withTitles);
    }
}
function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r18 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 5);
        i0.ɵɵlistener("valueChange", function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_1_Template_imx_cdr_editor_valueChange_0_listener() { const restoredCtx = i0.ɵɵrestoreView(_r18); const cdr_r16 = restoredCtx.$implicit; const ctx_r17 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r17.valueHasChanged(cdr_r16.column.ColumnName)); })("controlCreated", function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_1_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r18); const ctx_r19 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r19.addFormControl(ctx_r19.subscriptionPropertiesFormArray, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r16 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r16);
    }
}
function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r22 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 7);
        i0.ɵɵlistener("controlCreated", function SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r22); const ctx_r21 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r21.addFormControl(ctx_r21.subscriptionParameterFormArray, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r20 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r20);
    }
}
function SubscriptionPropertiesComponent_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 2);
        i0.ɵɵtemplate(1, SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_1_Template, 1, 1, "imx-cdr-editor", 3);
        i0.ɵɵtemplate(2, SubscriptionPropertiesComponent_ng_template_1_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 6);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r2.cdrList);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r2.parameterCdrList);
    }
}
class SubscriptionPropertiesComponent {
    constructor() {
        this.cdrList = [];
        this.parameterCdrList = [];
        this.subscriptionPropertiesFormArray = new UntypedFormArray([]);
        this.subscriptionParameterFormArray = new UntypedFormArray([]);
        this.withTitles = true;
        this.displayedColumns = [];
    }
    ngOnInit() {
        if (this.formGroup) {
            this.formGroup.addControl('subscriptionProperties', this.subscriptionPropertiesFormArray);
            this.formGroup.addControl('subscriptionParameter', this.subscriptionParameterFormArray);
        }
    }
    ngOnChanges() {
        this.subscriptionPropertiesFormArray.clear();
        this.cdrList = this.subscription == null ? [] : this.subscription.getCdrs(this.displayedColumns);
        this.subscriptionParameterFormArray.clear();
        this.parameterCdrList = this.subscription == null ? [] : this.subscription.getParameterCdr();
        this.withSeparateParameterList = this.withTitles || this.parameterCdrList.length > 0;
    }
    valueHasChanged(name) {
        if (this.subscription.columnsWithParameterReload.indexOf(name) !== -1) {
            this.subscriptionParameterFormArray.clear();
            this.parameterCdrList = this.subscription.getParameterCdr();
        }
    }
    addFormControl(array, control) {
        setTimeout(() => {
            array.push(control);
        });
    }
}
SubscriptionPropertiesComponent.ɵfac = function SubscriptionPropertiesComponent_Factory(t) { return new (t || SubscriptionPropertiesComponent)(); };
SubscriptionPropertiesComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionPropertiesComponent, selectors: [["imx-subscription-properties"]], inputs: { subscription: "subscription", formGroup: "formGroup", withTitles: "withTitles", displayedColumns: "displayedColumns" }, features: [i0.ɵɵNgOnChangesFeature], decls: 3, vars: 2, consts: [["class", "imx-parameter-grid", 4, "ngIf", "ngIfElse"], ["singleMode", ""], [1, "imx-parameter-grid"], [3, "cdr", "valueChange", "controlCreated", 4, "ngFor", "ngForOf"], [4, "ngIf"], [3, "cdr", "valueChange", "controlCreated"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [3, "cdr", "controlCreated"]], template: function SubscriptionPropertiesComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, SubscriptionPropertiesComponent_div_0_Template, 12, 9, "div", 0);
            i0.ɵɵtemplate(1, SubscriptionPropertiesComponent_ng_template_1_Template, 3, 2, "ng-template", null, 1, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
            const _r1 = i0.ɵɵreference(2);
            i0.ɵɵproperty("ngIf", ctx.withSeparateParameterList)("ngIfElse", _r1);
        }
    }, dependencies: [i1.CdrEditorComponent, i3$1.NgForOf, i3$1.NgIf, i3$2.TranslatePipe], styles: [".imx-parameter-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:20px 40px}h4[_ngcontent-%COMP%]{font-size:medium;font-weight:600;margin-bottom:40px}@media only screen and (max-width: 1024px){.imx-parameter-grid[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{grid-column-start:1;grid-column-end:3}}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionPropertiesComponent, [{
            type: Component,
            args: [{ selector: 'imx-subscription-properties', template: "<div class=\"imx-parameter-grid\" *ngIf=\"withSeparateParameterList;else singleMode\" >\r\n  <div>\r\n    <h4>\r\n      {{'#LDS#Heading Subscription Details' | translate}}\r\n    </h4>\r\n    <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (valueChange)=\"valueHasChanged(cdr.column.ColumnName)\"\r\n      (controlCreated)=\"addFormControl(subscriptionPropertiesFormArray, $event)\">\r\n    </imx-cdr-editor>\r\n  </div>\r\n\r\n  <div>\r\n    <h4>\r\n      {{'#LDS#Heading Parameters' | translate}}\r\n    </h4>\r\n    <div *ngIf=\"parameterCdrList.length > 0\">\r\n      <imx-cdr-editor *ngFor=\"let cdr of parameterCdrList\" [cdr]=\"cdr\"\r\n        (controlCreated)=\"addFormControl(subscriptionParameterFormArray, $event)\">\r\n      </imx-cdr-editor>\r\n    </div>\r\n    <div *ngIf=\"parameterCdrList.length === 0 && withTitles\">\r\n      {{'#LDS#There are no parameters for this subscription.' | translate}}\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<ng-template #singleMode>\r\n  <div class=\"imx-parameter-grid\">\r\n    <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (valueChange)=\"valueHasChanged(cdr.column.ColumnName)\"\r\n      (controlCreated)=\"addFormControl(subscriptionPropertiesFormArray, $event)\">\r\n    </imx-cdr-editor>\r\n    <imx-cdr-editor *ngFor=\"let cdr of parameterCdrList\" [cdr]=\"cdr\"\r\n      (controlCreated)=\"addFormControl(subscriptionParameterFormArray, $event)\">\r\n    </imx-cdr-editor>\r\n  </div>\r\n</ng-template>", styles: [".imx-parameter-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px 40px}h4{font-size:medium;font-weight:600;margin-bottom:40px}@media only screen and (max-width: 1024px){.imx-parameter-grid>div{grid-column-start:1;grid-column-end:3}}\n"] }]
        }], null, { subscription: [{
                type: Input
            }], formGroup: [{
                type: Input
            }], withTitles: [{
                type: Input
            }], displayedColumns: [{
                type: Input
            }] });
})();

class SubscriptionDetailsComponent {
    constructor(subscription, sidesheetRef, busyService, confirmation) {
        this.subscription = subscription;
        this.sidesheetRef = sidesheetRef;
        this.busyService = busyService;
        this.confirmation = confirmation;
        this.formGroup = new UntypedFormGroup({});
        this.reload = false;
        this.closeClickSubscription = this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
            if (!this.formGroup.dirty
                || (yield this.confirmation.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close(this.reload);
            }
        }));
    }
    ngOnDestroy() {
        this.closeClickSubscription.unsubscribe();
    }
    submit() {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => overlayRef = this.busyService.show());
            try {
                yield this.subscription.submit(true);
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
                this.reload = true;
                this.formGroup.markAsPristine();
            }
        });
    }
}
SubscriptionDetailsComponent.ɵfac = function SubscriptionDetailsComponent_Factory(t) { return new (t || SubscriptionDetailsComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i1.ConfirmationService)); };
SubscriptionDetailsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionDetailsComponent, selectors: [["ng-component"]], decls: 8, vars: 7, consts: [["eui-sidesheet-content", ""], [3, "formGroup"], [3, "formGroup", "subscription"], ["eui-sidesheet-actions", ""], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "subscription-details-button-save", 3, "disabled", "click"]], template: function SubscriptionDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "form", 1);
            i0.ɵɵelement(3, "imx-subscription-properties", 2);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(4, "div", 3)(5, "button", 4);
            i0.ɵɵlistener("click", function SubscriptionDetailsComponent_Template_button_click_5_listener() { return ctx.submit(); });
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.formGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("formGroup", ctx.formGroup)("subscription", ctx.subscription);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.formGroup.dirty || ctx.formGroup.invalid);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 5, "#LDS#Save"), " ");
        }
    }, dependencies: [i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i4$1.MatButton, i9.MatCard, i10.ɵNgNoValidate, i10.NgControlStatusGroup, i10.FormGroupDirective, SubscriptionPropertiesComponent, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;max-height:100%}.button-row[_ngcontent-%COMP%]{border-top-style:solid;border-top-width:0px;display:flex;flex-direction:row;justify-content:flex-end;padding:16px 8px 16px 24px}.button-row[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{margin-left:10px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionDetailsComponent, [{
            type: Component,
            args: [{ template: "<div eui-sidesheet-content>\r\n  <mat-card>\r\n    <form [formGroup]=\"formGroup\">\r\n      <imx-subscription-properties [formGroup]=\"formGroup\" [subscription]=\"subscription\"></imx-subscription-properties>\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n\r\n<div eui-sidesheet-actions>\r\n  <button mat-raised-button color=\"primary\" [disabled]=\"!formGroup.dirty || formGroup.invalid\" data-imx-identifier=\"subscription-details-button-save\" (click)=\"submit()\">\r\n    {{ '#LDS#Save' | translate }}\r\n  </button>\r\n</div>\r\n", styles: [":host{display:flex;flex-direction:column;max-height:100%}.button-row{border-top-style:solid;border-top-width:0px;display:flex;flex-direction:row;justify-content:flex-end;padding:16px 8px 16px 24px}.button-row>*{margin-left:10px}\n"] }]
        }], function () {
        return [{ type: ReportSubscription, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i1$1.EuiSidesheetRef }, { type: i1$1.EuiLoadingService }, { type: i1.ConfirmationService }];
    }, null);
})();

function SubscriptionOverviewComponent_div_0_div_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 5)(1, "eui-alert", 6)(2, "eui-alert-header", 7);
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("dismissable", true);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 2, "#LDS#You cannot receive the report. You have not specified an email address. Please add an email address to your user account."), " ");
    }
}
function SubscriptionOverviewComponent_div_0_div_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 5)(1, "eui-alert", 8)(2, "eui-alert-header", 7);
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "eui-alert-content");
        i0.ɵɵtext(6);
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("dismissable", true);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 3, "#LDS#The following subscribers cannot receive the report. No email addresses have been specified for the user accounts of these subscribers."), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", ctx_r3.additionalRecipientWithoutEmail.join("; "), " ");
    }
}
function SubscriptionOverviewComponent_div_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div")(1, "div", 2);
        i0.ɵɵelement(2, "imx-property-viewer", 3);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(3, SubscriptionOverviewComponent_div_0_div_3_Template, 5, 4, "div", 4);
        i0.ɵɵtemplate(4, SubscriptionOverviewComponent_div_0_div_4_Template, 7, 5, "div", 4);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("properties", ctx_r0.setProperties);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.userIsMissingEMail);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.additionalRecipientWithoutEmail.length > 0);
    }
}
function SubscriptionOverviewComponent_div_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 9);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#The overview is calculated. Please wait."), "\n");
    }
}
class SubscriptionOverviewComponent {
    constructor(multiValue, busyService, personService, authentication) {
        this.multiValue = multiValue;
        this.busyService = busyService;
        this.personService = personService;
        this.userIsMissingEMail = false;
        this.additionalRecipientWithoutEmail = [];
        this.setProperties = [];
        authentication.onSessionResponse.subscribe(state => this.currentUserId = state.UserUid);
    }
    ngOnInit() {
        if (this.subscribersChanged) {
            this.subscribersChanged.subscribe(() => __awaiter(this, void 0, void 0, function* () {
                if (this.subscription != null) {
                    this.setProperties = this.subscription.getDisplayableColums();
                }
                yield this.checkEmailAddresses();
            }));
        }
    }
    ngOnDestroy() {
        if (this.subscribersChanged) {
            this.subscribersChanged.unsubscribe();
        }
    }
    checkEmailAddresses() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.subscription == null) {
                return;
            }
            let overlayRef;
            setTimeout(() => overlayRef = this.busyService.show());
            try {
                this.userIsMissingEMail = (yield this.getPersonNameAndAddress(this.currentUserId)).address === '';
                const subscribers = this.multiValue.getValues(this.subscription.subscription.AddtlSubscribers.value);
                const subscriberMails = [];
                for (const value of subscribers) {
                    const mail = yield this.getPersonNameAndAddress(value);
                    subscriberMails.push(mail);
                }
                this.additionalRecipientWithoutEmail = subscriberMails
                    .filter(elem => elem.address == null || elem.address === '').map(elem => elem.name);
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
        });
    }
    getPersonNameAndAddress(uid) {
        return __awaiter(this, void 0, void 0, function* () {
            const user = yield this.personService.get(uid);
            return user.Data.length > 0 ? {
                name: user.Data[0].GetEntity().GetDisplay(),
                address: user.Data[0].DefaultEmailAddress.value
            } : null;
        });
    }
}
SubscriptionOverviewComponent.ɵfac = function SubscriptionOverviewComponent_Factory(t) { return new (t || SubscriptionOverviewComponent)(i0.ɵɵdirectiveInject(i1.MultiValueService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i5.PersonService), i0.ɵɵdirectiveInject(i1.AuthenticationService)); };
SubscriptionOverviewComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionOverviewComponent, selectors: [["imx-subscription-overview"]], inputs: { subscription: "subscription", subscribersChanged: "subscribersChanged", isWaitingForLoad: "isWaitingForLoad" }, decls: 2, vars: 2, consts: [[4, "ngIf"], ["class", "imx-wait-for-overview-load", 4, "ngIf"], [1, "imx-report-table"], [3, "properties"], ["class", "imx-overview-alert", 4, "ngIf"], [1, "imx-overview-alert"], ["type", "warning", "data-imx-identifier", "subscription-overview-alert-no-mail", 1, "mat-elevation-z0", 3, "dismissable"], [1, "mat-elevation-z0"], ["type", "warning", "data-imx-identifier", "subscription-overview-alert-no-mail-for-subscribers", 1, "mat-elevation-z0", 3, "dismissable"], [1, "imx-wait-for-overview-load"]], template: function SubscriptionOverviewComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, SubscriptionOverviewComponent_div_0_Template, 5, 3, "div", 0);
            i0.ɵɵtemplate(1, SubscriptionOverviewComponent_div_1_Template, 3, 3, "div", 1);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", !ctx.isWaitingForLoad);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.isWaitingForLoad);
        }
    }, dependencies: [i1.PropertyViewerComponent, i3$1.NgIf, i1$1.EuiAlertComponent, i1$1.EuiAlertContentDirective, i1$1.EuiAlertHeaderDirective, i3$2.TranslatePipe], styles: [".imx-report-table[_ngcontent-%COMP%]{display:flex;margin-top:10px}.imx-user-warning[_ngcontent-%COMP%]{color:#e36a00}imx-property-viewer[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.imx-overview-alert[_ngcontent-%COMP%], .imx-wait-for-overview-load[_ngcontent-%COMP%]{margin:10px 0}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionOverviewComponent, [{
            type: Component,
            args: [{ selector: 'imx-subscription-overview', template: "<div *ngIf=\"!isWaitingForLoad\">\r\n  <div class=\"imx-report-table\">\r\n    <imx-property-viewer [properties]=\"setProperties\"></imx-property-viewer>\r\n  </div>\r\n  <div *ngIf=\"userIsMissingEMail\" class=\"imx-overview-alert\">\r\n    <eui-alert [dismissable]=\"true\" type=\"warning\" class=\"mat-elevation-z0\"\r\n      data-imx-identifier=\"subscription-overview-alert-no-mail\">\r\n      <eui-alert-header class=\"mat-elevation-z0\">\r\n        {{'#LDS#You cannot receive the report. You have not specified an email address. Please add an email address to your user account.' |\r\n        translate}}\r\n      </eui-alert-header>\r\n    </eui-alert>\r\n  </div>\r\n  <div *ngIf=\"additionalRecipientWithoutEmail.length >0\" class=\"imx-overview-alert\">\r\n    <eui-alert [dismissable]=\"true\" type=\"warning\" class=\"mat-elevation-z0\"\r\n      data-imx-identifier=\"subscription-overview-alert-no-mail-for-subscribers\">\r\n    <eui-alert-header class=\"mat-elevation-z0\">\r\n      {{'#LDS#The following subscribers cannot receive the report. No email addresses have been specified for the user accounts of these subscribers.' |translate}}\r\n    </eui-alert-header>\r\n    <eui-alert-content>\r\n      {{additionalRecipientWithoutEmail.join('; ')}}\r\n    </eui-alert-content>\r\n    </eui-alert>\r\n  </div>\r\n</div>\r\n<div *ngIf=\"isWaitingForLoad\" class=\"imx-wait-for-overview-load\">\r\n  {{'#LDS#The overview is calculated. Please wait.' | translate}}\r\n</div>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.imx-report-table{display:flex;margin-top:10px}.imx-user-warning{color:#e36a00}imx-property-viewer{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.imx-overview-alert,.imx-wait-for-overview-load{margin:10px 0}\n"] }]
        }], function () { return [{ type: i1.MultiValueService }, { type: i1$1.EuiLoadingService }, { type: i5.PersonService }, { type: i1.AuthenticationService }]; }, { subscription: [{
                type: Input
            }], subscribersChanged: [{
                type: Input
            }], isWaitingForLoad: [{
                type: Input
            }] });
})();

const _c0$3 = function () { return ["search", "filter", "sort", "settings"]; };
/**
 * A component, that displays the data of a list report
 *
 * Example:
 * code behind:
 *          dataService:ListReportDataProvider = {...};
 *          reportParameter:{ [key: string]: any } = {...};
 * html:
 *          <imx-list-report-viewer [dataService]="dataService" [reportParameter]="reportParameter"></imx-list-report-viewer>
 */
class ListReportViewerComponent {
    constructor(logger) {
        this.logger = logger;
        this.busyService = new BusyService();
        this.navigationState = {};
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                yield this.initData();
                yield this.navigate();
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    /**
     * Updates the search parameter and navigates
     * @param key: the keyword, that should be searched for
     */
    onSearch(key) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState = Object.assign(Object.assign({}, this.navigationState), { StartIndex: 0, search: key });
            return this.navigate();
        });
    }
    /**
     * Updates the navigation state and navigates
     * @param newState: the new navigation state
     */
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState = newState;
            return this.navigate();
        });
    }
    /**
     * Is called, if the grouping changed.
     * Updates the grouping navigation state and navigates
     * @param groupKey the gouping keyword
     */
    onGroupingChange(groupInfo) {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const groupedData = this.groupData[groupInfo.key];
                const navigationState = Object.assign({}, groupedData.navigationState);
                groupedData.data = groupInfo.isInitial ? { totalCount: 0, Data: [] } : yield this.dataService.get(navigationState);
                groupedData.settings = {
                    displayedColumns: this.dstSettings.displayedColumns,
                    dataModel: this.dstSettings.dataModel,
                    dataSource: groupedData.data,
                    entitySchema: this.dstSettings.entitySchema,
                    navigationState,
                };
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    /**
     * navigates the list report data
     */
    navigate() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const data = yield this.dataService.get(Object.assign({}, this.navigationState));
                //Apply new schema to data
                data.Data.forEach((elem) => elem.GetEntity().ApplySchema(this.entitySchema));
                const displayedColumns = this.reportColumns.map((elem) => this.entitySchema.Columns[elem]).filter((elem) => !!elem);
                if (displayedColumns.length === 0) {
                    displayedColumns.push(DisplayColumns.DISPLAY_PROPERTY);
                    this.logger.warn(this, 'There was a problem, loading the columns. The displays of the objects will be shown instead');
                }
                let exportMethod;
                if (this.dataService.exportReports) {
                    exportMethod = this.dataService.exportReports(this.navigationState);
                    exportMethod.initialColumns = displayedColumns.map((col) => col.ColumnName);
                }
                this.dstSettings = {
                    dataSource: data,
                    entitySchema: this.entitySchema,
                    navigationState: this.navigationState,
                    displayedColumns,
                    dataModel: this.dataModel,
                    groupData: this.groupData,
                    filters: this.dataModel.Filters,
                    exportMethod,
                };
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    /**
     * Initializes the data, that is used for the view
     */
    initData() {
        return __awaiter(this, void 0, void 0, function* () {
            this.dataModel = yield this.dataService.getDataModel();
            const data = yield this.dataService.get({ PageSize: -1 });
            this.reportColumns = data.extendedData.Columns;
            // create a copy of listReportSchema and add additional columns to it (because the schema only provides the display at this point) and update the TypeName property
            this.entitySchema = Object.assign(Object.assign({}, this.dataService.entitySchema), { TypeName: data.tableName });
            for (const column of this.reportColumns) {
                this.entitySchema.Columns[column] = data.extendedData.AdditionalProperties.find((elem) => elem.ColumnName === column);
            }
            this.navigationState = Object.assign({}, this.navigationState);
            if (this.reportParameter) {
                this.navigationState.parameters = this.reportParameter;
            }
            this.groupData = createGroupData(this.dataModel, (parameters) => this.dataService.getGroupInfo(Object.assign({
                PageSize: this.navigationState.PageSize,
                StartIndex: 0,
            }, parameters)), []);
        });
    }
}
ListReportViewerComponent.ɵfac = function ListReportViewerComponent_Factory(t) { return new (t || ListReportViewerComponent)(i0.ɵɵdirectiveInject(i1.ClassloggerService)); };
ListReportViewerComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ListReportViewerComponent, selectors: [["imx-list-report-viewer"]], inputs: { dataService: "dataService", reportParameter: "reportParameter" }, decls: 6, vars: 7, consts: [[1, "imx-table-container"], ["data-imx-identifier", "list-report-viewer-toolbar", 3, "settings", "busyService", "options", "search", "navigationStateChanged"], ["dst", ""], ["detailViewVisible", "false", "mode", "auto", "data-imx-identifier", "list-report-viewer-table", 3, "dst", "groupData", "groupDataChanged"], ["data-imx-identifier", "list-report-viewer-paginator", 3, "dst"]], template: function ListReportViewerComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "div", 0)(2, "imx-data-source-toolbar", 1, 2);
            i0.ɵɵlistener("search", function ListReportViewerComponent_Template_imx_data_source_toolbar_search_2_listener($event) { return ctx.onSearch($event); })("navigationStateChanged", function ListReportViewerComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { return ctx.onNavigationStateChanged($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "imx-data-table", 3);
            i0.ɵɵlistener("groupDataChanged", function ListReportViewerComponent_Template_imx_data_table_groupDataChanged_4_listener($event) { return ctx.onGroupingChange($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelement(5, "imx-data-source-paginator", 4);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(3);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("settings", ctx.dstSettings)("busyService", ctx.busyService)("options", i0.ɵɵpureFunction0(6, _c0$3));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0)("groupData", ctx.groupData);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i9.MatCard, i1.DataSourceToolbarComponent, i1.DataSourcePaginatorComponent, i1.DataTableComponent], styles: ["[_nghost-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .mat-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:3px}[_nghost-%COMP%]   .imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListReportViewerComponent, [{
            type: Component,
            args: [{ selector: 'imx-list-report-viewer', template: "<mat-card>\r\n  <div class=\"imx-table-container\">\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      [settings]=\"dstSettings\"\r\n      [busyService]=\"busyService\"\r\n      data-imx-identifier=\"list-report-viewer-toolbar\"\r\n      [options]=\"['search', 'filter', 'sort', 'settings']\"\r\n      (search)=\"onSearch($event)\"\r\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n\r\n    <imx-data-table\r\n      [dst]=\"dst\"\r\n      detailViewVisible=\"false\"\r\n      mode=\"auto\"\r\n      data-imx-identifier=\"list-report-viewer-table\"\r\n      [groupData]=\"groupData\"\r\n      (groupDataChanged)=\"onGroupingChange($event)\"\r\n    >\r\n    </imx-data-table>\r\n    <imx-data-source-paginator data-imx-identifier=\"list-report-viewer-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\r\n  </div>\r\n</mat-card>\r\n", styles: [":host{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}:host .mat-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:3px}:host .imx-table-container{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}\n"] }]
        }], function () { return [{ type: i1.ClassloggerService }]; }, { dataService: [{
                type: Input
            }], reportParameter: [{
                type: Input
            }] });
})();

function ListReportViewerSidesheetComponent_div_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r2 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 3)(1, "button", 4);
        i0.ɵɵlistener("click", function ListReportViewerSidesheetComponent_div_2_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r2); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.downloadReport()); });
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 1, "#LDS#Download report"), " ");
    }
}
/**
 * Represents the content of a side sheet, that shows the data of a list report
 * Uses the following side sheet data:
 *  dataService:   a {@link ListReportDataProvider} that handles the api calls
 *  subscription:  an optional {@link ReportSubscription}
 */
class ListReportViewerSidesheetComponent {
    constructor(data, reportSubscriptionService) {
        this.data = data;
        this.reportSubscriptionService = reportSubscriptionService;
        if (data.subscription) {
            this.reportParameter = data.subscription.getParameterDictionary();
        }
    }
    /**
     * Downloads the subscription
     */
    downloadReport() {
        return __awaiter(this, void 0, void 0, function* () {
            this.reportSubscriptionService.downloadSubsciption(this.data.subscription);
        });
    }
}
ListReportViewerSidesheetComponent.ɵfac = function ListReportViewerSidesheetComponent_Factory(t) { return new (t || ListReportViewerSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(ReportSubscriptionService)); };
ListReportViewerSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ListReportViewerSidesheetComponent, selectors: [["imx-list-report-viewer-sidesheet"]], decls: 3, vars: 3, consts: [["eui-sidesheet-content", "", 1, "imx-flex-content"], [3, "dataService", "reportParameter"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["color", "primary", "mat-raised-button", "", "data-imx-identifier", "view-config-download-report-button", 3, "click"]], template: function ListReportViewerSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "imx-list-report-viewer", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(2, ListReportViewerSidesheetComponent_div_2_Template, 4, 3, "div", 2);
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dataService", ctx.data.dataService)("reportParameter", ctx.reportParameter);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.data.subscription);
        }
    }, dependencies: [i3$1.NgIf, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i4$1.MatButton, ListReportViewerComponent, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .imx-flex-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListReportViewerSidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-list-report-viewer-sidesheet', template: "<div eui-sidesheet-content class=\"imx-flex-content\">\r\n<imx-list-report-viewer [dataService]=\"data.dataService\" [reportParameter]=\"reportParameter\"></imx-list-report-viewer>\r\n</div>\r\n<div eui-sidesheet-actions *ngIf=\"data.subscription\">\r\n  <button color=\"primary\" mat-raised-button (click)=\"downloadReport()\" data-imx-identifier=\"view-config-download-report-button\">\r\n    {{ '#LDS#Download report' | translate }}\r\n  </button>\r\n</div>", styles: [":host{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}:host .imx-flex-content{display:flex;flex-direction:column}\n"] }]
        }], function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: ReportSubscriptionService }];
    }, null);
})();

/**
 * Implements a {@link ListReportDataProvider} to get the list report data for a given report id
 */
class ListReportViewerService {
    constructor(api) {
        this.api = api;
    }
    /**
     * Sets the uid of the report used by this service
     * @param value the uid of a list report
     */
    setUidReport(value) {
        this.uidReport = value;
    }
    get entitySchema() {
        return this.api.typedClient.PortalReportData.GetSchema();
    }
    getDataModel() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.uidReport) {
                throw 'setUidReport(...) has to be called with a valid uid';
            }
            return this.api.client.portal_report_data_datamodel_get(this.uidReport);
        });
    }
    get(parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.uidReport) {
                throw 'setUidReport(...) has to be called with a valid uid';
            }
            return this.api.typedClient.PortalReportData.Get(this.uidReport, parameter);
        });
    }
    getGroupInfo(parameters = {}) {
        if (!this.uidReport) {
            throw 'setUidReport(...) has to be called with a valid uid';
        }
        const { withProperties, OrderBy, search } = parameters, params = __rest(parameters, ["withProperties", "OrderBy", "search"]);
        return this.api.client.portal_report_data_group_get(this.uidReport, Object.assign({}, params));
    }
    exportReports(parameters) {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_report_data_get(this.uidReport, Object.assign(Object.assign({}, parameters), { withProperties, PageSize, StartIndex: 0 }));
                }
                else {
                    method = factory.portal_report_data_get(this.uidReport, Object.assign(Object.assign({}, parameters), { withProperties }));
                }
                return new MethodDefinition(method);
            },
        };
    }
}
ListReportViewerService.ɵfac = function ListReportViewerService_Factory(t) { return new (t || ListReportViewerService)(i0.ɵɵinject(RpsApiService)); };
ListReportViewerService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ListReportViewerService, factory: ListReportViewerService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListReportViewerService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: RpsApiService }]; }, null);
})();

function ReportViewConfigComponent_mat_card_5_imx_busy_indicator_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-busy-indicator");
    }
}
function ReportViewConfigComponent_mat_card_5_div_2_mat_radio_group_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-radio-group", 18)(1, "mat-radio-button", 19);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "mat-radio-button", 20);
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("value", "view");
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 4, "#LDS#View in browser"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("value", "export");
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 6, "#LDS#Export"), " ");
    }
}
function ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r8 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 21);
        i0.ɵɵlistener("controlCreated", function ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r7 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r7.reportFormGroup.controls.exportType = $event); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext(3);
        i0.ɵɵproperty("cdr", ctx_r4.formatCdr);
    }
}
function ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r11 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 21);
        i0.ɵɵlistener("controlCreated", function ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_4_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r10.addFormControl($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r9 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r9);
    }
}
function ReportViewConfigComponent_mat_card_5_div_2_div_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 22);
        i0.ɵɵelement(1, "eui-icon", 7);
        i0.ɵɵelementStart(2, "p", 8);
        i0.ɵɵtext(3, "#LDS#For this report, no parameters must be specified.");
        i0.ɵɵelementEnd()();
    }
}
function ReportViewConfigComponent_mat_card_5_div_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 12)(1, "div", 13);
        i0.ɵɵtemplate(2, ReportViewConfigComponent_mat_card_5_div_2_mat_radio_group_2_Template, 7, 8, "mat-radio-group", 14);
        i0.ɵɵtemplate(3, ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_3_Template, 1, 1, "imx-cdr-editor", 15);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(4, ReportViewConfigComponent_mat_card_5_div_2_imx_cdr_editor_4_Template, 1, 1, "imx-cdr-editor", 16);
        i0.ɵɵtemplate(5, ReportViewConfigComponent_mat_card_5_div_2_div_5_Template, 4, 0, "div", 17);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r2.isListReport);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r2.formatCdr && (ctx_r2.reportFormGroup.controls.viewType.value === "export" || !ctx_r2.isListReport));
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r2.parameterCdrList);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r2.hasParameter);
    }
}
function ReportViewConfigComponent_mat_card_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 9);
        i0.ɵɵtemplate(1, ReportViewConfigComponent_mat_card_5_imx_busy_indicator_1_Template, 1, 0, "imx-busy-indicator", 10);
        i0.ɵɵtemplate(2, ReportViewConfigComponent_mat_card_5_div_2_Template, 6, 4, "div", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.isLoading);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r0.isLoading);
    }
}
class ReportViewConfigComponent {
    constructor(sidesheetRef, sideSheet, reportSubscriptionService, cdref, translate, viewReportService, errorService) {
        this.sidesheetRef = sidesheetRef;
        this.sideSheet = sideSheet;
        this.reportSubscriptionService = reportSubscriptionService;
        this.cdref = cdref;
        this.translate = translate;
        this.viewReportService = viewReportService;
        this.reportFormGroup = new FormGroup({
            viewType: new FormControl('view'),
            reportTable: new FormControl(undefined, Validators.required),
            exportType: new FormControl(undefined),
            parameters: new FormArray([]),
        });
        this.parameterCdrList = [];
        this.busyService = new BusyService();
        this.isLoading = false;
        this.reportIsLoaded = false;
        this.isListReport = false;
        this.uidReport = '';
        this.subscriptions = [];
        this.subscriptions.push(this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
            this.sidesheetRef.close(false);
        })));
        this.subscriptions.push(this.busyService.busyStateChanged.subscribe((elem) => {
            this.isLoading = elem;
            this.cdref.detectChanges();
        }));
        this.subscriptions.push(this.reportFormGroup.controls.reportTable.valueChanges.subscribe((val) => __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                this.uidReport = val;
                this.formControls.clear();
                // Standard caption is "Format (e-mail attachment)" -> change
                const format = yield this.translate.get('#LDS#Format').toPromise();
                if (val) {
                    this.newSubscription = yield this.reportSubscriptionService.createNewSubscription(this.uidReport);
                    this.isListReport = this.newSubscription.subscription.IsListReport.value;
                    // Set PDF as default, but only if the report supports PDF
                    const xformat = this.newSubscription.subscription.ExportFormat;
                    const allowedFormats = xformat.Column.GetMetadata().GetLimitedValues();
                    if (allowedFormats && allowedFormats.filter((f) => f.Value == 'PDF').length > 0) {
                        xformat.value = 'PDF';
                    }
                    this.formatCdr = new BaseCdr(this.newSubscription.subscription.ExportFormat.Column, format);
                    this.parameterCdrList = [...this.newSubscription.getParameterCdr()];
                    this.cdref.detectChanges();
                }
                else
                    this.newSubscription = null;
            }
            finally {
                isBusy.endBusy();
                this.reportIsLoaded = this.newSubscription != null;
            }
        })));
        this.disposable = errorService.setTarget('sidesheet');
    }
    get formControls() {
        return this.reportFormGroup.controls.parameters;
    }
    get hasParameter() {
        return this.reportFormGroup.controls.viewType.value === 'view' && this.isListReport
            ? this.parameterCdrList.filter((elem) => elem.column.ColumnName !== 'ExportFormat').length > 0
            : this.parameterCdrList.length > 0;
    }
    ngOnDestroy() {
        // sometimes there are problems with usage of disposed components
        setTimeout(() => {
            var _a;
            this.disposable();
            this.subscriptions.forEach((sub) => sub.unsubscribe());
            (_a = this.newSubscription) === null || _a === void 0 ? void 0 : _a.unsubscribeEvents();
        });
    }
    viewReport() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.reportFormGroup.controls.viewType.value === 'view' && this.isListReport) {
                yield this.viewReportInTable();
            }
            else {
                this.reportSubscriptionService.downloadSubsciption(this.newSubscription);
            }
        });
    }
    addFormControl(control) {
        this.formControls.push(control);
        this.cdref.detectChanges();
    }
    viewReportInTable() {
        return __awaiter(this, void 0, void 0, function* () {
            this.viewReportService.setUidReport(this.uidReport);
            const data = { dataService: this.viewReportService, subscription: this.newSubscription };
            this.sideSheet.open(ListReportViewerSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Report').toPromise(),
                subTitle: this.newSubscription.subscription.GetEntity().GetDisplay(),
                padding: '0',
                width: 'max(550px,55%)',
                testId: 'report-view-config-report-viewer',
                data,
            });
        });
    }
}
ReportViewConfigComponent.ɵfac = function ReportViewConfigComponent_Factory(t) { return new (t || ReportViewConfigComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(ListReportViewerService), i0.ɵɵdirectiveInject(i1.ErrorService)); };
ReportViewConfigComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportViewConfigComponent, selectors: [["imx-report-view-config"]], decls: 11, vars: 5, consts: [["eui-sidesheet-content", "", 1, "imx-flex-content"], ["panelClass", "imx-small-message", 1, "errormessages", 3, "target"], [1, "imx-report-form", 3, "formGroup"], ["formControlName", "reportTable", 3, "controlHeigth"], ["class", "imx-flex-card", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["color", "primary", "mat-raised-button", "", "data-imx-identifier", "view-config-view-report-button", 3, "disabled", "click"], ["icon", "reports"], ["translate", ""], [1, "imx-flex-card"], [4, "ngIf"], ["class", "imx-cdr-container", 4, "ngIf"], [1, "imx-cdr-container"], [1, "imx-export-type"], ["formControlName", "viewType", 4, "ngIf"], [3, "cdr", "controlCreated", 4, "ngIf"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["class", "imx-no-results", 4, "ngIf"], ["formControlName", "viewType"], ["data-imx-identifier", "export-view-config-view-in-browser", 3, "value"], ["data-imx-identifier", "export-view-config-export", 3, "value"], [3, "cdr", "controlCreated"], [1, "imx-no-results"]], template: function ReportViewConfigComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵelement(1, "imx-usermessage", 1);
            i0.ɵɵelementStart(2, "form", 2)(3, "mat-card");
            i0.ɵɵelement(4, "imx-report-selector", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(5, ReportViewConfigComponent_mat_card_5_Template, 3, 2, "mat-card", 4);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "div", 5)(7, "button", 6);
            i0.ɵɵlistener("click", function ReportViewConfigComponent_Template_button_click_7_listener() { return ctx.viewReport(); });
            i0.ɵɵelement(8, "eui-icon", 7);
            i0.ɵɵelementStart(9, "span", 8);
            i0.ɵɵtext(10, "#LDS#View report");
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("target", "sidesheet");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("formGroup", ctx.reportFormGroup);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("controlHeigth", 400);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.reportFormGroup.controls.reportTable.value);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.reportFormGroup.invalid || ctx.isLoading);
        }
    }, dependencies: [i1.CdrEditorComponent, i3$1.NgForOf, i3$1.NgIf, i1$1.EuiIconComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i4$1.MatButton, i9.MatCard, i9$1.MatRadioGroup, i9$1.MatRadioButton, i10.ɵNgNoValidate, i10.NgControlStatus, i10.NgControlStatusGroup, i10.FormGroupDirective, i10.FormControlName, i3$2.TranslateDirective, i1.UserMessageComponent, i1.BusyIndicatorComponent, ReportSelectorComponent, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   imx-usermessage[_ngcontent-%COMP%]{margin-bottom:16px}[_nghost-%COMP%]   .imx-flex-card[_ngcontent-%COMP%], [_nghost-%COMP%]   .imx-flex-content[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]   .imx-export-type[_ngcontent-%COMP%]{display:flex;flex-direction:row}[_nghost-%COMP%]   .imx-export-type[_ngcontent-%COMP%]   imx-cdr-editor[_ngcontent-%COMP%]{flex:1 1 auto}[_nghost-%COMP%]   .mat-card[_ngcontent-%COMP%]{margin:3px}[_nghost-%COMP%]   .imx-flex-card[_ngcontent-%COMP%]{margin-top:20px;overflow:hidden}@media only screen and (max-height: 870px){[_nghost-%COMP%]   .imx-flex-card[_ngcontent-%COMP%]{overflow:visible}}[_nghost-%COMP%]   .mat-radio-group[_ngcontent-%COMP%]{margin-bottom:10px}[_nghost-%COMP%]   .mat-radio-group[_ngcontent-%COMP%] > .mat-radio-button[_ngcontent-%COMP%]{margin-right:10px}[_nghost-%COMP%]   .imx-report-form[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;overflow-x:hidden}[_nghost-%COMP%]   .imx-report-form[_ngcontent-%COMP%]   imx-report-selector[_ngcontent-%COMP%]{flex:0 0 auto}[_nghost-%COMP%]   .imx-report-form[_ngcontent-%COMP%]   .imx-cdr-container[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}[_nghost-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}[_nghost-%COMP%]   .hidden[_ngcontent-%COMP%]{display:none}[_nghost-%COMP%]   .imx-report-alert[_ngcontent-%COMP%]{margin-top:20px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]{text-align:center;display:flex;margin:20px 0;flex-direction:column;flex:1 1 auto;align-items:center;justify-content:center}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:100px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:18px}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}[_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#919799}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{color:#dfe4e6}.eui-contrast-theme   [_nghost-%COMP%]   .imx-no-results[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#fff}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportViewConfigComponent, [{
            type: Component,
            args: [{ selector: 'imx-report-view-config', template: "<div eui-sidesheet-content class=\"imx-flex-content\">\r\n  <!-- report generation errors should appear here -->\r\n  <imx-usermessage class=\"errormessages\" panelClass=\"imx-small-message\" [target]=\"'sidesheet'\"></imx-usermessage>\r\n\r\n  <form [formGroup]=\"reportFormGroup\" class=\"imx-report-form\">\r\n    <mat-card>\r\n      <imx-report-selector [controlHeigth]=\"400\" formControlName=\"reportTable\"></imx-report-selector>\r\n    </mat-card>\r\n    <mat-card *ngIf=\"reportFormGroup.controls.reportTable.value\" class=\"imx-flex-card\">\r\n      <imx-busy-indicator *ngIf=\"isLoading\"></imx-busy-indicator>\r\n\r\n      <div class=\"imx-cdr-container\" *ngIf=\"!isLoading\">\r\n        <div class=\"imx-export-type\">\r\n          <mat-radio-group formControlName=\"viewType\" *ngIf=\"isListReport\">\r\n            <mat-radio-button [value]=\"'view'\" data-imx-identifier=\"export-view-config-view-in-browser\">\r\n              {{ '#LDS#View in browser' | translate }}\r\n            </mat-radio-button>\r\n            <mat-radio-button [value]=\"'export'\" data-imx-identifier=\"export-view-config-export\">\r\n              {{ '#LDS#Export' | translate }}\r\n            </mat-radio-button>\r\n          </mat-radio-group>\r\n          <imx-cdr-editor\r\n            *ngIf=\"formatCdr && (reportFormGroup.controls.viewType.value === 'export' || !isListReport)\"\r\n            [cdr]=\"formatCdr\"\r\n            (controlCreated)=\"reportFormGroup.controls.exportType = $event\"\r\n          >\r\n          </imx-cdr-editor>\r\n        </div>\r\n        <imx-cdr-editor *ngFor=\"let cdr of parameterCdrList\" [cdr]=\"cdr\" (controlCreated)=\"addFormControl($event)\"> </imx-cdr-editor>\r\n        <div class=\"imx-no-results\" *ngIf=\"!hasParameter\">\r\n          <eui-icon icon=\"reports\"></eui-icon>\r\n          <p translate>#LDS#For this report, no parameters must be specified.</p>\r\n        </div>\r\n      </div>\r\n    </mat-card>\r\n  </form>\r\n</div>\r\n\r\n<div eui-sidesheet-actions>\r\n  <button color=\"primary\" mat-raised-button (click)=\"viewReport()\" [disabled]=\"reportFormGroup.invalid || isLoading\" data-imx-identifier=\"view-config-view-report-button\">\r\n    <eui-icon icon=\"reports\"></eui-icon>\r\n    <span translate>#LDS#View report</span>\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}:host imx-usermessage{margin-bottom:16px}:host .imx-flex-card,:host .imx-flex-content{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}:host .imx-export-type{display:flex;flex-direction:row}:host .imx-export-type imx-cdr-editor{flex:1 1 auto}:host .mat-card{margin:3px}:host .imx-flex-card{margin-top:20px;overflow:hidden}@media only screen and (max-height: 870px){:host .imx-flex-card{overflow:visible}}:host .mat-radio-group{margin-bottom:10px}:host .mat-radio-group>.mat-radio-button{margin-right:10px}:host .imx-report-form{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;overflow-x:hidden}:host .imx-report-form imx-report-selector{flex:0 0 auto}:host .imx-report-form .imx-cdr-container{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}:host .justify-start{margin-right:auto}:host .hidden{display:none}:host .imx-report-alert{margin-top:20px}:host .imx-no-results{text-align:center;display:flex;margin:20px 0;flex-direction:column;flex:1 1 auto;align-items:center;justify-content:center}:host .imx-no-results .eui-icon{font-size:100px}:host .imx-no-results p{margin:0;font-size:18px}:host .imx-no-results .eui-icon{color:#dfe4e6}:host .imx-no-results p{color:#919799}.eui-dark-theme :host .imx-no-results .eui-icon{color:#c4cacc}.eui-dark-theme :host .imx-no-results p{color:#dfe4e6}.eui-contrast-theme :host .imx-no-results .eui-icon{color:#dfe4e6}.eui-contrast-theme :host .imx-no-results p{color:#fff}\n"] }]
        }], function () { return [{ type: i1$1.EuiSidesheetRef }, { type: i1$1.EuiSidesheetService }, { type: ReportSubscriptionService }, { type: i0.ChangeDetectorRef }, { type: i3$2.TranslateService }, { type: ListReportViewerService }, { type: i1.ErrorService }]; }, null);
})();

const _c0$2 = ["additionalApprover"];
function SubscriptionWizardComponent_ng_template_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(1, 1, "#LDS#Select report"));
    }
}
function SubscriptionWizardComponent_ng_template_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(1, 1, "#LDS#Configure subscription"));
    }
}
function SubscriptionWizardComponent_ng_template_25_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(1, 1, "#LDS#Add additional subscribers"));
    }
}
function SubscriptionWizardComponent_ng_template_40_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(1, 1, "#LDS#Check and create subscription"));
    }
}
class SubscriptionWizardComponent {
    constructor(sidesheetRef, reportSubscriptionService, confirmation, busyService) {
        this.sidesheetRef = sidesheetRef;
        this.reportSubscriptionService = reportSubscriptionService;
        this.confirmation = confirmation;
        this.busyService = busyService;
        this.reportFormGroup = new UntypedFormGroup({
            reportTable: new UntypedFormControl(undefined, Validators.required)
        });
        this.reportParameterFormGroup = new UntypedFormGroup({});
        this.additionalSubscribersFormGroup = new UntypedFormGroup({
            additionalSubscribers: new UntypedFormControl(undefined)
        });
        this.isLoadingOverview = false;
        this.subscribersChangedSubject = new BehaviorSubject(undefined);
        this.entitySchema = reportSubscriptionService.PortalSubscriptionInteractiveSchema;
        this.columnsForEdit = [
            this.entitySchema.Columns.Ident_RPSSubscription,
            this.entitySchema.Columns.UID_DialogSchedule,
            this.entitySchema.Columns.ExportFormat,
        ];
        this.closeClickSubscription = this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
            if ((!this.reportFormGroup.dirty && !this.reportParameterFormGroup.dirty && !this.additionalSubscribersFormGroup.dirty)
                || (yield this.confirmation.confirmLeaveWithUnsavedChanges())) {
                this.sidesheetRef.close(false);
            }
        }));
    }
    ngOnDestroy() {
        this.closeClickSubscription.unsubscribe();
    }
    selectedStepChanged(event) {
        return __awaiter(this, void 0, void 0, function* () {
            if (event.selectedIndex === 1 && event.previouslySelectedIndex === 0) {
                let overlayRef;
                setTimeout(() => overlayRef = this.busyService.show());
                try {
                    this.newSubscription =
                        yield this.reportSubscriptionService.createNewSubscription(this.reportFormGroup.get('reportTable').value);
                    this.additionalSubscribersFormGroup.get('additionalSubscribers')
                        .setValue(this.newSubscription.subscription.AddtlSubscribers.Column);
                }
                finally {
                    setTimeout(() => this.busyService.hide(overlayRef));
                }
            }
            if (event.selectedIndex === 3) {
                this.isLoadingOverview = true;
                yield this.additional.pushValue();
                this.isLoadingOverview = false;
                this.subscribersChangedSubject.next();
            }
        });
    }
    submit() {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => overlayRef = this.busyService.show());
            try {
                yield this.newSubscription.submit();
                this.newSubscription.unsubscribeEvents();
                this.sidesheetRef.close(true);
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
        });
    }
}
SubscriptionWizardComponent.ɵfac = function SubscriptionWizardComponent_Factory(t) { return new (t || SubscriptionWizardComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService)); };
SubscriptionWizardComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionWizardComponent, selectors: [["imx-subscription-wizard"]], viewQuery: function SubscriptionWizardComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$2, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.additional = _t.first);
        }
    }, decls: 49, vars: 45, consts: [["orientation", "vertical", 3, "linear", "selectionChange"], ["stepper", ""], ["data-imx-identifier", "subscription-wizard-step-1-choose-report", 3, "stepControl"], [3, "formGroup"], ["matStepLabel", ""], [1, "imx-report-table"], ["formControlName", "reportTable", 3, "controlHeigth"], [1, "imx-step-button"], ["mat-stroked-button", "", "color", "primary", "matStepperNext", "", "data-imx-identifier", "subscription-wizard-nextTo-step-2", 3, "disabled"], ["data-imx-identifier", "subscription-wizard-step-2-edit-parameter", 3, "stepControl"], [1, "imx-subscription-properties"], [3, "displayedColumns", "withTitles", "formGroup", "subscription"], ["mat-stroked-button", "", "matStepperPrevious", "", "data-imx-identifier", "subscription-wizard-backtTo-step-1"], ["mat-stroked-button", "", "color", "primary", "matStepperNext", "", "data-imx-identifier", "subscription-wizard-nextTo-step-3", 3, "disabled"], ["data-imx-identifier", "subscription-wizard-step-3-add-subscribers", 3, "stepControl"], [1, "imx-wizard-info"], ["formControlName", "additionalSubscribers", 3, "pushMethod", "selectedElementsCaption"], ["additionalApprover", ""], ["mat-stroked-button", "", "matStepperPrevious", "", "data-imx-identifier", "subscription-wizard-backTo-step-2"], ["mat-stroked-button", "", "color", "primary", "matStepperNext", "", "data-imx-identifier", "subscription-wizard-nextTo-step-4"], ["data-imx-identifier", "subscription-wizard-step-4-overview"], [3, "isWaitingForLoad", "subscription", "subscribersChanged"], ["mat-stroked-button", "", "matStepperPrevious", "", "data-imx-identifier", "subscription-wizard-backTo-step-3"], ["color", "primary", "mat-stroked-button", "", "data-imx-identifier", "subscription-wizard-create-subscription", 3, "click"]], template: function SubscriptionWizardComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-stepper", 0, 1);
            i0.ɵɵlistener("selectionChange", function SubscriptionWizardComponent_Template_mat_stepper_selectionChange_0_listener($event) { return ctx.selectedStepChanged($event); });
            i0.ɵɵelementStart(2, "mat-step", 2)(3, "form", 3);
            i0.ɵɵtemplate(4, SubscriptionWizardComponent_ng_template_4_Template, 2, 3, "ng-template", 4);
            i0.ɵɵelementStart(5, "div", 5);
            i0.ɵɵelement(6, "imx-report-selector", 6);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 7)(8, "button", 8);
            i0.ɵɵtext(9);
            i0.ɵɵpipe(10, "translate");
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(11, "mat-step", 9)(12, "form", 3);
            i0.ɵɵtemplate(13, SubscriptionWizardComponent_ng_template_13_Template, 2, 3, "ng-template", 4);
            i0.ɵɵelementStart(14, "div", 10);
            i0.ɵɵelement(15, "imx-subscription-properties", 11);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(16, "div", 7)(17, "button", 12);
            i0.ɵɵtext(18);
            i0.ɵɵpipe(19, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(20, "button", 13);
            i0.ɵɵtext(21);
            i0.ɵɵpipe(22, "translate");
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(23, "mat-step", 14)(24, "form", 3);
            i0.ɵɵtemplate(25, SubscriptionWizardComponent_ng_template_25_Template, 2, 3, "ng-template", 4);
            i0.ɵɵelementStart(26, "div", 15);
            i0.ɵɵtext(27);
            i0.ɵɵpipe(28, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(29, "imx-multi-select-formcontrol", 16, 17);
            i0.ɵɵpipe(31, "translate");
            i0.ɵɵelementStart(32, "div", 7)(33, "button", 18);
            i0.ɵɵtext(34);
            i0.ɵɵpipe(35, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(36, "button", 19);
            i0.ɵɵtext(37);
            i0.ɵɵpipe(38, "translate");
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(39, "mat-step", 20);
            i0.ɵɵtemplate(40, SubscriptionWizardComponent_ng_template_40_Template, 2, 3, "ng-template", 4);
            i0.ɵɵelement(41, "imx-subscription-overview", 21);
            i0.ɵɵelementStart(42, "div", 7)(43, "button", 22);
            i0.ɵɵtext(44);
            i0.ɵɵpipe(45, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(46, "button", 23);
            i0.ɵɵlistener("click", function SubscriptionWizardComponent_Template_button_click_46_listener() { return ctx.submit(); });
            i0.ɵɵtext(47);
            i0.ɵɵpipe(48, "translate");
            i0.ɵɵelementEnd()()()();
        }
        if (rf & 2) {
            i0.ɵɵproperty("linear", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("stepControl", ctx.reportFormGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("formGroup", ctx.reportFormGroup);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("controlHeigth", 500);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.reportFormGroup.dirty);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(10, 27, "#LDS#Next"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("stepControl", ctx.reportParameterFormGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("formGroup", ctx.reportParameterFormGroup);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("displayedColumns", ctx.columnsForEdit)("withTitles", false)("formGroup", ctx.reportParameterFormGroup)("subscription", ctx.newSubscription);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(19, 29, "#LDS#Back"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.reportParameterFormGroup.invalid);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(22, 31, "#LDS#Next"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("stepControl", ctx.additionalSubscribersFormGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("formGroup", ctx.additionalSubscribersFormGroup);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(28, 33, "#LDS#Here you can select identities that should also receive these reports."), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("pushMethod", "manual")("selectedElementsCaption", i0.ɵɵpipeBind1(31, 35, "#LDS#Selected subscribers"));
            i0.ɵɵadvance(5);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(35, 37, "#LDS#Back"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(38, 39, "#LDS#Next"), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("isWaitingForLoad", ctx.isLoadingOverview)("subscription", ctx.newSubscription)("subscribersChanged", ctx.subscribersChangedSubject);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(45, 41, "#LDS#Back"), " ");
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(48, 43, "#LDS#Create"));
        }
    }, dependencies: [i4$1.MatButton, i5$2.MatStep, i5$2.MatStepLabel, i5$2.MatStepper, i5$2.MatStepperNext, i5$2.MatStepperPrevious, i10.ɵNgNoValidate, i10.NgControlStatus, i10.NgControlStatusGroup, i1.MultiSelectFormcontrolComponent, i10.FormGroupDirective, i10.FormControlName, ReportSelectorComponent, SubscriptionPropertiesComponent, SubscriptionOverviewComponent, i3$2.TranslatePipe], styles: [".imx-report-table[_ngcontent-%COMP%]{display:flex;margin-top:10px}.imx-subscription-properties[_ngcontent-%COMP%]{margin-top:20px}imx-property-viewer[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.imx-wizard-info[_ngcontent-%COMP%]{margin:30px 0}.imx-step-button[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:first-child{margin-right:10px}@media only screen and (max-width: 1024px){.imx-wizard-info[_ngcontent-%COMP%]{margin:0}}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionWizardComponent, [{
            type: Component,
            args: [{ selector: 'imx-subscription-wizard', template: "<mat-stepper orientation=\"vertical\" [linear]=\"true\" #stepper (selectionChange)=\"selectedStepChanged($event)\">\r\n  <mat-step [stepControl]=\"reportFormGroup\" data-imx-identifier=\"subscription-wizard-step-1-choose-report\">\r\n    <form [formGroup]=\"reportFormGroup\">\r\n      <ng-template matStepLabel>{{ '#LDS#Select report' | translate }}</ng-template>\r\n      <div class=\"imx-report-table\">\r\n        <imx-report-selector [controlHeigth]=\"500\" formControlName=\"reportTable\"></imx-report-selector>\r\n      </div>\r\n      <div class=\"imx-step-button\">\r\n        <button [disabled]=\"!reportFormGroup.dirty\" mat-stroked-button color=\"primary\" matStepperNext data-imx-identifier=\"subscription-wizard-nextTo-step-2\">\r\n          {{ '#LDS#Next' | translate }}\r\n        </button>\r\n      </div>\r\n    </form>\r\n  </mat-step>\r\n  <mat-step [stepControl]=\"reportParameterFormGroup\" data-imx-identifier=\"subscription-wizard-step-2-edit-parameter\">\r\n    <form [formGroup]=\"reportParameterFormGroup\">\r\n      <ng-template matStepLabel>{{ '#LDS#Configure subscription' | translate }}</ng-template>\r\n      <div class=\"imx-subscription-properties\">\r\n        <imx-subscription-properties\r\n          [displayedColumns]=\"columnsForEdit\"\r\n          [withTitles]=\"false\"\r\n          [formGroup]=\"reportParameterFormGroup\"\r\n          [subscription]=\"newSubscription\"\r\n        ></imx-subscription-properties>\r\n      </div>\r\n      <div class=\"imx-step-button\">\r\n        <button mat-stroked-button matStepperPrevious data-imx-identifier=\"subscription-wizard-backtTo-step-1\">\r\n          {{ '#LDS#Back' | translate }}\r\n        </button>\r\n        <button [disabled]=\"reportParameterFormGroup.invalid\" mat-stroked-button color=\"primary\" matStepperNext data-imx-identifier=\"subscription-wizard-nextTo-step-3\">\r\n          {{ '#LDS#Next' | translate }}\r\n        </button>\r\n      </div>\r\n    </form>\r\n  </mat-step>\r\n  <mat-step [stepControl]=\"additionalSubscribersFormGroup\" data-imx-identifier=\"subscription-wizard-step-3-add-subscribers\">\r\n    <form [formGroup]=\"additionalSubscribersFormGroup\">\r\n      <ng-template matStepLabel>{{ '#LDS#Add additional subscribers' | translate }}</ng-template>\r\n      <div class=\"imx-wizard-info\">\r\n        {{ '#LDS#Here you can select identities that should also receive these reports.' | translate }}\r\n      </div>\r\n      <imx-multi-select-formcontrol\r\n        #additionalApprover\r\n        [pushMethod]=\"'manual'\"\r\n        [selectedElementsCaption]=\"'#LDS#Selected subscribers' | translate\"\r\n        formControlName=\"additionalSubscribers\"\r\n      >\r\n      </imx-multi-select-formcontrol>\r\n      <div class=\"imx-step-button\">\r\n        <button mat-stroked-button matStepperPrevious data-imx-identifier=\"subscription-wizard-backTo-step-2\">\r\n          {{ '#LDS#Back' | translate }}\r\n        </button>\r\n        <button mat-stroked-button color=\"primary\" matStepperNext data-imx-identifier=\"subscription-wizard-nextTo-step-4\">\r\n          {{ '#LDS#Next' | translate }}\r\n        </button>\r\n      </div>\r\n    </form>\r\n  </mat-step>\r\n  <mat-step data-imx-identifier=\"subscription-wizard-step-4-overview\">\r\n    <ng-template matStepLabel>{{ '#LDS#Check and create subscription' | translate }}</ng-template>\r\n    <imx-subscription-overview [isWaitingForLoad]=\"isLoadingOverview\" [subscription]=\"newSubscription\" [subscribersChanged]=\"subscribersChangedSubject\"></imx-subscription-overview>\r\n    <div class=\"imx-step-button\">\r\n      <button mat-stroked-button matStepperPrevious data-imx-identifier=\"subscription-wizard-backTo-step-3\">\r\n        {{ '#LDS#Back' | translate }}\r\n      </button>\r\n      <button color=\"primary\" mat-stroked-button (click)=\"submit()\" data-imx-identifier=\"subscription-wizard-create-subscription\">{{ '#LDS#Create' | translate }}</button>\r\n    </div>\r\n  </mat-step>\r\n</mat-stepper>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.imx-report-table{display:flex;margin-top:10px}.imx-subscription-properties{margin-top:20px}imx-property-viewer{display:grid;grid-template-columns:1fr 1fr;gap:10px 20px}.imx-wizard-info{margin:30px 0}.imx-step-button>:first-child{margin-right:10px}@media only screen and (max-width: 1024px){.imx-wizard-info{margin:0}}\n"] }]
        }], function () { return [{ type: i1$1.EuiSidesheetRef }, { type: ReportSubscriptionService }, { type: i1.ConfirmationService }, { type: i1$1.EuiLoadingService }]; }, { additional: [{
                type: ViewChild,
                args: ['additionalApprover']
            }] });
})();

class SubscriptionsService {
    constructor(api) {
        this.api = api;
    }
    get PortalSubscriptionSchema() {
        return this.api.typedClient.PortalSubscription.GetSchema();
    }
    getSubscriptions(parameters) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalSubscription.Get(parameters);
        });
    }
    deleteSubscription(uid) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.client.portal_subscription_delete(uid);
        });
    }
    getSubscriptionInteractive(uid) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalSubscriptionInteractive.Get_byid(uid);
        });
    }
    sendMail(uidPort, withCc) {
        return __awaiter(this, void 0, void 0, function* () {
            if (withCc) {
                yield this.api.client.portal_subscription_sendmailcc_post(uidPort);
            }
            return this.api.client.portal_subscription_sendmail_post(uidPort);
        });
    }
    hasReports() {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.api.typedClient.PortalReports.Get({ PageSize: -1 })).totalCount > 0;
        });
    }
}
SubscriptionsService.ɵfac = function SubscriptionsService_Factory(t) { return new (t || SubscriptionsService)(i0.ɵɵinject(RpsApiService)); };
SubscriptionsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: SubscriptionsService, factory: SubscriptionsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: RpsApiService }]; }, null);
})();

function SubscriptionsComponent_ng_template_9_button_16_Template(rf, ctx) {
    if (rf & 1) {
        const _r7 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 17);
        i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_button_16_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r7); const subscription_r2 = i0.ɵɵnextContext().$implicit; const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.viewReportSubscription(subscription_r2)); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#View report"), " ");
    }
}
function SubscriptionsComponent_ng_template_9_Template(rf, ctx) {
    if (rf & 1) {
        const _r10 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 11);
        i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_Template_button_click_0_listener($event) { return $event.stopPropagation(); });
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelement(2, "eui-icon", 12);
        i0.ɵɵtext(3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "mat-menu", 13, 14)(7, "button", 15);
        i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_Template_button_click_7_listener() { const restoredCtx = i0.ɵɵrestoreView(_r10); const subscription_r2 = restoredCtx.$implicit; const ctx_r9 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r9.delete(subscription_r2)); });
        i0.ɵɵtext(8);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(10, "button", 16);
        i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_Template_button_click_10_listener() { const restoredCtx = i0.ɵɵrestoreView(_r10); const subscription_r2 = restoredCtx.$implicit; const ctx_r11 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r11.sendMail(subscription_r2, false)); });
        i0.ɵɵtext(11);
        i0.ɵɵpipe(12, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(13, "button", 17);
        i0.ɵɵlistener("click", function SubscriptionsComponent_ng_template_9_Template_button_click_13_listener() { const restoredCtx = i0.ɵɵrestoreView(_r10); const subscription_r2 = restoredCtx.$implicit; const ctx_r12 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r12.sendMail(subscription_r2, true)); });
        i0.ɵɵtext(14);
        i0.ɵɵpipe(15, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(16, SubscriptionsComponent_ng_template_9_button_16_Template, 3, 3, "button", 18);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const subscription_r2 = ctx.$implicit;
        const _r3 = i0.ɵɵreference(6);
        i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(1, 7, "#LDS#Actions"));
        i0.ɵɵproperty("matMenuTriggerFor", _r3);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 9, "#LDS#Actions"), " ");
        i0.ɵɵadvance(5);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(9, 11, "#LDS#Unsubscribe"), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(12, 13, "#LDS#Send report to me"), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(15, 15, "#LDS#Send report to all subscribers"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", subscription_r2.IsListReport.value);
    }
}
const _c0$1 = function () { return ["search"]; };
class SubscriptionsComponent {
    constructor(subscriptionService, rpsReportService, confirmationService, sideSheet, snackbar, translate, busyServiceElemental, listReportViewerService) {
        this.subscriptionService = subscriptionService;
        this.rpsReportService = rpsReportService;
        this.confirmationService = confirmationService;
        this.sideSheet = sideSheet;
        this.snackbar = snackbar;
        this.translate = translate;
        this.busyServiceElemental = busyServiceElemental;
        this.listReportViewerService = listReportViewerService;
        this.DisplayColumns = DisplayColumns;
        this.canAddSubscription = false;
        this.navigationState = { PageSize: 25, StartIndex: 0 };
        this.busyService = new BusyService();
        this.entitySchema = subscriptionService.PortalSubscriptionSchema;
        this.displayedColumns = [
            this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            {
                ColumnName: 'actions',
                Type: ValType.String,
                afterAdditionals: true,
                untranslatedDisplay: '#LDS#Actions',
            },
        ];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                this.canAddSubscription = yield this.subscriptionService.hasReports();
            }
            finally {
                isBusy.endBusy();
            }
            yield this.navigate();
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState = newState;
            yield this.navigate();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState = {
                PageSize: this.navigationState.PageSize,
                StartIndex: 0,
                search: keywords,
            };
            return this.navigate();
        });
    }
    sendMail(subscription, withCc) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.subscriptionService.sendMail(subscription.GetEntity().GetKeys()[0], withCc);
            this.snackbar.open({
                key: withCc ? '#LDS#The report "{0}" will be sent to all subscribers.' : '#LDS#The report "{0}" will be sent to you.',
                parameters: [subscription.UID_RPSReport.Column.GetDisplayValue()],
            });
        });
    }
    viewReportSubscription(subscription) {
        return __awaiter(this, void 0, void 0, function* () {
            let reportSub;
            const over = this.busyServiceElemental.show();
            try {
                const sub = yield this.subscriptionService.getSubscriptionInteractive(subscription.GetEntity().GetKeys()[0]);
                reportSub = yield this.rpsReportService.buildRpsSubscription(sub.Data[0]);
            }
            finally {
                this.busyServiceElemental.hide(over);
            }
            if (!reportSub) {
                return;
            }
            this.listReportViewerService.setUidReport(subscription.UID_RPSReport.value);
            const data = { dataService: this.listReportViewerService, subscription: reportSub };
            this.sideSheet.open(ListReportViewerSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Report').toPromise(),
                subTitle: subscription.GetEntity().GetDisplay(),
                padding: '0',
                width: 'max(550px,55%)',
                testId: 'subscription-report-viewer',
                data,
            });
        });
    }
    delete(subscription) {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.confirmationService.confirm({
                Title: '#LDS#Heading Unsubscribe Report',
                Message: '#LDS#Do you want to unsubscribe from this report?',
                identifier: 'subscriptions-confirm-unsubscribe-report',
            })) {
                let overlayRef;
                setTimeout(() => (overlayRef = this.busyServiceElemental.show()));
                try {
                    yield this.subscriptionService.deleteSubscription(subscription.GetEntity().GetKeys()[0]);
                }
                finally {
                    setTimeout(() => this.busyServiceElemental.hide(overlayRef));
                }
                const message = {
                    key: '#LDS#You have successfully unsubscribed from the report "{0}".',
                    parameters: [subscription.GetEntity().GetDisplay()],
                };
                this.navigate();
                this.snackbar.open(message);
            }
        });
    }
    editSubscription(subscription) {
        return __awaiter(this, void 0, void 0, function* () {
            let rpsSubscription;
            let overlayRef;
            setTimeout(() => (overlayRef = this.busyServiceElemental.show()));
            try {
                const sub = yield this.subscriptionService.getSubscriptionInteractive(subscription.GetEntity().GetKeys()[0]);
                if (sub.Data.length > 0) {
                    rpsSubscription = this.rpsReportService.buildRpsSubscription(sub.Data[0]);
                }
            }
            finally {
                setTimeout(() => this.busyServiceElemental.hide(overlayRef));
            }
            if (rpsSubscription) {
                const sidesheetRef = this.sideSheet.open(SubscriptionDetailsComponent, {
                    title: yield this.translate.get('#LDS#Heading Edit Subscription').toPromise(),
                    subTitle: subscription.GetEntity().GetDisplay(),
                    testId: 'edit-subscription-sidesheet',
                    padding: '0px',
                    width: 'max(700px,70%)',
                    disableClose: true,
                    data: rpsSubscription,
                });
                if (yield sidesheetRef.afterClosed().toPromise()) {
                    return this.navigate();
                }
            }
        });
    }
    createSubscription() {
        return __awaiter(this, void 0, void 0, function* () {
            const sidesheetRef = this.sideSheet.open(SubscriptionWizardComponent, {
                title: yield this.translate.get('#LDS#Heading Add Report Subscription').toPromise(),
                padding: '0px',
                width: '70%',
                disableClose: true,
                testId: 'subscriptions-create',
            });
            if (yield sidesheetRef.afterClosed().toPromise()) {
                this.snackbar.open({ key: '#LDS#The subscription has been successfully created.' });
                return this.navigate();
            }
        });
    }
    viewReport() {
        return __awaiter(this, void 0, void 0, function* () {
            const sidesheetRef = this.sideSheet.open(ReportViewConfigComponent, {
                title: yield this.translate.get('#LDS#Heading View a Report').toPromise(),
                padding: '0px',
                width: '70%',
                testId: 'subscriptions-view-config',
            });
            if (yield sidesheetRef.afterClosed().toPromise()) {
                this.snackbar.open({ key: '#LDS#The subscription has been successfully created.' });
                return this.navigate();
            }
        });
    }
    navigate() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const subscriptions = yield this.subscriptionService.getSubscriptions(this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: subscriptions,
                    entitySchema: this.entitySchema,
                    navigationState: this.navigationState,
                };
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
}
SubscriptionsComponent.ɵfac = function SubscriptionsComponent_Factory(t) { return new (t || SubscriptionsComponent)(i0.ɵɵdirectiveInject(SubscriptionsService), i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i1.SnackBarService), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(ListReportViewerService)); };
SubscriptionsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SubscriptionsComponent, selectors: [["imx-subscriptions"]], decls: 19, vars: 18, consts: [[1, "imx-table-container"], ["data-imx-identifier", "subscriptions-table-toolbar", 3, "settings", "busyService", "options", "search", "navigationStateChanged"], ["dst", ""], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "subscriptions-table", 3, "dst", "highlightedEntityChanged"], [3, "entityColumn", "columnLabel"], ["columnName", "actions", "columnLabel", ""], ["data-imx-identifier", "subscriptions-table-paginator", 3, "dst"], [1, "imx-button-bar"], ["mat-stroked-button", "", "data-imx-identifier", "subscriptions-view-report", 3, "disabled", "click"], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "subscriptions-create-new-subscription", 3, "disabled", "click"], ["icon", "add"], ["mat-stroked-button", "", "data-imx-identifier", "subscriptions-actions", 1, "imx-right-button", 3, "title", "matMenuTriggerFor", "click"], ["icon", "ellipsisvertical"], ["data-imx-identifier", "subscriptions-actions-menu"], ["actionsMenu", "matMenu"], ["mat-menu-item", "", "color", "primary", "data-imx-identifier", "subscriptions-show-edit", 3, "click"], ["mat-menu-item", "", "color", "primary", "data-imx-identifier", "subscriptions-send-mail", 1, "imx-separate-menu-item", 3, "click"], ["mat-menu-item", "", "color", "primary", "data-imx-identifier", "subscriptions-send-mail-to-subscribers", 3, "click"], ["mat-menu-item", "", "color", "primary", "data-imx-identifier", "subscriptions-send-mail-to-subscribers", 3, "click", 4, "ngIf"]], template: function SubscriptionsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-content")(2, "div", 0)(3, "imx-data-source-toolbar", 1, 2);
            i0.ɵɵlistener("search", function SubscriptionsComponent_Template_imx_data_source_toolbar_search_3_listener($event) { return ctx.onSearch($event); })("navigationStateChanged", function SubscriptionsComponent_Template_imx_data_source_toolbar_navigationStateChanged_3_listener($event) { return ctx.onNavigationStateChanged($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "imx-data-table", 3);
            i0.ɵɵlistener("highlightedEntityChanged", function SubscriptionsComponent_Template_imx_data_table_highlightedEntityChanged_5_listener($event) { return ctx.editSubscription($event); });
            i0.ɵɵelement(6, "imx-data-table-column", 4);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementStart(8, "imx-data-table-generic-column", 5);
            i0.ɵɵtemplate(9, SubscriptionsComponent_ng_template_9_Template, 17, 17, "ng-template");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(10, "imx-data-source-paginator", 6);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(11, "div", 7)(12, "button", 8);
            i0.ɵɵlistener("click", function SubscriptionsComponent_Template_button_click_12_listener() { return ctx.viewReport(); });
            i0.ɵɵtext(13);
            i0.ɵɵpipe(14, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(15, "button", 9);
            i0.ɵɵlistener("click", function SubscriptionsComponent_Template_button_click_15_listener() { return ctx.createSubscription(); });
            i0.ɵɵelement(16, "eui-icon", 10);
            i0.ɵɵtext(17);
            i0.ɵɵpipe(18, "translate");
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(4);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("settings", ctx.dstSettings)("busyService", ctx.busyService)("options", i0.ɵɵpureFunction0(17, _c0$1));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵpropertyInterpolate("columnLabel", i0.ɵɵpipeBind1(7, 11, "#LDS#Subscription"));
            i0.ɵɵproperty("entityColumn", ctx.entitySchema == null ? null : ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canAddSubscription);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(14, 13, "#LDS#View a report"), " ");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canAddSubscription);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(18, 15, "#LDS#Add subscription"), " ");
        }
    }, dependencies: [i3$1.NgIf, i1.DataSourceToolbarComponent, i1.DataSourcePaginatorComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i1.DataTableGenericColumnComponent, i1$1.EuiIconComponent, i4$1.MatButton, i9.MatCard, i9.MatCardContent, i10$1.MatMenu, i10$1.MatMenuItem, i10$1.MatMenuTrigger, i3$2.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit}imx-data-table[_ngcontent-%COMP%]{flex:1 1 auto}.imx-right-button[_ngcontent-%COMP%]{float:right;margin-right:10px}[_nghost-%COMP%]     imx-data-table .mat-header-row .mat-header-cell{font-weight:600;font-size:14px;padding:0 10px}[_nghost-%COMP%]     imx-data-table .mat-row .mat-cell{padding:0 10px}.imx-separate-menu-item[_ngcontent-%COMP%]{border-top:1px solid #c4cacc}.imx-table-container[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}[_nghost-%COMP%]     eui-sidesheet .eui-sidesheet__content{display:flex;flex-direction:column;max-height:100%;box-sizing:content-box}.mat-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:inherit;overflow:hidden}.mat-card[_ngcontent-%COMP%]   .mat-card-content[_ngcontent-%COMP%]{overflow-y:auto;overflow-x:hidden;flex:1 1 auto;display:flex;flex-direction:column}.mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.imx-button-bar[_ngcontent-%COMP%]{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-button-bar[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:16px}.imx-button-bar[_ngcontent-%COMP%]   .imx-menu-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.imx-button-bar[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%], .imx-button-bar[_ngcontent-%COMP%]   .mat-raised-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionsComponent, [{
            type: Component,
            args: [{ selector: 'imx-subscriptions', template: "<mat-card>\r\n  <mat-card-content>\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-source-toolbar\r\n        #dst\r\n        [settings]=\"dstSettings\"\r\n        [busyService]=\"busyService\"\r\n        data-imx-identifier=\"subscriptions-table-toolbar\"\r\n        [options]=\"['search']\"\r\n        (search)=\"onSearch($event)\"\r\n        (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n      >\r\n      </imx-data-source-toolbar>\r\n\r\n      <imx-data-table [dst]=\"dst\" detailViewVisible=\"false\" mode=\"manual\" data-imx-identifier=\"subscriptions-table\" (highlightedEntityChanged)=\"editSubscription($event)\">\r\n        <imx-data-table-column [entityColumn]=\"entitySchema?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\" columnLabel=\"{{ '#LDS#Subscription' | translate }}\">\r\n        </imx-data-table-column>\r\n        <imx-data-table-generic-column columnName=\"actions\" columnLabel=\"\">\r\n          <ng-template let-subscription>\r\n            <button\r\n              mat-stroked-button\r\n              class=\"imx-right-button\"\r\n              data-imx-identifier=\"subscriptions-actions\"\r\n              (click)=\"$event.stopPropagation()\"\r\n              title=\"{{ '#LDS#Actions' | translate }}\"\r\n              [matMenuTriggerFor]=\"actionsMenu\"\r\n            >\r\n              <eui-icon icon=\"ellipsisvertical\"></eui-icon>\r\n              {{ '#LDS#Actions' | translate }}\r\n            </button>\r\n            <mat-menu data-imx-identifier=\"subscriptions-actions-menu\" #actionsMenu=\"matMenu\">\r\n              <button mat-menu-item color=\"primary\" (click)=\"delete(subscription)\" data-imx-identifier=\"subscriptions-show-edit\">\r\n                {{ '#LDS#Unsubscribe' | translate }}\r\n              </button>\r\n              <button mat-menu-item color=\"primary\" class=\"imx-separate-menu-item\" (click)=\"sendMail(subscription, false)\" data-imx-identifier=\"subscriptions-send-mail\">\r\n                {{ '#LDS#Send report to me' | translate }}\r\n              </button>\r\n              <button mat-menu-item color=\"primary\" (click)=\"sendMail(subscription, true)\" data-imx-identifier=\"subscriptions-send-mail-to-subscribers\">\r\n                {{ '#LDS#Send report to all subscribers' | translate }}\r\n              </button>\r\n              <button\r\n                mat-menu-item\r\n                color=\"primary\"\r\n                *ngIf=\"subscription.IsListReport.value\"\r\n                (click)=\"viewReportSubscription(subscription)\"\r\n                data-imx-identifier=\"subscriptions-send-mail-to-subscribers\"\r\n              >\r\n                {{ '#LDS#View report' | translate }}\r\n              </button>\r\n            </mat-menu>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n      </imx-data-table>\r\n      <imx-data-source-paginator data-imx-identifier=\"subscriptions-table-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\r\n    </div>\r\n  </mat-card-content>\r\n</mat-card>\r\n\r\n<div class=\"imx-button-bar\">\r\n  <button [disabled]=\"!canAddSubscription\" mat-stroked-button (click)=\"viewReport()\" data-imx-identifier=\"subscriptions-view-report\">\r\n    {{ '#LDS#View a report' | translate }}\r\n  </button>\r\n  <button [disabled]=\"!canAddSubscription\" mat-raised-button (click)=\"createSubscription()\" color=\"primary\" data-imx-identifier=\"subscriptions-create-new-subscription\">\r\n    <eui-icon icon=\"add\"></eui-icon>\r\n    {{ '#LDS#Add subscription' | translate }}\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;height:inherit}imx-data-table{flex:1 1 auto}.imx-right-button{float:right;margin-right:10px}:host ::ng-deep imx-data-table .mat-header-row .mat-header-cell{font-weight:600;font-size:14px;padding:0 10px}:host ::ng-deep imx-data-table .mat-row .mat-cell{padding:0 10px}.imx-separate-menu-item{border-top:1px solid #c4cacc}.imx-table-container{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}:host ::ng-deep eui-sidesheet .eui-sidesheet__content{display:flex;flex-direction:column;max-height:100%;box-sizing:content-box}.mat-card{display:flex;flex-direction:column;height:inherit;overflow:hidden}.mat-card .mat-card-content{overflow-y:auto;overflow-x:hidden;flex:1 1 auto;display:flex;flex-direction:column}.mat-stroked-button eui-icon{font-size:14px;margin-right:4px}.imx-button-bar{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-button-bar>button:not(:last-of-type){margin-right:16px}.imx-button-bar .imx-menu-spacer{flex:1 1 auto}.imx-button-bar .mat-stroked-button eui-icon,.imx-button-bar .mat-raised-button eui-icon{font-size:14px;margin-right:4px}\n"] }]
        }], function () { return [{ type: SubscriptionsService }, { type: ReportSubscriptionService }, { type: i1.ConfirmationService }, { type: i1$1.EuiSidesheetService }, { type: i1.SnackBarService }, { type: i3$2.TranslateService }, { type: i1$1.EuiLoadingService }, { type: ListReportViewerService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ListReportViewerModule {
}
ListReportViewerModule.ɵfac = function ListReportViewerModule_Factory(t) { return new (t || ListReportViewerModule)(); };
ListReportViewerModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ListReportViewerModule });
ListReportViewerModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, MatCardModule, DataSourceToolbarModule, DataTableModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ListReportViewerModule, [{
            type: NgModule,
            args: [{
                    declarations: [ListReportViewerComponent],
                    imports: [CommonModule, MatCardModule, DataSourceToolbarModule, DataTableModule],
                    exports: [ListReportViewerComponent],
                }]
        }], null, null);
})();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ListReportViewerModule, { declarations: [ListReportViewerComponent], imports: [CommonModule, MatCardModule, DataSourceToolbarModule, DataTableModule], exports: [ListReportViewerComponent] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes$1 = [
    {
        path: 'reportsubscriptions',
        component: SubscriptionsComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService]
    }
];
class SubscriptionsModule {
}
SubscriptionsModule.ɵfac = function SubscriptionsModule_Factory(t) { return new (t || SubscriptionsModule)(); };
SubscriptionsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: SubscriptionsModule });
SubscriptionsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [ReportSubscriptionService, SubscriptionsService], imports: [CdrModule,
        CommonModule,
        ConfirmationModule,
        DataSourceToolbarModule,
        DataTableModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        HttpClientModule,
        LdsReplaceModule,
        MultiSelectFormcontrolModule,
        OverlayModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes$1),
        ScrollingModule,
        TranslateModule,
        UserMessageModule,
        BusyIndicatorModule,
        ListReportViewerModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SubscriptionsModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        ReportSelectorComponent,
                        ReportViewConfigComponent,
                        SubscriptionDetailsComponent,
                        SubscriptionPropertiesComponent,
                        SubscriptionOverviewComponent,
                        SubscriptionWizardComponent,
                        SubscriptionsComponent,
                        ListReportViewerSidesheetComponent,
                    ],
                    imports: [
                        CdrModule,
                        CommonModule,
                        ConfirmationModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        FormsModule,
                        HttpClientModule,
                        LdsReplaceModule,
                        MultiSelectFormcontrolModule,
                        OverlayModule,
                        ReactiveFormsModule,
                        RouterModule.forChild(routes$1),
                        ScrollingModule,
                        TranslateModule,
                        UserMessageModule,
                        BusyIndicatorModule,
                        ListReportViewerModule,
                    ],
                    providers: [ReportSubscriptionService, SubscriptionsService],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(SubscriptionsModule, { declarations: [ReportSelectorComponent,
            ReportViewConfigComponent,
            SubscriptionDetailsComponent,
            SubscriptionPropertiesComponent,
            SubscriptionOverviewComponent,
            SubscriptionWizardComponent,
            SubscriptionsComponent,
            ListReportViewerSidesheetComponent], imports: [CdrModule,
            CommonModule,
            ConfirmationModule,
            DataSourceToolbarModule,
            DataTableModule,
            EuiCoreModule,
            EuiMaterialModule,
            FormsModule,
            HttpClientModule,
            LdsReplaceModule,
            MultiSelectFormcontrolModule,
            OverlayModule,
            ReactiveFormsModule, i1$2.RouterModule, ScrollingModule,
            TranslateModule,
            UserMessageModule,
            BusyIndicatorModule,
            ListReportViewerModule] });
})();

class EditReportSqlWizardService {
    constructor(api) {
        this.api = api;
    }
    getFilterProperties(table) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.api.client.portal_reports_sqlwizard_tables_columns_get(table)).Properties;
        });
    }
    getCandidates(parentTable, options) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.api.client.portal_reports_sqlwizard_candidates_get(parentTable, options);
        });
    }
}
EditReportSqlWizardService.ɵfac = function EditReportSqlWizardService_Factory(t) { return new (t || EditReportSqlWizardService)(i0.ɵɵinject(RpsApiService)); };
EditReportSqlWizardService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EditReportSqlWizardService, factory: EditReportSqlWizardService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportSqlWizardService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: RpsApiService }]; }, null);
})();

function EditReportSidesheetComponent_imx_cdr_editor_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r5 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 5);
        i0.ɵɵlistener("controlCreated", function EditReportSidesheetComponent_imx_cdr_editor_2_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.addCdr($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r3 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r3);
    }
}
function EditReportSidesheetComponent_mat_card_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(4, "imx-ordered-list", 6);
        i0.ɵɵpipe(5, "translate");
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(3, 7, "#LDS#Columns to be included"), "*");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("isReadOnly", ctx_r1.data.isReadonly)("addNewText", i0.ɵɵpipeBind1(5, 9, "#LDS#Add column"))("deleteText", i0.ɵɵpipeBind1(6, 11, "#LDS#Delete"))("placeholder", i0.ɵɵpipeBind1(7, 13, "#LDS#Column name"))("data", ctx_r1.definition.SelectedColumns)("dataSource", ctx_r1.definition.AvailableColumns);
    }
}
function EditReportSidesheetComponent_ng_container_4_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 8);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("colored", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, ctx_r6.ldsUnsupportedExpression), " ");
    }
}
function EditReportSidesheetComponent_ng_container_4_mat_card_2_eui_alert_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 8);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r8 = i0.ɵɵnextContext(3);
        i0.ɵɵproperty("colored", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, ctx_r8.ldsAllRowsInfoText), " ");
    }
}
function EditReportSidesheetComponent_ng_container_4_mat_card_2_imx_sqlwizard_5_Template(rf, ctx) {
    if (rf & 1) {
        const _r11 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-sqlwizard", 10);
        i0.ɵɵlistener("change", function EditReportSidesheetComponent_ng_container_4_mat_card_2_imx_sqlwizard_5_Template_imx_sqlwizard_change_0_listener() { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r10.checkChanges()); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r9 = i0.ɵɵnextContext(3);
        i0.ɵɵproperty("tableName", ctx_r9.definition.TableName)("apiService", ctx_r9.svc)("expression", ctx_r9.sqlExpression.Expression);
    }
}
function EditReportSidesheetComponent_ng_container_4_mat_card_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card")(1, "mat-card-title");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(4, EditReportSidesheetComponent_ng_container_4_mat_card_2_eui_alert_4_Template, 3, 4, "eui-alert", 7);
        i0.ɵɵtemplate(5, EditReportSidesheetComponent_ng_container_4_mat_card_2_imx_sqlwizard_5_Template, 1, 3, "imx-sqlwizard", 9);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r7 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(3, 3, "#LDS#Conditions"), "*");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", (ctx_r7.sqlExpression.Expression == null ? null : ctx_r7.sqlExpression.Expression.Expressions.length) < 1);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r7.sqlExpression.IsUnsupported);
    }
}
function EditReportSidesheetComponent_ng_container_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtemplate(1, EditReportSidesheetComponent_ng_container_4_eui_alert_1_Template, 3, 4, "eui-alert", 7);
        i0.ɵɵtemplate(2, EditReportSidesheetComponent_ng_container_4_mat_card_2_Template, 6, 5, "mat-card", 2);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r2.sqlExpression.IsUnsupported);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r2.sqlExpression.IsUnsupported);
    }
}
class EditReportSidesheetComponent {
    constructor(formBuilder, svc, data, snackBar, sideSheetRef, api, entityService, busyService, cdref, config, cdrFactoryService, confirmation) {
        var _a, _b;
        this.svc = svc;
        this.data = data;
        this.snackBar = snackBar;
        this.sideSheetRef = sideSheetRef;
        this.api = api;
        this.entityService = entityService;
        this.busyService = busyService;
        this.cdref = cdref;
        this.config = config;
        this.cdrFactoryService = cdrFactoryService;
        this.cdrList = [];
        this.ldsUnsupportedExpression = '#LDS#You cannot edit the conditions of this report in the Web Portal.';
        this.ldsAllRowsInfoText = '#LDS#All data from the selected table will be included in the report.';
        this.exprHasntChanged = true;
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.closeSubscription = this.sideSheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
            if ((!this.detailsFormGroup.dirty && this.exprHasntChanged) || (yield confirmation.confirmLeaveWithUnsavedChanges())) {
                this.sideSheetRef.close();
            }
        }));
        this.report = data.report.Data[0];
        // Save a local copy of the definition object. The entity will change with every update
        // of the interactive entity that comes back from the server
        this.definition = (_a = this.report.extendedDataRead) === null || _a === void 0 ? void 0 : _a.Definition[0];
        this.lastSavedExpression = _.cloneDeep((_b = this.sqlExpression) === null || _b === void 0 ? void 0 : _b.Expression);
    }
    get formArray() {
        return this.detailsFormGroup.get('formArray');
    }
    get sqlExpression() {
        var _a;
        return (_a = this.definition) === null || _a === void 0 ? void 0 : _a.Data;
    }
    get controlsInvalid() {
        var _a;
        return ((this.detailsFormGroup.pristine && this.exprHasntChanged) ||
            this.detailsFormGroup.invalid ||
            (!((_a = this.sqlExpression) === null || _a === void 0 ? void 0 : _a.IsUnsupported) && this.isConditionInvalid()));
    }
    checkChanges() {
        var _a;
        this.exprHasntChanged = _.isEqual((_a = this.sqlExpression) === null || _a === void 0 ? void 0 : _a.Expression, this.lastSavedExpression);
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const c = yield this.config.getConfig();
            this.cdrList = this.cdrFactoryService.buildCdrFromColumnList(this.report.GetEntity(), c.OwnershipConfig.EditableFields[this.report.GetEntity().TypeName], this.data.isReadonly);
            if (this.definition) {
                // is it a list report?
                this.cdrList.push(yield this.buildTableCdr());
            }
            this.cdrList.push(this.data.isReadonly ? new BaseReadonlyCdr(this.report.AvailableTo.Column) : new BaseCdr(this.report.AvailableTo.Column));
        });
    }
    addCdr(control) {
        this.formArray.push(control);
        this.cdref.detectChanges();
    }
    ngOnDestroy() {
        if (this.closeSubscription) {
            this.closeSubscription.unsubscribe();
        }
    }
    save() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.detailsFormGroup.valid) {
                return;
            }
            const busy = this.busyService.show();
            try {
                if (this.definition) {
                    this.report.extendedData = {
                        Definition: [
                            {
                                SelectedColumns: this.definition.SelectedColumns,
                                Data: {
                                    Filters: [this.definition.Data.Expression],
                                },
                            },
                        ],
                    };
                }
                yield this.report.GetEntity().Commit(false);
                this.detailsFormGroup.markAsPristine();
                this.sideSheetRef.close(true);
                this.snackBar.open({ key: '#LDS#The report has been successfully saved.' });
            }
            finally {
                this.busyService.hide(busy);
            }
        });
    }
    isConditionInvalid() {
        if (!this.definition) {
            return false;
        } // not a list report?
        if (this.definition.SelectedColumns.filter((elem) => elem != null && elem !== '').length < 1) {
            return true;
        } // must select at least one column
        // not initialized? avoid NG1000
        if (!this.sqlwizard || !this.sqlwizard.viewSettings) {
            return true;
        }
        // check if the sqlWizard has a valid expression
        return isExpressionInvalid(this.sqlExpression) || !this.hasValuesSet(this.sqlExpression.Expression);
    }
    hasValuesSet(sqlExpression, checkCurrent = false) {
        var _a;
        const current = !checkCurrent || sqlExpression.Value != null;
        if (((_a = sqlExpression.Expressions) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            return current && sqlExpression.Expressions.every((elem) => this.hasValuesSet(elem, true));
        }
        return current;
    }
    buildTableCdr() {
        return __awaiter(this, void 0, void 0, function* () {
            const fkProviderItem = {
                columnName: 'uid_dialogtable',
                fkTableName: 'DialogTable',
                parameterNames: ['search'],
                load: (_, parameters) => __awaiter(this, void 0, void 0, function* () {
                    return this.api.client.portal_reports_tables_get(parameters);
                }),
                getDataModel: (_) => __awaiter(this, void 0, void 0, function* () {
                    return {};
                }),
            };
            const tableCol = this.entityService.createLocalEntityColumn({
                ColumnName: fkProviderItem.columnName,
                Type: ValType.String,
                FkRelation: {
                    IsMemberRelation: false,
                    ParentTableName: fkProviderItem.fkTableName,
                    ParentColumnName: 'TableName',
                },
                ValidReferencedTables: [{ TableName: fkProviderItem.fkTableName }],
                MinLen: 1,
            }, [fkProviderItem]);
            yield tableCol.PutValueStruct({
                DataValue: this.definition.TableName,
                DisplayValue: this.definition.TableNameDisplay,
            });
            tableCol.ColumnChanged.subscribe(() => __awaiter(this, void 0, void 0, function* () {
                var _a;
                // send an extended data update to the server, wait for the updated column object to get back
                yield this.report.setExtendedData({
                    Definition: [
                        {
                            TableName: tableCol.GetValue(),
                        },
                    ],
                });
                this.definition = (_a = this.report.extendedDataRead) === null || _a === void 0 ? void 0 : _a.Definition[0];
                this.cdref.detectChanges();
            }));
            const tableCdr = this.data.isReadonly
                ? new BaseReadonlyCdr(tableCol, '#LDS#Include data from the table')
                : new BaseCdr(tableCol, '#LDS#Include data from the table');
            return tableCdr;
        });
    }
}
EditReportSidesheetComponent.ɵfac = function EditReportSidesheetComponent_Factory(t) { return new (t || EditReportSidesheetComponent)(i0.ɵɵdirectiveInject(i10.UntypedFormBuilder), i0.ɵɵdirectiveInject(EditReportSqlWizardService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(RpsApiService), i0.ɵɵdirectiveInject(i1.EntityService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i5.ProjectConfigurationService), i0.ɵɵdirectiveInject(i1.CdrFactoryService), i0.ɵɵdirectiveInject(i1.ConfirmationService)); };
EditReportSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditReportSidesheetComponent, selectors: [["ng-component"]], viewQuery: function EditReportSidesheetComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(SqlWizardComponent, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.sqlwizard = _t.first);
        }
    }, decls: 9, vars: 7, consts: [["eui-sidesheet-content", ""], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-raised-button", "", "color", "primary", "data-imx-identifier", "report-sidesheet-button", 3, "disabled", "click"], [3, "cdr", "controlCreated"], [3, "isReadOnly", "addNewText", "deleteText", "placeholder", "data", "dataSource"], ["class", "helper-alert", "condensed", "true", "type", "info", 3, "colored", 4, "ngIf"], ["condensed", "true", "type", "info", 1, "helper-alert", 3, "colored"], [3, "tableName", "apiService", "expression", "change", 4, "ngIf"], [3, "tableName", "apiService", "expression", "change"]], template: function EditReportSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card");
            i0.ɵɵtemplate(2, EditReportSidesheetComponent_imx_cdr_editor_2_Template, 1, 1, "imx-cdr-editor", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(3, EditReportSidesheetComponent_mat_card_3_Template, 8, 15, "mat-card", 2);
            i0.ɵɵtemplate(4, EditReportSidesheetComponent_ng_container_4_Template, 3, 2, "ng-container", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "div", 3)(6, "button", 4);
            i0.ɵɵlistener("click", function EditReportSidesheetComponent_Template_button_click_6_listener() { return ctx.save(); });
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.definition == null ? null : ctx.definition.TableName);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", (ctx.definition == null ? null : ctx.definition.TableName) && ctx.sqlExpression);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.controlsInvalid || ctx.data.isReadonly);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(8, 5, ctx.data.isNew ? "#LDS#Create" : "#LDS#Save"), " ");
        }
    }, dependencies: [i1.CdrEditorComponent, i3$1.NgForOf, i3$1.NgIf, i1$1.EuiAlertComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i4$1.MatButton, i9.MatCard, i9.MatCardTitle, i1.OrderedListComponent, i1.SqlWizardComponent, i3$2.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}[_nghost-%COMP%]   .eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}eui-alert[_ngcontent-%COMP%]{display:block;margin-bottom:1em}mat-card[_ngcontent-%COMP%]{margin-bottom:1em}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportSidesheetComponent, [{
            type: Component,
            args: [{ template: "<div eui-sidesheet-content>\r\n  <mat-card>\r\n    <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"addCdr($event)\"></imx-cdr-editor>\r\n  </mat-card>\r\n\r\n  <mat-card *ngIf=\"definition?.TableName\">\r\n    <mat-card-title>{{ '#LDS#Columns to be included' | translate }}*</mat-card-title>\r\n\r\n    <imx-ordered-list\r\n      [isReadOnly]=\"data.isReadonly\"\r\n      [addNewText]=\"'#LDS#Add column' | translate\"\r\n      [deleteText]=\"'#LDS#Delete' | translate\"\r\n      [placeholder]=\"'#LDS#Column name' | translate\"\r\n      [data]=\"definition.SelectedColumns\"\r\n      [dataSource]=\"definition.AvailableColumns\"\r\n    ></imx-ordered-list>\r\n  </mat-card>\r\n\r\n  <ng-container *ngIf=\"definition?.TableName && sqlExpression\">\r\n    <eui-alert class=\"helper-alert\" *ngIf=\"sqlExpression.IsUnsupported\" condensed=\"true\" [colored]=\"true\" type=\"info\">\r\n      {{ ldsUnsupportedExpression | translate }}\r\n    </eui-alert>\r\n\r\n    <mat-card *ngIf=\"!sqlExpression.IsUnsupported\">\r\n      <mat-card-title>{{ '#LDS#Conditions' | translate }}*</mat-card-title>\r\n\r\n      <eui-alert class=\"helper-alert\" *ngIf=\"sqlExpression.Expression?.Expressions.length < 1\" condensed=\"true\" [colored]=\"true\" type=\"info\">\r\n        {{ ldsAllRowsInfoText | translate }}\r\n      </eui-alert>\r\n      <imx-sqlwizard *ngIf=\"!sqlExpression.IsUnsupported\" [tableName]=\"definition.TableName\" [apiService]=\"svc\" [expression]=\"sqlExpression.Expression\" (change)=\"checkChanges()\">\r\n      </imx-sqlwizard>\r\n    </mat-card>\r\n  </ng-container>\r\n</div>\r\n<div eui-sidesheet-actions>\r\n  <button mat-raised-button color=\"primary\" data-imx-identifier=\"report-sidesheet-button\" [disabled]=\"controlsInvalid || data.isReadonly\" (click)=\"save()\">\r\n    {{ (data.isNew ? '#LDS#Create' : '#LDS#Save') | translate }}\r\n  </button>\r\n</div>\r\n", styles: [".eui-sidesheet-content{display:flex;flex-direction:column}:host .eui-sidesheet-actions .justify-start{margin-right:auto}:host .eui-sidesheet-actions button:not(:last-of-type):not(.justify-start){margin-right:10px}eui-alert{display:block;margin-bottom:1em}mat-card{margin-bottom:1em}\n"] }]
        }], function () {
        return [{ type: i10.UntypedFormBuilder }, { type: EditReportSqlWizardService }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i1.SnackBarService }, { type: i1$1.EuiSidesheetRef }, { type: RpsApiService }, { type: i1.EntityService }, { type: i1$1.EuiLoadingService }, { type: i0.ChangeDetectorRef }, { type: i5.ProjectConfigurationService }, { type: i1.CdrFactoryService }, { type: i1.ConfirmationService }];
    }, { sqlwizard: [{
                type: ViewChild,
                args: [SqlWizardComponent]
            }] });
})();

class EditReportService {
    constructor(api) {
        this.api = api;
        this.reportSchema = PortalReportsEditInteractive.GetEntitySchema();
    }
    getReport(id) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.api.typedClient.PortalReportsEditInteractive.Get_byid(id);
        });
    }
    createNew() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalReportsEditInteractive.Get();
        });
    }
    getReportsOwnedByUser(navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalReports.Get(Object.assign({ owned: true }, navigationState));
        });
    }
    getAllReports(navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.api.typedClient.PortalReports.Get(navigationState);
        });
    }
    deleteReport(report) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.api.client.portal_reports_edit_delete(report.GetEntity().GetKeys()[0]);
        });
    }
}
EditReportService.ɵfac = function EditReportService_Factory(t) { return new (t || EditReportService)(i0.ɵɵinject(RpsApiService)); };
EditReportService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: EditReportService, factory: EditReportService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: RpsApiService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isRpsAdmin(groups) {
    return groups.find(item => item === 'vi_4_RPSADMIN_ADMIN') != null;
}

class RpsPermissionsService {
    constructor(userService) {
        this.userService = userService;
    }
    isRpsAdmin() {
        return __awaiter(this, void 0, void 0, function* () {
            return isRpsAdmin((yield this.userService.getGroups()).map(group => group.Name));
        });
    }
}
RpsPermissionsService.ɵfac = function RpsPermissionsService_Factory(t) { return new (t || RpsPermissionsService)(i0.ɵɵinject(i5.UserModelService)); };
RpsPermissionsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: RpsPermissionsService, factory: RpsPermissionsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RpsPermissionsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i5.UserModelService }]; }, null);
})();

const _c0 = ["dataTable"];
function EditReportComponent_ng_template_15_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 18);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(2, "div", 19);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r3 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r3.GetEntity().GetDisplay());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r3.Description.Column.GetDisplayValue());
    }
}
const _c1 = function () { return ["search"]; };
class EditReportComponent {
    constructor(reportService, busy, sidesheet, translate, confirmationService, rpsPermissionService, snackBarService, helpContextualService) {
        this.reportService = reportService;
        this.busy = busy;
        this.sidesheet = sidesheet;
        this.translate = translate;
        this.confirmationService = confirmationService;
        this.rpsPermissionService = rpsPermissionService;
        this.snackBarService = snackBarService;
        this.helpContextualService = helpContextualService;
        this.DisplayColumns = DisplayColumns;
        this.selectedReports = [];
        this.busyService = new BusyService();
        this.entitySchema = this.reportService.reportSchema;
        this.subscriptions = [];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const isRpsAdmin = yield this.rpsPermissionService.isRpsAdmin();
            this.dstWrapper = new DataSourceWrapper((state, requestOpts, isInitial) => isInitial
                ? Promise.resolve({ totalCount: 0, Data: [] })
                : isRpsAdmin
                    ? this.reportService.getAllReports(state)
                    : this.reportService.getReportsOwnedByUser(state), [this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]], this.entitySchema);
            yield this.getData(undefined);
        });
    }
    ngOnDestroy() {
        this.subscriptions.forEach((s) => s.unsubscribe());
    }
    getData(parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const parameters = Object.assign({}, parameter);
                this.dstSettings = yield this.dstWrapper.getDstSettings(parameters, undefined);
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    onSelectionChanged(items) {
        this.selectedReports = items;
    }
    createNew() {
        return __awaiter(this, void 0, void 0, function* () {
            const overlay = this.busy.show();
            let report;
            try {
                report = yield this.reportService.createNew();
            }
            finally {
                this.busy.hide(overlay);
            }
            if (report) {
                yield this.openSidesheet(report, true, false);
            }
        });
    }
    viewDetails(selectedReport) {
        return __awaiter(this, void 0, void 0, function* () {
            const overlay = this.busy.show();
            let report;
            try {
                report = yield this.reportService.getReport(selectedReport.GetEntity().GetKeys()[0]);
            }
            finally {
                this.busy.hide(overlay);
            }
            if (report) {
                yield this.openSidesheet(report, false, selectedReport.IsOob.value);
            }
        });
    }
    openSidesheet(report, isNew, isReadonly) {
        return __awaiter(this, void 0, void 0, function* () {
            this.helpContextualService.setHelpContextId(isNew ? HELP_CONTEXTUAL.ReportsCreate : HELP_CONTEXTUAL.ReportsEdit);
            const result = yield this.sidesheet
                .open(EditReportSidesheetComponent, {
                title: yield this.translate.get(isNew ? '#LDS#Heading Create Report' : '#LDS#Heading Edit Report').toPromise(),
                subTitle: isNew ? '' : report.Data[0].GetEntity().GetDisplay(),
                panelClass: 'imx-sidesheet',
                disableClose: true,
                padding: '0',
                width: 'max(768px, 80%)',
                testId: isNew ? 'report-create-sidesheet' : 'report-details-sidesheet',
                data: {
                    report,
                    isNew,
                    isReadonly,
                },
                headerComponent: HelpContextualComponent,
            })
                .afterClosed()
                .toPromise();
            if (result) {
                this.getData();
            }
        });
    }
    canDeleteSelected() {
        return this.selectedReports.length > 0 && this.selectedReports.filter((i) => i.GetEntity().GetColumn('IsOob').GetValue()).length == 0;
    }
    deleteSelected() {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.confirmationService.confirm({
                Title: '#LDS#Heading Delete Reports',
                Message: '#LDS#Are you sure you want to delete the selected reports?',
                identifier: 'report-confirm-delete',
            })) {
                const overlay = this.busy.show();
                try {
                    for (var report of this.selectedReports) {
                        yield this.reportService.deleteReport(report);
                    }
                    this.snackBarService.open({ key: '#LDS#The reports have been successfully deleted.' }, '#LDS#Close');
                    this.reportsTable.clearSelection();
                    yield this.getData();
                }
                finally {
                    this.busy.hide(overlay);
                }
            }
        });
    }
}
EditReportComponent.ɵfac = function EditReportComponent_Factory(t) { return new (t || EditReportComponent)(i0.ɵɵdirectiveInject(EditReportService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(i1.ConfirmationService), i0.ɵɵdirectiveInject(RpsPermissionsService), i0.ɵɵdirectiveInject(i1.SnackBarService), i0.ɵɵdirectiveInject(i1.HelpContextualService)); };
EditReportComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: EditReportComponent, selectors: [["ng-component"]], viewQuery: function EditReportComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.reportsTable = _t.first);
        }
    }, decls: 28, vars: 25, consts: [[1, "imx-reports-page"], [1, "heading-wrapper"], [1, "mat-headline"], [1, "imx-content-card"], [1, "imx-table-container"], ["data-imx-identifier", "report-dst", 3, "options", "settings", "busyService", "alwaysVisible", "search", "navigationStateChanged"], ["dst", ""], ["mode", "manual", "data-imx-identifier", "report-datatable", 1, "imx-reports-table", 3, "dst", "detailViewVisible", "selectable", "showSelectedItemsMenu", "noDataText", "highlightedEntityChanged", "selectionChanged"], ["dataTable", ""], ["data-imx-identifier", "report-table-column-display", 3, "entityColumn"], ["data-imx-identifier", "report-paginator", 3, "dst"], [1, "imx-button-bar"], [3, "selectedElements"], [1, "imx-menu-spacer"], ["mat-stroked-button", "", "color", "warn", 3, "disabled", "click"], ["icon", "delete"], ["mat-raised-button", "", "color", "primary", 3, "click"], ["icon", "add"], ["data-imx-identifier", "report-table-display"], ["subtitle", "", "data-imx-identifier", "report-table-description"]], template: function EditReportComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "h2", 2)(3, "span");
            i0.ɵɵtext(4);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(6, "imx-help-contextual");
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(7, "mat-card", 3)(8, "div", 4)(9, "imx-data-source-toolbar", 5, 6);
            i0.ɵɵlistener("search", function EditReportComponent_Template_imx_data_source_toolbar_search_9_listener($event) { return ctx.getData({ search: $event }); })("navigationStateChanged", function EditReportComponent_Template_imx_data_source_toolbar_navigationStateChanged_9_listener($event) { return ctx.getData($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(11, "imx-data-table", 7, 8);
            i0.ɵɵlistener("highlightedEntityChanged", function EditReportComponent_Template_imx_data_table_highlightedEntityChanged_11_listener($event) { return ctx.viewDetails($event); })("selectionChanged", function EditReportComponent_Template_imx_data_table_selectionChanged_11_listener($event) { return ctx.onSelectionChanged($event); });
            i0.ɵɵpipe(13, "translate");
            i0.ɵɵelementStart(14, "imx-data-table-column", 9);
            i0.ɵɵtemplate(15, EditReportComponent_ng_template_15_Template, 4, 2, "ng-template");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(16, "imx-data-source-paginator", 10);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(17, "div", 11);
            i0.ɵɵelement(18, "imx-selected-elements", 12)(19, "div", 13);
            i0.ɵɵelementStart(20, "button", 14);
            i0.ɵɵlistener("click", function EditReportComponent_Template_button_click_20_listener() { return ctx.deleteSelected(); });
            i0.ɵɵelement(21, "eui-icon", 15);
            i0.ɵɵtext(22);
            i0.ɵɵpipe(23, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(24, "button", 16);
            i0.ɵɵlistener("click", function EditReportComponent_Template_button_click_24_listener() { return ctx.createNew(); });
            i0.ɵɵelement(25, "eui-icon", 17);
            i0.ɵɵtext(26);
            i0.ɵɵpipe(27, "translate");
            i0.ɵɵelementEnd()()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(10);
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 16, "#LDS#Heading Reports"));
            i0.ɵɵadvance(5);
            i0.ɵɵproperty("options", i0.ɵɵpureFunction0(24, _c1))("settings", ctx.dstSettings)("busyService", ctx.busyService)("alwaysVisible", true);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0)("detailViewVisible", false)("selectable", true)("showSelectedItemsMenu", false)("noDataText", i0.ɵɵpipeBind1(13, 18, "#LDS#There are currently no reports."));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("selectedElements", ctx.selectedReports);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", !ctx.canDeleteSelected());
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(23, 20, "#LDS#Delete"), " ");
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(27, 22, "#LDS#Create report"), " ");
        }
    }, dependencies: [i1.DataSourceToolbarComponent, i1.DataSourcePaginatorComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i1$1.EuiIconComponent, i4$1.MatButton, i9.MatCard, i1.SelectedElementsComponent, i1.HelpContextualComponent, i3$2.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.heading-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:row;flex:0 0 auto}.heading-wrapper[_ngcontent-%COMP%]   .helper-alert[_ngcontent-%COMP%]{display:flex;margin-bottom:15px}.heading-wrapper[_ngcontent-%COMP%]   .alert-wrapper[_ngcontent-%COMP%]{margin:0 0 0 auto;align-self:flex-end;width:50%}[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:100%;max-width:100%}.imx-content-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:3px}.imx-reports-page[_ngcontent-%COMP%]{background-color:inherit;overflow:hidden;display:flex;flex-direction:column;flex:1 1 auto}.imx-reports-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto}.imx-reports-page[_ngcontent-%COMP%]   div.imx-table-container[_ngcontent-%COMP%]   .imx-reports-table[_ngcontent-%COMP%]{flex-grow:1;overflow:auto}.imx-reports-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-reports-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]:not(:last-of-type){margin-right:16px}.imx-reports-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .imx-menu-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.imx-reports-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%], .imx-reports-page[_ngcontent-%COMP%]   .imx-button-bar[_ngcontent-%COMP%]   .mat-raised-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}@media screen and (max-width: 768px){.imx-reports-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]{display:block}.imx-reports-page[_ngcontent-%COMP%]   .heading-wrapper[_ngcontent-%COMP%]   .alert-wrapper[_ngcontent-%COMP%]{margin:0 0 20px;width:100%}}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportComponent, [{
            type: Component,
            args: [{ template: "<div class=\"imx-reports-page\">\r\n  <div class=\"heading-wrapper\">\r\n    <h2 class=\"mat-headline\">\r\n      <span>{{ '#LDS#Heading Reports' | translate }}</span>\r\n      <imx-help-contextual></imx-help-contextual>\r\n    </h2>\r\n  </div>\r\n  <mat-card class=\"imx-content-card\">\r\n    <div class=\"imx-table-container\">\r\n      <imx-data-source-toolbar\r\n        #dst\r\n        [options]=\"['search']\"\r\n        [settings]=\"dstSettings\"\r\n        [busyService]=\"busyService\"\r\n        [alwaysVisible]=\"true\"\r\n        (search)=\"getData({ search: $event })\"\r\n        (navigationStateChanged)=\"getData($event)\"\r\n        data-imx-identifier=\"report-dst\"\r\n      >\r\n      </imx-data-source-toolbar>\r\n      <imx-data-table\r\n        #dataTable\r\n        [dst]=\"dst\"\r\n        class=\"imx-reports-table\"\r\n        [detailViewVisible]=\"false\"\r\n        mode=\"manual\"\r\n        (highlightedEntityChanged)=\"viewDetails($event)\"\r\n        [selectable]=\"true\"\r\n        [showSelectedItemsMenu]=\"false\"\r\n        (selectionChanged)=\"onSelectionChanged($event)\"\r\n        [noDataText]=\"'#LDS#There are currently no reports.' | translate\"\r\n        data-imx-identifier=\"report-datatable\"\r\n      >\r\n        <imx-data-table-column data-imx-identifier=\"report-table-column-display\" [entityColumn]=\"entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n          <ng-template let-item>\r\n            <div data-imx-identifier=\"report-table-display\">{{ item.GetEntity().GetDisplay() }}</div>\r\n            <div subtitle data-imx-identifier=\"report-table-description\">{{ item.Description.Column.GetDisplayValue() }}</div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n      </imx-data-table>\r\n      <imx-data-source-paginator data-imx-identifier=\"report-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\r\n    </div>\r\n  </mat-card>\r\n\r\n  <div class=\"imx-button-bar\">\r\n    <imx-selected-elements [selectedElements]=\"selectedReports\"></imx-selected-elements>\r\n    <div class=\"imx-menu-spacer\"></div>\r\n    <button mat-stroked-button color=\"warn\" [disabled]=\"!canDeleteSelected()\" (click)=\"deleteSelected()\">\r\n      <eui-icon icon=\"delete\"></eui-icon>\r\n      {{ '#LDS#Delete' | translate }}\r\n    </button>\r\n    <button mat-raised-button color=\"primary\" (click)=\"createNew()\">\r\n      <eui-icon icon=\"add\"></eui-icon>\r\n      {{ '#LDS#Create report' | translate }}\r\n    </button>\r\n  </div>\r\n</div>\r\n", styles: [".eui-sidesheet-content{display:flex;flex-direction:column}.heading-wrapper{display:flex;flex-direction:row;flex:0 0 auto}.heading-wrapper .helper-alert{display:flex;margin-bottom:15px}.heading-wrapper .alert-wrapper{margin:0 0 0 auto;align-self:flex-end;width:50%}:host{display:flex;flex-direction:column;overflow:hidden;height:100%;max-width:100%}.imx-content-card{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden;margin:3px}.imx-reports-page{background-color:inherit;overflow:hidden;display:flex;flex-direction:column;flex:1 1 auto}.imx-reports-page div.imx-table-container{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto}.imx-reports-page div.imx-table-container .imx-reports-table{flex-grow:1;overflow:auto}.imx-reports-page .imx-button-bar{display:flex;flex-direction:row;justify-content:flex-end;margin-top:16px}.imx-reports-page .imx-button-bar>button:not(:last-of-type){margin-right:16px}.imx-reports-page .imx-button-bar .imx-menu-spacer{flex:1 1 auto}.imx-reports-page .imx-button-bar .mat-stroked-button eui-icon,.imx-reports-page .imx-button-bar .mat-raised-button eui-icon{font-size:14px;margin-right:4px}@media screen and (max-width: 768px){.imx-reports-page .heading-wrapper{display:block}.imx-reports-page .heading-wrapper .alert-wrapper{margin:0 0 20px;width:100%}}\n"] }]
        }], function () { return [{ type: EditReportService }, { type: i1$1.EuiLoadingService }, { type: i1$1.EuiSidesheetService }, { type: i3$2.TranslateService }, { type: i1.ConfirmationService }, { type: RpsPermissionsService }, { type: i1.SnackBarService }, { type: i1.HelpContextualService }]; }, { reportsTable: [{
                type: ViewChild,
                args: ['dataTable']
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class EditReportModule {
    constructor(menuService) {
        this.menuService = menuService;
        this.setupMenu();
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, features) => {
            const items = [];
            if (preProps.includes('REPORT_SUBSCRIPTION')) {
                items.push({
                    id: 'RPS_Reports',
                    navigationCommands: {
                        commands: ['reports']
                    },
                    title: '#LDS#Menu Entry Reports',
                    sorting: '60-70',
                });
            }
            if (items.length === 0) {
                return null;
            }
            return {
                id: 'ROOT_Setup',
                title: '#LDS#Setup',
                sorting: '60',
                items
            };
        });
    }
}
EditReportModule.ɵfac = function EditReportModule_Factory(t) { return new (t || EditReportModule)(i0.ɵɵinject(i1.MenuService)); };
EditReportModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: EditReportModule });
EditReportModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        {
            // This does not work for some reason!
            provide: SqlWizardApiService,
            useClass: EditReportSqlWizardService
        },
        RpsPermissionsService
    ], imports: [CdrModule,
        CommonModule,
        DataSourceToolbarModule,
        DataTableModule,
        DragDropModule,
        EuiCoreModule,
        EuiMaterialModule,
        FormsModule,
        MatCardModule,
        OrderedListModule,
        ReactiveFormsModule,
        TranslateModule,
        SqlWizardModule,
        SelectedElementsModule,
        HelpContextualModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(EditReportModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        EditReportComponent,
                        EditReportSidesheetComponent
                    ],
                    providers: [
                        {
                            // This does not work for some reason!
                            provide: SqlWizardApiService,
                            useClass: EditReportSqlWizardService
                        },
                        RpsPermissionsService
                    ],
                    imports: [
                        CdrModule,
                        CommonModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        DragDropModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        FormsModule,
                        MatCardModule,
                        OrderedListModule,
                        ReactiveFormsModule,
                        TranslateModule,
                        SqlWizardModule,
                        SelectedElementsModule,
                        HelpContextualModule,
                    ]
                }]
        }], function () { return [{ type: i1.MenuService }]; }, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(EditReportModule, { declarations: [EditReportComponent,
            EditReportSidesheetComponent], imports: [CdrModule,
            CommonModule,
            DataSourceToolbarModule,
            DataTableModule,
            DragDropModule,
            EuiCoreModule,
            EuiMaterialModule,
            FormsModule,
            MatCardModule,
            OrderedListModule,
            ReactiveFormsModule,
            TranslateModule,
            SqlWizardModule,
            SelectedElementsModule,
            HelpContextualModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ParameterSidesheetComponent_imx_cdr_editor_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r4 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 6);
        i0.ɵɵlistener("controlCreated", function ParameterSidesheetComponent_imx_cdr_editor_3_Template_imx_cdr_editor_controlCreated_0_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r4); const cdr_r2 = restoredCtx.$implicit; const ctx_r3 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r3.addFormControl(cdr_r2.column.columnName, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r2 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r2);
    }
}
function ParameterSidesheetComponent_mat_spinner_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner", 7);
    }
}
class ParameterSidesheetComponent {
    constructor(sidesheetRef, changeDetectorRef, data, logger) {
        this.sidesheetRef = sidesheetRef;
        this.changeDetectorRef = changeDetectorRef;
        this.data = data;
        this.reportFormGroup = new UntypedFormGroup({});
        this.writeOperators = 1;
        this.cdrs = data.subscription.getParameterCdr();
        data.subscription.reportEntityWrapper.startWriteData.subscribe(() => {
            this.writeOperators = this.writeOperators + 1;
            logger.debug(this, 'number of write operations:', this.writeOperators);
            changeDetectorRef.detectChanges();
        });
        data.subscription.reportEntityWrapper.endWriteData.subscribe(() => {
            this.writeOperators = this.writeOperators - 1;
            logger.debug(this, 'number of write operations:', this.writeOperators);
            changeDetectorRef.detectChanges();
        });
    }
    addFormControl(name, control) {
        this.reportFormGroup.addControl(name, control);
        this.changeDetectorRef.detectChanges();
    }
    viewReport() {
        this.sidesheetRef.close(true);
    }
}
ParameterSidesheetComponent.ɵfac = function ParameterSidesheetComponent_Factory(t) { return new (t || ParameterSidesheetComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i1.ClassloggerService)); };
ParameterSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ParameterSidesheetComponent, selectors: [["imx-parameter-sidesheet"]], decls: 9, vars: 7, consts: [["eui-sidesheet-content", ""], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], ["diameter", "30", 4, "ngIf"], ["data-imx-identifier", "parameter-sidesheet-show-report-button", "mat-raised-button", "", "color", "primary", 3, "disabled", "click"], [3, "cdr", "controlCreated"], ["diameter", "30"]], template: function ParameterSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-card")(2, "form", 1);
            i0.ɵɵtemplate(3, ParameterSidesheetComponent_imx_cdr_editor_3_Template, 1, 1, "imx-cdr-editor", 2);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(4, "div", 3);
            i0.ɵɵtemplate(5, ParameterSidesheetComponent_mat_spinner_5_Template, 1, 0, "mat-spinner", 4);
            i0.ɵɵelementStart(6, "button", 5);
            i0.ɵɵlistener("click", function ParameterSidesheetComponent_Template_button_click_6_listener() { return ctx.viewReport(); });
            i0.ɵɵtext(7);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("formGroup", ctx.reportFormGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.cdrs);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.writeOperators > 0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("disabled", ctx.reportFormGroup.invalid || ctx.writeOperators > 0);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(8, 5, "#LDS#View report"));
        }
    }, dependencies: [i3$1.NgForOf, i3$1.NgIf, i1.CdrEditorComponent, i4$1.MatButton, i8.MatProgressSpinner, i9.MatCard, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i10.ɵNgNoValidate, i10.NgControlStatusGroup, i10.FormGroupDirective, i3$2.TranslatePipe], styles: [".mat-spinner[_ngcontent-%COMP%]{margin-right:10px;align-self:center}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ParameterSidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-parameter-sidesheet', template: "<div eui-sidesheet-content>\r\n  <mat-card>\r\n    <form [formGroup]=\"reportFormGroup\">\r\n      <imx-cdr-editor *ngFor=\"let cdr of cdrs\" [cdr]=\"cdr\" (controlCreated)=\"addFormControl(cdr.column.columnName, $event)\">\r\n      </imx-cdr-editor>\r\n    </form>\r\n  </mat-card>  \r\n</div>\r\n<div eui-sidesheet-actions>\r\n  <mat-spinner diameter=\"30\" *ngIf=\"writeOperators>0\"></mat-spinner>\r\n  <button data-imx-identifier=\"parameter-sidesheet-show-report-button\" mat-raised-button color=\"primary\" [disabled]=\"reportFormGroup.invalid || writeOperators > 0\" (click)=\"viewReport()\">{{'#LDS#View report' |translate}}</button>\r\n</div>", styles: [".mat-spinner{margin-right:10px;align-self:center}\n"] }]
        }], function () {
        return [{ type: i1$1.EuiSidesheetRef }, { type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i1.ClassloggerService }];
    }, null);
})();

function ReportButtonComponent_button_0_Template(rf, ctx) {
    if (rf & 1) {
        const _r2 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 1);
        i0.ɵɵlistener("click", function ReportButtonComponent_button_0_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.viewReport()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, ctx_r0.inputData.caption), "\n");
    }
}
class ReportButtonComponent {
    constructor(elementalUiConfigService, config, http, injector, reportSubscriptionService, overlay, busy, system, sideSheet, translator, userModelService) {
        this.elementalUiConfigService = elementalUiConfigService;
        this.config = config;
        this.http = http;
        this.injector = injector;
        this.reportSubscriptionService = reportSubscriptionService;
        this.overlay = overlay;
        this.busy = busy;
        this.system = system;
        this.sideSheet = sideSheet;
        this.translator = translator;
        this.userModelService = userModelService;
        this.isButtonRendered = true;
        this.apiMethodFactory = new V2ApiClientMethodFactory();
    }
    ngOnDestroy() {
        var _a;
        (_a = this.subscription) === null || _a === void 0 ? void 0 : _a.unsubscribeEvents;
    }
    ngOnInit() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            if (this.inputData.groups == null && this.inputData.preprop == null) {
                this.isButtonRendered = true;
                return;
            }
            const over = this.busy.show();
            try {
                const info = yield this.system.get();
                const user = (yield this.userModelService.getGroups()).map((elem) => elem.Name);
                const userFeatures = (yield this.userModelService.getFeatures()).Features;
                const pre = this.inputData.preprop == null ||
                    this.inputData.preprop.some((elem) => info.PreProps.find((item) => item.toUpperCase() === elem.toUpperCase()) != null);
                const groups = this.inputData.groups == null ||
                    this.inputData.groups.some((elem) => user.find((item) => item.toUpperCase() === elem.toUpperCase()) != null);
                const features = (_a = this.inputData) === null || _a === void 0 ? void 0 : _a.features.some(feature => userFeatures.find(userFeature => feature === userFeature) != null);
                this.isButtonRendered = pre && (groups || features);
            }
            finally {
                this.busy.hide(over);
            }
        });
    }
    viewReport() {
        return __awaiter(this, void 0, void 0, function* () {
            const over = this.busy.show();
            try {
                if (this.subscription != null) {
                    this.subscription.unsubscribeEvents();
                    this.subscription = null;
                }
                this.subscription = yield this.reportSubscriptionService.createNewSubscription(this.inputData.uidReport);
            }
            finally {
                this.busy.hide(over);
            }
            if (!this.subscription) {
                return;
            }
            this.subscription.subscription.ExportFormat.value = 'PDF';
            if (this.subscription.hasParameter) {
                const result = yield this.sideSheet
                    .open(ParameterSidesheetComponent, {
                    title: yield this.translator.get('#LDS#Heading Specify Parameters').toPromise(),
                    subTitle: yield this.translator.get(this.inputData.caption).toPromise(),
                    padding: '0px',
                    width: 'max(600px,60%)',
                    testId: 'report-button-view-parameter-sidesheet',
                    data: { subscription: this.subscription },
                })
                    .afterClosed()
                    .toPromise();
                if (!result) {
                    return;
                }
            }
            const parameters = this.subscription.subscription.enrichMethodCallParameters();
            const def = new MethodDefinition(this.apiMethodFactory.portal_subscription_interactive_report_get(parameters.entityid, parameters));
            // not pretty, but the download directive does not support dynamic URLs
            const directive = new EuiDownloadDirective(null /* no element */, this.http, this.overlay, this.injector);
            directive.downloadOptions = Object.assign(Object.assign({}, this.elementalUiConfigService.Config.downloadOptions), { fileMimeType: '', url: this.config.BaseUrl + def.path, disableElement: false });
            // start the report download
            directive.onClick();
        });
    }
}
ReportButtonComponent.ɵfac = function ReportButtonComponent_Factory(t) { return new (t || ReportButtonComponent)(i0.ɵɵdirectiveInject(i1.ElementalUiConfigService), i0.ɵɵdirectiveInject(i1.AppConfigService), i0.ɵɵdirectiveInject(i3.HttpClient), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(ReportSubscriptionService), i0.ɵɵdirectiveInject(i4.Overlay), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i1.SystemInfoService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$2.TranslateService), i0.ɵɵdirectiveInject(i5.UserModelService)); };
ReportButtonComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportButtonComponent, selectors: [["imx-report-button"]], decls: 1, vars: 1, consts: [["mat-menu-item", "", "data-imx-identifier", "report-button-ext-menu-item", 3, "click", 4, "ngIf"], ["mat-menu-item", "", "data-imx-identifier", "report-button-ext-menu-item", 3, "click"]], template: function ReportButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, ReportButtonComponent_button_0_Template, 3, 3, "button", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.isButtonRendered);
        }
    }, dependencies: [i3$1.NgIf, i10$1.MatMenuItem, i3$2.TranslatePipe] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonComponent, [{
            type: Component,
            args: [{ selector: 'imx-report-button', template: "<button *ngIf=\"isButtonRendered\" mat-menu-item data-imx-identifier=\"report-button-ext-menu-item\" (click)=\"viewReport()\">\r\n  {{inputData.caption | translate}}\r\n</button>" }]
        }], function () { return [{ type: i1.ElementalUiConfigService }, { type: i1.AppConfigService }, { type: i3.HttpClient }, { type: i0.Injector }, { type: ReportSubscriptionService }, { type: i4.Overlay }, { type: i1$1.EuiLoadingService }, { type: i1.SystemInfoService }, { type: i1$1.EuiSidesheetService }, { type: i3$2.TranslateService }, { type: i5.UserModelService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportButtonModule {
}
ReportButtonModule.ɵfac = function ReportButtonModule_Factory(t) { return new (t || ReportButtonModule)(); };
ReportButtonModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ReportButtonModule });
ReportButtonModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        CdrModule,
        MatMenuModule,
        MatButtonModule,
        MatProgressSpinnerModule,
        MatCardModule,
        EuiCoreModule,
        TranslateModule,
        ReactiveFormsModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonModule, [{
            type: NgModule,
            args: [{
                    declarations: [ReportButtonComponent, ParameterSidesheetComponent],
                    imports: [
                        CommonModule,
                        CdrModule,
                        MatMenuModule,
                        MatButtonModule,
                        MatProgressSpinnerModule,
                        MatCardModule,
                        EuiCoreModule,
                        TranslateModule,
                        ReactiveFormsModule
                    ],
                    exports: [ReportButtonComponent]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ReportButtonModule, { declarations: [ReportButtonComponent, ParameterSidesheetComponent], imports: [CommonModule,
            CdrModule,
            MatMenuModule,
            MatButtonModule,
            MatProgressSpinnerModule,
            MatCardModule,
            EuiCoreModule,
            TranslateModule,
            ReactiveFormsModule], exports: [ReportButtonComponent] });
})();

/**
 * Implements a {@link ListReportDataProvider} to get the list report data for a statistic
 */
class StatisticReportButtonService {
    constructor(api) {
        this.api = api;
    }
    /**
     * Sets the statistic id used by this service
     * @param value the id of a statistic
     */
    setIdStatistic(value) {
        this.idStatistic = value;
    }
    get entitySchema() {
        return this.api.typedClient.PortalStatisticsData.GetSchema();
    }
    getDataModel() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.idStatistic) {
                throw 'setIdStatistic(...) has to be called with a valid id';
            }
            return this.api.client.portal_statistics_data_datamodel_get(this.idStatistic);
        });
    }
    get(param) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.idStatistic) {
                throw 'setIdStatistic(...) has to be called with a valid id';
            }
            return this.api.typedClient.PortalStatisticsData.Get(this.idStatistic, param);
        });
    }
    getGroupInfo(parameters = {}) {
        if (!this.idStatistic) {
            throw 'setIdStatistic(...) has to be called with a valid id';
        }
        const { withProperties, OrderBy, search } = parameters, params = __rest(parameters, ["withProperties", "OrderBy", "search"]);
        return this.api.client.portal_statistics_data_group_get(this.idStatistic, Object.assign({}, params));
    }
}
StatisticReportButtonService.ɵfac = function StatisticReportButtonService_Factory(t) { return new (t || StatisticReportButtonService)(i0.ɵɵinject(RpsApiService)); };
StatisticReportButtonService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: StatisticReportButtonService, factory: StatisticReportButtonService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StatisticReportButtonService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: RpsApiService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function StatisticReportButtonComponent_button_0_Template(rf, ctx) {
    if (rf & 1) {
        const _r2 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 1);
        i0.ɵɵlistener("click", function StatisticReportButtonComponent_button_0_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.viewReport()); });
        i0.ɵɵelement(1, "eui-icon", 2);
        i0.ɵɵelementStart(2, "span", 3);
        i0.ɵɵtext(3, "#LDS#View report");
        i0.ɵɵelementEnd()();
    }
}
class StatisticReportButtonComponent {
    constructor(statisticService, sideSheet, translate) {
        this.statisticService = statisticService;
        this.sideSheet = sideSheet;
        this.translate = translate;
    }
    /**
     * Shows the related list report data in a {@link ListReportViewerSidesheetComponent} sidesheet
     */
    viewReport() {
        this.statisticService.setIdStatistic(this.referrer.Id.value);
        const data = { dataService: this.statisticService };
        this.sideSheet.open(ListReportViewerSidesheetComponent, {
            title: this.translate.instant('#LDS#Heading View Report'),
            subTitle: this.referrer.GetDisplay(),
            padding: '0',
            width: 'max(550px,55%)',
            testId: 'statistic-report-button-report-viewer',
            data,
        });
    }
}
StatisticReportButtonComponent.ɵfac = function StatisticReportButtonComponent_Factory(t) { return new (t || StatisticReportButtonComponent)(i0.ɵɵdirectiveInject(StatisticReportButtonService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i3$2.TranslateService)); };
StatisticReportButtonComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: StatisticReportButtonComponent, selectors: [["imx-statistic-report-button"]], decls: 1, vars: 1, consts: [["mat-raised-button", "", 3, "click", 4, "ngIf"], ["mat-raised-button", "", 3, "click"], ["icon", "reports"], ["translate", ""]], template: function StatisticReportButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, StatisticReportButtonComponent_button_0_Template, 4, 0, "button", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.referrer.HasListReport == null ? null : ctx.referrer.HasListReport.value);
        }
    }, dependencies: [i3$1.NgIf, i4$1.MatButton, i3$2.TranslateDirective, i1$1.EuiIconComponent], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:row}[_nghost-%COMP%]   button[_ngcontent-%COMP%]{display:flex;box-shadow:0 1px 1px #00000024,0 2px 1px #0000001f,0 1px 3px #0003;transition:all .4s ease}[_nghost-%COMP%]   button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{margin-right:4px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StatisticReportButtonComponent, [{
            type: Component,
            args: [{ selector: 'imx-statistic-report-button', template: "<button mat-raised-button (click)=\"viewReport()\" *ngIf=\"referrer.HasListReport?.value\">\r\n  <eui-icon icon=\"reports\"></eui-icon>\r\n  <span translate>#LDS#View report</span>\r\n</button>", styles: [":host{display:flex;flex-direction:row}:host button{display:flex;box-shadow:0 1px 1px #00000024,0 2px 1px #0000001f,0 1px 3px #0003;transition:all .4s ease}:host button eui-icon{margin-right:4px}\n"] }]
        }], function () { return [{ type: StatisticReportButtonService }, { type: i1$1.EuiSidesheetService }, { type: i3$2.TranslateService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class StatisticReportButtonModule {
}
StatisticReportButtonModule.ɵfac = function StatisticReportButtonModule_Factory(t) { return new (t || StatisticReportButtonModule)(); };
StatisticReportButtonModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: StatisticReportButtonModule });
StatisticReportButtonModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule, MatButtonModule, TranslateModule, EuiCoreModule, MatProgressSpinnerModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(StatisticReportButtonModule, [{
            type: NgModule,
            args: [{
                    declarations: [StatisticReportButtonComponent],
                    imports: [CommonModule, MatButtonModule, TranslateModule, EuiCoreModule, MatProgressSpinnerModule],
                }]
        }], null, null);
})();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(StatisticReportButtonModule, { declarations: [StatisticReportButtonComponent], imports: [CommonModule, MatButtonModule, TranslateModule, EuiCoreModule, MatProgressSpinnerModule] }); })();

class InitService {
    constructor(router, entlTypeService, apiService, dynamicMethodService, extService) {
        this.router = router;
        this.entlTypeService = entlTypeService;
        this.apiService = apiService;
        this.dynamicMethodService = dynamicMethodService;
        this.extService = extService;
    }
    onInit(routes) {
        this.addRoutes(routes);
        this.extService.register('profile', {
            instance: SubscriptionsComponent,
            inputData: {
                id: 'subscriptions',
                label: '#LDS#Heading Report Subscriptions',
                checkVisibility: (_) => __awaiter(this, void 0, void 0, function* () { return true; }),
            },
            SortOrder: 0,
        });
        this.extService.register('identityReportsManager', {
            instance: ReportButtonComponent,
            inputData: {
                uidReport: 'CPL-77d3c04ac2084a968433ef7daf7e56ff',
                caption: '#LDS#Download report on rule violations by identities you are directly responsible for',
                preprop: ['COMPLIANCE'],
                features: ['Portal_UI_PersonManager']
            }
        });
        this.extService.register('statisticButton', {
            instance: StatisticReportButtonComponent
        });
        // FIXME Add auditor and fix report button component
        this.extService.register('identityReports', {
            instance: ReportButtonComponent,
            inputData: {
                uidReport: 'TSB-C1848795DA424F46B2ACC101888361B1',
                caption: '#LDS#Compare identities',
                preprop: undefined,
                features: ['Portal_UI_PersonAdmin', 'Portal_UI_PersonManager'],
                groups: ['VI_4_AUDITING_AUDITOR']
            }
        });
        this.extService.register('identityReportsManager', {
            instance: ReportButtonComponent,
            inputData: {
                uidReport: 'TSB-0D509AC9C160394693CEF814A9CE1FD0',
                caption: '#LDS#Compare identities who report directly to you',
                preprop: undefined,
                features: ['Portal_UI_PersonAdmin', 'Portal_UI_PersonManager']
            }
        });
        this.extService.register('identityReportsManager', {
            instance: ReportButtonComponent,
            inputData: {
                uidReport: 'TSB-1BDEF479FF239A47BCA4EBEFC899C006',
                caption: '#LDS#Compare identities who report to you (directly and indirectly)',
                preprop: undefined,
                features: ['Portal_UI_PersonAdmin', 'Portal_UI_PersonManager']
            }
        });
        this.entlTypeService.Register(() => __awaiter(this, void 0, void 0, function* () {
            return [
                new RequestableEntitlementType('RPSReport', this.apiService.apiClient, 'UID_RPSReport', this.dynamicMethodService),
            ];
        }));
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i1$2.Router), i0.ɵɵinject(i5.RequestableEntitlementTypeService), i0.ɵɵinject(RpsApiService), i0.ɵɵinject(i1.DynamicMethodService), i0.ɵɵinject(i1.ExtService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i1$2.Router }, { type: i5.RequestableEntitlementTypeService }, { type: RpsApiService }, { type: i1.DynamicMethodService }, { type: i1.ExtService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'reports',
        component: EditReportComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.Reports
        }
    }
];
class RpsConfigModule {
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 RPS loaded');
        this.initializer.onInit(routes);
        console.log('▶️ RPS initialized');
    }
}
RpsConfigModule.ɵfac = function RpsConfigModule_Factory(t) { return new (t || RpsConfigModule)(i0.ɵɵinject(InitService)); };
RpsConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: RpsConfigModule });
RpsConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [EditReportModule,
        SubscriptionsModule,
        ReportButtonModule,
        StatisticReportButtonModule,
        RouterModule.forChild(routes)] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RpsConfigModule, [{
            type: NgModule,
            args: [{
                    imports: [
                        EditReportModule,
                        SubscriptionsModule,
                        ReportButtonModule,
                        StatisticReportButtonModule,
                        RouterModule.forChild(routes)
                    ]
                }]
        }], function () { return [{ type: InitService }]; }, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RpsConfigModule, { imports: [EditReportModule,
            SubscriptionsModule,
            ReportButtonModule,
            StatisticReportButtonModule, i1$2.RouterModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of rps
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ReportButtonComponent, ReportButtonModule, RpsConfigModule, SubscriptionsComponent, SubscriptionsModule };
//# sourceMappingURL=rps.mjs.map
