export declare function isRpsAdmin(groups: string[]): boolean;
