import { UserModelService } from 'qer';
import * as i0 from "@angular/core";
export declare class RpsPermissionsService {
    private readonly userService;
    constructor(userService: UserModelService);
    isRpsAdmin(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RpsPermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RpsPermissionsService>;
}
