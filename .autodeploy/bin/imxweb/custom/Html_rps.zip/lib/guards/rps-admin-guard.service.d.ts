import { OnDestroy } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AppConfigService, AuthenticationService } from 'qbm';
import { RpsPermissionsService } from '../admin/rps-permissions.service';
import * as i0 from "@angular/core";
export declare class RpsAdminGuardService implements CanActivate, OnDestroy {
    private readonly rpsPermissionService;
    private readonly authentication;
    private readonly appConfig;
    private readonly router;
    private onSessionResponse;
    constructor(rpsPermissionService: RpsPermissionsService, authentication: AuthenticationService, appConfig: AppConfigService, router: Router);
    canActivate(): Observable<boolean>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RpsAdminGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RpsAdminGuardService>;
}
