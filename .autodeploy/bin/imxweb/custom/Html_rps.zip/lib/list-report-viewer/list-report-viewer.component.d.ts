import { OnInit } from '@angular/core';
import { CollectionLoadParameters, EntitySchema } from 'imx-qbm-dbts';
import { BusyService, ClassloggerService, DataSourceToolbarGroupData, DataSourceToolbarSettings } from 'qbm';
import { ListReportDataProvider } from './list-report-data-provider.interface';
import * as i0 from "@angular/core";
/**
 * A component, that displays the data of a list report
 *
 * Example:
 * code behind:
 *          dataService:ListReportDataProvider = {...};
 *          reportParameter:{ [key: string]: any } = {...};
 * html:
 *          <imx-list-report-viewer [dataService]="dataService" [reportParameter]="reportParameter"></imx-list-report-viewer>
 */
export declare class ListReportViewerComponent implements OnInit {
    private logger;
    /**
     * the data service, that is used for API communication
     */
    dataService: ListReportDataProvider;
    /**
     * Report parameter, that are necessary for the report generation
     */
    reportParameter: {
        [key: string]: any;
    };
    busyService: BusyService;
    dstSettings: DataSourceToolbarSettings;
    entitySchema: EntitySchema;
    groupData: DataSourceToolbarGroupData;
    private dataModel;
    private reportColumns;
    private navigationState;
    constructor(logger: ClassloggerService);
    ngOnInit(): Promise<void>;
    /**
     * Updates the search parameter and navigates
     * @param key: the keyword, that should be searched for
     */
    onSearch(key: string): Promise<void>;
    /**
     * Updates the navigation state and navigates
     * @param newState: the new navigation state
     */
    onNavigationStateChanged(newState: CollectionLoadParameters): Promise<void>;
    /**
     * Is called, if the grouping changed.
     * Updates the grouping navigation state and navigates
     * @param groupKey the gouping keyword
     */
    onGroupingChange(groupInfo: {
        key: string;
        isInitial: boolean;
    }): Promise<void>;
    /**
     * navigates the list report data
     */
    private navigate;
    /**
     * Initializes the data, that is used for the view
     */
    private initData;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListReportViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListReportViewerComponent, "imx-list-report-viewer", never, { "dataService": "dataService"; "reportParameter": "reportParameter"; }, {}, never, never, false>;
}
