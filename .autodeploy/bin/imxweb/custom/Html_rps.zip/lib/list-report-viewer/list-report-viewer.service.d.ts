import { ListReportContentData, PortalReportData } from 'imx-api-rps';
import { CollectionLoadParameters, DataModel, EntitySchema, ExtendedTypedEntityCollection, GroupInfoData } from 'imx-qbm-dbts';
import { DataSourceToolbarExportMethod } from 'qbm';
import { RpsApiService } from '../rps-api-client.service';
import { ListReportDataProvider } from './list-report-data-provider.interface';
import * as i0 from "@angular/core";
/**
 * Implements a {@link ListReportDataProvider} to get the list report data for a given report id
 */
export declare class ListReportViewerService implements ListReportDataProvider {
    private readonly api;
    constructor(api: RpsApiService);
    private uidReport;
    /**
     * Sets the uid of the report used by this service
     * @param value the uid of a list report
     */
    setUidReport(value: string): void;
    get entitySchema(): EntitySchema;
    getDataModel(): Promise<DataModel>;
    get(parameter: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalReportData, ListReportContentData>>;
    getGroupInfo(parameters?: {
        by?: string;
        def?: string;
    } & CollectionLoadParameters): Promise<GroupInfoData>;
    exportReports(parameters: CollectionLoadParameters): DataSourceToolbarExportMethod;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListReportViewerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ListReportViewerService>;
}
