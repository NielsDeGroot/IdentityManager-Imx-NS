import { ChangeDetectorRef } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { EuiSidesheetRef } from '@elemental-ui/core';
import { ClassloggerService, ColumnDependentReference } from 'qbm';
import { ReportSubscription } from '../../subscriptions/report-subscription/report-subscription';
import * as i0 from "@angular/core";
export declare class ParameterSidesheetComponent {
    private readonly sidesheetRef;
    private readonly changeDetectorRef;
    readonly data: {
        subscription: ReportSubscription;
    };
    readonly reportFormGroup: UntypedFormGroup;
    cdrs: ColumnDependentReference[];
    writeOperators: number;
    constructor(sidesheetRef: EuiSidesheetRef, changeDetectorRef: ChangeDetectorRef, data: {
        subscription: ReportSubscription;
    }, logger: ClassloggerService);
    addFormControl(name: string, control: UntypedFormControl): void;
    viewReport(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParameterSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ParameterSidesheetComponent, "imx-parameter-sidesheet", never, {}, {}, never, never, false>;
}
