import * as i0 from "@angular/core";
import * as i1 from "./report-button.component";
import * as i2 from "./parameter-sidesheet/parameter-sidesheet.component";
import * as i3 from "@angular/common";
import * as i4 from "qbm";
import * as i5 from "@angular/material/menu";
import * as i6 from "@angular/material/button";
import * as i7 from "@angular/material/progress-spinner";
import * as i8 from "@angular/material/card";
import * as i9 from "@elemental-ui/core";
import * as i10 from "@ngx-translate/core";
import * as i11 from "@angular/forms";
export declare class ReportButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReportButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReportButtonModule, [typeof i1.ReportButtonComponent, typeof i2.ParameterSidesheetComponent], [typeof i3.CommonModule, typeof i4.CdrModule, typeof i5.MatMenuModule, typeof i6.MatButtonModule, typeof i7.MatProgressSpinnerModule, typeof i8.MatCardModule, typeof i9.EuiCoreModule, typeof i10.TranslateModule, typeof i11.ReactiveFormsModule], [typeof i1.ReportButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReportButtonModule>;
}
