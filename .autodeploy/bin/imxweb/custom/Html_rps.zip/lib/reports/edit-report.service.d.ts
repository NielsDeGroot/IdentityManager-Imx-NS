import { ListReportDefinitionRead, PortalReports, PortalReportsEditInteractive } from 'imx-api-rps';
import { CollectionLoadParameters, ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { RpsApiService } from '../rps-api-client.service';
import * as i0 from "@angular/core";
export declare class EditReportService {
    private readonly api;
    constructor(api: RpsApiService);
    reportSchema: import("imx-qbm-dbts").StaticSchema<"Description" | "IsListReport" | "Ident_RPSReport" | "AvailableTo">;
    getReport(id: string): Promise<ExtendedTypedEntityCollection<PortalReportsEditInteractive, ListReportDefinitionRead>>;
    createNew(): Promise<ExtendedTypedEntityCollection<PortalReportsEditInteractive, ListReportDefinitionRead>>;
    getReportsOwnedByUser(navigationState?: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalReports, unknown>>;
    getAllReports(navigationState?: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalReports, unknown>>;
    deleteReport(report: PortalReports): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditReportService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EditReportService>;
}
