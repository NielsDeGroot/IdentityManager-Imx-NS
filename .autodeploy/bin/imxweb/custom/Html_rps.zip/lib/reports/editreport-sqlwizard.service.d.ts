import { CollectionLoadParameters, EntityCollectionData, FilterProperty } from "imx-qbm-dbts";
import { SqlWizardApiService } from "qbm";
import { RpsApiService } from "../rps-api-client.service";
import * as i0 from "@angular/core";
export declare class EditReportSqlWizardService implements SqlWizardApiService {
    private readonly api;
    constructor(api: RpsApiService);
    getFilterProperties(table: string): Promise<FilterProperty[]>;
    getCandidates(parentTable: string, options?: CollectionLoadParameters): Promise<EntityCollectionData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditReportSqlWizardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EditReportSqlWizardService>;
}
