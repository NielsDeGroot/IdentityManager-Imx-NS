import * as i0 from "@angular/core";
import * as i1 from "./statistic-report-button.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/button";
import * as i4 from "@ngx-translate/core";
import * as i5 from "@elemental-ui/core";
import * as i6 from "@angular/material/progress-spinner";
export declare class StatisticReportButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StatisticReportButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StatisticReportButtonModule, [typeof i1.StatisticReportButtonComponent], [typeof i2.CommonModule, typeof i3.MatButtonModule, typeof i4.TranslateModule, typeof i5.EuiCoreModule, typeof i6.MatProgressSpinnerModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StatisticReportButtonModule>;
}
