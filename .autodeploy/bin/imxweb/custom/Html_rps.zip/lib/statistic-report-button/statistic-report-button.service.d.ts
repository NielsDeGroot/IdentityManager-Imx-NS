import { CollectionLoadParameters, DataModel, EntitySchema, ExtendedTypedEntityCollection, GroupInfoData } from 'imx-qbm-dbts';
import { ListReportContentData, PortalReportData } from 'imx-api-rps';
import { RpsApiService } from '../rps-api-client.service';
import { ListReportDataProvider } from '../list-report-viewer/list-report-data-provider.interface';
import * as i0 from "@angular/core";
/**
 * Implements a {@link ListReportDataProvider} to get the list report data for a statistic
 */
export declare class StatisticReportButtonService implements ListReportDataProvider {
    private readonly api;
    constructor(api: RpsApiService);
    private idStatistic;
    /**
     * Sets the statistic id used by this service
     * @param value the id of a statistic
     */
    setIdStatistic(value: string): void;
    get entitySchema(): EntitySchema;
    getDataModel(): Promise<DataModel>;
    get(param: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalReportData, ListReportContentData>>;
    getGroupInfo(parameters?: {
        by?: string;
        def?: string;
    } & CollectionLoadParameters): Promise<GroupInfoData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatisticReportButtonService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StatisticReportButtonService>;
}
