import { ReportSubscription } from '../report-subscription/report-subscription';
import { ReportSubscriptionService } from '../report-subscription/report-subscription.service';
import { ListReportDataProvider } from '../../list-report-viewer/list-report-data-provider.interface';
import * as i0 from "@angular/core";
/**
 * Represents the content of a side sheet, that shows the data of a list report
 * Uses the following side sheet data:
 *  dataService:   a {@link ListReportDataProvider} that handles the api calls
 *  subscription:  an optional {@link ReportSubscription}
 */
export declare class ListReportViewerSidesheetComponent {
    readonly data: {
        dataService: ListReportDataProvider;
        subscription?: ReportSubscription;
    };
    private readonly reportSubscriptionService;
    /**
     * A set of report parameter
     */
    reportParameter: {
        [key: string]: any;
    };
    constructor(data: {
        dataService: ListReportDataProvider;
        subscription?: ReportSubscription;
    }, reportSubscriptionService: ReportSubscriptionService);
    /**
     * Downloads the subscription
     */
    downloadReport(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListReportViewerSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListReportViewerSidesheetComponent, "imx-list-report-viewer-sidesheet", never, {}, {}, never, never, false>;
}
