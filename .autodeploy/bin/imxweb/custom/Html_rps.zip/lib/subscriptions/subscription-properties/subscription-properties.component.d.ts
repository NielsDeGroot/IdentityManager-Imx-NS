import { OnChanges, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { IClientProperty } from 'imx-qbm-dbts';
import { ColumnDependentReference } from 'qbm';
import { ReportSubscription } from '../report-subscription/report-subscription';
import * as i0 from "@angular/core";
export declare class SubscriptionPropertiesComponent implements OnInit, OnChanges {
    cdrList: ColumnDependentReference[];
    parameterCdrList: ColumnDependentReference[];
    readonly subscriptionPropertiesFormArray: UntypedFormArray;
    readonly subscriptionParameterFormArray: UntypedFormArray;
    withSeparateParameterList: boolean;
    subscription: ReportSubscription;
    formGroup: UntypedFormGroup;
    withTitles: boolean;
    displayedColumns: IClientProperty[];
    ngOnInit(): void;
    ngOnChanges(): void;
    valueHasChanged(name: any): void;
    addFormControl(array: UntypedFormArray, control: UntypedFormControl): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionPropertiesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionPropertiesComponent, "imx-subscription-properties", never, { "subscription": "subscription"; "formGroup": "formGroup"; "withTitles": "withTitles"; "displayedColumns": "displayedColumns"; }, {}, never, never, false>;
}
