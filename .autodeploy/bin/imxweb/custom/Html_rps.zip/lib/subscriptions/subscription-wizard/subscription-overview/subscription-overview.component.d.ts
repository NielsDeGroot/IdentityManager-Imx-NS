import { OnDestroy, OnInit } from '@angular/core';
import { IEntityColumn } from 'imx-qbm-dbts';
import { BehaviorSubject } from 'rxjs';
import { EuiLoadingService } from '@elemental-ui/core';
import { MultiValueService, AuthenticationService } from 'qbm';
import { PersonService } from 'qer';
import { ReportSubscription } from '../../report-subscription/report-subscription';
import * as i0 from "@angular/core";
export declare class SubscriptionOverviewComponent implements OnInit, OnDestroy {
    private readonly multiValue;
    private readonly busyService;
    private readonly personService;
    userIsMissingEMail: boolean;
    additionalRecipientWithoutEmail: string[];
    setProperties: IEntityColumn[];
    subscription: ReportSubscription;
    subscribersChanged: BehaviorSubject<void>;
    isWaitingForLoad: boolean;
    private currentUserId;
    constructor(multiValue: MultiValueService, busyService: EuiLoadingService, personService: PersonService, authentication: AuthenticationService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private checkEmailAddresses;
    private getPersonNameAndAddress;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionOverviewComponent, "imx-subscription-overview", never, { "subscription": "subscription"; "subscribersChanged": "subscribersChanged"; "isWaitingForLoad": "isWaitingForLoad"; }, {}, never, never, false>;
}
