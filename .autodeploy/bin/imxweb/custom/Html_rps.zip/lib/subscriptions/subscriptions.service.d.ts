import { PortalSubscription, PortalSubscriptionInteractive } from 'imx-api-rps';
import { CollectionLoadParameters, EntitySchema, ExtendedEntityCollectionData, ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { RpsApiService } from '../rps-api-client.service';
import * as i0 from "@angular/core";
export declare class SubscriptionsService {
    private readonly api;
    constructor(api: RpsApiService);
    get PortalSubscriptionSchema(): EntitySchema;
    getSubscriptions(parameters?: CollectionLoadParameters): Promise<ExtendedTypedEntityCollection<PortalSubscription, any>>;
    deleteSubscription(uid: string): Promise<ExtendedEntityCollectionData<any>>;
    getSubscriptionInteractive(uid: string): Promise<ExtendedTypedEntityCollection<PortalSubscriptionInteractive, {}>>;
    sendMail(uidPort: string, withCc: boolean): Promise<void>;
    hasReports(): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionsService>;
}
