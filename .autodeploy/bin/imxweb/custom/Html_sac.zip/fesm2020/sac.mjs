import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Input, ViewChild, NgModule } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import * as i1$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i1 from 'qbm';
import { DataSourceToolbarModule, DataTableModule, DataTreeWrapperModule } from 'qbm';
import { V2Client, TypedClient } from 'imx-api-sac';
import * as i3 from '@elemental-ui/core';
import { EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import * as i4$1 from '@angular/material/core';
import * as i5$1 from '@angular/material/chips';
import { MatChipsModule } from '@angular/material/chips';
import * as i6$1 from '@angular/material/form-field';
import * as i7$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i8$1 from '@angular/material/select';
import { TypedEntity, ValType, DisplayColumns, TypedEntityBuilder } from 'imx-qbm-dbts';
import * as i4 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import * as i7 from '@angular/material/table';
import { MatTableDataSource } from '@angular/material/table';
import * as i6 from '@angular/material/sort';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { FormControl } from '@angular/forms';
import * as i3$1 from '@angular/material/button';
import * as i5 from '@angular/material/icon';
import * as i8 from '@angular/material/tooltip';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SapComplianceApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
SapComplianceApiService.ɵfac = function SapComplianceApiService_Factory(t) { return new (t || SapComplianceApiService)(i0.ɵɵinject(i1.AppConfigService), i0.ɵɵinject(i1.ClassloggerService), i0.ɵɵinject(i1.ImxTranslationProviderService)); };
SapComplianceApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: SapComplianceApiService, factory: SapComplianceApiService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SapComplianceApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i1.AppConfigService }, { type: i1.ClassloggerService }, { type: i1.ImxTranslationProviderService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
var SapSelectionTypeEnum;
(function (SapSelectionTypeEnum) {
    SapSelectionTypeEnum["ROLE"] = "ROLE";
    SapSelectionTypeEnum["ABILITY"] = "ABILITY";
})(SapSelectionTypeEnum || (SapSelectionTypeEnum = {}));

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SapComplianceByAbilityEntity extends TypedEntity {
    constructor() {
        super(...arguments);
        this.Ident_SAPProfile = this.GetEntityValue('Ident_SAPProfile');
        this.Ident_SAPAuthObject = this.GetEntityValue('Ident_SAPAuthObject');
        this.Ident_SAPField = this.GetEntityValue('Ident_SAPField');
        this.LowerLimit = this.GetEntityValue('LowerLimit');
        this.UpperLimit = this.GetEntityValue('UpperLimit');
        this.UID_SAPFunctionInstance = this.GetEntityValue('UID_SAPFunctionInstance');
        this.DisplaySapFunctionInstance = this.GetEntityValue('DisplaySapFunctionInstance');
        this.DisplaySapTransaction = this.GetEntityValue('DisplaySapTransaction');
    }
    static GetEntitySchema() {
        const columns = {
            Ident_SAPProfile: {
                Type: ValType.String,
                ColumnName: 'Ident_SAPProfile',
            },
            Ident_SAPAuthObject: {
                Type: ValType.String,
                ColumnName: 'Ident_SAPAuthObject',
            },
            Ident_SAPField: {
                Type: ValType.String,
                ColumnName: 'Ident_SAPField',
            },
            LowerLimit: {
                Type: ValType.String,
                ColumnName: 'LowerLimit',
            },
            UpperLimit: {
                Type: ValType.String,
                ColumnName: 'UpperLimit',
            },
            UID_SAPFunctionInstance: {
                Type: ValType.String,
                ColumnName: 'UID_SAPFunctionInstance',
            },
            DisplaySapFunctionInstance: {
                Type: ValType.String,
                ColumnName: 'DisplaySapFunctionInstance',
            },
            DisplaySapTransaction: {
                Type: ValType.String,
                ColumnName: 'DisplaySapTransaction',
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        return { Columns: columns };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SapComplianceByAbilityBuilder {
    constructor() {
        this.entitySchema = SapComplianceByAbilityEntity.GetEntitySchema();
        this.builder = new TypedEntityBuilder(SapComplianceByAbilityEntity);
    }
    build(entityCollectionData) {
        return this.builder.buildReadWriteEntities(entityCollectionData, this.entitySchema);
    }
    buildEntityCollectionData(items) {
        const entities = items.map((elem) => this.buildEntityData(elem));
        return { Entities: entities, TotalCount: items.length };
    }
    buildEntityData(item) {
        return {
            Columns: {
                Ident_SAPProfile: { Value: item.Ident_SAPProfile },
                Ident_SAPAuthObject: { Value: item.Ident_SAPAuthObject },
                Ident_SAPField: { Value: item.Ident_SAPField },
                LowerLimit: { Value: item.LowerLimit },
                UpperLimit: { Value: item.UpperLimit },
                DisplaySapFunctionInstance: { Value: item.DisplaySapFunctionInstance },
                DisplaySapTransaction: { Value: item.DisplaySapTransaction },
                UID_SAPFunctionInstance: { Value: item.UID_SAPFunctionInstance },
            },
            Keys: [
                'Ident_SAPProfile',
                'Ident_SAPAuthObject',
                'Ident_SAPField',
                'LowerLimit',
                'UpperLimit',
                'DisplaySapFunctionInstance',
                'DisplaySapTransaction',
                'UID_SAPFunctionInstance',
            ],
        };
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function SapComplianceViolationViewsByAbilityComponent_div_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 8);
    i0.ɵɵelement(1, "eui-icon", 9);
    i0.ɵɵelementStart(2, "p");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("icon", "table");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#No data"));
} }
const _c0$1 = function () { return ["search", "groupBy"]; };
class SapComplianceViolationViewsByAbilityComponent {
    constructor(translateService) {
        this.translateService = translateService;
        this._resultByAbility = { Data: [] };
        this.groupData = {};
        this.sapComplianceByAbilityBuilder = new SapComplianceByAbilityBuilder();
        this.entitySchema = SapComplianceByAbilityEntity.GetEntitySchema();
    }
    set resultByAbility(value) {
        this._resultByAbility = value;
        if (!!value?.Data) {
            this.buildDataSource(value.Data);
        }
    }
    get resultByAbility() {
        return this._resultByAbility;
    }
    /**
     * Called when search action is emitted.
     * @param searchValue current search param
     */
    onSearch(searchValue) {
        if (!!searchValue) {
            searchValue = searchValue.toLocaleLowerCase();
            this.dstSettings.dataSource.Data = this.defaultData.filter((profile) => profile.Ident_SAPProfile.value.toLocaleLowerCase().includes(searchValue) ||
                profile.Ident_SAPAuthObject.value.toLocaleLowerCase().includes(searchValue) ||
                profile.Ident_SAPField.value.toLocaleLowerCase().includes(searchValue) ||
                profile.LowerLimit.value.toLocaleLowerCase().includes(searchValue) ||
                profile.UpperLimit.value.toLocaleLowerCase().includes(searchValue));
        }
        else {
            this.dstSettings.dataSource.Data = this.defaultData;
        }
        this.dstSettings = { ...this.dstSettings, navigationState: { ...this.dstSettings.navigationState, search: searchValue } };
    }
    /**
     * Updates the selected group data. Called when group action is emitted.
     * @param groupKey selected grouping key
     */
    onGroupingChange(groupInfo) {
        const groupedData = this.groupData[groupInfo.key];
        let filter = groupedData.navigationState?.filter;
        groupedData.data = this.getFilteredData(filter[0]);
        groupedData.settings = {
            displayedColumns: this.dstSettings.displayedColumns,
            dataModel: this.dstSettings.dataModel,
            dataSource: {
                Data: groupedData.data,
                totalCount: groupedData.data.length,
            },
            entitySchema: this.dstSettings.entitySchema,
            navigationState: groupedData.navigationState,
        };
    }
    /**
     * Called when navigaiton state changed. Here is called when search badge is removed.
     */
    onNavigationStateChanged(params) {
        this.onSearch(params.search);
    }
    /**
     * Build the data source and the data source toolbar settings.
     */
    buildDataSource(items) {
        this.dataSource = this.sapComplianceByAbilityBuilder.build(this.sapComplianceByAbilityBuilder.buildEntityCollectionData(items));
        this.defaultData = this.dataSource.Data;
        this.dstSettings = {
            dataSource: this.dataSource,
            entitySchema: this.entitySchema,
            navigationState: {},
            displayedColumns: [
                this.entitySchema.Columns.Ident_SAPProfile,
                this.entitySchema.Columns.Ident_SAPAuthObject,
                this.entitySchema.Columns.Ident_SAPField,
                this.entitySchema.Columns.LowerLimit,
                this.entitySchema.Columns.UpperLimit,
                this.entitySchema.Columns.DisplaySapFunctionInstance,
                this.entitySchema.Columns.DisplaySapTransaction,
            ],
            groupData: this.createGroupData(),
        };
    }
    /**
     * Creating data source toolbar group setting.
     * @returns Data source toolbar group setting.
     */
    createGroupData() {
        const groups = [
            {
                property: {
                    Property: {
                        Type: ValType.String,
                        ColumnName: 'DisplaySapFunctionInstance',
                        Display: this.translateService.instant('#LDS#SAP function instance'),
                    },
                },
                getData: async () => await this.groupingData('DisplaySapFunctionInstance'),
            },
            {
                property: {
                    Property: {
                        Type: ValType.String,
                        ColumnName: 'DisplaySapTransaction',
                        Display: this.translateService.instant('#LDS#SAP transaction'),
                    },
                },
                getData: async () => await this.groupingData('DisplaySapTransaction'),
            },
        ];
        return { groups };
    }
    /**
     * The method generating the group info data from the group column key.
     * @param groupColumn
     * @returns Generated group info data.
     */
    async groupingData(groupColumn) {
        const Groups = [];
        this.dataSource.Data?.map((item, index) => {
            if (Groups.every((groupItem) => item[groupColumn].value !== groupItem.Display[0].Display)) {
                const groupItems = this.dataSource.Data.filter((row) => row[groupColumn].value === item[groupColumn].value);
                Groups.push({
                    Display: [{ Display: item[groupColumn].value }],
                    Filters: [{ ColumnName: groupColumn, Values: groupItems.map((groupItem) => groupItem[groupColumn].value) }],
                    Count: groupItems.length,
                });
            }
        });
        return {
            TotalCount: Groups.length,
            Groups,
        };
    }
    /**
     * The method filter the data source with the filter column name.
     * @param filter
     * @returns Filtered data source.
     */
    getFilteredData(filter) {
        return this.dataSource.Data.filter((dataRow) => filter.Values.indexOf(dataRow[filter.ColumnName].value) >= 0);
    }
}
SapComplianceViolationViewsByAbilityComponent.ɵfac = function SapComplianceViolationViewsByAbilityComponent_Factory(t) { return new (t || SapComplianceViolationViewsByAbilityComponent)(i0.ɵɵdirectiveInject(i1$1.TranslateService)); };
SapComplianceViolationViewsByAbilityComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SapComplianceViolationViewsByAbilityComponent, selectors: [["imx-sap-compliance-violation-views-by-ability"]], inputs: { resultByAbility: "resultByAbility" }, decls: 21, vars: 39, consts: [[1, "sap-analysis"], [1, "sap-analysis__table"], ["data-imx-identifier", "role-recommendation-result-data-source-toolbar", 3, "settings", "options", "search", "navigationStateChanged"], ["dst", ""], [1, "imx-data-table-container"], ["data-imx-identifier", "role-recommendation-result-data-table", "detailViewVisible", "false", 3, "selectable", "showSelectionInfo", "showSelectedItemsMenu", "showGroupPaginator", "dst", "groupData", "mode", "groupDataChanged"], [3, "entityColumn", "columnLabel"], ["class", "no-results", 4, "ngIf"], [1, "no-results"], [3, "icon"]], template: function SapComplianceViolationViewsByAbilityComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 0)(1, "div", 1)(2, "imx-data-source-toolbar", 2, 3);
        i0.ɵɵlistener("search", function SapComplianceViolationViewsByAbilityComponent_Template_imx_data_source_toolbar_search_2_listener($event) { return ctx.onSearch($event); })("navigationStateChanged", function SapComplianceViolationViewsByAbilityComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { return ctx.onNavigationStateChanged($event); });
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "div", 4)(5, "imx-data-table", 5);
        i0.ɵɵlistener("groupDataChanged", function SapComplianceViolationViewsByAbilityComponent_Template_imx_data_table_groupDataChanged_5_listener($event) { return ctx.onGroupingChange($event); });
        i0.ɵɵelement(6, "imx-data-table-column", 6);
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelement(8, "imx-data-table-column", 6);
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelement(10, "imx-data-table-column", 6);
        i0.ɵɵpipe(11, "translate");
        i0.ɵɵelement(12, "imx-data-table-column", 6);
        i0.ɵɵpipe(13, "translate");
        i0.ɵɵelement(14, "imx-data-table-column", 6);
        i0.ɵɵpipe(15, "translate");
        i0.ɵɵelement(16, "imx-data-table-column", 6);
        i0.ɵɵpipe(17, "translate");
        i0.ɵɵelement(18, "imx-data-table-column", 6);
        i0.ɵɵpipe(19, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(20, SapComplianceViolationViewsByAbilityComponent_div_20_Template, 5, 4, "div", 7);
        i0.ɵɵelementEnd()();
    } if (rf & 2) {
        const _r0 = i0.ɵɵreference(3);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(38, _c0$1));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("selectable", false)("showSelectionInfo", false)("showSelectedItemsMenu", false)("showGroupPaginator", false)("dst", _r0)("groupData", ctx.groupData)("mode", "manual");
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.Ident_SAPProfile)("columnLabel", i0.ɵɵpipeBind1(7, 24, "#LDS#Authentication"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.Ident_SAPAuthObject)("columnLabel", i0.ɵɵpipeBind1(9, 26, "#LDS#Object"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.Ident_SAPField)("columnLabel", i0.ɵɵpipeBind1(11, 28, "#LDS#Field"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.LowerLimit)("columnLabel", i0.ɵɵpipeBind1(13, 30, "#LDS#Lower limit"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.UpperLimit)("columnLabel", i0.ɵɵpipeBind1(15, 32, "#LDS#Upper limit"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.DisplaySapFunctionInstance)("columnLabel", i0.ɵɵpipeBind1(17, 34, "#LDS#SAP function instance"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns.DisplaySapTransaction)("columnLabel", i0.ɵɵpipeBind1(19, 36, "#LDS#SAP transaction"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.dataSource.Data.length == 0);
    } }, dependencies: [i2.NgIf, i3.EuiIconComponent, i4.MatCard, i1.DataSourceToolbarComponent, i1.DataTableComponent, i1.DataTableColumnComponent, i1$1.TranslatePipe], styles: [".sap-analysis[_ngcontent-%COMP%]{display:flex;flex-direction:column;height:100%;justify-content:space-between;gap:16px}.sap-analysis__table[_ngcontent-%COMP%]{overflow:hidden auto;flex-grow:1}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SapComplianceViolationViewsByAbilityComponent, [{
        type: Component,
        args: [{ selector: 'imx-sap-compliance-violation-views-by-ability', template: "<mat-card class=\"sap-analysis\">\r\n  <div class=\"sap-analysis__table\">\r\n    <imx-data-source-toolbar\r\n      #dst\r\n      data-imx-identifier=\"role-recommendation-result-data-source-toolbar\"\r\n      [settings]=\"dstSettings\"\r\n      [options]=\"['search', 'groupBy']\"\r\n      (search)=\"onSearch($event)\"\r\n      (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n    >\r\n    </imx-data-source-toolbar>\r\n    <div class=\"imx-data-table-container\">\r\n      <imx-data-table\r\n        [selectable]=\"false\"\r\n        [showSelectionInfo]=\"false\"\r\n        [showSelectedItemsMenu]=\"false\"\r\n        [showGroupPaginator]=\"false\"\r\n        [dst]=\"dst\"\r\n        [groupData]=\"groupData\"\r\n        [mode]=\"'manual'\"\r\n        data-imx-identifier=\"role-recommendation-result-data-table\"\r\n        detailViewVisible=\"false\"\r\n        (groupDataChanged)=\"onGroupingChange($event)\"\r\n      >\r\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.Ident_SAPProfile\" [columnLabel]=\"'#LDS#Authentication' | translate\"> </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.Ident_SAPAuthObject\" [columnLabel]=\"'#LDS#Object' | translate\"> </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.Ident_SAPField\" [columnLabel]=\"'#LDS#Field' | translate\"> </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.LowerLimit\" [columnLabel]=\"'#LDS#Lower limit' | translate\"> </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UpperLimit\" [columnLabel]=\"'#LDS#Upper limit' | translate\"> </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.DisplaySapFunctionInstance\" [columnLabel]=\"'#LDS#SAP function instance' | translate\"> </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchema.Columns.DisplaySapTransaction\" [columnLabel]=\"'#LDS#SAP transaction' | translate\"> </imx-data-table-column>\r\n      </imx-data-table>\r\n    </div>\r\n    <div *ngIf=\"dataSource.Data.length == 0\" class=\"no-results\">\r\n      <eui-icon [icon]=\"'table'\"></eui-icon>\r\n      <p>{{ '#LDS#No data' | translate }}</p>\r\n    </div>\r\n  </div>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.sap-analysis{display:flex;flex-direction:column;height:100%;justify-content:space-between;gap:16px}.sap-analysis__table{overflow:hidden auto;flex-grow:1}\n"] }]
    }], function () { return [{ type: i1$1.TranslateService }]; }, { resultByAbility: [{
            type: Input
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function SapComplianceViolationViewsByRoleComponent_button_6_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 16);
    i0.ɵɵlistener("click", function SapComplianceViolationViewsByRoleComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r10.toggleRoleExpand()); });
    i0.ɵɵpipe(1, "translate");
    i0.ɵɵelement(2, "eui-icon", 17);
    i0.ɵɵelementStart(3, "h3");
    i0.ɵɵtext(4, "SAP Analysis Roles");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 1, ctx_r0.extendRole ? "#LDS#Hide roles" : "#LDS#Show roles"));
} }
function SapComplianceViolationViewsByRoleComponent_th_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 18)(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵstyleProp("padding-left", 40, "px");
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 3, "#LDS#Group name"));
} }
function SapComplianceViolationViewsByRoleComponent_td_11_Template(rf, ctx) { if (rf & 1) {
    const _r14 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 19)(1, "button", 20);
    i0.ɵɵlistener("click", function SapComplianceViolationViewsByRoleComponent_td_11_Template_button_click_1_listener() { const restoredCtx = i0.ɵɵrestoreView(_r14); const data_r12 = restoredCtx.$implicit; const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.treeControl.toggle(data_r12)); });
    i0.ɵɵelementStart(2, "mat-icon", 21);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd()();
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r12 = ctx.$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵstyleProp("visibility", !data_r12.expandable ? "hidden" : "")("margin-left", data_r12.level * 16, "px");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r2.treeControl.isExpanded(data_r12) ? "expand_more" : "chevron_right", " ");
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", data_r12.GroupName, " ");
} }
function SapComplianceViolationViewsByRoleComponent_th_13_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 18);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Description"));
} }
function SapComplianceViolationViewsByRoleComponent_td_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22)(1, "span", 23);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const data_r15 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵpropertyInterpolate("title", data_r15.Description);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r15.Description);
} }
function SapComplianceViolationViewsByRoleComponent_th_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 18);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Group type"));
} }
function SapComplianceViolationViewsByRoleComponent_td_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r16 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r16.GroupType);
} }
function SapComplianceViolationViewsByRoleComponent_tr_18_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "tr", 24);
} }
const _c0 = function (a0) { return { "sap-analysis-table-row-highlighted": a0 }; };
function SapComplianceViolationViewsByRoleComponent_tr_19_Template(rf, ctx) { if (rf & 1) {
    const _r19 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "tr", 25);
    i0.ɵɵlistener("click", function SapComplianceViolationViewsByRoleComponent_tr_19_Template_tr_click_0_listener() { const restoredCtx = i0.ɵɵrestoreView(_r19); const row_r17 = restoredCtx.$implicit; const ctx_r18 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r18.updateProfiles(row_r17)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r17 = ctx.$implicit;
    const ctx_r8 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(1, _c0, ctx_r8.hasProfiles(row_r17)));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Authentication"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r34 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r34.Ident_SAPProfile);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Objects"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r35 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r35.Objects);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Field"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r36 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r36.Field);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#From"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r37 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r37.LowerLimit);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 39);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#To"));
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 22);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const data_r38 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(data_r38.UpperLimit);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_tr_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "tr", 24);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_tr_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "tr", 40);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "table", 31);
    i0.ɵɵelementContainerStart(1, 32);
    i0.ɵɵtemplate(2, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_2_Template, 3, 3, "th", 33);
    i0.ɵɵtemplate(3, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_3_Template, 2, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(4, 34);
    i0.ɵɵtemplate(5, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_5_Template, 3, 3, "th", 33);
    i0.ɵɵtemplate(6, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_6_Template, 2, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(7, 35);
    i0.ɵɵtemplate(8, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_8_Template, 3, 3, "th", 33);
    i0.ɵɵtemplate(9, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_9_Template, 2, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(10, 36);
    i0.ɵɵtemplate(11, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_11_Template, 3, 3, "th", 33);
    i0.ɵɵtemplate(12, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_12_Template, 2, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵelementContainerStart(13, 37);
    i0.ɵɵtemplate(14, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_th_14_Template, 3, 3, "th", 33);
    i0.ɵɵtemplate(15, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_td_15_Template, 2, 1, "td", 11);
    i0.ɵɵelementContainerEnd();
    i0.ɵɵtemplate(16, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_tr_16_Template, 1, 0, "tr", 13);
    i0.ɵɵtemplate(17, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_tr_17_Template, 1, 0, "tr", 38);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r20 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("dataSource", ctx_r20.profileDataSource);
    i0.ɵɵadvance(16);
    i0.ɵɵproperty("matHeaderRowDef", ctx_r20.displayedProfileColumns)("matHeaderRowDefSticky", true);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("matRowDefColumns", ctx_r20.displayedProfileColumns);
} }
function SapComplianceViolationViewsByRoleComponent_mat_card_20_div_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 41);
    i0.ɵɵelement(1, "eui-icon", 42);
    i0.ɵɵelementStart(2, "p");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("icon", "table");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#No data"));
} }
const _c1 = function (a0) { return { "mat-card--decreased": a0 }; };
function SapComplianceViolationViewsByRoleComponent_mat_card_20_Template(rf, ctx) { if (rf & 1) {
    const _r41 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 1)(1, "div", 2)(2, "button", 16);
    i0.ɵɵlistener("click", function SapComplianceViolationViewsByRoleComponent_mat_card_20_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r41); const ctx_r40 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r40.toggleProfilesExpand()); });
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelement(4, "eui-icon", 26);
    i0.ɵɵelementStart(5, "h3");
    i0.ɵɵtext(6);
    i0.ɵɵpipe(7, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(8, "h3", 27);
    i0.ɵɵtext(9);
    i0.ɵɵpipe(10, "translate");
    i0.ɵɵelementEnd()();
    i0.ɵɵelement(11, "eui-search", 28);
    i0.ɵɵpipe(12, "translate");
    i0.ɵɵelementStart(13, "div", 5);
    i0.ɵɵtemplate(14, SapComplianceViolationViewsByRoleComponent_mat_card_20_table_14_Template, 18, 4, "table", 29);
    i0.ɵɵtemplate(15, SapComplianceViolationViewsByRoleComponent_mat_card_20_div_15_Template, 5, 4, "div", 30);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r9 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(17, _c1, !ctx_r9.extendProfiles));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(3, 9, ctx_r9.extendProfiles ? "#LDS#Hide profiles" : "#LDS#Show profiles"));
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(7, 11, "#LDS#Profiles"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate2("", i0.ɵɵpipeBind1(10, 13, "#LDS#Heading Selected Role"), ": ", ctx_r9.selectedRole == null ? null : ctx_r9.selectedRole.GroupName, "");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("placeholder", i0.ɵɵpipeBind1(12, 15, "#LDS#Search"))("searchControl", ctx_r9.profileSearchControl);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngIf", ctx_r9.profileDataSource.data.length > 0);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r9.profileDataSource.data.length == 0);
} }
class SapComplianceViolationViewsByRoleComponent {
    constructor(cdref) {
        this.cdref = cdref;
        this.displayedColumns = ['GroupName', 'Description', 'GroupType'];
        this.displayedProfileColumns = ['Ident_SAPProfile', 'Objects', 'Field', 'LowerLimit', 'UpperLimit'];
        this.transformer = (node, level) => {
            return {
                expandable: !!node.ChildElements && node.ChildElements.length > 0,
                level: level,
                GroupName: node.GroupName,
                Description: node.Description,
                GroupFlag: node.GroupFlag,
                GroupType: node.GroupType,
                ChildElements: node.ChildElements,
                Prof: node.Prof,
            };
        };
        this.treeControl = new FlatTreeControl((node) => node.level, (node) => node.expandable);
        this.treeFlattener = new MatTreeFlattener(this.transformer, (node) => node.level, (node) => node.expandable, (node) => node.ChildElements);
        this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
        this.selectedProfiles = [];
        this.profileDataSource = new MatTableDataSource();
        this.extendRole = true;
        this.extendProfiles = true;
        this.showProfiles = false;
        this.profileSearchControl = new FormControl('');
    }
    set resultByRole(value) {
        this._resultByRole = value;
        if (!!value?.Elements) {
            this.dataSource.data = value.Elements;
        }
    }
    get resultByRole() {
        return this._resultByRole;
    }
    ngOnInit() {
        this.profileSearchControl.valueChanges.subscribe((searchValue) => this.searchProfiles(searchValue));
    }
    hasChild(_, node) {
        return node.expandable;
    }
    hasProfiles(node) {
        return !!node.Prof && node.Prof.length > 0;
    }
    updateProfiles(node) {
        if (!!node?.Prof) {
            this.showProfiles = true;
            this.selectedProfiles = node.Prof;
            this.profileDataSource.data = node.Prof;
            this.selectedRole = node;
            this.cdref.detectChanges();
            this.profileDataSource.sort = this.sort;
        }
    }
    toggleRoleExpand() {
        this.extendRole = !this.extendRole;
        if (!this.extendRole) {
            this.extendProfiles = true;
        }
    }
    toggleProfilesExpand() {
        this.extendProfiles = !this.extendProfiles;
        if (!this.extendProfiles) {
            this.extendRole = true;
        }
    }
    searchProfiles(searchValue) {
        if (!!searchValue) {
            searchValue = searchValue.toLocaleLowerCase();
            this.profileDataSource.data = this.selectedProfiles.filter((profile) => profile.Ident_SAPProfile.toLocaleLowerCase().includes(searchValue) ||
                profile.Objects.toLocaleLowerCase().includes(searchValue) ||
                profile.Field.toLocaleLowerCase().includes(searchValue) ||
                profile.LowerLimit.toLocaleLowerCase().includes(searchValue) ||
                profile.UpperLimit.toLocaleLowerCase().includes(searchValue));
        }
        else {
            this.profileDataSource.data = this.selectedProfiles;
        }
    }
}
SapComplianceViolationViewsByRoleComponent.ɵfac = function SapComplianceViolationViewsByRoleComponent_Factory(t) { return new (t || SapComplianceViolationViewsByRoleComponent)(i0.ɵɵdirectiveInject(i0.ChangeDetectorRef)); };
SapComplianceViolationViewsByRoleComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SapComplianceViolationViewsByRoleComponent, selectors: [["imx-sap-compliance-violation-views-by-role"]], viewQuery: function SapComplianceViolationViewsByRoleComponent_Query(rf, ctx) { if (rf & 1) {
        i0.ɵɵviewQuery(MatSort, 5);
    } if (rf & 2) {
        let _t;
        i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.sort = _t.first);
    } }, inputs: { resultByRole: "resultByRole" }, decls: 21, vars: 12, consts: [[1, "sap-analysis"], [3, "ngClass"], [1, "mat-card__header"], [1, "mat-card__header__title"], ["data-imx-identifier", "sidenav-tree-expand-toggle", "mat-button", "", "color", "primary", 3, "matTooltip", "click", 4, "ngIf"], [1, "sap-analysis__table"], ["mat-table", "", 3, "dataSource"], ["matColumnDef", "GroupName"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["mat-cell", "", "class", "td--no-wrap", 4, "matCellDef"], ["matColumnDef", "Description"], ["mat-cell", "", 4, "matCellDef"], ["matColumnDef", "GroupType"], ["mat-header-row", "", 4, "matHeaderRowDef", "matHeaderRowDefSticky"], ["mat-row", "", 3, "ngClass", "click", 4, "matRowDef", "matRowDefColumns"], [3, "ngClass", 4, "ngIf"], ["data-imx-identifier", "sidenav-tree-expand-toggle", "mat-button", "", "color", "primary", 3, "matTooltip", "click"], ["icon", "collapseleft"], ["mat-header-cell", ""], ["mat-cell", "", 1, "td--no-wrap"], ["mat-icon-button", "", 3, "click"], [1, "mat-icon-rtl-mirror"], ["mat-cell", ""], [1, "imx-table-column-ellipsis", 3, "title"], ["mat-header-row", ""], ["mat-row", "", 3, "ngClass", "click"], ["icon", "collapseright"], [1, "mat-card__header__title", "mat-card__header__title--wide"], ["size", "s", "width", "100%", 3, "placeholder", "searchControl"], ["mat-table", "", "matSort", "", 3, "dataSource", 4, "ngIf"], ["class", "no-results", 4, "ngIf"], ["mat-table", "", "matSort", "", 3, "dataSource"], ["matColumnDef", "Ident_SAPProfile"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["matColumnDef", "Objects"], ["matColumnDef", "Field"], ["matColumnDef", "LowerLimit"], ["matColumnDef", "UpperLimit"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["mat-header-cell", "", "mat-sort-header", ""], ["mat-row", ""], [1, "no-results"], [3, "icon"]], template: function SapComplianceViolationViewsByRoleComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "mat-card", 1)(2, "div", 2)(3, "h3", 3);
        i0.ɵɵtext(4);
        i0.ɵɵpipe(5, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(6, SapComplianceViolationViewsByRoleComponent_button_6_Template, 5, 3, "button", 4);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "div", 5)(8, "table", 6);
        i0.ɵɵelementContainerStart(9, 7);
        i0.ɵɵtemplate(10, SapComplianceViolationViewsByRoleComponent_th_10_Template, 4, 5, "th", 8);
        i0.ɵɵtemplate(11, SapComplianceViolationViewsByRoleComponent_td_11_Template, 5, 6, "td", 9);
        i0.ɵɵelementContainerEnd();
        i0.ɵɵelementContainerStart(12, 10);
        i0.ɵɵtemplate(13, SapComplianceViolationViewsByRoleComponent_th_13_Template, 3, 3, "th", 8);
        i0.ɵɵtemplate(14, SapComplianceViolationViewsByRoleComponent_td_14_Template, 3, 2, "td", 11);
        i0.ɵɵelementContainerEnd();
        i0.ɵɵelementContainerStart(15, 12);
        i0.ɵɵtemplate(16, SapComplianceViolationViewsByRoleComponent_th_16_Template, 3, 3, "th", 8);
        i0.ɵɵtemplate(17, SapComplianceViolationViewsByRoleComponent_td_17_Template, 2, 1, "td", 11);
        i0.ɵɵelementContainerEnd();
        i0.ɵɵtemplate(18, SapComplianceViolationViewsByRoleComponent_tr_18_Template, 1, 0, "tr", 13);
        i0.ɵɵtemplate(19, SapComplianceViolationViewsByRoleComponent_tr_19_Template, 1, 3, "tr", 14);
        i0.ɵɵelementEnd()()();
        i0.ɵɵtemplate(20, SapComplianceViolationViewsByRoleComponent_mat_card_20_Template, 16, 19, "mat-card", 15);
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(10, _c1, !ctx.extendRole));
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 8, "#LDS#Heading Rule Analysis by Role"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.selectedProfiles.length > 0);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dataSource", ctx.dataSource);
        i0.ɵɵadvance(10);
        i0.ɵɵproperty("matHeaderRowDef", ctx.displayedColumns)("matHeaderRowDefSticky", true);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("matRowDefColumns", ctx.displayedColumns);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.showProfiles);
    } }, dependencies: [i2.NgClass, i2.NgIf, i3.EuiIconComponent, i3.EuiSearchComponent, i3$1.MatButton, i4.MatCard, i5.MatIcon, i6.MatSort, i6.MatSortHeader, i7.MatTable, i7.MatHeaderCellDef, i7.MatHeaderRowDef, i7.MatColumnDef, i7.MatCellDef, i7.MatRowDef, i7.MatHeaderCell, i7.MatCell, i7.MatHeaderRow, i7.MatRow, i8.MatTooltip, i1$1.TranslatePipe], styles: [".sap-analysis[_ngcontent-%COMP%]{display:flex;gap:16px;height:100%;justify-content:space-between}.sap-analysis__table[_ngcontent-%COMP%]{overflow:hidden auto;flex-grow:1}.sap-analysis[_ngcontent-%COMP%]   .mat-card[_ngcontent-%COMP%]{width:100%;transition:width .4s ease;display:flex;flex-direction:column;gap:20px}.sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]{padding:0;width:48px}.sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]{height:100%}.sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]   .mat-card__header__title[_ngcontent-%COMP%]{display:none}.sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{width:48px;padding:20px 0;min-width:unset;height:100%}.sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]     .mat-button-wrapper{height:100%;display:flex;flex-direction:column}.sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{display:block;margin:auto 0;rotate:-90deg}.sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{rotate:180deg}.sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]   .sap-analysis__table[_ngcontent-%COMP%], .sap-analysis[_ngcontent-%COMP%]   .mat-card--decreased[_ngcontent-%COMP%]   eui-search[_ngcontent-%COMP%]{display:none}.sap-analysis[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between}.sap-analysis[_ngcontent-%COMP%]   .mat-card__header__title--wide[_ngcontent-%COMP%]{margin:auto}.sap-analysis[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{padding:0;min-width:32px}.sap-analysis[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{display:none}.sap-analysis[_ngcontent-%COMP%]   .mat-card__header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{transition:rotate .4s ease}.sap-analysis[_ngcontent-%COMP%]   .mat-table[_ngcontent-%COMP%]{box-shadow:none}.sap-analysis[_ngcontent-%COMP%]   .mat-table[_ngcontent-%COMP%]   .td--no-wrap[_ngcontent-%COMP%]{white-space:nowrap}.sap-analysis[_ngcontent-%COMP%]   .mat-table[_ngcontent-%COMP%]   .sap-analysis-table-row-highlighted[_ngcontent-%COMP%]:hover{background-color:#f2f6f7;cursor:pointer}[_nghost-%COMP%]     .mat-table tbody .mat-row .mat-cell .imx-table-column-ellipsis{width:120px;display:block;white-space:nowrap;overflow-x:hidden;text-overflow:ellipsis}.eui-dark-theme   [_nghost-%COMP%]   .sap-analysis[_ngcontent-%COMP%]   .mat-table[_ngcontent-%COMP%]   .sap-analysis-table-row-highlighted[_ngcontent-%COMP%]:hover{background-color:#616566}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SapComplianceViolationViewsByRoleComponent, [{
        type: Component,
        args: [{ selector: 'imx-sap-compliance-violation-views-by-role', template: "<div class=\"sap-analysis\">\r\n  <mat-card [ngClass]=\"{ 'mat-card--decreased': !extendRole }\">\r\n    <div class=\"mat-card__header\">\r\n      <h3 class=\"mat-card__header__title\">{{'#LDS#Heading Rule Analysis by Role' | translate}}</h3>\r\n      <button\r\n        data-imx-identifier=\"sidenav-tree-expand-toggle\"\r\n        mat-button\r\n        color=\"primary\"\r\n        (click)=\"toggleRoleExpand()\"\r\n        [matTooltip]=\"(extendRole ? '#LDS#Hide roles' : '#LDS#Show roles') | translate\"\r\n        *ngIf=\"selectedProfiles.length > 0\"\r\n      >\r\n        <eui-icon icon=\"collapseleft\"></eui-icon>\r\n        <h3>SAP Analysis Roles</h3>\r\n      </button>\r\n    </div>\r\n    <div class=\"sap-analysis__table\">\r\n      <table mat-table [dataSource]=\"dataSource\">\r\n        <ng-container matColumnDef=\"GroupName\">\r\n          <th mat-header-cell *matHeaderCellDef>\r\n            <span [style.paddingLeft.px]=\"40\">{{'#LDS#Group name' | translate}}</span>\r\n          </th>\r\n          <td mat-cell *matCellDef=\"let data\" class=\"td--no-wrap\">\r\n            <button mat-icon-button [style.visibility]=\"!data.expandable ? 'hidden' : ''\" [style.marginLeft.px]=\"data.level * 16\" (click)=\"treeControl.toggle(data)\">\r\n              <mat-icon class=\"mat-icon-rtl-mirror\">\r\n                {{ treeControl.isExpanded(data) ? 'expand_more' : 'chevron_right' }}\r\n              </mat-icon>\r\n            </button>\r\n\r\n            {{ data.GroupName }}\r\n          </td>\r\n        </ng-container>\r\n        <ng-container matColumnDef=\"Description\">\r\n          <th mat-header-cell *matHeaderCellDef>{{'#LDS#Description' | translate}}</th>\r\n          <td mat-cell *matCellDef=\"let data\" ><span class=\"imx-table-column-ellipsis\" title=\"{{data.Description}}\">{{ data.Description }}</span></td>\r\n        </ng-container>\r\n        <ng-container matColumnDef=\"GroupType\">\r\n          <th mat-header-cell *matHeaderCellDef>{{'#LDS#Group type' | translate}}</th>\r\n          <td mat-cell *matCellDef=\"let data\">{{ data.GroupType }}</td>\r\n        </ng-container>\r\n        <tr mat-header-row *matHeaderRowDef=\"displayedColumns; sticky: true\"></tr>\r\n        <tr mat-row *matRowDef=\"let row; columns: displayedColumns\" [ngClass]=\"{'sap-analysis-table-row-highlighted': hasProfiles(row) }\" (click)=\"updateProfiles(row)\"></tr>\r\n      </table>\r\n    </div>\r\n  </mat-card>\r\n  <mat-card *ngIf=\"showProfiles\" [ngClass]=\"{ 'mat-card--decreased': !extendProfiles }\">\r\n    <div class=\"mat-card__header\">\r\n      <button\r\n        data-imx-identifier=\"sidenav-tree-expand-toggle\"\r\n        mat-button\r\n        color=\"primary\"\r\n        (click)=\"toggleProfilesExpand()\"\r\n        [matTooltip]=\"(extendProfiles ? '#LDS#Hide profiles' : '#LDS#Show profiles') | translate\"\r\n      >\r\n        <eui-icon icon=\"collapseright\"></eui-icon>\r\n        <h3>{{'#LDS#Profiles' | translate}}</h3>\r\n      </button>\r\n      <h3 class=\"mat-card__header__title mat-card__header__title--wide\" >{{'#LDS#Heading Selected Role' | translate}}: {{selectedRole?.GroupName}}</h3>\r\n    </div>\r\n    <eui-search\r\n      [placeholder]=\"'#LDS#Search' | translate\"\r\n      [searchControl]=\"profileSearchControl\"\r\n      size=\"s\"\r\n      width=\"100%\"\r\n    >\r\n    </eui-search>\r\n    <div class=\"sap-analysis__table\">\r\n      <table mat-table matSort [dataSource]=\"profileDataSource\" *ngIf=\"profileDataSource.data.length > 0\">\r\n        <ng-container matColumnDef=\"Ident_SAPProfile\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{'#LDS#Authentication' | translate}}</th>\r\n          <td mat-cell *matCellDef=\"let data\">{{ data.Ident_SAPProfile }}</td>\r\n        </ng-container>\r\n        <ng-container matColumnDef=\"Objects\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{'#LDS#Objects' | translate}}</th>\r\n          <td mat-cell *matCellDef=\"let data\">{{ data.Objects }}</td>\r\n        </ng-container>\r\n        <ng-container matColumnDef=\"Field\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{'#LDS#Field' | translate}}</th>\r\n          <td mat-cell *matCellDef=\"let data\">{{ data.Field }}</td>\r\n        </ng-container>\r\n        <ng-container matColumnDef=\"LowerLimit\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{'#LDS#From' | translate}}</th>\r\n          <td mat-cell *matCellDef=\"let data\">{{ data.LowerLimit }}</td>\r\n        </ng-container>\r\n        <ng-container matColumnDef=\"UpperLimit\">\r\n          <th mat-header-cell *matHeaderCellDef mat-sort-header>{{'#LDS#To' | translate}}</th>\r\n          <td mat-cell *matCellDef=\"let data\">{{ data.UpperLimit }}</td>\r\n        </ng-container>\r\n        <tr mat-header-row *matHeaderRowDef=\"displayedProfileColumns; sticky: true\"></tr>\r\n        <tr mat-row *matRowDef=\"let row; columns: displayedProfileColumns\"></tr>\r\n      </table>\r\n      <div *ngIf=\"profileDataSource.data.length == 0\" class=\"no-results\">\r\n        <eui-icon [icon]=\"'table'\"></eui-icon>\r\n        <p>{{ '#LDS#No data' | translate}}</p>\r\n      </div>\r\n    </div>\r\n  </mat-card>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.sap-analysis{display:flex;gap:16px;height:100%;justify-content:space-between}.sap-analysis__table{overflow:hidden auto;flex-grow:1}.sap-analysis .mat-card{width:100%;transition:width .4s ease;display:flex;flex-direction:column;gap:20px}.sap-analysis .mat-card--decreased{padding:0;width:48px}.sap-analysis .mat-card--decreased .mat-card__header{height:100%}.sap-analysis .mat-card--decreased .mat-card__header__title{display:none}.sap-analysis .mat-card--decreased .mat-card__header button{width:48px;padding:20px 0;min-width:unset;height:100%}.sap-analysis .mat-card--decreased .mat-card__header button ::ng-deep .mat-button-wrapper{height:100%;display:flex;flex-direction:column}.sap-analysis .mat-card--decreased .mat-card__header button h3{display:block;margin:auto 0;rotate:-90deg}.sap-analysis .mat-card--decreased .mat-card__header button .eui-icon{rotate:180deg}.sap-analysis .mat-card--decreased .sap-analysis__table,.sap-analysis .mat-card--decreased eui-search{display:none}.sap-analysis .mat-card__header{display:flex;align-items:center;justify-content:space-between}.sap-analysis .mat-card__header__title--wide{margin:auto}.sap-analysis .mat-card__header button{padding:0;min-width:32px}.sap-analysis .mat-card__header button h3{display:none}.sap-analysis .mat-card__header button .eui-icon{transition:rotate .4s ease}.sap-analysis .mat-table{box-shadow:none}.sap-analysis .mat-table .td--no-wrap{white-space:nowrap}.sap-analysis .mat-table .sap-analysis-table-row-highlighted:hover{background-color:#f2f6f7;cursor:pointer}:host ::ng-deep .mat-table tbody .mat-row .mat-cell .imx-table-column-ellipsis{width:120px;display:block;white-space:nowrap;overflow-x:hidden;text-overflow:ellipsis}.eui-dark-theme :host .sap-analysis .mat-table .sap-analysis-table-row-highlighted:hover{background-color:#616566}\n"] }]
    }], function () { return [{ type: i0.ChangeDetectorRef }]; }, { resultByRole: [{
            type: Input
        }], sort: [{
            type: ViewChild,
            args: [MatSort]
        }] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function SapComplianceViolationComponent_div_1_mat_form_field_1_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-option", 11);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const account_r9 = ctx.$implicit;
    i0.ɵɵproperty("value", account_r9);
    i0.ɵɵattribute("data-imx-identifier", "sap-user-option-" + account_r9.GetEntity().GetDisplay());
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", account_r9.GetEntity().GetDisplay(), " ");
} }
function SapComplianceViolationComponent_div_1_mat_form_field_1_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-form-field", 8)(1, "mat-label");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "mat-select", 9);
    i0.ɵɵlistener("selectionChange", function SapComplianceViolationComponent_div_1_mat_form_field_1_Template_mat_select_selectionChange_4_listener() { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r10.onUserOptionSelected()); })("valueChange", function SapComplianceViolationComponent_div_1_mat_form_field_1_Template_mat_select_valueChange_4_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r12 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r12.selectedAccount = $event); });
    i0.ɵɵtemplate(5, SapComplianceViolationComponent_div_1_mat_form_field_1_mat_option_5_Template, 2, 3, "mat-option", 10);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r5 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 4, "#LDS#SAP user"));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("value", ctx_r5.selectedAccount)("disabled", ctx_r5.loading);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngForOf", ctx_r5.accounts);
} }
function SapComplianceViolationComponent_div_1_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span");
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1("", i0.ɵɵpipeBind1(2, 1, "#LDS#Rule analysis"), ":");
} }
function SapComplianceViolationComponent_div_1_mat_chip_list_3_mat_chip_1_Template(rf, ctx) { if (rf & 1) {
    const _r16 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-chip", 13);
    i0.ɵɵlistener("click", function SapComplianceViolationComponent_div_1_mat_chip_list_3_mat_chip_1_Template_mat_chip_click_0_listener() { const restoredCtx = i0.ɵɵrestoreView(_r16); const option_r14 = restoredCtx.$implicit; const ctx_r15 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r15.onSelectionChange(option_r14)); });
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r14 = ctx.$implicit;
    const ctx_r13 = i0.ɵɵnextContext(3);
    i0.ɵɵproperty("selected", ctx_r13.isOptionSelected(option_r14.value))("disabled", ctx_r13.loading);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, option_r14.label), " ");
} }
function SapComplianceViolationComponent_div_1_mat_chip_list_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "mat-chip-list");
    i0.ɵɵtemplate(1, SapComplianceViolationComponent_div_1_mat_chip_list_3_mat_chip_1_Template, 3, 5, "mat-chip", 12);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r7 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngForOf", ctx_r7.selectionOptions);
} }
function SapComplianceViolationComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 6);
    i0.ɵɵtemplate(1, SapComplianceViolationComponent_div_1_mat_form_field_1_Template, 6, 6, "mat-form-field", 7);
    i0.ɵɵtemplate(2, SapComplianceViolationComponent_div_1_span_2_Template, 3, 3, "span", 2);
    i0.ɵɵtemplate(3, SapComplianceViolationComponent_div_1_mat_chip_list_3_Template, 2, 1, "mat-chip-list", 2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", (ctx_r0.accounts == null ? null : ctx_r0.accounts.length) > 1);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.hideChips);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", !ctx_r0.hideChips);
} }
function SapComplianceViolationComponent_mat_spinner_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "mat-spinner");
} }
function SapComplianceViolationComponent_imx_sap_compliance_violation_views_by_role_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-sap-compliance-violation-views-by-role", 14);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("resultByRole", ctx_r2.resultByRole);
} }
function SapComplianceViolationComponent_imx_sap_compliance_violation_views_by_ability_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "imx-sap-compliance-violation-views-by-ability", 15);
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵproperty("resultByAbility", ctx_r3.resultByAbility);
} }
function SapComplianceViolationComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 16);
    i0.ɵɵelement(1, "eui-icon", 17);
    i0.ɵɵelementStart(2, "p");
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("icon", "table");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(4, 2, "#LDS#No data"));
} }
class SapComplianceViolationComponent {
    constructor(api) {
        this.api = api;
        this.accounts = [];
        this.resultByRole = { Elements: [] };
        this.resultByAbility = { Data: [] };
        this.selectionOptions = [
            { value: SapSelectionTypeEnum.ROLE, label: '#LDS#By role' },
            { value: SapSelectionTypeEnum.ABILITY, label: '#LDS#By ability' },
        ];
        this.selectedOption = SapSelectionTypeEnum.ROLE;
        this.loading = false;
        this.sapSelectionTypeEnum = SapSelectionTypeEnum;
    }
    async ngOnInit() {
        this.loading = true;
        const uidPerson = this.data.selectedRulesViolation.UID_Person.value;
        this.accounts = (await this.api.typedClient.PortalTargetsystemSapuser.Get({
            UID_PersonAssociated: uidPerson,
        })).Data;
        if (this.accounts.length > 0 && !!this.data.complianceRule?.EntityKeysData?.Keys?.[0]) {
            this.selectedAccount = this.accounts[0];
            await this.loadResult();
        }
        this.loading = false;
    }
    onSelectionChange(option) {
        this.selectedOption = option.value;
    }
    isOptionSelected(value) {
        return value === this.selectedOption;
    }
    onUserOptionSelected() {
        this.loadResult();
    }
    get showNoData() {
        const roleLength = this.resultByRole?.Elements?.length || 0;
        const abilityLength = this.resultByAbility?.Data?.length || 0;
        return (!this.loading &&
            ((this.isOptionSelected(this.sapSelectionTypeEnum.ROLE) && roleLength == 0) ||
                (this.isOptionSelected(this.sapSelectionTypeEnum.ABILITY) && abilityLength == 0)));
    }
    get hideChips() {
        return this.resultByRole?.Elements?.length == 0 && this.resultByAbility?.Data?.length == 0;
    }
    async loadResult() {
        this.loading = true;
        const uidsapuser = this.selectedAccount.GetEntity().GetKeys()[0];
        this.resultByAbility = await this.api.client.portal_sap_ruleanalysis_fld_get(uidsapuser, this.data.complianceRule?.EntityKeysData?.Keys?.[0]);
        this.resultByRole = await this.api.client.portal_sap_ruleanalysis_byrole_get(uidsapuser, this.data.complianceRule?.EntityKeysData?.Keys?.[0]);
        this.loading = false;
    }
}
SapComplianceViolationComponent.ɵfac = function SapComplianceViolationComponent_Factory(t) { return new (t || SapComplianceViolationComponent)(i0.ɵɵdirectiveInject(SapComplianceApiService)); };
SapComplianceViolationComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SapComplianceViolationComponent, selectors: [["ng-component"]], decls: 6, vars: 5, consts: [["eui-sidesheet-content", ""], ["class", "imx-sap-compliance-selection", 4, "ngIf"], [4, "ngIf"], [3, "resultByRole", 4, "ngIf"], [3, "resultByAbility", 4, "ngIf"], ["class", "no-results", 4, "ngIf"], [1, "imx-sap-compliance-selection"], ["appearance", "outline", "class", "namespace-selector", 4, "ngIf"], ["appearance", "outline", 1, "namespace-selector"], ["required", "", "data-imx-identifier", "sap-user-select", 3, "value", "disabled", "selectionChange", "valueChange"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], ["color", "primary", 3, "selected", "disabled", "click", 4, "ngFor", "ngForOf"], ["color", "primary", 3, "selected", "disabled", "click"], [3, "resultByRole"], [3, "resultByAbility"], [1, "no-results"], [3, "icon"]], template: function SapComplianceViolationComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0);
        i0.ɵɵtemplate(1, SapComplianceViolationComponent_div_1_Template, 4, 3, "div", 1);
        i0.ɵɵtemplate(2, SapComplianceViolationComponent_mat_spinner_2_Template, 1, 0, "mat-spinner", 2);
        i0.ɵɵtemplate(3, SapComplianceViolationComponent_imx_sap_compliance_violation_views_by_role_3_Template, 1, 1, "imx-sap-compliance-violation-views-by-role", 3);
        i0.ɵɵtemplate(4, SapComplianceViolationComponent_imx_sap_compliance_violation_views_by_ability_4_Template, 1, 1, "imx-sap-compliance-violation-views-by-ability", 4);
        i0.ɵɵtemplate(5, SapComplianceViolationComponent_div_5_Template, 5, 4, "div", 5);
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx.loading);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx.loading);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx.loading && ctx.isOptionSelected(ctx.sapSelectionTypeEnum.ROLE) && (ctx.resultByRole.Elements == null ? null : ctx.resultByRole.Elements.length) > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx.loading && ctx.isOptionSelected(ctx.sapSelectionTypeEnum.ABILITY) && (ctx.resultByAbility.Data == null ? null : ctx.resultByAbility.Data.length) > 0);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx.loading && ctx.showNoData);
    } }, dependencies: [i2.NgForOf, i2.NgIf, i3.EuiIconComponent, i3.EuiSidesheetContentDirective, i4$1.MatOption, i5$1.MatChipList, i5$1.MatChip, i6$1.MatFormField, i6$1.MatLabel, i7$1.MatProgressSpinner, i8$1.MatSelect, SapComplianceViolationViewsByAbilityComponent, SapComplianceViolationViewsByRoleComponent, i1$1.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]{display:flex;flex-direction:column}.eui-sidesheet-content[_ngcontent-%COMP%]   imx-sap-compliance-violation-views-by-role[_ngcontent-%COMP%], .eui-sidesheet-content[_ngcontent-%COMP%]   imx-sap-compliance-violation-views-by-ability[_ngcontent-%COMP%]{display:block;overflow:hidden;height:100%}.eui-sidesheet-content[_ngcontent-%COMP%]   .mat-progress-spinner[_ngcontent-%COMP%]{margin:auto}.eui-sidesheet-content[_ngcontent-%COMP%]   .mat-chip[_ngcontent-%COMP%]{cursor:pointer}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-sap-compliance-selection[_ngcontent-%COMP%]{display:flex;align-items:baseline;font-size:14px;gap:20px}.eui-sidesheet-content[_ngcontent-%COMP%]   .imx-sap-compliance-selection[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{padding-bottom:20px}.eui-sidesheet-content[_ngcontent-%COMP%]     .no-results{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.eui-sidesheet-content[_ngcontent-%COMP%]     .no-results .eui-icon{font-size:100px;color:#dfe4e6}.eui-sidesheet-content[_ngcontent-%COMP%]     .no-results p{margin:0;font-size:18px;color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]     .no-results eui-icon{color:#c4cacc}.eui-dark-theme   [_nghost-%COMP%]   .eui-sidesheet-content[_ngcontent-%COMP%]     .no-results p{color:#dfe4e6}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SapComplianceViolationComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\r\n  <div class=\"imx-sap-compliance-selection\" *ngIf=\"!loading\">\r\n    <mat-form-field appearance=\"outline\" class=\"namespace-selector\" *ngIf=\"this.accounts?.length > 1\">\r\n      <mat-label>{{ '#LDS#SAP user' | translate }}</mat-label>\r\n      <mat-select required (selectionChange)=\"onUserOptionSelected()\" [(value)]=\"selectedAccount\" [disabled]=\"loading\" data-imx-identifier=\"sap-user-select\">\r\n        <mat-option *ngFor=\"let account of accounts\" [value]=\"account\" [attr.data-imx-identifier]=\"'sap-user-option-' + account.GetEntity().GetDisplay()\">\r\n          {{ account.GetEntity().GetDisplay() }}\r\n        </mat-option>\r\n      </mat-select>\r\n    </mat-form-field>\r\n    <span *ngIf=\"!hideChips\">{{ '#LDS#Rule analysis' | translate }}:</span>\r\n    <mat-chip-list *ngIf=\"!hideChips\">\r\n      <mat-chip *ngFor=\"let option of selectionOptions\" (click)=\"onSelectionChange(option)\" [selected]=\"isOptionSelected(option.value)\" color=\"primary\" [disabled]=\"loading\">\r\n        {{ option.label | translate }}\r\n      </mat-chip>\r\n    </mat-chip-list>\r\n  </div>\r\n  <mat-spinner *ngIf=\"loading\"></mat-spinner>\r\n  <imx-sap-compliance-violation-views-by-role\r\n    [resultByRole]=\"resultByRole\"\r\n    *ngIf=\"!loading && isOptionSelected(sapSelectionTypeEnum.ROLE) && resultByRole.Elements?.length > 0\"\r\n  ></imx-sap-compliance-violation-views-by-role>\r\n  <imx-sap-compliance-violation-views-by-ability\r\n    [resultByAbility]=\"resultByAbility\"\r\n    *ngIf=\"!loading && isOptionSelected(sapSelectionTypeEnum.ABILITY) && resultByAbility.Data?.length > 0\"\r\n  ></imx-sap-compliance-violation-views-by-ability>\r\n  <div *ngIf=\"!loading && showNoData\" class=\"no-results\">\r\n    <eui-icon [icon]=\"'table'\"></eui-icon>\r\n    <p>{{ '#LDS#No data' | translate }}</p>\r\n  </div>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.eui-sidesheet-content{display:flex;flex-direction:column}.eui-sidesheet-content imx-sap-compliance-violation-views-by-role,.eui-sidesheet-content imx-sap-compliance-violation-views-by-ability{display:block;overflow:hidden;height:100%}.eui-sidesheet-content .mat-progress-spinner{margin:auto}.eui-sidesheet-content .mat-chip{cursor:pointer}.eui-sidesheet-content .imx-sap-compliance-selection{display:flex;align-items:baseline;font-size:14px;gap:20px}.eui-sidesheet-content .imx-sap-compliance-selection span{padding-bottom:20px}.eui-sidesheet-content ::ng-deep .no-results{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.eui-sidesheet-content ::ng-deep .no-results .eui-icon{font-size:100px;color:#dfe4e6}.eui-sidesheet-content ::ng-deep .no-results p{margin:0;font-size:18px;color:#2f3233}.eui-dark-theme :host .eui-sidesheet-content ::ng-deep .no-results eui-icon{color:#c4cacc}.eui-dark-theme :host .eui-sidesheet-content ::ng-deep .no-results p{color:#dfe4e6}\n"] }]
    }], function () { return [{ type: SapComplianceApiService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    constructor(extService) {
        this.extService = extService;
    }
    onInit() {
        this.extService.register('RuleViolationsTab', { instance: SapComplianceViolationComponent, inputData: { label: '#LDS#Heading SAP Functions' } });
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i1.ExtService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], function () { return [{ type: i1.ExtService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class SacConfigModule {
    constructor(initservice, logger) {
        this.initservice = initservice;
        this.logger = logger;
        this.logger.info(this, '🔥 SAC loaded');
        this.initservice.onInit();
        this.logger.info(this, '▶️ SAC initialized');
    }
}
SacConfigModule.ɵfac = function SacConfigModule_Factory(t) { return new (t || SacConfigModule)(i0.ɵɵinject(InitService), i0.ɵɵinject(i1.ClassloggerService)); };
SacConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: SacConfigModule });
SacConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        TranslateModule,
        EuiCoreModule,
        EuiMaterialModule,
        MatTabsModule,
        MatCardModule,
        MatChipsModule,
        MatProgressSpinnerModule,
        MatSortModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTreeWrapperModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SacConfigModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    SapComplianceViolationComponent,
                    SapComplianceViolationViewsByAbilityComponent,
                    SapComplianceViolationViewsByRoleComponent,
                ],
                imports: [
                    CommonModule,
                    TranslateModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    MatTabsModule,
                    MatCardModule,
                    MatChipsModule,
                    MatProgressSpinnerModule,
                    MatSortModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    DataTreeWrapperModule,
                ],
            }]
    }], function () { return [{ type: InitService }, { type: i1.ClassloggerService }]; }, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(SacConfigModule, { declarations: [SapComplianceViolationComponent,
        SapComplianceViolationViewsByAbilityComponent,
        SapComplianceViolationViewsByRoleComponent], imports: [CommonModule,
        TranslateModule,
        EuiCoreModule,
        EuiMaterialModule,
        MatTabsModule,
        MatCardModule,
        MatChipsModule,
        MatProgressSpinnerModule,
        MatSortModule,
        DataSourceToolbarModule,
        DataTableModule,
        DataTreeWrapperModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of sac
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SacConfigModule };
//# sourceMappingURL=sac.mjs.map
