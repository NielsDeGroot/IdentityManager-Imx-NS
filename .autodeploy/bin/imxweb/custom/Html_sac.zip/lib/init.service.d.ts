import { ExtService } from "qbm";
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly extService;
    constructor(extService: ExtService);
    onInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
