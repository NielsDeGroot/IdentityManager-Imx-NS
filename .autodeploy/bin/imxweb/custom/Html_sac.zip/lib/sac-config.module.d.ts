import { InitService } from './init.service';
import { ClassloggerService } from 'qbm';
import * as i0 from "@angular/core";
import * as i1 from "./sap-compliance-violation/sap-compliance-violation.component";
import * as i2 from "./sap-compliance-violation/sap-compliance-violation-views-by-ability/sap-compliance-violation-views-by-ability.component";
import * as i3 from "./sap-compliance-violation/sap-compliance-violation-views-by-role/sap-compliance-violation-views-by-role.component";
import * as i4 from "@angular/common";
import * as i5 from "@ngx-translate/core";
import * as i6 from "@elemental-ui/core";
import * as i7 from "@angular/material/tabs";
import * as i8 from "@angular/material/card";
import * as i9 from "@angular/material/chips";
import * as i10 from "@angular/material/progress-spinner";
import * as i11 from "@angular/material/sort";
import * as i12 from "qbm";
export declare class SacConfigModule {
    private readonly initservice;
    private readonly logger;
    constructor(initservice: InitService, logger: ClassloggerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<SacConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SacConfigModule, [typeof i1.SapComplianceViolationComponent, typeof i2.SapComplianceViolationViewsByAbilityComponent, typeof i3.SapComplianceViolationViewsByRoleComponent], [typeof i4.CommonModule, typeof i5.TranslateModule, typeof i6.EuiCoreModule, typeof i6.EuiMaterialModule, typeof i7.MatTabsModule, typeof i8.MatCardModule, typeof i9.MatChipsModule, typeof i10.MatProgressSpinnerModule, typeof i11.MatSortModule, typeof i12.DataSourceToolbarModule, typeof i12.DataTableModule, typeof i12.DataTreeWrapperModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SacConfigModule>;
}
