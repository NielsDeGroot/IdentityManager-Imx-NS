import { EntityCollectionData, EntityData, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { SapComplianceByAbilityEntity } from './sap-compliance-violation-views-by-ability-entity';
import { SAPUserFunctionSrcFLD } from 'imx-api-sac';
export declare class SapComplianceByAbilityBuilder {
    readonly entitySchema: import("imx-qbm-dbts").EntitySchema;
    private readonly builder;
    build(entityCollectionData: EntityCollectionData): TypedEntityCollectionData<SapComplianceByAbilityEntity>;
    buildEntityCollectionData(items: SAPUserFunctionSrcFLD[]): EntityCollectionData;
    buildEntityData(item: SAPUserFunctionSrcFLD): EntityData;
}
