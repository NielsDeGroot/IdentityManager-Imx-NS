import { ByAbilityResult } from 'imx-api-sac';
import { CollectionLoadParameters, EntitySchema, GroupInfoData, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings, DataTableGroupedData } from 'qbm';
import { SapComplianceByAbilityEntity } from './sap-compliance-violation-views-by-ability-entity';
import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
export declare class SapComplianceViolationViewsByAbilityComponent {
    private translateService;
    set resultByAbility(value: ByAbilityResult);
    get resultByAbility(): ByAbilityResult;
    _resultByAbility: ByAbilityResult;
    dstSettings: DataSourceToolbarSettings;
    entitySchema: EntitySchema;
    dataSource: TypedEntityCollectionData<SapComplianceByAbilityEntity>;
    groupData: {
        [key: string]: DataTableGroupedData;
    };
    private defaultData;
    private sapComplianceByAbilityBuilder;
    constructor(translateService: TranslateService);
    /**
     * Called when search action is emitted.
     * @param searchValue current search param
     */
    onSearch(searchValue: string): void;
    /**
     * Updates the selected group data. Called when group action is emitted.
     * @param groupKey selected grouping key
     */
    onGroupingChange(groupInfo: {
        key: string;
        isInitial: boolean;
    }): void;
    /**
     * Called when navigaiton state changed. Here is called when search badge is removed.
     */
    onNavigationStateChanged(params: CollectionLoadParameters): void;
    /**
     * Build the data source and the data source toolbar settings.
     */
    private buildDataSource;
    /**
     * Creating data source toolbar group setting.
     * @returns Data source toolbar group setting.
     */
    private createGroupData;
    /**
     * The method generating the group info data from the group column key.
     * @param groupColumn
     * @returns Generated group info data.
     */
    groupingData(groupColumn: string): Promise<GroupInfoData>;
    /**
     * The method filter the data source with the filter column name.
     * @param filter
     * @returns Filtered data source.
     */
    private getFilteredData;
    static ɵfac: i0.ɵɵFactoryDeclaration<SapComplianceViolationViewsByAbilityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SapComplianceViolationViewsByAbilityComponent, "imx-sap-compliance-violation-views-by-ability", never, { "resultByAbility": "resultByAbility"; }, {}, never, never, false>;
}
