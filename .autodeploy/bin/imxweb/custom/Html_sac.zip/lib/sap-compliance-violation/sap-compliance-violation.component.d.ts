import { OnInit } from '@angular/core';
import { PortalRules, PortalRulesViolations } from 'imx-api-cpl';
import { ByAbilityResult, ByRoleResult, PortalTargetsystemSapuser } from 'imx-api-sac';
import { SapComplianceApiService } from '../sac-api-client.service';
import { SapSelectionOptions, SapSelectionTypeEnum } from './sap-compliance-violation.model';
import * as i0 from "@angular/core";
export declare class SapComplianceViolationComponent implements OnInit {
    private readonly api;
    data: {
        selectedRulesViolation: PortalRulesViolations;
        complianceRule: PortalRules;
    };
    accounts: PortalTargetsystemSapuser[];
    resultByRole: ByRoleResult;
    resultByAbility: ByAbilityResult;
    selectionOptions: SapSelectionOptions[];
    selectedOption: SapSelectionTypeEnum;
    loading: boolean;
    sapSelectionTypeEnum: typeof SapSelectionTypeEnum;
    selectedAccount: PortalTargetsystemSapuser;
    constructor(api: SapComplianceApiService);
    ngOnInit(): Promise<void>;
    onSelectionChange(option: SapSelectionOptions): void;
    isOptionSelected(value: SapSelectionTypeEnum): boolean;
    onUserOptionSelected(): void;
    get showNoData(): boolean;
    get hideChips(): boolean;
    private loadResult;
    static ɵfac: i0.ɵɵFactoryDeclaration<SapComplianceViolationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SapComplianceViolationComponent, "ng-component", never, {}, {}, never, never, false>;
}
