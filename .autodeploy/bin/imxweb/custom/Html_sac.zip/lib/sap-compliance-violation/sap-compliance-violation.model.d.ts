import { ByRoleResultElement } from 'imx-api-sac';
export interface SapRoleTreeNodeModel extends ByRoleResultElement {
    level: number;
    expandable: boolean;
}
export declare enum SapSelectionTypeEnum {
    ROLE = "ROLE",
    ABILITY = "ABILITY"
}
export interface SapSelectionOptions {
    label: string;
    value: SapSelectionTypeEnum;
}
