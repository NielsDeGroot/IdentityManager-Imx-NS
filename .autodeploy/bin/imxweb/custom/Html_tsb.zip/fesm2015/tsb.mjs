import * as i7 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, NgModule, ViewChild, Input, Inject, EventEmitter, Output } from '@angular/core';
import * as i8 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i10 from '@angular/material/stepper';
import { MatStepperModule } from '@angular/material/stepper';
import * as i9 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i1$2 from '@angular/forms';
import { UntypedFormGroup, FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import * as i1$1 from '@elemental-ui/core';
import { EuiCoreModule, EUI_SIDESHEET_DATA, EuiDownloadDirective, EuiMaterialModule } from '@elemental-ui/core';
import * as i7$1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i2 from 'qbm';
import { BaseCdr, CdrModule, LdsReplaceModule, HelpContextualModule, EntityTreeDatabase, CdrFactoryService, FkAdvancedPickerComponent, BusyService, FilterTreeDatabase, HELP_CONTEXTUAL, DataSourceToolbarModule, DataTableModule, DataTreeModule, ExtModule, BusyIndicatorModule, DynamicTabsModule, ObjectHistoryModule, SelectedElementsModule, RouteGuardService, TileModule } from 'qbm';
import { __awaiter } from 'tslib';
import * as i7$3 from 'imx-api-tsb';
import { V2Client, TypedClient, V2ApiClientMethodFactory, PortalTargetsystemUnsGroupServiceitem } from 'imx-api-tsb';
import { DbObjectKey, ValType, TypedEntity, DisplayColumns, CompareOperator, FilterType, MethodDefinition, WriteExtTypedEntity } from 'imx-qbm-dbts';
import * as i1 from 'qer';
import { SourceDetectiveType, SourceDetectiveSidesheetComponent, ObjectHyperviewModule, OwnerControlModule, ServiceItemsEditFormModule, IdentityRoleMembershipsModule, RequestableEntitlementType, BusinessownerAddonTileModule, BusinessownerOverviewTileModule } from 'qer';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import * as i1$3 from '@angular/router';
import { RouterModule } from '@angular/router';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule } from '@angular/material/sidenav';
import * as i10$1 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i10$2 from '@angular/material/tabs';
import * as i8$1 from '@angular/material/tooltip';
import * as i7$2 from '@angular/material/button-toggle';
import { Subject, Observable } from 'rxjs';
import * as i11 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i11$1 from '@angular/material/slide-toggle';
import * as i5 from '@angular/common/http';
import * as i6 from '@angular/cdk/overlay';
import * as i5$1 from '@angular/material/divider';
import * as i6$1 from '@angular/material/form-field';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class TsbApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing TSB API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
TsbApiService.ɵfac = function TsbApiService_Factory(t) { return new (t || TsbApiService)(i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(i2.ImxTranslationProviderService)); };
TsbApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TsbApiService, factory: TsbApiService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TsbApiService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i2.AppConfigService }, { type: i2.ClassloggerService }, { type: i2.ImxTranslationProviderService }]; }, null);
})();

class TargetSystemService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    getUserConfig() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.client.portal_targetsystem_userconfig_get();
        });
    }
}
TargetSystemService.ɵfac = function TargetSystemService_Factory(t) { return new (t || TargetSystemService)(i0.ɵɵinject(TsbApiService)); };
TargetSystemService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TargetSystemService, factory: TargetSystemService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TargetSystemService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: TsbApiService }]; }, null);
})();

class ClaimGroupService {
    constructor(apiService, entityService) {
        this.apiService = apiService;
        this.entityService = entityService;
    }
    hasSuggestedOwners(tableName, key) {
        return __awaiter(this, void 0, void 0, function* () {
            const collection = yield this.getOwnerCandidates(tableName, key);
            return collection.Entities != null && collection.Entities.length > 0;
        });
    }
    assignOwner(tableName, key, uidOwner) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.apiService.client.portal_claimgroup_post(uidOwner, tableName, key);
        });
    }
    getFkValue(column) {
        const dbObjectKey = DbObjectKey.FromXml(column.GetValue());
        return {
            table: dbObjectKey.TableName,
            key: dbObjectKey.Keys[0]
        };
    }
    createCdrSystemEntitlement() {
        const column = this.createColumn({
            ChildColumnName: 'UID_UNSGroup',
            IsMemberRelation: false,
            ParentTableName: 'UNSGroup',
            ParentColumnName: 'XObjectKey'
        }, parameters => this.apiService.client.portal_claimgroup_group_get(parameters));
        return new BaseCdr(column, '#LDS#System entitlement' /* TODO: globalize */);
    }
    createColumnSuggestedOwner(tableName, key) {
        const fkRelation = {
            ChildColumnName: 'UID_Owner',
            IsMemberRelation: false,
            ParentTableName: tableName,
            ParentColumnName: 'XObjectKey'
        };
        return this.createColumn(fkRelation, parameters => this.getOwnerCandidates(fkRelation.ParentTableName, key, parameters));
    }
    createColumn(fkRelation, loadFkCandidates) {
        return this.entityService.createLocalEntityColumn({
            ColumnName: fkRelation.ChildColumnName,
            Type: ValType.String,
            MinLen: 1,
            FkRelation: fkRelation
        }, [{
                columnName: fkRelation.ChildColumnName,
                fkTableName: fkRelation.ParentTableName,
                parameterNames: [
                    'OrderBy',
                    'StartIndex',
                    'PageSize',
                    'filter',
                    'search',
                ],
                load: (_, parameters = {}) => __awaiter(this, void 0, void 0, function* () { return loadFkCandidates(parameters); }),
                getDataModel: () => __awaiter(this, void 0, void 0, function* () { return ({}); }),
                getFilterTree: () => __awaiter(this, void 0, void 0, function* () { return ({ Elements: [] }); })
            }]);
    }
    getOwnerCandidates(tableName, uid, parameters = {}) {
        return __awaiter(this, void 0, void 0, function* () {
            const collection = yield this.apiService.client.portal_claimgroup_suggestedowner_get(tableName, uid, parameters);
            if (collection.Entities && collection.Entities.length > 0) {
                return collection;
            }
            return this.apiService.client.portal_claimgroup_suggestedowner2_get(tableName, uid, parameters);
        });
    }
}
ClaimGroupService.ɵfac = function ClaimGroupService_Factory(t) { return new (t || ClaimGroupService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.EntityService)); };
ClaimGroupService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ClaimGroupService, factory: ClaimGroupService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ClaimGroupService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: TsbApiService }, { type: i2.EntityService }]; }, null);
})();

function ClaimGroupComponent_mat_stepper_6_button_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 17);
        i0.ɵɵlistener("click", function ClaimGroupComponent_mat_stepper_6_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r12); const ctx_r11 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r11.loadSuggestedOwners()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r4 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("disabled", ctx_r4.entitlementForm.invalid);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Next"), " ");
    }
}
function ClaimGroupComponent_mat_stepper_6_ng_template_8_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "ldsReplace");
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r13 = i0.ɵɵnextContext(3);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind2(2, 1, i0.ɵɵpipeBind1(3, 4, "#LDS#Specify the owner for the system entitlement \"{0}\"."), ctx_r13.entitlementCdr.column.GetDisplayValue()), " ");
    }
}
function ClaimGroupComponent_mat_stepper_6_ng_template_8_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(1, 1, "#LDS#Specify the owner"), " ");
    }
}
function ClaimGroupComponent_mat_stepper_6_ng_template_8_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, ClaimGroupComponent_mat_stepper_6_ng_template_8_ng_container_0_Template, 4, 6, "ng-container", 18);
        i0.ɵɵtemplate(1, ClaimGroupComponent_mat_stepper_6_ng_template_8_ng_template_1_Template, 2, 3, "ng-template", null, 19, i0.ɵɵtemplateRefExtractor);
    }
    if (rf & 2) {
        const _r14 = i0.ɵɵreference(2);
        const ctx_r5 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("ngIf", ctx_r5.entitlementCdr.column.GetDisplayValue())("ngIfElse", _r14);
    }
}
function ClaimGroupComponent_mat_stepper_6_mat_radio_group_12_mat_radio_button_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-radio-button", 22);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const option_r17 = ctx.$implicit;
        const i_r18 = ctx.index;
        i0.ɵɵproperty("value", option_r17)("checked", i_r18 === 0);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, option_r17.title), " ");
    }
}
function ClaimGroupComponent_mat_stepper_6_mat_radio_group_12_Template(rf, ctx) {
    if (rf & 1) {
        const _r20 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-radio-group", 20);
        i0.ɵɵlistener("change", function ClaimGroupComponent_mat_stepper_6_mat_radio_group_12_Template_mat_radio_group_change_0_listener($event) { i0.ɵɵrestoreView(_r20); const ctx_r19 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r19.ownerCandidateListChange($event)); });
        i0.ɵɵtemplate(1, ClaimGroupComponent_mat_stepper_6_mat_radio_group_12_mat_radio_button_1_Template, 3, 5, "mat-radio-button", 21);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r6.ownershipOptions);
    }
}
function ClaimGroupComponent_mat_stepper_6_imx_cdr_editor_14_Template(rf, ctx) {
    if (rf & 1) {
        const _r22 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 8);
        i0.ɵɵlistener("controlCreated", function ClaimGroupComponent_mat_stepper_6_imx_cdr_editor_14_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r22); const ctx_r21 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r21.ownerForm.addControl(ctx_r21.ownerCdr.column.ColumnName, $event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r7 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("cdr", ctx_r7.ownerCdr);
    }
}
function ClaimGroupComponent_mat_stepper_6_button_18_Template(rf, ctx) {
    if (rf & 1) {
        const _r24 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 17);
        i0.ɵɵlistener("click", function ClaimGroupComponent_mat_stepper_6_button_18_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r24); const ctx_r23 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r23.assignOwner()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r8 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("disabled", ctx_r8.ownerForm.invalid);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 2, "#LDS#Next"));
    }
}
function ClaimGroupComponent_mat_stepper_6_ng_template_20_ng_container_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "ldsReplace");
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const ctx_r25 = i0.ɵɵnextContext(3);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind3(2, 1, i0.ɵɵpipeBind1(3, 5, "#LDS#Assign ownership for the system entitlement \"{0}\" to \"{1}\"."), ctx_r25.entitlementCdr.column.GetDisplayValue(), ctx_r25.ownerDisplay), " ");
    }
}
function ClaimGroupComponent_mat_stepper_6_ng_template_20_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtext(0);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(1, 1, "#LDS#Assign ownership"), " ");
    }
}
function ClaimGroupComponent_mat_stepper_6_ng_template_20_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, ClaimGroupComponent_mat_stepper_6_ng_template_20_ng_container_0_Template, 4, 7, "ng-container", 18);
        i0.ɵɵtemplate(1, ClaimGroupComponent_mat_stepper_6_ng_template_20_ng_template_1_Template, 2, 3, "ng-template", null, 19, i0.ɵɵtemplateRefExtractor);
    }
    if (rf & 2) {
        const _r26 = i0.ɵɵreference(2);
        const ctx_r9 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("ngIf", ctx_r9.entitlementCdr.column.GetDisplayValue() && ctx_r9.ownerDisplay)("ngIfElse", _r26);
    }
}
function ClaimGroupComponent_mat_stepper_6_div_21_Template(rf, ctx) {
    if (rf & 1) {
        const _r29 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 23)(1, "p");
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "button", 24);
        i0.ɵɵlistener("click", function ClaimGroupComponent_mat_stepper_6_div_21_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r29); i0.ɵɵnextContext(); const _r3 = i0.ɵɵreference(1); const ctx_r28 = i0.ɵɵnextContext(); ctx_r28.resetForms(); return i0.ɵɵresetView(_r3.reset()); });
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Your changes have been successfully saved. It may take some time for the changes to take effect."), " ");
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Assign another system entitlement"));
    }
}
function ClaimGroupComponent_mat_stepper_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r31 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-stepper", 4, 5);
        i0.ɵɵlistener("selectionChange", function ClaimGroupComponent_mat_stepper_6_Template_mat_stepper_selectionChange_0_listener($event) { i0.ɵɵrestoreView(_r31); const ctx_r30 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r30.stepChange($event)); });
        i0.ɵɵelementStart(2, "mat-step", 6);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementStart(4, "form", 7)(5, "imx-cdr-editor", 8);
        i0.ɵɵlistener("controlCreated", function ClaimGroupComponent_mat_stepper_6_Template_imx_cdr_editor_controlCreated_5_listener($event) { i0.ɵɵrestoreView(_r31); const ctx_r32 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r32.entitlementForm.addControl(ctx_r32.entitlementCdr.column.ColumnName, $event)); });
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(6, ClaimGroupComponent_mat_stepper_6_button_6_Template, 3, 4, "button", 9);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "mat-step", 10);
        i0.ɵɵtemplate(8, ClaimGroupComponent_mat_stepper_6_ng_template_8_Template, 3, 2, "ng-template", 11);
        i0.ɵɵelementStart(9, "p");
        i0.ɵɵtext(10);
        i0.ɵɵpipe(11, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(12, ClaimGroupComponent_mat_stepper_6_mat_radio_group_12_Template, 2, 1, "mat-radio-group", 12);
        i0.ɵɵelementStart(13, "form", 7);
        i0.ɵɵtemplate(14, ClaimGroupComponent_mat_stepper_6_imx_cdr_editor_14_Template, 1, 1, "imx-cdr-editor", 13);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(15, "button", 14);
        i0.ɵɵtext(16);
        i0.ɵɵpipe(17, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(18, ClaimGroupComponent_mat_stepper_6_button_18_Template, 3, 4, "button", 9);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(19, "mat-step", 15);
        i0.ɵɵtemplate(20, ClaimGroupComponent_mat_stepper_6_ng_template_20_Template, 3, 2, "ng-template", 11);
        i0.ɵɵtemplate(21, ClaimGroupComponent_mat_stepper_6_div_21_Template, 7, 6, "div", 16);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("linear", true);
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(3, 17, "#LDS#Select a system entitlement"));
        i0.ɵɵproperty("stepControl", ctx_r0.entitlementForm)("editable", !ctx_r0.ownerAssigned);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("formGroup", ctx_r0.entitlementForm);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("cdr", ctx_r0.entitlementCdr);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.entitlementForm);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("stepControl", ctx_r0.ownerForm)("editable", !ctx_r0.ownerAssigned);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(11, 19, "#LDS#Here you can claim ownership of the system entitlement. If you are not the owner of the system entitlement, you can specify the actual owner (who will be notified and must confirm the ownership)."), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", (ctx_r0.ownershipOptions == null ? null : ctx_r0.ownershipOptions.length) > 1);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("formGroup", ctx_r0.ownerForm);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.ownerCdr);
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(17, 21, "#LDS#Previous"));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r0.ownerForm);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("editable", !ctx_r0.ownerAssigned);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r0.ownerAssigned);
    }
}
function ClaimGroupComponent_ng_template_7_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "p");
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#You cannot currently assign owners for system entitlements. The system entitlement ownership attestation policy is deactivated."));
    }
}
class ClaimGroupComponent {
    constructor(targetSystem, claimGroupService, personService, busyService, authentication, errorHandler) {
        this.targetSystem = targetSystem;
        this.claimGroupService = claimGroupService;
        this.personService = personService;
        this.busyService = busyService;
        this.authentication = authentication;
        this.errorHandler = errorHandler;
        this.ownerAssigned = false;
        this.canClaimGroup = false;
        this.entitlementForm = new UntypedFormGroup({});
        this.ownerForm = new UntypedFormGroup({});
        this.entitlementFkValue = {};
        this.user = {};
        this.subscriptions = [];
        this.initEntitlementCdr();
        this.subscriptions.push(this.authentication.onSessionResponse.subscribe((sessionState) => __awaiter(this, void 0, void 0, function* () {
            if (sessionState) {
                this.user.uid = sessionState.UserUid;
                this.user.name = sessionState.Username;
            }
        })));
    }
    get ownerDisplay() { return this.ownerCdr ? this.ownerCdr.column.GetDisplayValue() : this.user.name; }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => overlayRef = this.busyService.show());
            try {
                // TODO wrap in cache
                this.canClaimGroup = (yield this.targetSystem.getUserConfig()).CanClaimGroup;
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
        });
    }
    ngOnDestroy() {
        this.subscriptions.forEach(subscription => subscription.unsubscribe());
    }
    resetForms() {
        this.initEntitlementCdr();
        this.initOwnerCdr(undefined);
        this.ownerAssigned = false;
    }
    ownerCandidateListChange(change) {
        this.initOwnerCdr(change.value.createOwnerCdr());
    }
    stepChange(change) {
        return __awaiter(this, void 0, void 0, function* () {
            switch (change.selectedIndex) {
                case 2:
                    return this.loadSuggestedOwners();
                case 3:
                    return this.assignOwner();
            }
        });
    }
    loadSuggestedOwners() {
        return __awaiter(this, void 0, void 0, function* () {
            const fkValue = this.claimGroupService.getFkValue(this.entitlementCdr.column);
            if (this.entitlementFkValue.table === fkValue.table && this.entitlementFkValue.key === fkValue.key) {
                return;
            }
            this.entitlementFkValue.table = fkValue.table;
            this.entitlementFkValue.key = fkValue.key;
            let hasSuggestedOwners = false;
            let overlayRef;
            setTimeout(() => overlayRef = this.busyService.show());
            try {
                hasSuggestedOwners = yield this.claimGroupService.hasSuggestedOwners(this.entitlementFkValue.table, this.entitlementFkValue.key);
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
            const display = '#LDS#Designated owner'; // TODO: globalize;
            this.ownershipOptions = [];
            this.ownershipOptions.push({
                title: '#LDS#I want to take ownership of this system entitlement',
                createOwnerCdr: () => undefined
            });
            if (hasSuggestedOwners) {
                this.ownershipOptions.push({
                    title: '#LDS#Select from the suggested possible owners',
                    createOwnerCdr: () => new BaseCdr(this.claimGroupService.createColumnSuggestedOwner(this.entitlementFkValue.table, this.entitlementFkValue.key), display)
                });
            }
            this.ownershipOptions.push({
                title: '#LDS#Select another owner',
                createOwnerCdr: () => new BaseCdr(this.personService.createColumnCandidatesPerson(), display)
            });
            this.initOwnerCdr(this.ownershipOptions[0].createOwnerCdr());
        });
    }
    assignOwner() {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => overlayRef = this.busyService.show());
            try {
                yield this.claimGroupService.assignOwner(this.entitlementFkValue.table, this.entitlementFkValue.key, this.ownerCdr ? this.ownerCdr.column.GetValue() : this.user.uid);
                this.ownerAssigned = true;
            }
            catch (error) {
                this.errorHandler.handleError(error);
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
        });
    }
    initEntitlementCdr() {
        Object.keys(this.entitlementForm.controls).forEach(name => this.entitlementForm.removeControl(name));
        this.entitlementCdr = this.claimGroupService.createCdrSystemEntitlement();
    }
    initOwnerCdr(cdr) {
        Object.keys(this.ownerForm.controls).forEach(name => this.ownerForm.removeControl(name));
        this.ownerCdr = cdr;
    }
}
ClaimGroupComponent.ɵfac = function ClaimGroupComponent_Factory(t) { return new (t || ClaimGroupComponent)(i0.ɵɵdirectiveInject(TargetSystemService), i0.ɵɵdirectiveInject(ClaimGroupService), i0.ɵɵdirectiveInject(i1.PersonService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.AuthenticationService), i0.ɵɵdirectiveInject(i0.ErrorHandler)); };
ClaimGroupComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ClaimGroupComponent, selectors: [["ng-component"]], decls: 9, vars: 5, consts: [[1, "mat-headline"], [1, "imx-system-entitlement-stepper"], ["orientation", "vertical", 3, "linear", "selectionChange", 4, "ngIf", "ngIfElse"], ["policyDeactivated", ""], ["orientation", "vertical", 3, "linear", "selectionChange"], ["stepper", ""], [3, "stepControl", "label", "editable"], [3, "formGroup"], [3, "cdr", "controlCreated"], ["mat-raised-button", "", "color", "primary", "matStepperNext", "", 3, "disabled", "click", 4, "ngIf"], [3, "stepControl", "editable"], ["matStepLabel", ""], [3, "change", 4, "ngIf"], [3, "cdr", "controlCreated", 4, "ngIf"], ["mat-stroked-button", "", "matStepperPrevious", "", 1, "imx-button-previous"], [3, "editable"], ["class", "imx-owner-assigned", 4, "ngIf"], ["mat-raised-button", "", "color", "primary", "matStepperNext", "", 3, "disabled", "click"], [4, "ngIf", "ngIfElse"], ["disabledDisplay", ""], [3, "change"], [3, "value", "checked", 4, "ngFor", "ngForOf"], [3, "value", "checked"], [1, "imx-owner-assigned"], ["mat-raised-button", "", "color", "primary", 3, "click"]], template: function ClaimGroupComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "h2", 0)(1, "span");
            i0.ɵɵtext(2);
            i0.ɵɵpipe(3, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(4, "imx-help-contextual");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "div", 1);
            i0.ɵɵtemplate(6, ClaimGroupComponent_mat_stepper_6_Template, 22, 23, "mat-stepper", 2);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(7, ClaimGroupComponent_ng_template_7_Template, 3, 3, "ng-template", null, 3, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
            const _r1 = i0.ɵɵreference(8);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 3, "#LDS#Heading Assign an Owner for a System Entitlement"));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", ctx.canClaimGroup)("ngIfElse", _r1);
        }
    }, dependencies: [i2.CdrEditorComponent, i7.NgForOf, i7.NgIf, i1$2.ɵNgNoValidate, i1$2.NgControlStatusGroup, i8.MatButton, i9.MatRadioGroup, i9.MatRadioButton, i10.MatStep, i10.MatStepLabel, i10.MatStepper, i10.MatStepperNext, i10.MatStepperPrevious, i1$2.FormGroupDirective, i2.HelpContextualComponent, i2.LdsReplacePipe, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{max-width:100%;display:flex;flex-direction:column;height:100%;overflow:hidden}mat-radio-group[_ngcontent-%COMP%]{display:flex;flex-direction:column}.imx-button-previous[_ngcontent-%COMP%]{margin-right:10px}.imx-owner-assigned[_ngcontent-%COMP%]{display:flex;flex-direction:column}.imx-owner-assigned[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:not(:last-child){margin-bottom:10px}.imx-owner-assigned[_ngcontent-%COMP%] > button[_ngcontent-%COMP%]{align-self:flex-end}.imx-system-entitlement-stepper[_ngcontent-%COMP%]{flex:1 1 auto;max-width:100%;overflow:auto;display:flex;flex-direction:column}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ClaimGroupComponent, [{
            type: Component,
            args: [{ template: "<h2 class=\"mat-headline\">\r\n  <span>{{ '#LDS#Heading Assign an Owner for a System Entitlement' | translate }}</span>\r\n  <imx-help-contextual></imx-help-contextual>\r\n</h2>\r\n<div class=\"imx-system-entitlement-stepper\">\r\n  <mat-stepper orientation=\"vertical\" *ngIf=\"canClaimGroup; else policyDeactivated\" [linear]=\"true\" (selectionChange)=\"stepChange($event)\" #stepper>\r\n    <mat-step [stepControl]=\"entitlementForm\" label=\"{{ '#LDS#Select a system entitlement' | translate }}\" [editable]=\"!ownerAssigned\">\r\n      <form [formGroup]=\"entitlementForm\">\r\n        <imx-cdr-editor [cdr]=\"entitlementCdr\" (controlCreated)=\"entitlementForm.addControl(entitlementCdr.column.ColumnName, $event)\"></imx-cdr-editor>\r\n      </form>\r\n\r\n      <button *ngIf=\"entitlementForm\" [disabled]=\"entitlementForm.invalid\" mat-raised-button color=\"primary\" matStepperNext (click)=\"loadSuggestedOwners()\">\r\n        {{ '#LDS#Next' | translate }}\r\n      </button>\r\n    </mat-step>\r\n\r\n    <mat-step [stepControl]=\"ownerForm\" [editable]=\"!ownerAssigned\">\r\n      <ng-template matStepLabel>\r\n        <ng-container *ngIf=\"entitlementCdr.column.GetDisplayValue(); else disabledDisplay\">\r\n          {{ '#LDS#Specify the owner for the system entitlement \"{0}\".' | translate | ldsReplace : entitlementCdr.column.GetDisplayValue() }}\r\n        </ng-container>\r\n        <ng-template #disabledDisplay>\r\n          {{ '#LDS#Specify the owner' | translate }}\r\n        </ng-template>\r\n      </ng-template>\r\n\r\n      <p>\r\n        {{\r\n          '#LDS#Here you can claim ownership of the system entitlement. If you are not the owner of the system entitlement, you can specify the actual owner (who will be notified and must confirm the ownership).'\r\n            | translate\r\n        }}\r\n      </p>\r\n\r\n      <mat-radio-group *ngIf=\"ownershipOptions?.length > 1\" (change)=\"ownerCandidateListChange($event)\">\r\n        <mat-radio-button *ngFor=\"let option of ownershipOptions; let i = index\" [value]=\"option\" [checked]=\"i === 0\">\r\n          {{ option.title | translate }}\r\n        </mat-radio-button>\r\n      </mat-radio-group>\r\n\r\n      <form [formGroup]=\"ownerForm\">\r\n        <imx-cdr-editor *ngIf=\"ownerCdr\" [cdr]=\"ownerCdr\" (controlCreated)=\"ownerForm.addControl(ownerCdr.column.ColumnName, $event)\"></imx-cdr-editor>\r\n      </form>\r\n\r\n      <button class=\"imx-button-previous\" mat-stroked-button matStepperPrevious>{{ '#LDS#Previous' | translate }}</button>\r\n      <button *ngIf=\"ownerForm\" [disabled]=\"ownerForm.invalid\" mat-raised-button color=\"primary\" (click)=\"assignOwner()\" matStepperNext>{{ '#LDS#Next' | translate }}</button>\r\n    </mat-step>\r\n\r\n    <mat-step [editable]=\"!ownerAssigned\">\r\n      <ng-template matStepLabel>\r\n        <ng-container *ngIf=\"entitlementCdr.column.GetDisplayValue() && ownerDisplay; else disabledDisplay\">\r\n          {{ '#LDS#Assign ownership for the system entitlement \"{0}\" to \"{1}\".' | translate | ldsReplace : entitlementCdr.column.GetDisplayValue() : ownerDisplay }}\r\n        </ng-container>\r\n        <ng-template #disabledDisplay>\r\n          {{ '#LDS#Assign ownership' | translate }}\r\n        </ng-template>\r\n      </ng-template>\r\n\r\n      <div *ngIf=\"ownerAssigned\" class=\"imx-owner-assigned\">\r\n        <p>\r\n          {{ '#LDS#Your changes have been successfully saved. It may take some time for the changes to take effect.' | translate }}\r\n        </p>\r\n        <button mat-raised-button color=\"primary\" (click)=\"resetForms(); stepper.reset()\">{{ '#LDS#Assign another system entitlement' | translate }}</button>\r\n      </div>\r\n    </mat-step>\r\n  </mat-stepper>\r\n</div>\r\n<ng-template #policyDeactivated>\r\n  <p>{{ '#LDS#You cannot currently assign owners for system entitlements. The system entitlement ownership attestation policy is deactivated.' | translate }}</p>\r\n</ng-template>\r\n", styles: [":host{max-width:100%;display:flex;flex-direction:column;height:100%;overflow:hidden}mat-radio-group{display:flex;flex-direction:column}.imx-button-previous{margin-right:10px}.imx-owner-assigned{display:flex;flex-direction:column}.imx-owner-assigned>*:not(:last-child){margin-bottom:10px}.imx-owner-assigned>button{align-self:flex-end}.imx-system-entitlement-stepper{flex:1 1 auto;max-width:100%;overflow:auto;display:flex;flex-direction:column}\n"] }]
        }], function () { return [{ type: TargetSystemService }, { type: ClaimGroupService }, { type: i1.PersonService }, { type: i1$1.EuiLoadingService }, { type: i2.AuthenticationService }, { type: i0.ErrorHandler }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ClaimGroupModule {
}
ClaimGroupModule.ɵfac = function ClaimGroupModule_Factory(t) { return new (t || ClaimGroupModule)(); };
ClaimGroupModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ClaimGroupModule });
ClaimGroupModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CdrModule,
        CommonModule,
        EuiCoreModule,
        FormsModule,
        LdsReplaceModule,
        MatButtonModule,
        MatRadioModule,
        MatStepperModule,
        ReactiveFormsModule,
        TranslateModule,
        HelpContextualModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ClaimGroupModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        ClaimGroupComponent
                    ],
                    imports: [
                        CdrModule,
                        CommonModule,
                        EuiCoreModule,
                        FormsModule,
                        LdsReplaceModule,
                        MatButtonModule,
                        MatRadioModule,
                        MatStepperModule,
                        ReactiveFormsModule,
                        TranslateModule,
                        HelpContextualModule,
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ClaimGroupModule, { declarations: [ClaimGroupComponent], imports: [CdrModule,
            CommonModule,
            EuiCoreModule,
            FormsModule,
            LdsReplaceModule,
            MatButtonModule,
            MatRadioModule,
            MatStepperModule,
            ReactiveFormsModule,
            TranslateModule,
            HelpContextualModule] });
})();

class ContainerTreeDatabaseWrapper {
    constructor(busyService, dataHelper) {
        this.busyService = busyService;
        this.dataHelper = dataHelper;
        this.selectionEnabled = false;
        this.entityTreeDatabase = new EntityTreeDatabase(parameters => this.getEntities(parameters), this.busyService);
    }
    get targetSystemFilterValue() {
        return this.system;
    }
    set targetSystemFilterValue(value) {
        this.system = value;
        this.entityTreeDatabase = new EntityTreeDatabase(parameters => this.getEntities(parameters, value), this.busyService);
    }
    getEntities(parameters = {}, system = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const navigationState = { PageSize: 1000, StartIndex: 0, ParentKey: '' };
            if (parameters.ParentKey) {
                navigationState.ParentKey = parameters.ParentKey;
            }
            if (system) {
                navigationState.system = system;
            }
            const containerData = yield this.dataHelper.getContainers(navigationState);
            return containerData.Data.map(element => element.GetEntity());
        });
    }
}

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountTypedEntity extends TypedEntity {
    constructor() {
        super(...arguments);
        // TODO fix this: we are in TSB, not ADS
        this.displayColumn = this.GetEntity().GetColumn(DisplayColumns.DISPLAY_PROPERTYNAME);
        this.isNeverConnectManualColumn = CdrFactoryService.tryGetColumn(this.GetEntity(), 'IsNeverConnectManual');
        this.objectKeyManagerColumn = CdrFactoryService.tryGetColumn(this.GetEntity(), 'ObjectKeyManager');
        this.uidPersonColumn = CdrFactoryService.tryGetColumn(this.GetEntity(), 'UID_Person');
        this.uidADSDomain = CdrFactoryService.tryGetColumn(this.GetEntity(), 'UID_ADSDomain');
    }
}

class TargetSystemDynamicMethodService {
    constructor(tsbClient, dynamicMethod, metadata) {
        this.tsbClient = tsbClient;
        this.dynamicMethod = dynamicMethod;
        this.metadata = metadata;
    }
    getCollection(type, tableName, parameters = {}) {
        return __awaiter(this, void 0, void 0, function* () {
            const path = '/portal/targetsystem/' + tableName;
            return this.dynamicMethod.get(this.tsbClient.apiClient, { type, path }, parameters);
        });
    }
    getById(type, dbObjectKeyWrapper) {
        return __awaiter(this, void 0, void 0, function* () {
            const key = dbObjectKeyWrapper.dbObjectKey.Keys[0];
            const tableName = dbObjectKeyWrapper.dbObjectKey.TableName.toLowerCase();
            const path = '/portal/targetsystem/' + tableName + '/interactive';
            return (yield this.dynamicMethod.getInteractive(this.tsbClient.apiClient, { type, key, path }, {
                name: dbObjectKeyWrapper.columnName, value: key
            })).Data[0];
        });
    }
    get(type, dbObjectKeyWrapper) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            yield this.metadata.updateNonExisting([dbObjectKeyWrapper.dbObjectKey.TableName]);
            const tableMetadata = this.metadata.tables[dbObjectKeyWrapper.dbObjectKey.TableName];
            const filter = [{
                    ColumnName: (_a = dbObjectKeyWrapper.columnName) !== null && _a !== void 0 ? _a : tableMetadata.PrimaryKeyColumns[0],
                    Type: FilterType.Compare,
                    CompareOp: CompareOperator.Equal,
                    Value1: dbObjectKeyWrapper.dbObjectKey.Keys[0]
                }];
            return (_b = (yield this.getCollection(type, dbObjectKeyWrapper.dbObjectKey.TableName, { filter }))) === null || _b === void 0 ? void 0 : _b.Data[0];
        });
    }
    delete(tableName, pathParameterWrapper) {
        return __awaiter(this, void 0, void 0, function* () {
            const path = '/portal/' + tableName + '/' + pathParameterWrapper.path;
            return this.dynamicMethod.delete(this.tsbClient.apiClient, path, pathParameterWrapper.parameters);
        });
    }
}
TargetSystemDynamicMethodService.ɵfac = function TargetSystemDynamicMethodService_Factory(t) { return new (t || TargetSystemDynamicMethodService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.DynamicMethodService), i0.ɵɵinject(i2.MetadataService)); };
TargetSystemDynamicMethodService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TargetSystemDynamicMethodService, factory: TargetSystemDynamicMethodService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TargetSystemDynamicMethodService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: TsbApiService }, { type: i2.DynamicMethodService }, { type: i2.MetadataService }]; }, null);
})();

class AccountsService {
    constructor(tsbClient, dynamicMethod) {
        this.tsbClient = tsbClient;
        this.dynamicMethod = dynamicMethod;
        this.abortController = new AbortController();
    }
    get accountSchema() {
        return this.tsbClient.typedClient.PortalTargetsystemUnsAccount.GetSchema();
    }
    /**
     * Gets a list of accounts.
     *
     * @param navigationState Page size, start index, search and filtering options etc,.
     *
     * @returns Wrapped list of Accounts.
     */
    getAccounts(navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            if ((navigationState === null || navigationState === void 0 ? void 0 : navigationState.search) !== undefined) {
                // abort the request only while searching
                this.abortCall();
            }
            return this.tsbClient.typedClient.PortalTargetsystemUnsAccount.Get(navigationState, { signal: this.abortController.signal });
        });
    }
    exportAccounts(navigationState) {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_targetsystem_uns_account_get(Object.assign(Object.assign({}, navigationState), { withProperties, PageSize, StartIndex: 0 }));
                }
                else {
                    method = factory.portal_targetsystem_uns_account_get(Object.assign(Object.assign({}, navigationState), { withProperties }));
                }
                return new MethodDefinition(method);
            },
        };
    }
    getAccount(dbObjectKey, columnName) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.dynamicMethod.get(AccountTypedEntity, { dbObjectKey, columnName });
        });
    }
    getAccountInteractive(dbObjectKey, columnName) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.dynamicMethod.getById(AccountTypedEntity, { dbObjectKey, columnName }));
        });
    }
    /** @deprecated Will be removed. Please load the data model first.*/
    getFilterOptions() {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.getDataModel()).Filters;
        });
    }
    getDataModel() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.tsbClient.client.portal_targetsystem_uns_account_datamodel_get(undefined);
        });
    }
    getFilterTree(parameter) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.tsbClient.client.portal_targetsystem_uns_account_filtertree_get(parameter);
        });
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
}
AccountsService.ɵfac = function AccountsService_Factory(t) { return new (t || AccountsService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(TargetSystemDynamicMethodService)); };
AccountsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AccountsService, factory: AccountsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: TsbApiService }, { type: TargetSystemDynamicMethodService }]; }, null);
})();

class AccountsReportsService {
    constructor(tsbClient, settings, appConfig) {
        this.tsbClient = tsbClient;
        this.settings = settings;
        this.appConfig = appConfig;
    }
    accountsReport(historyDays, accountId, tableName) {
        const path = `targetsystem/uns/account/${tableName}/${accountId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountsOwnedByPersonReport(historyDays, personId) {
        const path = `targetsystem/uns/account/ownedby/${personId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountsOwnedByManagedReport(historyDays, personId) {
        const path = `targetsystem/uns/account/ownedbymanaged/${personId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountsByRootReport(historyDays, rootId) {
        const path = `targetsystem/uns/root/${rootId}/accounts/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountsByContainerReport(historyDays, containerId) {
        const path = `targetsystem/uns/container/${containerId}/accounts/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    accountData(search) {
        return __awaiter(this, void 0, void 0, function* () {
            const options = this.getDefaultDataOptions(search);
            return this.tsbClient.typedClient.PortalTargetsystemUnsAccount.Get(options);
        });
    }
    getDefaultDataOptions(search) {
        const options = {
            PageSize: this.settings.DefaultPageSize,
            StartIndex: 0,
        };
        if (search) {
            options.search = search;
        }
        return options;
    }
    getReportUrl(reportPath) {
        return `${this.appConfig.BaseUrl}/portal/${reportPath}`;
    }
}
AccountsReportsService.ɵfac = function AccountsReportsService_Factory(t) { return new (t || AccountsReportsService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.SettingsService), i0.ɵɵinject(i2.AppConfigService)); };
AccountsReportsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AccountsReportsService, factory: AccountsReportsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsReportsService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: TsbApiService }, { type: i2.SettingsService }, { type: i2.AppConfigService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GroupTypedEntity extends WriteExtTypedEntity {
    getColumns(showRiskIndex, propertyList) {
        // TODO: for each property, determine from dynamic entity schema (282445)
        if (propertyList.indexOf('DisplayName') === -1) {
            propertyList.unshift('DisplayName');
        }
        if (showRiskIndex && propertyList.indexOf('RiskIndex') === -1) {
            propertyList.push('RiskIndex');
        }
        return propertyList.map(elem => CdrFactoryService.tryGetColumn(this.GetEntity(), elem)).filter(elem => elem != null);
    }
}

class GroupsService {
    constructor(tsbClient, logger, dynamicMethod) {
        this.tsbClient = tsbClient;
        this.logger = logger;
        this.dynamicMethod = dynamicMethod;
        this.abortController = new AbortController();
    }
    unsGroupsSchema(isAdmin) {
        return isAdmin
            ? this.tsbClient.typedClient.PortalTargetsystemUnsGroup.GetSchema()
            : this.tsbClient.typedClient.PortalRespUnsgroup.GetSchema();
    }
    get UnsGroupMembersSchema() {
        return this.tsbClient.typedClient.PortalTargetsystemUnsGroupmembers.GetSchema();
    }
    get UnsGroupDirectMembersSchema() {
        return this.tsbClient.typedClient.PortalTargetsystemUnsDirectmembers.GetSchema();
    }
    get UnsGroupNestedMembersSchema() {
        return this.tsbClient.typedClient.PortalTargetsystemUnsNestedmembers.GetSchema();
    }
    getFilterTree(options) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.tsbClient.client.portal_targetsystem_uns_group_filtertree_get(options);
        });
    }
    getGroups(navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            if ((navigationState === null || navigationState === void 0 ? void 0 : navigationState.search) !== undefined) {
                // abort the request only while searching
                this.abortCall();
            }
            return this.tsbClient.typedClient.PortalTargetsystemUnsGroup.Get(navigationState, { signal: this.abortController.signal });
        });
    }
    exportGroups(navigationState) {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_targetsystem_uns_group_get(Object.assign(Object.assign({}, navigationState), { withProperties, PageSize, StartIndex: 0 }));
                }
                else {
                    method = factory.portal_targetsystem_uns_group_get(Object.assign(Object.assign({}, navigationState), { withProperties }));
                }
                return new MethodDefinition(method);
            },
        };
    }
    getGroupsResp(navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            if ((navigationState === null || navigationState === void 0 ? void 0 : navigationState.search) !== undefined) {
                // abort the request only while searching
                this.abortCall();
            }
            return this.tsbClient.typedClient.PortalRespUnsgroup.Get(navigationState, { signal: this.abortController.signal });
        });
    }
    exportGroupsResp(navigationState) {
        const factory = new V2ApiClientMethodFactory();
        return {
            getMethod: (withProperties, PageSize) => {
                let method;
                if (PageSize) {
                    method = factory.portal_resp_unsgroup_get(Object.assign(Object.assign({}, navigationState), { withProperties, PageSize, StartIndex: 0 }));
                }
                else {
                    method = factory.portal_resp_unsgroup_get(Object.assign(Object.assign({}, navigationState), { withProperties }));
                }
                return new MethodDefinition(method);
            },
        };
    }
    getGroupDetails(dbObjectKey) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.dynamicMethod.get(GroupTypedEntity, { dbObjectKey });
        });
    }
    getGroupDetailsInteractive(dbObjectKey, columnName) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.dynamicMethod.getById(GroupTypedEntity, { dbObjectKey, columnName }));
        });
    }
    getGroupServiceItem(key) {
        return __awaiter(this, void 0, void 0, function* () {
            const navigationState = { filter: [] };
            navigationState.filter.push({
                ColumnName: 'UID_AccProduct',
                Type: FilterType.Compare,
                CompareOp: CompareOperator.Equal,
                Value1: key,
            });
            return (yield this.tsbClient.typedClient.PortalTargetsystemUnsGroupServiceitem.Get(navigationState)).Data[0];
        });
    }
    bulkUpdateGroupServiceItems(updateData) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.tsbClient.client.portal_targetsystem_uns_group_serviceitem_bulk_put(updateData);
        });
    }
    getGroupDirectMembers(groupId, navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Retrieving group direct memberships`);
            this.logger.trace('GroupId', groupId);
            return this.tsbClient.typedClient.PortalTargetsystemUnsDirectmembers.Get(groupId, navigationState);
        });
    }
    getGroupNestedMembers(groupId, navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Retrieving group nested memberships`);
            this.logger.trace('GroupId', groupId);
            return this.tsbClient.typedClient.PortalTargetsystemUnsNestedmembers.Get(groupId, navigationState);
        });
    }
    deleteGroupMembers(dbObjectKey, uidAccountList) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Deleting group memberships`);
            this.logger.trace(this, 'AccountId', JSON.stringify(uidAccountList));
            // TODO: change to bulk when API supports it
            const groupId = dbObjectKey.Keys[0];
            return Promise.all(uidAccountList.map((accountId) => this.dynamicMethod.delete(dbObjectKey.TableName, {
                path: '{groupId}/memberships/{accountId}',
                parameters: { groupId, accountId },
            })));
        });
    }
    getGroupsGroupMembers(groupId, navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Retrieving groups group memberships`);
            this.logger.trace('GroupId', groupId);
            return this.tsbClient.typedClient.PortalTargetsystemUnsGroupmembers.Get(groupId, navigationState);
        });
    }
    /** @deprecated Will be removed. Please load the data model first.*/
    getFilterOptions(forAdmin) {
        return __awaiter(this, void 0, void 0, function* () {
            return forAdmin
                ? (yield this.tsbClient.client.portal_targetsystem_uns_group_datamodel_get(undefined)).Filters
                : (yield this.tsbClient.client.portal_resp_unsgroup_datamodel_get(undefined)).Filters;
        });
    }
    getDataModel(forAdmin) {
        return __awaiter(this, void 0, void 0, function* () {
            return forAdmin
                ? this.tsbClient.client.portal_targetsystem_uns_group_datamodel_get(undefined)
                : this.tsbClient.client.portal_resp_unsgroup_datamodel_get(undefined);
        });
    }
    updateMultipleOwner(uidAccProducts, uidPerson) {
        return __awaiter(this, void 0, void 0, function* () {
            let confirmMessage = '#LDS#The product owner has been successfully assigned.';
            try {
                for (const data of uidAccProducts) {
                    const product = yield this.getGroupServiceItem(data);
                    if (uidPerson.uidPerson) {
                        product.extendedData = {
                            UidPerson: uidPerson.uidPerson,
                            CopyAllMembers: true,
                        };
                        confirmMessage = '#LDS#The product owner has been successfully assigned. It may take some time for the changes to take effect.';
                    }
                    else {
                        product.extendedData = undefined;
                    }
                    if (uidPerson.uidRole) {
                        product.UID_OrgRuler.value = uidPerson.uidRole;
                    }
                    yield product.GetEntity().Commit(true);
                }
            }
            catch (exception) {
                confirmMessage = '';
                throw exception;
            }
            return confirmMessage;
        });
    }
    abortCall() {
        this.abortController.abort();
        this.abortController = new AbortController();
    }
}
GroupsService.ɵfac = function GroupsService_Factory(t) { return new (t || GroupsService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.ClassloggerService), i0.ɵɵinject(TargetSystemDynamicMethodService)); };
GroupsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GroupsService, factory: GroupsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupsService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: TsbApiService }, { type: i2.ClassloggerService }, { type: TargetSystemDynamicMethodService }]; }, null);
})();

class GroupsReportsService {
    constructor(tsbClient, settings, appConfig) {
        this.tsbClient = tsbClient;
        this.settings = settings;
        this.appConfig = appConfig;
    }
    groupsByGroupReport(historyDays, groupId) {
        const path = `targetsystem/uns/group/${groupId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    groupsByRootReport(historyDays, rootId) {
        const path = `targetsystem/uns/root/${rootId}/groups/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    groupsByContainerReport(historyDays, containerId) {
        const path = `targetsystem/uns/container/${containerId}/groups/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    groupsOwnedByPersonReport(historyDays, personId) {
        const path = `targetsystem/uns/ownedby/${personId}/report?historydays=${historyDays}`;
        return this.getReportUrl(path);
    }
    groupData(search) {
        return __awaiter(this, void 0, void 0, function* () {
            const options = this.getDefaultDataOptions(search);
            return this.tsbClient.typedClient.PortalTargetsystemUnsGroup.Get(options);
        });
    }
    getDefaultDataOptions(search) {
        const options = {
            PageSize: this.settings.DefaultPageSize,
            StartIndex: 0,
        };
        if (search) {
            options.search = search;
        }
        return options;
    }
    getReportUrl(reportPath) {
        return `${this.appConfig.BaseUrl}/portal/${reportPath}`;
    }
}
GroupsReportsService.ɵfac = function GroupsReportsService_Factory(t) { return new (t || GroupsReportsService)(i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.SettingsService), i0.ɵɵinject(i2.AppConfigService)); };
GroupsReportsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GroupsReportsService, factory: GroupsReportsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupsReportsService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: TsbApiService }, { type: i2.SettingsService }, { type: i2.AppConfigService }]; }, null);
})();

class NewMembershipService {
    constructor(itShop, qerClient, busyService, userService) {
        this.itShop = itShop;
        this.qerClient = qerClient;
        this.busyService = busyService;
        this.userService = userService;
    }
    requestMembership(members, product) {
        return __awaiter(this, void 0, void 0, function* () {
            let items = this.getServiceItemsForPersons(product, members);
            yield this.itShop.setShops(items);
            if (items.every((elem) => elem.UidITShopOrg == null || elem.UidITShopOrg === '')) {
                return false;
            }
            let busyIndicator;
            setTimeout(() => (busyIndicator = this.busyService.show()));
            try {
                items = items.filter((elem) => elem.UidITShopOrg != null && elem.UidITShopOrg !== '');
                for (const item of items) {
                    const entity = this.qerClient.typedClient.PortalCartitem.createEntity();
                    entity.UID_ITShopOrg.value = item.UidITShopOrg;
                    entity.UID_PersonOrdered.value = item.UidPerson;
                    yield this.qerClient.typedClient.PortalCartitem.Post(entity);
                }
                yield this.userService.reloadPendingItems();
            }
            finally {
                setTimeout(() => {
                    this.busyService.hide(busyIndicator);
                });
            }
            return true;
        });
    }
    getFKRelation() {
        return this.qerClient.typedClient.PortalCartitem.createEntity().UID_PersonOrdered.GetMetadata().GetFkRelations();
    }
    unsubscribeMembership(item) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.qerClient.client.portal_itshop_unsubscribe_post({ UidPwo: [item.GetEntity().GetColumn('UID_PersonWantsOrg').GetValue()] });
        });
    }
    getServiceItemsForPersons(serviceItem, recipients) {
        return recipients
            .map((recipient) => ({
            UidPerson: recipient.DataValue,
            UidAccProduct: serviceItem.GetEntity().GetKeys()[0],
            Display: serviceItem.GetEntity().GetDisplay(),
            DisplayRecipient: recipient.DisplayValue,
        }))
            .reduce((a, b) => a.concat(b), []);
    }
}
NewMembershipService.ɵfac = function NewMembershipService_Factory(t) { return new (t || NewMembershipService)(i0.ɵɵinject(i1.ShelfService), i0.ɵɵinject(i1.QerApiService), i0.ɵɵinject(i1$1.EuiLoadingService), i0.ɵɵinject(i1.UserModelService)); };
NewMembershipService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: NewMembershipService, factory: NewMembershipService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(NewMembershipService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: i1.ShelfService }, { type: i1.QerApiService }, { type: i1$1.EuiLoadingService }, { type: i1.UserModelService }]; }, null);
})();

const _c0$8 = ["membersTable"];
function GroupMembersComponent_div_0_Template(rf, ctx) {
    if (rf & 1) {
        const _r5 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div")(1, "mat-button-toggle-group", 1, 2);
        i0.ɵɵlistener("change", function GroupMembersComponent_div_0_Template_mat_button_toggle_group_change_1_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r4 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r4.onToggleChanged($event)); });
        i0.ɵɵelementStart(3, "mat-button-toggle", 3);
        i0.ɵɵpipe(4, "translate");
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "mat-button-toggle", 4);
        i0.ɵɵpipe(8, "translate");
        i0.ɵɵtext(9);
        i0.ɵɵpipe(10, "translate");
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("vertical", ctx_r0.isMobile);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(4, 5, ctx_r0.LdsDirectlyAssignedHint));
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 7, ctx_r0.LdsDirectlyAssigned));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(8, 9, ctx_r0.LdsIndirectlyAssignedHint));
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(10, 11, ctx_r0.LdsIndirectlyAssigned));
    }
}
function GroupMembersComponent_ng_container_1_eui_alert_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r11 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-alert", 14);
        i0.ɵɵlistener("dismissed", function GroupMembersComponent_ng_container_1_eui_alert_4_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r10.onWarningDismissed()); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 4, ctx_r6.LdsNotUnsubscribableHint));
    }
}
function GroupMembersComponent_ng_container_1_ng_template_17_div_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div")(1, "eui-badge", 15);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const item_r12 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r12.XMarkedForDeletion.Column.GetDisplayValue());
    }
}
function GroupMembersComponent_ng_container_1_ng_template_17_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, GroupMembersComponent_ng_container_1_ng_template_17_div_0_Template, 3, 1, "div", 0);
    }
    if (rf & 2) {
        const item_r12 = ctx.$implicit;
        i0.ɵɵproperty("ngIf", item_r12.XMarkedForDeletion.value !== 0);
    }
}
const _c1$5 = function () { return ["namespace"]; };
function GroupMembersComponent_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r16 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "eui-alert", 5);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(4, GroupMembersComponent_ng_container_1_eui_alert_4_Template, 3, 6, "eui-alert", 6);
        i0.ɵɵelementStart(5, "imx-data-source-toolbar", 7, 8);
        i0.ɵɵlistener("navigationStateChanged", function GroupMembersComponent_ng_container_1_Template_imx_data_source_toolbar_navigationStateChanged_5_listener($event) { i0.ɵɵrestoreView(_r16); const ctx_r15 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r15.onDirectNavigationStateChanged($event)); });
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(8, "imx-data-table", 9, 10);
        i0.ɵɵlistener("highlightedEntityChanged", function GroupMembersComponent_ng_container_1_Template_imx_data_table_highlightedEntityChanged_8_listener($event) { i0.ɵɵrestoreView(_r16); const ctx_r17 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r17.onShowDetails($event)); })("selectionChanged", function GroupMembersComponent_ng_container_1_Template_imx_data_table_selectionChanged_8_listener($event) { i0.ɵɵrestoreView(_r16); const ctx_r18 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r18.onSelectionChanged($event)); });
        i0.ɵɵelement(10, "imx-data-table-column", 11)(11, "imx-data-table-column", 11)(12, "imx-data-table-column", 11)(13, "imx-data-table-column", 11)(14, "imx-data-table-column", 11)(15, "imx-data-table-column", 11);
        i0.ɵɵelementStart(16, "imx-data-table-generic-column", 12);
        i0.ɵɵtemplate(17, GroupMembersComponent_ng_container_1_ng_template_17_Template, 1, 1, "ng-template");
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(18, "imx-data-source-paginator", 13);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const _r7 = i0.ɵɵreference(6);
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("colored", true)("dismissable", false);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 18, "#LDS#Here you can manage the memberships of the system entitlement. You can request and remove memberships and view the assignment analysis for each membership."), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx_r1.showUnsubscribeWarning);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("settings", ctx_r1.dstSettings)("hiddenFilters", i0.ɵɵpureFunction0(22, _c1$5))("itemStatus", ctx_r1.itemStatus)("searchBoxText", i0.ɵɵpipeBind1(7, 20, "#LDS#Search"));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("dst", _r7)("selectable", true);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx_r1.entitySchemaGroupDirectMemberships == null ? null : ctx_r1.entitySchemaGroupDirectMemberships.Columns.UID_Person);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r1.entitySchemaGroupDirectMemberships == null ? null : ctx_r1.entitySchemaGroupDirectMemberships.Columns.UID_UNSAccount);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r1.entitySchemaGroupDirectMemberships == null ? null : ctx_r1.entitySchemaGroupDirectMemberships.Columns.XOrigin);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r1.entitySchemaGroupDirectMemberships == null ? null : ctx_r1.entitySchemaGroupDirectMemberships.Columns.XDateInserted);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r1.entitySchemaGroupDirectMemberships == null ? null : ctx_r1.entitySchemaGroupDirectMemberships.Columns.OrderState);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r1.entitySchemaGroupDirectMemberships == null ? null : ctx_r1.entitySchemaGroupDirectMemberships.Columns.ValidUntil);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("columnName", ctx_r1.entitySchemaGroupDirectMemberships == null ? null : ctx_r1.entitySchemaGroupDirectMemberships.Columns.XMarkedForDeletion.ColumnName);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r7);
    }
}
function GroupMembersComponent_ng_container_2_ng_template_12_div_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div")(1, "eui-badge", 15);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const item_r22 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r22.XMarkedForDeletion.Column.GetDisplayValue());
    }
}
function GroupMembersComponent_ng_container_2_ng_template_12_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, GroupMembersComponent_ng_container_2_ng_template_12_div_0_Template, 3, 1, "div", 0);
    }
    if (rf & 2) {
        const item_r22 = ctx.$implicit;
        i0.ɵɵproperty("ngIf", item_r22.XMarkedForDeletion.value !== 0);
    }
}
function GroupMembersComponent_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r26 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "eui-alert", 5);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "imx-data-source-toolbar", 16, 17);
        i0.ɵɵlistener("navigationStateChanged", function GroupMembersComponent_ng_container_2_Template_imx_data_source_toolbar_navigationStateChanged_4_listener($event) { i0.ɵɵrestoreView(_r26); const ctx_r25 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r25.onNestedNavigationStateChanged($event)); });
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "imx-data-table", 18, 10);
        i0.ɵɵlistener("highlightedEntityChanged", function GroupMembersComponent_ng_container_2_Template_imx_data_table_highlightedEntityChanged_7_listener($event) { i0.ɵɵrestoreView(_r26); const ctx_r27 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r27.onShowDetails($event)); });
        i0.ɵɵelement(9, "imx-data-table-column", 11)(10, "imx-data-table-column", 11);
        i0.ɵɵelementStart(11, "imx-data-table-generic-column", 12);
        i0.ɵɵtemplate(12, GroupMembersComponent_ng_container_2_ng_template_12_Template, 1, 1, "ng-template");
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(13, "imx-data-source-paginator", 13);
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const _r19 = i0.ɵɵreference(5);
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("colored", true)("dismissable", false);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 11, "#LDS#Here you can get an overview of the memberships of the system entitlement. Additionally, you can view the assignment analysis for each membership."), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("settings", ctx_r2.dstNestedGroupSettings)("hiddenFilters", i0.ɵɵpureFunction0(15, _c1$5))("searchBoxText", i0.ɵɵpipeBind1(6, 13, "#LDS#Search"));
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("dst", _r19);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx_r2.entitySchemaGroupNestedMemberships == null ? null : ctx_r2.entitySchemaGroupNestedMemberships.Columns.UID_Person);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r2.entitySchemaGroupNestedMemberships == null ? null : ctx_r2.entitySchemaGroupNestedMemberships.Columns.UID_UNSGroupChild);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("columnName", ctx_r2.entitySchemaGroupNestedMemberships == null ? null : ctx_r2.entitySchemaGroupNestedMemberships.Columns.XMarkedForDeletion.ColumnName);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r19);
    }
}
class GroupMembersComponent {
    constructor(busyService, snackBarService, sidesheet, groupsService, confirmationService, membershipService, translate, settingsService) {
        this.busyService = busyService;
        this.snackBarService = snackBarService;
        this.sidesheet = sidesheet;
        this.groupsService = groupsService;
        this.confirmationService = confirmationService;
        this.membershipService = membershipService;
        this.translate = translate;
        this.settingsService = settingsService;
        this.viewDirectMemberships = new UntypedFormControl(true);
        this.canViewInheritedMemberships = false;
        this.showUnsubscribeWarning = false;
        this.itemStatus = {
            enabled: (item) => {
                var _a;
                return (!((_a = item.IsFromDynamic) === null || _a === void 0 ? void 0 : _a.value) &&
                    ((item.UID_PersonWantsOrg.value !== '' && item.IsRequestCancellable.value) || item.XOrigin.value === 1));
            },
        };
        this.displayedColumns = [];
        this.nestedDisplayColumns = [];
        this.selectedItems = [];
        this.selectedMembershipView = 'direct';
        this.LdsNotUnsubscribableHint = '#LDS#There is at least one membership you cannot unsubscribe. You can only unsubscribe memberships you have requested.';
        this.LdsDirectlyAssignedHint = '#LDS#Here you can get an overview of members assigned to the system entitlement itself.';
        this.LdsIndirectlyAssignedHint = '#LDS#Here you can get an overview of members not assigned to the system entitlement itself, but to a child system entitlement.';
        this.LdsDirectlyAssigned = '#LDS#Direct memberships';
        this.LdsIndirectlyAssigned = '#LDS#Inherited memberships';
        this.entitySchemaGroupDirectMemberships = groupsService.UnsGroupDirectMembersSchema;
        this.entitySchemaGroupNestedMemberships = groupsService.UnsGroupNestedMembersSchema;
        this.navigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
        this.nestedNavigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
    }
    get membershipView() {
        return this.selectedMembershipView;
    }
    get isMobile() {
        return document.body.offsetWidth <= 768;
    }
    ngOnInit() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            this.displayedColumns = [
                this.entitySchemaGroupDirectMemberships.Columns.UID_Person,
                this.entitySchemaGroupDirectMemberships.Columns.UID_UNSAccount,
                this.entitySchemaGroupDirectMemberships.Columns.XOrigin,
                this.entitySchemaGroupDirectMemberships.Columns.XDateInserted,
                this.entitySchemaGroupDirectMemberships.Columns.OrderState,
                this.entitySchemaGroupDirectMemberships.Columns.ValidUntil,
                this.entitySchemaGroupDirectMemberships.Columns.XMarkedForDeletion,
            ];
            this.nestedDisplayColumns = [
                this.entitySchemaGroupNestedMemberships.Columns.UID_Person,
                this.entitySchemaGroupNestedMemberships.Columns.UID_UNSGroupChild,
                this.entitySchemaGroupNestedMemberships.Columns.XMarkedForDeletion,
            ];
            this.groupId = this.unsGroupDbObjectKey.Keys[0];
            this.canViewInheritedMemberships = ((_a = this.unsGroupDbObjectKey) === null || _a === void 0 ? void 0 : _a.TableName) === 'ADSGroup';
            yield this.navigateDirect();
        });
    }
    get selectedItemsCount() {
        return this.selectedItems.length;
    }
    onSelectionChanged(items) {
        this.selectedItems = items;
    }
    canUnsubscribeSelected() {
        return (this.selectedItems != null &&
            this.selectedItemsCount > 0 &&
            this.selectedItems.every((elem) => elem.GetEntity().GetColumn('UID_PersonWantsOrg').GetValue() !== '' &&
                elem.GetEntity().GetColumn('IsRequestCancellable').GetValue()));
    }
    canDeleteSelected() {
        return (this.selectedItems != null &&
            this.selectedItemsCount > 0 &&
            this.selectedItems.every((elem) => elem.GetEntity().GetColumn('XOrigin').GetValue() === 1));
    }
    onToggleChanged(change) {
        return __awaiter(this, void 0, void 0, function* () {
            this.selectedMembershipView = change.value;
            this.selectedItems = [];
            if (this.selectedMembershipView === 'direct') {
                return this.onDirectNavigationStateChanged({ PageSize: this.settingsService.DefaultPageSize, StartIndex: 0 });
            }
            else {
                return this.onNestedNavigationStateChanged({ PageSize: this.settingsService.DefaultPageSize, StartIndex: 0 });
            }
        });
    }
    onDirectNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.navigateDirect();
        });
    }
    onNestedNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.nestedNavigationState = newState;
            }
            yield this.navigateNested();
        });
    }
    deleteMembers() {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield this.confirmationService.confirm({
                Title: '#LDS#Heading Remove Memberships',
                Message: '#LDS#The removal of memberships may take some time. The displayed data may differ from the actual state. Are you sure you want to remove the selected memberships?',
                identifier: 'group-members-confirm-delete-memberships',
            })) {
                this.handleOpenLoader();
                try {
                    yield this.groupsService.deleteGroupMembers(this.unsGroupDbObjectKey, this.selectedItems.map((i) => i.GetEntity().GetColumn('UID_UNSAccount').GetValue()));
                    this.membersTable.clearSelection();
                    this.snackBarService.open({ key: '#LDS#The memberships have been successfully removed.' }, '#LDS#Close');
                    yield this.navigateDirect();
                }
                finally {
                    this.handleCloseLoader();
                }
            }
        });
    }
    requestMembership(serviceItem) {
        return __awaiter(this, void 0, void 0, function* () {
            const sidesheetRef = this.sidesheet.open(FkAdvancedPickerComponent, {
                title: yield this.translate.get('#LDS#Heading Request Memberships').toPromise(),
                subTitle: serviceItem.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(600px, 60%)',
                icon: 'usergroup',
                testId: 'systementitlements-reqeust-memberships',
                data: {
                    fkRelations: this.membershipService.getFKRelation(),
                    isMultiValue: true,
                },
            });
            const result = yield sidesheetRef.afterClosed().toPromise();
            if (result && result.candidates.length > 0 && (yield this.membershipService.requestMembership(result.candidates, serviceItem))) {
                this.snackBarService.open({
                    key: '#LDS#The memberships for "{0}" have been successfully added to the shopping cart.',
                    parameters: [serviceItem.GetEntity().GetDisplay()],
                });
            }
        });
    }
    onWarningDismissed() {
        this.showUnsubscribeWarning = false;
    }
    unsubscribeMembership() {
        return __awaiter(this, void 0, void 0, function* () {
            // if there is at least 1 item, that is not unsubscribable, show a warning instead
            const notSubscribable = this.selectedItems.some((entity) => entity.GetEntity().GetColumn('IsRequestCancellable').GetValue() === false);
            if (notSubscribable) {
                this.showUnsubscribeWarning = true;
                this.membersTable.clearSelection();
                return;
            }
            if (yield this.confirmationService.confirm({
                Title: '#LDS#Heading Unsubscribe Memberships',
                Message: '#LDS#Are you sure you want to unsubscribe the selected memberships?',
                identifier: 'group-members-confirm-unsubscribe-membership',
            })) {
                this.handleOpenLoader();
                try {
                    yield Promise.all(this.selectedItems.map((entity) => this.membershipService.unsubscribeMembership(entity)));
                    this.snackBarService.open({
                        key: '#LDS#The memberships have been successfully unsubscribed. It may take some time for the changes to take effect. The displayed data may differ from the actual state.',
                    });
                }
                finally {
                    this.handleCloseLoader();
                    this.membersTable.clearSelection();
                    yield this.navigateDirect();
                }
            }
        });
    }
    onShowDetails(item) {
        return __awaiter(this, void 0, void 0, function* () {
            const uidPerson = item.UID_Person.value;
            const data = {
                UID_Person: uidPerson,
                Type: SourceDetectiveType.MembershipOfSystemEntitlement,
                UID: this.unsGroupDbObjectKey.Keys[0],
                TableName: this.unsGroupDbObjectKey.TableName,
            };
            this.sidesheet.open(SourceDetectiveSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Assignment Analysis').toPromise(),
                subTitle: item.GetEntity().GetDisplay(),
                padding: '0px',
                width: '800px',
                disableClose: false,
                testId: 'systementitlements-membership-assingment-analysis',
                data,
            });
        });
    }
    navigateDirect() {
        return __awaiter(this, void 0, void 0, function* () {
            this.handleOpenLoader();
            try {
                this.groupDirectMembershipData = yield this.groupsService.getGroupDirectMembers(this.groupId, this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayedColumns,
                    dataSource: this.groupDirectMembershipData,
                    entitySchema: this.entitySchemaGroupDirectMemberships,
                    navigationState: this.navigationState,
                };
            }
            finally {
                this.handleCloseLoader();
            }
        });
    }
    navigateNested() {
        return __awaiter(this, void 0, void 0, function* () {
            this.showUnsubscribeWarning = false;
            this.handleOpenLoader();
            try {
                this.groupNestedMembershipData = yield this.groupsService.getGroupNestedMembers(this.groupId, this.nestedNavigationState);
                this.dstNestedGroupSettings = {
                    displayedColumns: this.nestedDisplayColumns,
                    dataSource: this.groupNestedMembershipData,
                    entitySchema: this.entitySchemaGroupNestedMemberships,
                    navigationState: this.nestedNavigationState,
                };
            }
            finally {
                this.handleCloseLoader();
            }
        });
    }
    handleOpenLoader() {
        if (!this.busyIndicator) {
            this.busyIndicator = this.busyService.show();
        }
    }
    handleCloseLoader() {
        if (this.busyIndicator) {
            setTimeout(() => {
                this.busyService.hide(this.busyIndicator);
                this.busyIndicator = undefined;
            });
        }
    }
}
GroupMembersComponent.ɵfac = function GroupMembersComponent_Factory(t) { return new (t || GroupMembersComponent)(i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(GroupsService), i0.ɵɵdirectiveInject(i2.ConfirmationService), i0.ɵɵdirectiveInject(NewMembershipService), i0.ɵɵdirectiveInject(i7$1.TranslateService), i0.ɵɵdirectiveInject(i2.SettingsService)); };
GroupMembersComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GroupMembersComponent, selectors: [["imx-group-members"]], viewQuery: function GroupMembersComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$8, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.membersTable = _t.first);
        }
    }, inputs: { groupDirectMembershipData: "groupDirectMembershipData", groupNestedMembershipData: "groupNestedMembershipData", unsGroupDbObjectKey: "unsGroupDbObjectKey" }, decls: 3, vars: 3, consts: [[4, "ngIf"], ["value", "direct", 3, "vertical", "change"], ["buttonToggle", ""], ["value", "direct", 3, "matTooltip"], ["value", "nested", 3, "matTooltip"], ["condensed", "true", "type", "info", 1, "helper-alert", 3, "colored", "dismissable"], ["type", "warning", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [3, "settings", "hiddenFilters", "itemStatus", "searchBoxText", "navigationStateChanged"], ["dstDirect", ""], ["mode", "manual", "detailViewVisible", "false", "noDataText", "#LDS#There are currently no direct memberships.", 3, "dst", "selectable", "highlightedEntityChanged", "selectionChanged"], ["membersTable", ""], [3, "entityColumn"], ["alignHeader", "center", "alignContent", "center", 3, "columnName"], [3, "dst"], ["type", "warning", 3, "condensed", "colored", "dismissable", "dismissed"], ["color", "gray"], [3, "settings", "hiddenFilters", "searchBoxText", "navigationStateChanged"], ["dstNested", ""], ["mode", "manual", "detailViewVisible", "false", "noDataText", "#LDS#There are currently no inherited memberships.", 3, "dst", "highlightedEntityChanged"]], template: function GroupMembersComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, GroupMembersComponent_div_0_Template, 11, 13, "div", 0);
            i0.ɵɵtemplate(1, GroupMembersComponent_ng_container_1_Template, 19, 23, "ng-container", 0);
            i0.ɵɵtemplate(2, GroupMembersComponent_ng_container_2_Template, 14, 16, "ng-container", 0);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.canViewInheritedMemberships);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.membershipView === "direct");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.membershipView === "nested" && ctx.canViewInheritedMemberships);
        }
    }, dependencies: [i7.NgIf, i1$1.EuiAlertComponent, i1$1.EuiBadgeComponent, i7$2.MatButtonToggleGroup, i7$2.MatButtonToggle, i8$1.MatTooltip, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;height:100%;flex-direction:column}.mat-button-toggle-group[_ngcontent-%COMP%]{margin-bottom:10px}.mat-button-toggle-group[_ngcontent-%COMP%]   .mat-button-toggle-checked[_ngcontent-%COMP%]{background-color:#f7e4d0}  .mat-checkbox-disabled{cursor:not-allowed}.helper-alert[_ngcontent-%COMP%]{margin:20px 2px}@media screen and (max-width: 768px){.mat-button-toggle-group[_ngcontent-%COMP%]{width:100%}}.eui-dark-theme   [_nghost-%COMP%]     .mat-button-toggle-group .mat-button-toggle-checked{background-color:#616566}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupMembersComponent, [{
            type: Component,
            args: [{ selector: 'imx-group-members', template: "<div *ngIf=\"canViewInheritedMemberships\">\r\n  <mat-button-toggle-group #buttonToggle value=\"direct\" (change)=\"onToggleChanged($event)\" [vertical]=\"isMobile\">\r\n    <mat-button-toggle [matTooltip]=\"LdsDirectlyAssignedHint | translate\" value=\"direct\">{{ LdsDirectlyAssigned\r\n      | translate }}</mat-button-toggle>\r\n    <mat-button-toggle [matTooltip]=\"LdsIndirectlyAssignedHint | translate\" value=\"nested\">{{ LdsIndirectlyAssigned\r\n      | translate }}</mat-button-toggle>\r\n  </mat-button-toggle-group>\r\n</div>\r\n\r\n<ng-container *ngIf=\"membershipView === 'direct'\">\r\n  <eui-alert class=\"helper-alert\" condensed=\"true\" [colored]=\"true\" type=\"info\" [dismissable]=\"false\" >\r\n    {{ '#LDS#Here you can manage the memberships of the system entitlement. You can request and remove memberships and view the assignment analysis for each membership.' | translate }}\r\n    </eui-alert>\r\n  <eui-alert *ngIf=\"showUnsubscribeWarning\" type=\"warning\" [condensed]=\"true\" [colored]=\"true\" [dismissable]=\"true\"\r\n    (dismissed)=\"onWarningDismissed()\">{{LdsNotUnsubscribableHint | translate}}</eui-alert>\r\n    \r\n  <imx-data-source-toolbar #dstDirect [settings]=\"dstSettings\"\r\n    [hiddenFilters]=\"['namespace']\"\r\n    [itemStatus]=\"itemStatus\" (navigationStateChanged)=\"onDirectNavigationStateChanged($event)\"\r\n    [searchBoxText]=\"'#LDS#Search' | translate\">\r\n  </imx-data-source-toolbar>\r\n\r\n  <imx-data-table #membersTable [dst]=\"dstDirect\" mode=\"manual\" detailViewVisible=\"false\"\r\n    noDataText=\"#LDS#There are currently no direct memberships.\" [selectable]=\"true\"\r\n    (highlightedEntityChanged)=\"onShowDetails($event)\"\r\n    (selectionChanged)=\"onSelectionChanged($event)\">\r\n    <imx-data-table-column [entityColumn]=\"entitySchemaGroupDirectMemberships?.Columns.UID_Person\">\r\n    </imx-data-table-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchemaGroupDirectMemberships?.Columns.UID_UNSAccount\">\r\n    </imx-data-table-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchemaGroupDirectMemberships?.Columns.XOrigin\">\r\n    </imx-data-table-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchemaGroupDirectMemberships?.Columns.XDateInserted\">\r\n    </imx-data-table-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchemaGroupDirectMemberships?.Columns.OrderState\">\r\n    </imx-data-table-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchemaGroupDirectMemberships?.Columns.ValidUntil\">\r\n    </imx-data-table-column>\r\n    <imx-data-table-generic-column alignHeader=\"center\" alignContent=\"center\"\r\n      [columnName]=\"entitySchemaGroupDirectMemberships?.Columns.XMarkedForDeletion.ColumnName\">\r\n      <ng-template let-item>\r\n        <div *ngIf=\"item.XMarkedForDeletion.value !== 0\">\r\n          <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\r\n        </div>\r\n      </ng-template>\r\n    </imx-data-table-generic-column>\r\n  </imx-data-table>\r\n\r\n\r\n  <imx-data-source-paginator [dst]=\"dstDirect\"></imx-data-source-paginator>\r\n</ng-container>\r\n\r\n<ng-container *ngIf=\"membershipView === 'nested' && canViewInheritedMemberships\">\r\n  <eui-alert class=\"helper-alert\" condensed=\"true\" [colored]=\"true\" type=\"info\" [dismissable]=\"false\" >\r\n    {{ '#LDS#Here you can get an overview of the memberships of the system entitlement. Additionally, you can view the assignment analysis for each membership.' | translate }}\r\n    </eui-alert>\r\n  <imx-data-source-toolbar #dstNested [settings]=\"dstNestedGroupSettings\"\r\n    [hiddenFilters]=\"['namespace']\"\r\n    (navigationStateChanged)=\"onNestedNavigationStateChanged($event)\" [searchBoxText]=\"'#LDS#Search' | translate\">\r\n  </imx-data-source-toolbar>\r\n\r\n  <imx-data-table #membersTable [dst]=\"dstNested\" mode=\"manual\" detailViewVisible=\"false\"\r\n  (highlightedEntityChanged)=\"onShowDetails($event)\"\r\n    noDataText=\"#LDS#There are currently no inherited memberships.\">\r\n    <imx-data-table-column [entityColumn]=\"entitySchemaGroupNestedMemberships?.Columns.UID_Person\">\r\n    </imx-data-table-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchemaGroupNestedMemberships?.Columns.UID_UNSGroupChild\">\r\n    </imx-data-table-column>\r\n    <imx-data-table-generic-column alignHeader=\"center\" alignContent=\"center\"\r\n      [columnName]=\"entitySchemaGroupNestedMemberships?.Columns.XMarkedForDeletion.ColumnName\">\r\n      <ng-template let-item>\r\n        <div *ngIf=\"item.XMarkedForDeletion.value !== 0\">\r\n          <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\r\n        </div>\r\n      </ng-template>\r\n    </imx-data-table-generic-column>\r\n  </imx-data-table>\r\n  <imx-data-source-paginator [dst]=\"dstNested\"></imx-data-source-paginator>\r\n</ng-container>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;height:100%;flex-direction:column}.mat-button-toggle-group{margin-bottom:10px}.mat-button-toggle-group .mat-button-toggle-checked{background-color:#f7e4d0}::ng-deep .mat-checkbox-disabled{cursor:not-allowed}.helper-alert{margin:20px 2px}@media screen and (max-width: 768px){.mat-button-toggle-group{width:100%}}.eui-dark-theme :host ::ng-deep .mat-button-toggle-group .mat-button-toggle-checked{background-color:#616566}\n"] }]
        }], function () { return [{ type: i1$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i1$1.EuiSidesheetService }, { type: GroupsService }, { type: i2.ConfirmationService }, { type: NewMembershipService }, { type: i7$1.TranslateService }, { type: i2.SettingsService }]; }, { groupDirectMembershipData: [{
                type: Input
            }], groupNestedMembershipData: [{
                type: Input
            }], unsGroupDbObjectKey: [{
                type: Input
            }], membersTable: [{
                type: ViewChild,
                args: ['membersTable']
            }] });
})();

const _c0$7 = function () { return ["hiddenFilters"]; };
const _c1$4 = function () { return ["namespace"]; };
class ChildSystemEntitlementsComponent {
    constructor(busyService, settingsService, groupsService) {
        this.busyService = busyService;
        this.settingsService = settingsService;
        this.groupsService = groupsService;
        this.groupDisplayedColumns = [];
        this.navigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaUnsGroupMemberships = groupsService.UnsGroupMembersSchema;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.groupDisplayedColumns = [
                this.entitySchemaUnsGroupMemberships.Columns.UID_UNSGroupChild,
                this.entitySchemaUnsGroupMemberships.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
                this.entitySchemaUnsGroupMemberships.Columns.XDateInserted,
            ];
            yield this.groupNavigate();
        });
    }
    getData(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.groupNavigate(newState);
        });
    }
    groupNavigate(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => overlayRef = this.busyService.show());
            try {
                if (newState) {
                    this.navigationState = newState;
                }
                this.groupsGroupMembershipData = yield this.groupsService.getGroupsGroupMembers(this.groupId, this.navigationState);
                this.groupsDstSettings = {
                    displayedColumns: this.groupDisplayedColumns,
                    dataSource: this.groupsGroupMembershipData,
                    entitySchema: this.entitySchemaUnsGroupMemberships,
                    navigationState: this.navigationState,
                };
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
        });
    }
}
ChildSystemEntitlementsComponent.ɵfac = function ChildSystemEntitlementsComponent_Factory(t) { return new (t || ChildSystemEntitlementsComponent)(i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(GroupsService)); };
ChildSystemEntitlementsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ChildSystemEntitlementsComponent, selectors: [["imx-child-system-entitlements"]], inputs: { groupId: "groupId", isAdmin: "isAdmin" }, decls: 4, vars: 7, consts: [[3, "settings", "options", "hiddenFilters", "navigationStateChanged"], ["groupsDst", ""], ["detailViewVisible", "false", "noDataText", "#LDS#There are currently no system entitlements.", 3, "dst"], [3, "dst"]], template: function ChildSystemEntitlementsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "imx-data-source-toolbar", 0, 1);
            i0.ɵɵlistener("navigationStateChanged", function ChildSystemEntitlementsComponent_Template_imx_data_source_toolbar_navigationStateChanged_0_listener($event) { return ctx.getData($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelement(2, "imx-data-table", 2)(3, "imx-data-source-paginator", 3);
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(1);
            i0.ɵɵproperty("settings", ctx.groupsDstSettings)("options", i0.ɵɵpureFunction0(5, _c0$7))("hiddenFilters", i0.ɵɵpureFunction0(6, _c1$4));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent], styles: ["[_nghost-%COMP%]{display:flex;height:100%;flex-direction:column}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChildSystemEntitlementsComponent, [{
            type: Component,
            args: [{ selector: 'imx-child-system-entitlements', template: "<imx-data-source-toolbar #groupsDst (navigationStateChanged)=\"getData($event)\" [settings]=\"groupsDstSettings\"\r\n  [options]=\"['hiddenFilters']\" [hiddenFilters]=\"['namespace']\">\r\n</imx-data-source-toolbar>\r\n\r\n<imx-data-table [dst]=\"groupsDst\" detailViewVisible=\"false\"\r\n  noDataText=\"#LDS#There are currently no system entitlements.\">\r\n</imx-data-table>\r\n<imx-data-source-paginator [dst]=\"groupsDst\"></imx-data-source-paginator>", styles: [":host{display:flex;height:100%;flex-direction:column}\n"] }]
        }], function () { return [{ type: i1$1.EuiLoadingService }, { type: i2.SettingsService }, { type: GroupsService }]; }, { groupId: [{
                type: Input
            }], isAdmin: [{
                type: Input
            }] });
})();

const _c0$6 = ["groupMembers"];
const _c1$3 = ["serviceItemsEditForm"];
function GroupSidesheetComponent_ng_template_2_eui_icon_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "eui-icon", 20);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
    }
}
function GroupSidesheetComponent_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 18);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelementStart(2, "span", 8);
        i0.ɵɵtext(3, "#LDS#Heading Main Data");
        i0.ɵɵelementEnd();
        i0.ɵɵtext(4, "\u00A0 ");
        i0.ɵɵtemplate(5, GroupSidesheetComponent_ng_template_2_eui_icon_5_Template, 2, 3, "eui-icon", 19);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, ctx_r0.detailsFormGroup.dirty ? "#LDS#You have unsaved changes" : ""));
        i0.ɵɵadvance(5);
        i0.ɵɵproperty("ngIf", ctx_r0.detailsFormGroup.dirty);
    }
}
function GroupSidesheetComponent_imx_cdr_editor_7_Template(rf, ctx) {
    if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 21);
        i0.ɵɵlistener("controlCreated", function GroupSidesheetComponent_imx_cdr_editor_7_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r11 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r11.formArray.push($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r10 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r10);
    }
}
function GroupSidesheetComponent_button_14_Template(rf, ctx) {
    if (rf & 1) {
        const _r14 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 22);
        i0.ɵɵlistener("click", function GroupSidesheetComponent_button_14_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r14); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.createServiceItem()); });
        i0.ɵɵelementStart(1, "span", 8);
        i0.ɵɵtext(2, "#LDS#Create service item");
        i0.ɵɵelementEnd()();
    }
}
function GroupSidesheetComponent_mat_tab_18_ng_template_1_eui_icon_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "eui-icon", 20);
        i0.ɵɵpipe(1, "translate");
    }
    if (rf & 2) {
        i0.ɵɵattribute("aria-label", i0.ɵɵpipeBind1(1, 1, "#LDS#You have unsaved changes."));
    }
}
function GroupSidesheetComponent_mat_tab_18_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 18);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵelementStart(2, "span", 8);
        i0.ɵɵtext(3, "#LDS#Heading Service Item");
        i0.ɵɵelementEnd();
        i0.ɵɵtext(4, " \u00A0 ");
        i0.ɵɵtemplate(5, GroupSidesheetComponent_mat_tab_18_ng_template_1_eui_icon_5_Template, 2, 3, "eui-icon", 19);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r15 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 2, ctx_r15.serviceItemFormGroup.dirty ? "#LDS#You have unsaved changes" : ""));
        i0.ɵɵadvance(5);
        i0.ɵɵproperty("ngIf", ctx_r15.serviceItemFormGroup.dirty);
    }
}
function GroupSidesheetComponent_mat_tab_18_imx_service_items_edit_form_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r20 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-service-items-edit-form", 25, 26);
        i0.ɵɵlistener("formControlCreated", function GroupSidesheetComponent_mat_tab_18_imx_service_items_edit_form_4_Template_imx_service_items_edit_form_formControlCreated_0_listener($event) { i0.ɵɵrestoreView(_r20); const ctx_r19 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r19.siFormArray.push($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r16 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("serviceItem", ctx_r16.groupServiceItem);
    }
}
function GroupSidesheetComponent_mat_tab_18_Template(rf, ctx) {
    if (rf & 1) {
        const _r22 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "mat-tab");
        i0.ɵɵtemplate(1, GroupSidesheetComponent_mat_tab_18_ng_template_1_Template, 6, 4, "ng-template", 0);
        i0.ɵɵelementStart(2, "div", 1)(3, "div", 2);
        i0.ɵɵtemplate(4, GroupSidesheetComponent_mat_tab_18_imx_service_items_edit_form_4_Template, 2, 1, "imx-service-items-edit-form", 23);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "div", 5)(6, "button", 24);
        i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_18_Template_button_click_6_listener() { i0.ɵɵrestoreView(_r22); const ctx_r21 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r21.saveGroupServiceItem()); });
        i0.ɵɵelementStart(7, "span", 8);
        i0.ɵɵtext(8, "#LDS#Save");
        i0.ɵɵelementEnd()()()()();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("ngIf", ctx_r3.groupServiceItem);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", !ctx_r3.serviceItemFormGroup.dirty || ctx_r3.serviceItemFormGroup.invalid);
    }
}
function GroupSidesheetComponent_mat_tab_19_ng_template_2_div_4_button_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r28 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 34);
        i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_19_ng_template_2_div_4_button_1_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r28); const ctx_r27 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r27.requestMembership()); });
        i0.ɵɵelementStart(1, "span", 8);
        i0.ɵɵtext(2, "#LDS#Request memberships");
        i0.ɵɵelementEnd()();
    }
}
function GroupSidesheetComponent_mat_tab_19_ng_template_2_div_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r30 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 5);
        i0.ɵɵtemplate(1, GroupSidesheetComponent_mat_tab_19_ng_template_2_div_4_button_1_Template, 3, 0, "button", 30);
        i0.ɵɵelementStart(2, "button", 31);
        i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_19_ng_template_2_div_4_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r30); const ctx_r29 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r29.onDeleteGroupMembers("delete")); });
        i0.ɵɵelement(3, "eui-icon", 32);
        i0.ɵɵelementStart(4, "span", 8);
        i0.ɵɵtext(5, "#LDS#Remove");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(6, "button", 33);
        i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_19_ng_template_2_div_4_Template_button_click_6_listener() { i0.ɵɵrestoreView(_r30); const ctx_r31 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r31.onDeleteGroupMembers("unsubscribe")); });
        i0.ɵɵelementStart(7, "span", 8);
        i0.ɵɵtext(8, "#LDS#Unsubscribe");
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r24 = i0.ɵɵreference(3);
        const ctx_r25 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r25.isRequestable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("disabled", _r24.selectedItemsCount === 0 || !ctx_r25.canDeleteSelected());
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("disabled", _r24.selectedItemsCount === 0 || !ctx_r25.canUnsubscribeSelected());
    }
}
function GroupSidesheetComponent_mat_tab_19_ng_template_2_Template(rf, ctx) {
    if (rf & 1) {
        const _r33 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 1)(1, "div", 2);
        i0.ɵɵelement(2, "imx-group-members", 27, 28);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(4, GroupSidesheetComponent_mat_tab_19_ng_template_2_div_4_Template, 9, 3, "div", 29);
        i0.ɵɵelementStart(5, "div", 5)(6, "button", 24);
        i0.ɵɵlistener("click", function GroupSidesheetComponent_mat_tab_19_ng_template_2_Template_button_click_6_listener() { i0.ɵɵrestoreView(_r33); const ctx_r32 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r32.saveGroupServiceItem()); });
        i0.ɵɵelementStart(7, "span", 8);
        i0.ɵɵtext(8, "#LDS#Save");
        i0.ɵɵelementEnd()()()();
    }
    if (rf & 2) {
        const _r24 = i0.ɵɵreference(3);
        const ctx_r23 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("unsGroupDbObjectKey", ctx_r23.unsGroupDbObjectKey);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", _r24.membershipView === "direct");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", !ctx_r23.serviceItemFormGroup.dirty || ctx_r23.serviceItemFormGroup.invalid);
    }
}
function GroupSidesheetComponent_mat_tab_19_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 14);
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵtemplate(2, GroupSidesheetComponent_mat_tab_19_ng_template_2_Template, 9, 3, "ng-template", 15);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵproperty("label", i0.ɵɵpipeBind1(1, 1, "#LDS#Heading Memberships"));
    }
}
function GroupSidesheetComponent_ng_template_22_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 1)(1, "div", 2);
        i0.ɵɵelement(2, "imx-child-system-entitlements", 35, 36);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("isAdmin", ctx_r5.isAdmin)("groupId", ctx_r5.groupId);
    }
}
function GroupSidesheetComponent_ng_template_25_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 37);
        i0.ɵɵelement(1, "imx-object-hyperview", 38);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext();
        let tmp_0_0;
        let tmp_1_0;
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("objectType", ctx_r6.sidesheetData == null ? null : ctx_r6.sidesheetData.group == null ? null : (tmp_0_0 = ctx_r6.sidesheetData.group.GetEntity()) == null ? null : tmp_0_0.TypeName)("objectUid", ctx_r6.sidesheetData == null ? null : (tmp_1_0 = ctx_r6.sidesheetData.group.GetEntity()) == null ? null : tmp_1_0.GetKeys()[0]);
    }
}
function GroupSidesheetComponent_ng_template_28_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 1)(1, "div", 2);
        i0.ɵɵelement(2, "imx-object-history", 39);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r7 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("showTitle", false)("objectUid", ctx_r7.groupId);
    }
}
function GroupSidesheetComponent_ng_container_29_ng_template_3_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0, 43);
    }
}
function GroupSidesheetComponent_ng_container_29_ng_template_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 1)(1, "div", 41);
        i0.ɵɵtemplate(2, GroupSidesheetComponent_ng_container_29_ng_template_3_ng_container_2_Template, 1, 0, "ng-container", 42);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const tab_r35 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngComponentOutlet", tab_r35.instance);
    }
}
function GroupSidesheetComponent_ng_container_29_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "mat-tab", 40);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵtemplate(3, GroupSidesheetComponent_ng_container_29_ng_template_3_Template, 3, 1, "ng-template", 15);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const tab_r35 = ctx.$implicit;
        const ctx_r8 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("imxDataProvider", ctx_r8.parameters)("label", i0.ɵɵpipeBind1(2, 2, tab_r35.inputData.label));
    }
}
class GroupSidesheetComponent {
    constructor(formBuilder, groups, sidesheetData, logger, busyService, snackbar, elementalUiConfigService, systemInfoService, reports, configService, sidesheetRef, tabService, confirmation) {
        var _a;
        this.groups = groups;
        this.sidesheetData = sidesheetData;
        this.logger = logger;
        this.busyService = busyService;
        this.snackbar = snackbar;
        this.elementalUiConfigService = elementalUiConfigService;
        this.systemInfoService = systemInfoService;
        this.reports = reports;
        this.configService = configService;
        this.sidesheetRef = sidesheetRef;
        this.tabService = tabService;
        this.confirmation = confirmation;
        this.cdrList = [];
        this.pendingAttestations = { loading: false };
        this.canCreateServiceItem = false;
        this.dynamicTabs = [];
        this.sidesheetRef.closeClicked().subscribe(() => __awaiter(this, void 0, void 0, function* () {
            if (!this.detailsFormGroup.dirty && !this.serviceItemFormGroup.dirty) {
                this.sidesheetRef.close();
                return;
            }
            if (yield this.confirmation.confirmLeaveWithUnsavedChanges()) {
                yield this.cancelProcess();
            }
        }));
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.serviceItemFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.isRequestable = sidesheetData.groupServiceItem != null && !sidesheetData.groupServiceItem.IsInActive.value;
        this.reportDownload = Object.assign(Object.assign({}, this.elementalUiConfigService.Config.downloadOptions), { url: this.reports.groupsByGroupReport(30, this.groupId) });
        this.unsGroupDbObjectKey = this.sidesheetData.unsGroupDbObjectKey;
        if (this.sidesheetData.unsGroupDbObjectKey) {
            this.parameters = {
                objecttable: this.unsGroupDbObjectKey.TableName,
                objectuid: this.unsGroupDbObjectKey.Keys[0]
            };
        }
        this.canCreateServiceItem = !((_a = sidesheetData.group.GetEntity().GetColumn('XReadOnlyMemberships')) === null || _a === void 0 ? void 0 : _a.GetValue());
        this.buttonBarExtensionReferrer = {
            type: this.sidesheetData.unsGroupDbObjectKey.TableName,
            uidGroup: this.sidesheetData.group.GetEntity().GetKeys()[0],
            defaultDownloadOptions: this.elementalUiConfigService.Config.downloadOptions
        };
    }
    get groupId() {
        return this.sidesheetData.group.GetEntity().GetKeys().join('');
    }
    get isAdmin() {
        return this.sidesheetData.isAdmin;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.setup();
        });
    }
    get groupServiceItem() {
        return this.sidesheetData.groupServiceItem;
    }
    get isAadGroup() {
        let isAad = false;
        const xObjKey = this.sidesheetData.unsGroupDbObjectKey;
        isAad = xObjKey ? xObjKey.TableName === 'AADGroup' : false;
        return isAad;
    }
    get formArray() {
        return this.detailsFormGroup.get('formArray');
    }
    get siFormArray() {
        return this.serviceItemFormGroup.get('formArray');
    }
    cancel() {
        this.sidesheetRef.close();
    }
    createServiceItem() {
        return __awaiter(this, void 0, void 0, function* () {
            this.sidesheetData.group.extendedData = {
                CreateServiceItem: true
            };
            yield this.saveChanges(this.detailsFormGroup, this.sidesheetData.group, '#LDS#The service item has been successfully created.', true);
        });
    }
    saveGroup() {
        return __awaiter(this, void 0, void 0, function* () {
            this.saveChanges(this.detailsFormGroup, this.sidesheetData.group, '#LDS#The system entitlement has been successfully saved.');
        });
    }
    saveGroupServiceItem() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            (_a = this.serviceItemsEditForm) === null || _a === void 0 ? void 0 : _a.saveTags();
            const uidPerson = (_b = this.serviceItemsEditForm) === null || _b === void 0 ? void 0 : _b.getSelectedUidPerson;
            let confirmMessage = '#LDS#The service item has been successfully saved.';
            if (uidPerson) {
                this.groupServiceItem.extendedData = {
                    UidPerson: uidPerson,
                    CopyAllMembers: true,
                };
                confirmMessage = '#LDS#The service item has been successfully saved. It may take some time for the changes to take effect.';
            }
            else {
                this.groupServiceItem.extendedData = undefined;
            }
            this.saveChanges(this.serviceItemFormGroup, this.groupServiceItem, confirmMessage);
        });
    }
    canUnsubscribeSelected() {
        var _a;
        return (_a = this.groupMembersComponent) === null || _a === void 0 ? void 0 : _a.canUnsubscribeSelected();
    }
    canDeleteSelected() {
        var _a;
        return (_a = this.groupMembersComponent) === null || _a === void 0 ? void 0 : _a.canDeleteSelected();
    }
    onDeleteGroupMembers(mode) {
        return __awaiter(this, void 0, void 0, function* () {
            return mode === 'delete' ? this.groupMembersComponent.deleteMembers() : this.groupMembersComponent.unsubscribeMembership();
        });
    }
    requestMembership() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.groupMembersComponent.requestMembership(this.groupServiceItem);
        });
    }
    cancelProcess() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.detailsFormGroup.pristine) {
                this.snackbar.open({ key: '#LDS#The changes were discarded.' }, '#LDS#Close');
            }
            this.sidesheetRef.close();
        });
    }
    setup() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            let overlayRef;
            setTimeout(() => overlayRef = this.busyService.show());
            try {
                const systemInfo = yield this.systemInfoService.get();
                const config = (yield this.configService.getConfig()).OwnershipConfig;
                const type = (_a = this.parameters) === null || _a === void 0 ? void 0 : _a.objecttable;
                this.dynamicTabs = (yield this.tabService.getFittingComponents('groupSidesheet', (ext) => ext.inputData.checkVisibility(this.parameters)))
                    .sort((tab1, tab2) => tab1.sortOrder - tab2.sortOrder);
                const cols = this.sidesheetData.group
                    .getColumns(systemInfo.PreProps.includes('RISKINDEX'), type == null ? [] : config.EditableFields[type]);
                this.cdrList = cols
                    .map(column => new BaseCdr(column));
            }
            finally {
                setTimeout(() => this.busyService.hide(overlayRef));
            }
        });
    }
    saveChanges(formGroup, objectToSave, confirmationText, reloadServiceItem = false) {
        return __awaiter(this, void 0, void 0, function* () {
            if (formGroup.valid) {
                this.logger.debug(this, `Saving group changes`);
                const overlayRef = this.busyService.show();
                try {
                    yield objectToSave.GetEntity().Commit(true);
                    if (reloadServiceItem) {
                        this.sidesheetData.uidAccProduct = this.sidesheetData.group.GetEntity().GetColumn('UID_AccProduct').GetValue();
                        this.sidesheetData.groupServiceItem = yield this.groups.getGroupServiceItem(this.sidesheetData.uidAccProduct);
                    }
                    this.isRequestable = !this.groupServiceItem.IsInActive.value;
                    formGroup.markAsPristine();
                    this.snackbar.open({ key: confirmationText }, '#LDS#Close');
                }
                finally {
                    this.busyService.hide(overlayRef);
                }
            }
        });
    }
}
GroupSidesheetComponent.ɵfac = function GroupSidesheetComponent_Factory(t) { return new (t || GroupSidesheetComponent)(i0.ɵɵdirectiveInject(i1$2.UntypedFormBuilder), i0.ɵɵdirectiveInject(GroupsService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.ElementalUiConfigService), i0.ɵɵdirectiveInject(i2.SystemInfoService), i0.ɵɵdirectiveInject(GroupsReportsService), i0.ɵɵdirectiveInject(i1.ProjectConfigurationService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.ExtService), i0.ɵɵdirectiveInject(i2.ConfirmationService)); };
GroupSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GroupSidesheetComponent, selectors: [["imx-group-sidesheet"]], viewQuery: function GroupSidesheetComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$6, 5);
            i0.ɵɵviewQuery(_c1$3, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.groupMembersComponent = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.serviceItemsEditForm = _t.first);
        }
    }, decls: 30, vars: 18, consts: [["mat-tab-label", ""], ["eui-sidesheet-content", "", 1, "governance-sidesheet__tab-content"], [1, "governance-sidesheet__tab-content-body"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], ["eui-sidesheet-actions", ""], [1, "justify-start", "imx-breakable"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-download-report", 3, "euiDownload"], ["translate", ""], ["id", "buttonBarExtensionComponent", 3, "referrer"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-create-service-item", 3, "click", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-save-group", 3, "disabled", "click"], [4, "ngIf"], [3, "label", 4, "ngIf"], [3, "label"], ["matTabContent", ""], ["data-imx-identifier", "groups-sidesheet-tab-history", 3, "label"], [4, "ngFor", "ngForOf"], [3, "matTooltip"], ["icon", "save", "class", "imx-dirty-indicator", "size", "s", 4, "ngIf"], ["icon", "save", "size", "s", 1, "imx-dirty-indicator"], [3, "cdr", "controlCreated"], ["mat-stroked-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-create-service-item", 3, "click"], [3, "serviceItem", "formControlCreated", 4, "ngIf"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-save-groupserviceitem", 3, "disabled", "click"], [3, "serviceItem", "formControlCreated"], ["serviceItemsEditForm", ""], [3, "unsGroupDbObjectKey"], ["groupMembers", ""], ["eui-sidesheet-actions", "", 4, "ngIf"], ["mat-button", "", "data-imx-identifier", "group-sidesheet-button-membership-new", 3, "click", 4, "ngIf"], ["mat-stroked-button", "", "color", "warn", "data-imx-identifier", "group-sidesheet-button-delete-groupmembers", 3, "disabled", "click"], ["icon", "delete"], ["mat-flat-button", "", "color", "primary", "data-imx-identifier", "group-sidesheet-button-delete-groupmembers", 3, "disabled", "click"], ["mat-button", "", "data-imx-identifier", "group-sidesheet-button-membership-new", 3, "click"], [3, "isAdmin", "groupId"], ["childEntitlements", ""], ["eui-sidesheet-content", "", 1, "imx-hyperview-sidesheet"], [3, "objectType", "objectUid"], ["objectType", "UNSGroup", 3, "showTitle", "objectUid"], [3, "imxDataProvider", "label"], [1, "governance-sidesheet__tab-content-body", "imx-flex-child"], ["style.flex", "1 1 auto", 4, "ngComponentOutlet"], ["style.flex", "1 1 auto"]], template: function GroupSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group")(1, "mat-tab");
            i0.ɵɵtemplate(2, GroupSidesheetComponent_ng_template_2_Template, 6, 4, "ng-template", 0);
            i0.ɵɵelementStart(3, "div", 1)(4, "div", 2)(5, "mat-card")(6, "form", 3);
            i0.ɵɵtemplate(7, GroupSidesheetComponent_imx_cdr_editor_7_Template, 1, 1, "imx-cdr-editor", 4);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(8, "div", 5)(9, "div", 6)(10, "button", 7)(11, "span", 8);
            i0.ɵɵtext(12, "#LDS#Download report");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(13, "imx-ext", 9);
            i0.ɵɵtemplate(14, GroupSidesheetComponent_button_14_Template, 3, 0, "button", 10);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(15, "button", 11);
            i0.ɵɵlistener("click", function GroupSidesheetComponent_Template_button_click_15_listener() { return ctx.saveGroup(); });
            i0.ɵɵelementStart(16, "span", 8);
            i0.ɵɵtext(17, "#LDS#Save");
            i0.ɵɵelementEnd()()()()();
            i0.ɵɵtemplate(18, GroupSidesheetComponent_mat_tab_18_Template, 9, 2, "mat-tab", 12);
            i0.ɵɵtemplate(19, GroupSidesheetComponent_mat_tab_19_Template, 3, 3, "mat-tab", 13);
            i0.ɵɵelementStart(20, "mat-tab", 14);
            i0.ɵɵpipe(21, "translate");
            i0.ɵɵtemplate(22, GroupSidesheetComponent_ng_template_22_Template, 4, 2, "ng-template", 15);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(23, "mat-tab", 14);
            i0.ɵɵpipe(24, "translate");
            i0.ɵɵtemplate(25, GroupSidesheetComponent_ng_template_25_Template, 2, 2, "ng-template", 15);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(26, "mat-tab", 16);
            i0.ɵɵpipe(27, "translate");
            i0.ɵɵtemplate(28, GroupSidesheetComponent_ng_template_28_Template, 3, 2, "ng-template", 15);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(29, GroupSidesheetComponent_ng_container_29_Template, 4, 4, "ng-container", 17);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(6);
            i0.ɵɵproperty("formGroup", ctx.detailsFormGroup);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.cdrList);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("euiDownload", ctx.reportDownload);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("referrer", ctx.buttonBarExtensionReferrer);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.groupServiceItem && ctx.canCreateServiceItem);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("disabled", !ctx.detailsFormGroup.dirty || ctx.detailsFormGroup.invalid);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.groupServiceItem);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.unsGroupDbObjectKey);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(21, 12, "#LDS#Heading Child System Entitlements"));
            i0.ɵɵadvance(3);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(24, 14, "#LDS#Heading Hyperview"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(27, 16, "#LDS#History"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngForOf", ctx.dynamicTabs);
        }
    }, dependencies: [i7.NgComponentOutlet, i7.NgForOf, i7.NgIf, i1$2.ɵNgNoValidate, i1$2.NgControlStatusGroup, i1$2.FormGroupDirective, i1$1.EuiIconComponent, i1$1.EuiDownloadDirective, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i10$1.MatCard, i10$2.MatTabGroup, i10$2.MatTabLabel, i10$2.MatTab, i10$2.MatTabContent, i8$1.MatTooltip, i2.ExtComponent, i2.CdrEditorComponent, i1.ObjectHyperviewComponent, i1.ServiceItemsEditFormComponent, i7$1.TranslateDirective, i2.DynamicTabDataProviderDirective, i2.ObjectHistoryComponent, GroupMembersComponent, ChildSystemEntitlementsComponent, i7$1.TranslatePipe], styles: [".product-owner-datasource-container[_ngcontent-%COMP%]{margin:10px 0 25px}.product-owner-datasource-container[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block;font-size:12px;color:#919799;padding-bottom:2px}.product-owner-datasource-container[_ngcontent-%COMP%]   mat-radio-button[_ngcontent-%COMP%]{margin-right:10px}.product-owner-datasource-container[_ngcontent-%COMP%]   .hidden[_ngcontent-%COMP%]{display:none}.product-owner-datasource-container[_ngcontent-%COMP%]   .help-icon[_ngcontent-%COMP%]{color:#0a96d1;font-size:16px;margin-left:5px}.product-owner-datasource-container[_ngcontent-%COMP%]   .mat-radio-group[_ngcontent-%COMP%]{display:block;margin-bottom:10px}[_nghost-%COMP%]     .mat-badge-small.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-16px;background:#e36a00}[_nghost-%COMP%]     .mat-tab-group{height:100%;flex-grow:1;overflow:auto}[_nghost-%COMP%]     .mat-tab-group .mat-tab-header{padding:0 32px;background-color:#fff}[_nghost-%COMP%]     .mat-tab-group   .mat-tab-body-wrapper{height:100%}[_nghost-%COMP%]     .mat-tab-group .imx-edit-fk-open-picker{display:none}@media screen and (max-width: 769px){.product-owner-datasource-container[_ngcontent-%COMP%]   .help-icon[_ngcontent-%COMP%]{display:none}}.governance-sidesheet__tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%]{flex:1 1 auto;overflow:auto;padding:20px}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:first-child{overflow:auto}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%] > .imx-ext[_ngcontent-%COMP%]{overflow:hidden}.governance-sidesheet__tab-content[_ngcontent-%COMP%]   .imx-flex-child[_ngcontent-%COMP%]   ng-container[_ngcontent-%COMP%]{flex:1 1 auto;display:flex}.governance-sidesheet__tab-content[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.mat-tab-body-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.imx-dirty-indicator[_ngcontent-%COMP%]{color:#e36a00}.eui-sidesheet-content[_ngcontent-%COMP%]:not(.imx-hyperview-sidesheet){padding:0}.eui-sidesheet-content[_ngcontent-%COMP%]:not(.imx-hyperview-sidesheet)     .mat-tab-body-content{display:flex;flex-direction:column}.eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}.imx-card[_ngcontent-%COMP%]{display:flex;justify-content:flex-end}.imx-card[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{margin-left:10px}.imx-breakable[_ngcontent-%COMP%]{margin-top:-10px}.imx-breakable[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]{margin-top:10px}.eui-dark-theme   [_nghost-%COMP%]   .product-owner-datasource-container[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#dfe4e6}.eui-dark-theme   [_nghost-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]   .product-owner-datasource-container[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:#fff}.eui-contrast-theme   [_nghost-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#16191a}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupSidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-group-sidesheet', template: "<mat-tab-group>\r\n  <mat-tab>\r\n    <ng-template mat-tab-label>\r\n      <div [matTooltip]=\"(detailsFormGroup.dirty ? '#LDS#You have unsaved changes' : '') | translate\">\r\n        <span translate>#LDS#Heading Main Data</span>&nbsp;\r\n        <eui-icon *ngIf=\"detailsFormGroup.dirty\" icon=\"save\" class=\"imx-dirty-indicator\" size=\"s\" [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"></eui-icon>\r\n      </div>\r\n    </ng-template>\r\n    <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n      <div class=\"governance-sidesheet__tab-content-body\">\r\n        <mat-card>\r\n          <form [formGroup]=\"detailsFormGroup\">\r\n            <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"> </imx-cdr-editor>\r\n          </form>\r\n        </mat-card>\r\n      </div>\r\n      <div eui-sidesheet-actions>\r\n        <div class=\"justify-start imx-breakable\">\r\n          <button mat-stroked-button color=\"primary\" [euiDownload]=\"reportDownload\" data-imx-identifier=\"group-sidesheet-button-download-report\">\r\n            <span translate>#LDS#Download report</span>\r\n          </button>\r\n          <imx-ext id=\"buttonBarExtensionComponent\" [referrer]=\"buttonBarExtensionReferrer\"></imx-ext>\r\n          <button\r\n            *ngIf=\"!groupServiceItem && canCreateServiceItem\"\r\n            mat-stroked-button\r\n            color=\"primary\"\r\n            data-imx-identifier=\"group-sidesheet-button-create-service-item\"\r\n            (click)=\"createServiceItem()\"\r\n          >\r\n            <span translate>#LDS#Create service item</span>\r\n          </button>\r\n        </div>\r\n        <button\r\n          mat-flat-button\r\n          color=\"primary\"\r\n          data-imx-identifier=\"group-sidesheet-button-save-group\"\r\n          (click)=\"saveGroup()\"\r\n          [disabled]=\"!detailsFormGroup.dirty || detailsFormGroup.invalid\"\r\n        >\r\n          <span translate>#LDS#Save</span>\r\n        </button>\r\n      </div>\r\n    </div>\r\n  </mat-tab>\r\n\r\n  <mat-tab *ngIf=\"groupServiceItem\">\r\n    <ng-template mat-tab-label>\r\n      <div [matTooltip]=\"(serviceItemFormGroup.dirty ? '#LDS#You have unsaved changes' : '') | translate\">\r\n        <span translate>#LDS#Heading Service Item</span>\r\n        &nbsp;\r\n        <eui-icon *ngIf=\"serviceItemFormGroup.dirty\" icon=\"save\" class=\"imx-dirty-indicator\" size=\"s\" [attr.aria-label]=\"'#LDS#You have unsaved changes.' | translate\"></eui-icon>\r\n      </div>\r\n    </ng-template>\r\n    <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n      <div class=\"governance-sidesheet__tab-content-body\">\r\n        <imx-service-items-edit-form #serviceItemsEditForm *ngIf=\"groupServiceItem\" [serviceItem]=\"groupServiceItem\" (formControlCreated)=\"this.siFormArray.push($event)\">\r\n        </imx-service-items-edit-form>\r\n      </div>\r\n      <div eui-sidesheet-actions>\r\n        <button\r\n          mat-flat-button\r\n          color=\"primary\"\r\n          data-imx-identifier=\"group-sidesheet-button-save-groupserviceitem\"\r\n          (click)=\"saveGroupServiceItem()\"\r\n          [disabled]=\"!serviceItemFormGroup.dirty || serviceItemFormGroup.invalid\"\r\n        >\r\n          <span translate>#LDS#Save</span>\r\n        </button>\r\n      </div>\r\n    </div>\r\n  </mat-tab>\r\n\r\n  <mat-tab [label]=\"'#LDS#Heading Memberships' | translate\" *ngIf=\"unsGroupDbObjectKey\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n        <div class=\"governance-sidesheet__tab-content-body\">\r\n          <imx-group-members #groupMembers [unsGroupDbObjectKey]=\"unsGroupDbObjectKey\"></imx-group-members>\r\n        </div>\r\n        <div eui-sidesheet-actions *ngIf=\"groupMembers.membershipView === 'direct'\">\r\n          <button mat-button (click)=\"requestMembership()\" data-imx-identifier=\"group-sidesheet-button-membership-new\" *ngIf=\"isRequestable\">\r\n            <span translate>#LDS#Request memberships</span>\r\n          </button>\r\n\r\n          <button\r\n            mat-stroked-button\r\n            color=\"warn\"\r\n            (click)=\"onDeleteGroupMembers('delete')\"\r\n            [disabled]=\"groupMembers.selectedItemsCount === 0 || !canDeleteSelected()\"\r\n            data-imx-identifier=\"group-sidesheet-button-delete-groupmembers\"\r\n          >\r\n            <eui-icon icon=\"delete\"></eui-icon>\r\n            <span translate>#LDS#Remove</span>\r\n          </button>\r\n          <button\r\n            mat-flat-button\r\n            color=\"primary\"\r\n            (click)=\"onDeleteGroupMembers('unsubscribe')\"\r\n            [disabled]=\"groupMembers.selectedItemsCount === 0 || !canUnsubscribeSelected()\"\r\n            data-imx-identifier=\"group-sidesheet-button-delete-groupmembers\"\r\n          >\r\n            <span translate>#LDS#Unsubscribe</span>\r\n          </button>\r\n        </div>\r\n        <div eui-sidesheet-actions>\r\n          <button\r\n            mat-flat-button\r\n            color=\"primary\"\r\n            data-imx-identifier=\"group-sidesheet-button-save-groupserviceitem\"\r\n            (click)=\"saveGroupServiceItem()\"\r\n            [disabled]=\"!serviceItemFormGroup.dirty || serviceItemFormGroup.invalid\"\r\n          >\r\n            <span translate>#LDS#Save</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab [label]=\"'#LDS#Heading Child System Entitlements' | translate\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n        <div class=\"governance-sidesheet__tab-content-body\">\r\n          <imx-child-system-entitlements #childEntitlements [isAdmin]=\"isAdmin\" [groupId]=\"groupId\"> </imx-child-system-entitlements>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content class=\"imx-hyperview-sidesheet\">\r\n        <imx-object-hyperview [objectType]=\"sidesheetData?.group?.GetEntity()?.TypeName\" [objectUid]=\"sidesheetData?.group.GetEntity()?.GetKeys()[0]\"> </imx-object-hyperview>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab data-imx-identifier=\"groups-sidesheet-tab-history\" [label]=\"'#LDS#History' | translate\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n        <div class=\"governance-sidesheet__tab-content-body\">\r\n          <imx-object-history objectType=\"UNSGroup\" [showTitle]=\"false\" [objectUid]=\"groupId\"> </imx-object-history>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <ng-container *ngFor=\"let tab of dynamicTabs\">\r\n    <mat-tab [imxDataProvider]=\"this.parameters\" [label]=\"tab.inputData.label | translate\">\r\n      <ng-template matTabContent>\r\n        <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n          <div class=\"governance-sidesheet__tab-content-body imx-flex-child\">\r\n            <ng-container style.flex=\"1 1 auto\" *ngComponentOutlet=\"tab.instance\"></ng-container>\r\n          </div>\r\n        </div>\r\n      </ng-template>\r\n    </mat-tab>\r\n  </ng-container>\r\n</mat-tab-group>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.product-owner-datasource-container{margin:10px 0 25px}.product-owner-datasource-container span{display:block;font-size:12px;color:#919799;padding-bottom:2px}.product-owner-datasource-container mat-radio-button{margin-right:10px}.product-owner-datasource-container .hidden{display:none}.product-owner-datasource-container .help-icon{color:#0a96d1;font-size:16px;margin-left:5px}.product-owner-datasource-container .mat-radio-group{display:block;margin-bottom:10px}:host ::ng-deep .mat-badge-small.mat-badge-overlap.mat-badge-after .mat-badge-content{right:-16px;background:#e36a00}:host ::ng-deep .mat-tab-group{height:100%;flex-grow:1;overflow:auto}:host ::ng-deep .mat-tab-group .mat-tab-header{padding:0 32px;background-color:#fff}:host ::ng-deep .mat-tab-group ::ng-deep .mat-tab-body-wrapper{height:100%}:host ::ng-deep .mat-tab-group .imx-edit-fk-open-picker{display:none}@media screen and (max-width: 769px){.product-owner-datasource-container .help-icon{display:none}}.governance-sidesheet__tab-content{display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body{flex:1 1 auto;overflow:auto;padding:20px}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body>:first-child{overflow:auto}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body>.imx-ext{overflow:hidden}.governance-sidesheet__tab-content .imx-flex-child ng-container{flex:1 1 auto;display:flex}.governance-sidesheet__tab-content eui-icon{font-size:14px;margin-right:4px}.mat-tab-body-content{display:flex;flex-direction:column;overflow:hidden}.imx-dirty-indicator{color:#e36a00}.eui-sidesheet-content:not(.imx-hyperview-sidesheet){padding:0}.eui-sidesheet-content:not(.imx-hyperview-sidesheet) ::ng-deep .mat-tab-body-content{display:flex;flex-direction:column}.eui-sidesheet-actions .justify-start{margin-right:auto}.eui-sidesheet-actions button:not(:last-of-type):not(.justify-start){margin-right:10px}.imx-card{display:flex;justify-content:flex-end}.imx-card button{margin-left:10px}.imx-breakable{margin-top:-10px}.imx-breakable>*{margin-top:10px}.eui-dark-theme :host .product-owner-datasource-container span{color:#dfe4e6}.eui-dark-theme :host ::ng-deep .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-contrast-theme :host .product-owner-datasource-container span{color:#fff}.eui-contrast-theme :host ::ng-deep .mat-tab-group .mat-tab-header{background-color:#16191a}\n"] }]
        }], function () {
        return [{ type: i1$2.UntypedFormBuilder }, { type: GroupsService }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i2.ClassloggerService }, { type: i1$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i2.ElementalUiConfigService }, { type: i2.SystemInfoService }, { type: GroupsReportsService }, { type: i1.ProjectConfigurationService }, { type: i1$1.EuiSidesheetRef }, { type: i2.ExtService }, { type: i2.ConfirmationService }];
    }, { groupMembersComponent: [{
                type: ViewChild,
                args: ['groupMembers']
            }], serviceItemsEditForm: [{
                type: ViewChild,
                args: ['serviceItemsEditForm']
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ProductOwnerSidesheetService {
    constructor(entityService, api) {
        this.entityService = entityService;
        this.api = api;
    }
    buildOrgRulerColumn(ref) {
        const provider = ref.GetFkCandidateProvider().getProviderItem('UID_OrgRuler', 'AERole');
        return this.entityService.createLocalEntityColumn(this.api.typedClient.PortalTargetsystemUnsGroupServiceitem.GetSchema().Columns.UID_OrgRuler, [provider]);
    }
}
ProductOwnerSidesheetService.ɵfac = function ProductOwnerSidesheetService_Factory(t) { return new (t || ProductOwnerSidesheetService)(i0.ɵɵinject(i2.EntityService), i0.ɵɵinject(TsbApiService)); };
ProductOwnerSidesheetService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: ProductOwnerSidesheetService, factory: ProductOwnerSidesheetService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ProductOwnerSidesheetService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i2.EntityService }, { type: TsbApiService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const _c0$5 = ["ownerControl"];
class ProductOwnerSidesheetComponent {
    constructor(sidesheetRef, ownerService, sidesheetData) {
        this.sidesheetRef = sidesheetRef;
        this.column = ownerService.buildOrgRulerColumn(sidesheetData.GetEntity());
    }
    onFormControlCreated(control) {
        setTimeout(() => {
            this.prdOwnerControl = control;
        }, 1000);
    }
    returnProductOwner() {
        this.sidesheetRef.close({ uidPerson: this.ownercontrol.uidPersonSelected, uidRole: this.ownercontrol.uidRoleSelected });
    }
}
ProductOwnerSidesheetComponent.ɵfac = function ProductOwnerSidesheetComponent_Factory(t) { return new (t || ProductOwnerSidesheetComponent)(i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(ProductOwnerSidesheetService), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA)); };
ProductOwnerSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ProductOwnerSidesheetComponent, selectors: [["ng-component"]], viewQuery: function ProductOwnerSidesheetComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$5, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.ownercontrol = _t.first);
        }
    }, decls: 9, vars: 1, consts: [[1, "governance-sidesheet"], [1, "governance-sidesheet__tab-content"], [1, "governance-sidesheet__tab-content-body"], [3, "column", "formControlCreated"], ["ownerControl", ""], [1, "governance-sidesheet__action-buttons"], ["mat-raised-button", "", "color", "primary", 3, "click"], ["translate", ""]], template: function ProductOwnerSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "imx-owner-control", 3, 4);
            i0.ɵɵlistener("formControlCreated", function ProductOwnerSidesheetComponent_Template_imx_owner_control_formControlCreated_3_listener($event) { return ctx.onFormControlCreated($event); });
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(5, "mat-card", 5)(6, "button", 6);
            i0.ɵɵlistener("click", function ProductOwnerSidesheetComponent_Template_button_click_6_listener() { return ctx.returnProductOwner(); });
            i0.ɵɵelementStart(7, "span", 7);
            i0.ɵɵtext(8, "#LDS#Apply");
            i0.ɵɵelementEnd()()()()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("column", ctx.column);
        }
    }, dependencies: [i8.MatButton, i10$1.MatCard, i1.OwnerControlComponent, i7$1.TranslateDirective], styles: [".governance-sidesheet__tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:first-child{overflow:auto}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ProductOwnerSidesheetComponent, [{
            type: Component,
            args: [{ template: "<div class=\"governance-sidesheet\">\r\n  <div class=\"governance-sidesheet__tab-content\">\r\n    <div class=\"governance-sidesheet__tab-content-body\">\r\n      <imx-owner-control #ownerControl [column]=\"column\"\r\n                (formControlCreated)=\"onFormControlCreated($event)\"></imx-owner-control>\r\n\r\n    </div>\r\n    <mat-card class=\"governance-sidesheet__action-buttons\">\r\n      <button mat-raised-button color=\"primary\" (click)=\"returnProductOwner()\">\r\n        <span translate>#LDS#Apply</span>\r\n      </button>\r\n    </mat-card>\r\n  </div>\r\n</div>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.governance-sidesheet__tab-content{display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body>:first-child{overflow:auto}\n"] }]
        }], function () {
        return [{ type: i1$1.EuiSidesheetRef }, { type: ProductOwnerSidesheetService }, { type: i7$3.PortalTargetsystemUnsGroupServiceitem, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }];
    }, { ownercontrol: [{
                type: ViewChild,
                args: ['ownerControl']
            }] });
})();

class DeHelperService {
    constructor(loader, tsbClient) {
        this.loader = loader;
        this.tsbClient = tsbClient;
        this.authorityDataDeleted = new Subject();
    }
    getAuthorityData(search, skipLoader) {
        return __awaiter(this, void 0, void 0, function* () {
            const loadParams = { PageSize: 50, StartIndex: 0 };
            if (search) {
                loadParams.search = search;
            }
            const method = this.tsbClient.typedClient.PortalTargetsystemUnsSystem;
            let data;
            if (skipLoader) {
                data = yield method.Get(loadParams);
            }
            else {
                data = yield this.handlePromiseLoader(method.Get(loadParams));
            }
            return {
                hasAuthorities: data.totalCount > 0,
                authorities: data.Data,
            };
        });
    }
    getContainers(navigationState) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.tsbClient.typedClient.PortalTargetsystemUnsContainer.Get(navigationState);
        });
    }
    handlePromiseLoader(promise) {
        const loaderRef = this.loader.show();
        return promise.finally(() => this.loader.hide(loaderRef));
    }
}
DeHelperService.ɵfac = function DeHelperService_Factory(t) { return new (t || DeHelperService)(i0.ɵɵinject(i1$1.EuiLoadingService), i0.ɵɵinject(TsbApiService)); };
DeHelperService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: DeHelperService, factory: DeHelperService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DeHelperService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i1$1.EuiLoadingService }, { type: TsbApiService }]; }, null);
})();

const _c0$4 = ["dataTable"];
function DataExplorerGroupsComponent_mat_card_0_ng_container_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function DataExplorerGroupsComponent_mat_card_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 6)(1, "div", 7)(2, "div", 8)(3, "h3", 9);
        i0.ɵɵtext(4, "#LDS#Heading System Entitlements");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(5, "imx-help-contextual", 10);
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(6, DataExplorerGroupsComponent_mat_card_0_ng_container_6_Template, 1, 0, "ng-container", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        const _r4 = i0.ɵɵreference(5);
        i0.ɵɵadvance(5);
        i0.ɵɵproperty("contextId", ctx_r0.contextId);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngTemplateOutlet", _r4);
    }
}
function DataExplorerGroupsComponent_div_1_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function DataExplorerGroupsComponent_div_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 12);
        i0.ɵɵtemplate(1, DataExplorerGroupsComponent_div_1_ng_container_1_Template, 1, 0, "ng-container", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r6 = i0.ɵɵreference(7);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngTemplateOutlet", _r6);
    }
}
function DataExplorerGroupsComponent_mat_card_2_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function DataExplorerGroupsComponent_mat_card_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-card", 13);
        i0.ɵɵtemplate(1, DataExplorerGroupsComponent_mat_card_2_ng_container_1_Template, 1, 0, "ng-container", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r4 = i0.ɵɵreference(5);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngTemplateOutlet", _r4);
    }
}
function DataExplorerGroupsComponent_div_3_ng_container_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function DataExplorerGroupsComponent_div_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 14);
        i0.ɵɵtemplate(1, DataExplorerGroupsComponent_div_3_ng_container_1_Template, 1, 0, "ng-container", 11);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r6 = i0.ɵɵreference(7);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngTemplateOutlet", _r6);
    }
}
function DataExplorerGroupsComponent_ng_template_4_ng_template_8_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 26);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(2, "div", 27);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r17 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r17.GetEntity().GetDisplay());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r17.Description.Column.GetDisplayValue());
    }
}
function DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_10_ng_template_1_div_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div")(1, "eui-badge", 30);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const item_r19 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r19.XMarkedForDeletion.Column.GetDisplayValue());
    }
}
function DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_10_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_10_ng_template_1_div_0_Template, 3, 1, "div", 29);
    }
    if (rf & 2) {
        const item_r19 = ctx.$implicit;
        i0.ɵɵproperty("ngIf", item_r19.XMarkedForDeletion.value !== 0);
    }
}
function DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_10_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-data-table-generic-column", 28);
        i0.ɵɵtemplate(1, DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_10_ng_template_1_Template, 1, 1, "ng-template");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r15 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("columnName", ctx_r15.entitySchemaUnsGroup == null ? null : ctx_r15.entitySchemaUnsGroup.Columns.XMarkedForDeletion.ColumnName);
    }
}
function DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_11_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r25 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 32);
        i0.ɵɵlistener("click", function DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_11_ng_template_1_Template_button_click_0_listener($event) { const restoredCtx = i0.ɵɵrestoreView(_r25); const item_r23 = restoredCtx.$implicit; const ctx_r24 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r24.viewSource($event, item_r23)); });
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r23 = ctx.$implicit;
        const ctx_r22 = i0.ɵɵnextContext(3);
        i0.ɵɵproperty("disabled", !ctx_r22.uidPerson);
        i0.ɵɵattribute("data-imx-identifier", "groups-table-button-view-assignment-analysis" + item_r23.GetEntity().GetKeys().join("_"));
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 3, "#LDS#View assignment analysis"), " ");
    }
}
function DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "imx-data-table-generic-column", 31);
        i0.ɵɵtemplate(1, DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_11_ng_template_1_Template, 3, 5, "ng-template");
        i0.ɵɵelementEnd();
    }
}
const _c1$2 = function () { return ["search", "sort", "filter", "filterTree", "settings"]; };
const _c2$2 = function () { return ["namespace"]; };
function DataExplorerGroupsComponent_ng_template_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r27 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-data-source-toolbar", 15, 16);
        i0.ɵɵlistener("navigationStateChanged", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_source_toolbar_navigationStateChanged_0_listener($event) { i0.ɵɵrestoreView(_r27); const ctx_r26 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r26.onNavigationStateChanged($event)); })("search", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_source_toolbar_search_0_listener($event) { i0.ɵɵrestoreView(_r27); const ctx_r28 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r28.onSearch($event)); })("filterTreeSelectionChanged", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_source_toolbar_filterTreeSelectionChanged_0_listener($event) { i0.ɵɵrestoreView(_r27); const ctx_r29 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r29.filterByTree($event)); })("updateConfig", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_source_toolbar_updateConfig_0_listener($event) { i0.ɵɵrestoreView(_r27); const ctx_r30 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r30.updateConfig($event)); })("deleteConfigById", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_source_toolbar_deleteConfigById_0_listener($event) { i0.ɵɵrestoreView(_r27); const ctx_r31 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r31.deleteConfigById($event)); });
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(3, "div", 17)(4, "div", 18)(5, "imx-data-table", 19, 20);
        i0.ɵɵlistener("highlightedEntityChanged", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_table_highlightedEntityChanged_5_listener($event) { i0.ɵɵrestoreView(_r27); const ctx_r32 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r32.onGroupChanged($event)); })("selectionChanged", function DataExplorerGroupsComponent_ng_template_4_Template_imx_data_table_selectionChanged_5_listener($event) { i0.ɵɵrestoreView(_r27); const ctx_r33 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r33.onGroupSelected($event)); });
        i0.ɵɵelementStart(7, "imx-data-table-column", 21);
        i0.ɵɵtemplate(8, DataExplorerGroupsComponent_ng_template_4_ng_template_8_Template, 4, 2, "ng-template");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(9, "imx-data-table-column", 22);
        i0.ɵɵtemplate(10, DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_10_Template, 2, 1, "imx-data-table-generic-column", 23);
        i0.ɵɵtemplate(11, DataExplorerGroupsComponent_ng_template_4_imx_data_table_generic_column_11_Template, 2, 0, "imx-data-table-generic-column", 24);
        i0.ɵɵelementEnd();
        i0.ɵɵelement(12, "imx-data-source-paginator", 25);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const _r12 = i0.ɵɵreference(1);
        const ctx_r5 = i0.ɵɵnextContext();
        i0.ɵɵproperty("settings", ctx_r5.dstSettings)("options", i0.ɵɵpureFunction0(17, _c1$2))("hiddenFilters", i0.ɵɵpureFunction0(18, _c2$2))("busyService", ctx_r5.busyService)("searchBoxText", i0.ɵɵpipeBind1(2, 15, "#LDS#Search"))("itemStatus", ctx_r5.itemStatus);
        i0.ɵɵadvance(5);
        i0.ɵɵproperty("dst", _r12)("showSelectionInfo", false)("showSelectedItemsMenu", false)("selectable", ctx_r5.unsAccountIdFilter ? false : true);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx_r5.entitySchemaUnsGroup == null ? null : ctx_r5.entitySchemaUnsGroup.Columns[ctx_r5.DisplayColumns.DISPLAY_PROPERTYNAME]);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx_r5.entitySchemaUnsGroup == null ? null : ctx_r5.entitySchemaUnsGroup.Columns.Requestable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r5.entitySchemaUnsGroup == null ? null : ctx_r5.entitySchemaUnsGroup.Columns.XMarkedForDeletion);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r5.unsAccountIdFilter);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("dst", _r12);
    }
}
function DataExplorerGroupsComponent_ng_template_6_button_15_Template(rf, ctx) {
    if (rf & 1) {
        const _r37 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 41);
        i0.ɵɵlistener("click", function DataExplorerGroupsComponent_ng_template_6_button_15_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r37); const ctx_r36 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r36.bulkUpdateOwner()); });
        i0.ɵɵelementStart(1, "span", 9);
        i0.ɵɵtext(2, "#LDS#Assign product owner");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r35 = i0.ɵɵnextContext(2);
        i0.ɵɵproperty("disabled", ctx_r35.selectedGroupsForUpdate.length === 0);
    }
}
function DataExplorerGroupsComponent_ng_template_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r39 = i0.ɵɵgetCurrentView();
        i0.ɵɵelement(0, "imx-selected-elements", 33)(1, "div", 34);
        i0.ɵɵelementStart(2, "button", 35);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelement(4, "eui-icon", 36);
        i0.ɵɵtext(5);
        i0.ɵɵpipe(6, "translate");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(7, "mat-menu", 37, 38)(9, "button", 39);
        i0.ɵɵlistener("click", function DataExplorerGroupsComponent_ng_template_6_Template_button_click_9_listener() { i0.ɵɵrestoreView(_r39); const ctx_r38 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r38.bulkUpdateSelected(true)); });
        i0.ɵɵelementStart(10, "span", 9);
        i0.ɵɵtext(11, "#LDS#Make requestable");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(12, "button", 39);
        i0.ɵɵlistener("click", function DataExplorerGroupsComponent_ng_template_6_Template_button_click_12_listener() { i0.ɵɵrestoreView(_r39); const ctx_r40 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r40.bulkUpdateSelected(false)); });
        i0.ɵɵelementStart(13, "span", 9);
        i0.ɵɵtext(14, "#LDS#Make not requestable");
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(15, DataExplorerGroupsComponent_ng_template_6_button_15_Template, 3, 1, "button", 40);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const _r34 = i0.ɵɵreference(8);
        const ctx_r7 = i0.ɵɵnextContext();
        i0.ɵɵproperty("selectedElements", ctx_r7.selectedGroupsForUpdate)("isLoading", ctx_r7.busyService.isBusy);
        i0.ɵɵadvance(2);
        i0.ɵɵpropertyInterpolate("title", i0.ɵɵpipeBind1(3, 8, "#LDS#Actions"));
        i0.ɵɵproperty("matMenuTriggerFor", _r34);
        i0.ɵɵadvance(3);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 10, "#LDS#Actions"), " ");
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("disabled", ctx_r7.itemsAreRequestable);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("disabled", ctx_r7.itemsAreNotRequestable);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("ngIf", ctx_r7.isAdmin);
    }
}
class DataExplorerGroupsComponent {
    constructor(route, sideSheet, busyServiceElemental, logger, groupsService, viewConfigService, dataHelper, translate, snackbar, settingsService) {
        var _a, _b;
        this.route = route;
        this.sideSheet = sideSheet;
        this.busyServiceElemental = busyServiceElemental;
        this.logger = logger;
        this.groupsService = groupsService;
        this.viewConfigService = viewConfigService;
        this.dataHelper = dataHelper;
        this.translate = translate;
        this.snackbar = snackbar;
        this.sidesheetWidth = '65%';
        this.applyIssuesFilter = false;
        this.uidPerson = '';
        this.usedInSidesheet = false;
        this.filterOptions = [];
        this.requestableBulkUpdateCtrl = new UntypedFormControl(true);
        this.DisplayColumns = DisplayColumns;
        this.selectedGroupsForUpdate = [];
        this.busyService = new BusyService();
        this.itemStatus = {
            enabled: (item) => {
                var _a;
                return ((_a = item.UID_AccProduct) === null || _a === void 0 ? void 0 : _a.value) !== '';
            },
        };
        this.displayedColumns = [];
        this.isAdmin = ((_b = (_a = this.route.snapshot) === null || _a === void 0 ? void 0 : _a.url[0]) === null || _b === void 0 ? void 0 : _b.path) === 'admin';
        this.navigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaUnsGroup = this.groupsService.unsGroupsSchema(this.isAdmin);
        this.authorityDataDeleted$ = this.dataHelper.authorityDataDeleted.subscribe(() => this.navigate());
        this.treeDbWrapper = new ContainerTreeDatabaseWrapper(this.busyService, dataHelper);
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.entitySchemaUnsGroup = this.groupsService.unsGroupsSchema(this.isAdmin);
            this.displayedColumns = [
                this.entitySchemaUnsGroup.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
                this.entitySchemaUnsGroup.Columns.Requestable,
            ];
            if (this.entitySchemaUnsGroup.Columns.XMarkedForDeletion) {
                this.displayedColumns.push(this.entitySchemaUnsGroup.Columns.XMarkedForDeletion);
            }
            if (this.unsAccountIdFilter) {
                this.displayedColumns.push({ ColumnName: 'action', Type: ValType.String });
            }
            const isBusy = this.busyService.beginBusy();
            try {
                this.dataModel = yield this.groupsService.getDataModel(this.isAdmin);
                this.filterOptions = this.dataModel.Filters;
                this.viewConfigPath = this.isAdmin || this.unsAccountIdFilter ? 'targetsystem/uns/group' : 'resp/unsgroup';
                this.viewConfig = yield this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
            }
            finally {
                isBusy.endBusy();
            }
            if (this.applyIssuesFilter && !this.issuesFilterMode) {
                const ownerFilter = this.filterOptions.find((f) => {
                    return f.Name === 'withowner';
                });
                if (ownerFilter) {
                    ownerFilter.InitialValue = '0';
                }
            }
            if (this.applyIssuesFilter && this.issuesFilterMode === 'requestable') {
                const requestableFliter = this.filterOptions.find((f) => {
                    return f.Name === 'published';
                });
                if (requestableFliter) {
                    requestableFliter.InitialValue = '0';
                }
            }
            yield this.navigate(true);
        });
    }
    ngOnDestroy() {
        if (this.authorityDataDeleted$) {
            this.authorityDataDeleted$.unsubscribe();
        }
    }
    updateConfig(config) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.putViewConfig(config);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    deleteConfigById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.deleteViewConfig(id);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    get itemsAreNotRequestable() {
        return this.selectedGroupsForUpdate.every((elem) => !elem.Requestable.value);
    }
    get itemsAreRequestable() {
        return this.selectedGroupsForUpdate.every((elem) => elem.Requestable.value);
    }
    /**
     * Occurs when the navigation state has changed - e.g. users clicks on the next page button.
     *
     */
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.navigate();
        });
    }
    onGroupChanged(group) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.unsAccountIdFilter) {
                return;
            }
            this.logger.debug(this, `Selected group changed`);
            this.logger.trace(this, `New group selected`, group);
            let data;
            let busy;
            const isBusy = this.busyService.beginBusy();
            try {
                const objKey = DbObjectKey.FromXml(group.XObjectKey.value);
                const uidAccProduct = group.UID_AccProduct.value;
                data = {
                    uidAccProduct,
                    unsGroupDbObjectKey: objKey,
                    group: yield this.groupsService.getGroupDetailsInteractive(objKey, 'UID_AccProduct'),
                    groupServiceItem: yield this.groupsService.getGroupServiceItem(uidAccProduct),
                    isAdmin: this.isAdmin,
                };
            }
            finally {
                isBusy.endBusy();
            }
            this.viewGroup(data);
        });
    }
    /**
     * Occurs when user triggers search.
     *
     * @param keywords Search keywords.
     */
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Searching for: ${keywords}`);
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.navigate();
        });
    }
    filterByTree(filters) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState.filter = filters;
            this.navigationState.StartIndex = 0;
            return this.navigate();
        });
    }
    onGroupSelected(selected) {
        this.selectedGroupsForUpdate = selected;
    }
    viewSource(event, item) {
        return __awaiter(this, void 0, void 0, function* () {
            event.stopPropagation();
            const uidPerson = this.uidPerson;
            const objKey = DbObjectKey.FromXml(item.XObjectKey.value);
            const data = {
                UID_Person: uidPerson,
                Type: SourceDetectiveType.MembershipOfSystemEntitlement,
                UID: objKey.Keys[0],
                TableName: objKey.TableName,
            };
            this.sideSheet.open(SourceDetectiveSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Assignment Analysis').toPromise(),
                subTitle: item.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(600px, 60%)',
                disableClose: false,
                testId: 'system-entitlement-role-membership-details',
                data,
            });
        });
    }
    bulkUpdateSelected(request) {
        return __awaiter(this, void 0, void 0, function* () {
            const updateData = {
                Keys: [],
                Data: [
                    {
                        Name: PortalTargetsystemUnsGroupServiceitem.GetEntitySchema().Columns.IsInActive.ColumnName,
                        // Inverse value as actual property is 'Not available'
                        Value: !request,
                    },
                ],
            };
            return this.updateSelectedGroups(updateData);
        });
    }
    bulkUpdateOwner() {
        return __awaiter(this, void 0, void 0, function* () {
            const selectedOwner = yield this.sideSheet
                .open(ProductOwnerSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading Assign Product Owner').toPromise(),
                subTitle: this.selectedGroupsForUpdate.length === 1 ? this.selectedGroupsForUpdate[0].GetEntity().GetDisplay() : '',
                padding: '0px',
                width: `max(650px, ${this.sidesheetWidth})`,
                icon: 'usergroup',
                testId: 'system-entitlements-assign-product-owner',
                data: yield this.groupsService.getGroupServiceItem(this.selectedGroupsForUpdate[0].UID_AccProduct.value),
            })
                .afterClosed()
                .toPromise();
            if (selectedOwner) {
                return this.updateOwnerForSelectedGroups(selectedOwner);
            }
        });
    }
    updateOwnerForSelectedGroups(selectedOwner) {
        return __awaiter(this, void 0, void 0, function* () {
            let confirmMessage = '';
            let busy;
            try {
                setTimeout(() => (busy = this.busyServiceElemental.show()));
                confirmMessage = yield this.groupsService.updateMultipleOwner(this.selectedGroupsForUpdate.map((elem) => elem.UID_AccProduct.value), selectedOwner);
            }
            finally {
                setTimeout(() => this.busyServiceElemental.hide(busy));
            }
            if (confirmMessage) {
                this.snackbar.open({ key: confirmMessage });
            }
            return this.navigate();
        });
    }
    updateSelectedGroups(updateData) {
        return __awaiter(this, void 0, void 0, function* () {
            this.selectedGroupsForUpdate.forEach((group) => {
                const serviceItemUid = group === null || group === void 0 ? void 0 : group.UID_AccProduct.value;
                if (serviceItemUid === null || serviceItemUid === void 0 ? void 0 : serviceItemUid.length) {
                    updateData.Keys.push([serviceItemUid]);
                }
            });
            let busy;
            try {
                setTimeout(() => (busy = this.busyServiceElemental.show()));
                yield this.groupsService.bulkUpdateGroupServiceItems(updateData);
                yield this.navigate();
                this.dataTable.clearSelection();
                this.requestableBulkUpdateCtrl.setValue(true, { emitEvent: false });
            }
            finally {
                setTimeout(() => this.busyServiceElemental.hide(busy));
            }
        });
    }
    navigate(isInitialLoad = false) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            const getParams = this.navigationState;
            try {
                if (this.unsAccountIdFilter) {
                    getParams.uid_unsaccount = this.unsAccountIdFilter;
                }
                const data = isInitialLoad
                    ? { totalCount: 0, Data: [] }
                    : this.isAdmin || this.unsAccountIdFilter // Wenn wir filtern, muss auch der Admin-Endpoint genutzt werden
                        ? yield this.groupsService.getGroups(getParams)
                        : yield this.groupsService.getGroupsResp(getParams);
                if (data) {
                    const exportMethod = this.isAdmin || this.unsAccountIdFilter
                        ? this.groupsService.exportGroups(getParams)
                        : this.groupsService.exportGroupsResp(getParams);
                    exportMethod.initialColumns = this.displayedColumns.map((col) => col.ColumnName);
                    this.dstSettings = {
                        displayedColumns: this.displayedColumns,
                        dataSource: data,
                        entitySchema: this.entitySchemaUnsGroup,
                        navigationState: this.navigationState,
                        filters: this.filterOptions,
                        filterTree: isInitialLoad
                            ? undefined
                            : {
                                filterMethode: (parentkey) => __awaiter(this, void 0, void 0, function* () {
                                    return this.groupsService.getFilterTree({
                                        parentkey,
                                        container: getParams.container,
                                        system: getParams.system,
                                        uid_unsaccount: getParams.uid_unsaccount,
                                    });
                                }),
                                multiSelect: false,
                            },
                        dataModel: this.dataModel,
                        viewConfig: this.viewConfig,
                        exportMethod,
                    };
                    this.logger.debug(this, `Head at ${((_a = data === null || data === void 0 ? void 0 : data.Data) === null || _a === void 0 ? void 0 : _a.length) + this.navigationState.StartIndex} of ${data === null || data === void 0 ? void 0 : data.totalCount} item(s)`);
                }
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    viewGroup(data) {
        return __awaiter(this, void 0, void 0, function* () {
            const sidesheetRef = this.sideSheet.open(GroupSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading Edit System Entitlement').toPromise(),
                subTitle: data.group.GetEntity().GetDisplay(),
                padding: '0px',
                width: `max(650px, ${this.sidesheetWidth})`,
                icon: 'usergroup',
                data,
                testId: 'edit-system-entitlement-sidesheet',
                disableClose: true,
            });
            // After the sidesheet closes, reload the current data to refresh any changes that might have been made
            sidesheetRef.afterClosed().subscribe(() => this.navigate());
        });
    }
}
DataExplorerGroupsComponent.ɵfac = function DataExplorerGroupsComponent_Factory(t) { return new (t || DataExplorerGroupsComponent)(i0.ɵɵdirectiveInject(i1$3.ActivatedRoute), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(GroupsService), i0.ɵɵdirectiveInject(i1.ViewConfigService), i0.ɵɵdirectiveInject(DeHelperService), i0.ɵɵdirectiveInject(i7$1.TranslateService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i2.SettingsService)); };
DataExplorerGroupsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataExplorerGroupsComponent, selectors: [["imx-data-explorer-groups"]], viewQuery: function DataExplorerGroupsComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$4, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataTable = _t.first);
        }
    }, inputs: { unsAccountIdFilter: "unsAccountIdFilter", sidesheetWidth: "sidesheetWidth", applyIssuesFilter: "applyIssuesFilter", issuesFilterMode: "issuesFilterMode", targetSystemData: "targetSystemData", isAdmin: "isAdmin", uidPerson: "uidPerson", usedInSidesheet: "usedInSidesheet", contextId: "contextId" }, decls: 8, vars: 4, consts: [["class", "data-explorer data-explorer--groups", 4, "ngIf"], ["class", "data-explorer-bottom-button-row", 4, "ngIf"], ["class", "imx-tab-card", 4, "ngIf"], ["eui-sidesheet-actions", "", 4, "ngIf"], ["table", ""], ["actions", ""], [1, "data-explorer", "data-explorer--groups"], [1, "data-explorer-card-header"], [1, "data-explorer-card-header-bg"], ["translate", ""], [3, "contextId"], [4, "ngTemplateOutlet"], [1, "data-explorer-bottom-button-row"], [1, "imx-tab-card"], ["eui-sidesheet-actions", ""], [3, "settings", "options", "hiddenFilters", "busyService", "searchBoxText", "itemStatus", "navigationStateChanged", "search", "filterTreeSelectionChanged", "updateConfig", "deleteConfigById"], ["dst", ""], [1, "imx-data-explorer-content"], [1, "data-explorer-table"], ["detailViewVisible", "false", "mode", "manual", "data-imx-identifier", "groups-tabledata-table", 3, "dst", "showSelectionInfo", "showSelectedItemsMenu", "selectable", "highlightedEntityChanged", "selectionChanged"], ["dataTable", ""], [3, "entityColumn"], ["align", "center", 3, "entityColumn"], ["alignHeader", "center", "alignContent", "center", 3, "columnName", 4, "ngIf"], ["alignHeader", "center", "alignContent", "center", "columnName", "action", 4, "ngIf"], [3, "dst"], ["data-imx-identifier", "groups-tabledata-display"], ["subtitle", "", "data-imx-identifier", "groups-tabledata-description"], ["alignHeader", "center", "alignContent", "center", 3, "columnName"], [4, "ngIf"], ["color", "gray"], ["alignHeader", "center", "alignContent", "center", "columnName", "action"], ["mat-button", "", "color", "primary", 3, "disabled", "click"], [3, "selectedElements", "isLoading"], [1, "imx-spacer"], ["mat-stroked-button", "", "data-imx-identifier", "groups-button-actions", 3, "title", "matMenuTriggerFor"], ["icon", "ellipsisvertical"], ["yPosition", "above", "xPosition", "before", "data-imx-identifier", "attestations-actions-menu"], ["actionsMenu", "matMenu"], ["mat-menu-item", "", "color", "primary", 3, "disabled", "click"], ["mat-menu-item", "", "class", "imx-right-button", 3, "disabled", "click", 4, "ngIf"], ["mat-menu-item", "", 1, "imx-right-button", 3, "disabled", "click"]], template: function DataExplorerGroupsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵtemplate(0, DataExplorerGroupsComponent_mat_card_0_Template, 7, 2, "mat-card", 0);
            i0.ɵɵtemplate(1, DataExplorerGroupsComponent_div_1_Template, 2, 1, "div", 1);
            i0.ɵɵtemplate(2, DataExplorerGroupsComponent_mat_card_2_Template, 2, 1, "mat-card", 2);
            i0.ɵɵtemplate(3, DataExplorerGroupsComponent_div_3_Template, 2, 1, "div", 3);
            i0.ɵɵtemplate(4, DataExplorerGroupsComponent_ng_template_4_Template, 13, 19, "ng-template", null, 4, i0.ɵɵtemplateRefExtractor);
            i0.ɵɵtemplate(6, DataExplorerGroupsComponent_ng_template_6_Template, 16, 12, "ng-template", null, 5, i0.ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngIf", !ctx.usedInSidesheet);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !ctx.usedInSidesheet);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.usedInSidesheet);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.usedInSidesheet && (ctx.unsAccountIdFilter ? false : true));
        }
    }, dependencies: [i7.NgIf, i7.NgTemplateOutlet, i1$1.EuiBadgeComponent, i1$1.EuiIconComponent, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i10$1.MatCard, i11.MatMenu, i11.MatMenuItem, i11.MatMenuTrigger, i7$1.TranslateDirective, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i2.SelectedElementsComponent, i2.HelpContextualComponent, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:hidden}.data-explorer--groups[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:nth-child(2){flex:0 0 auto}.imx-data-explorer-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.data-explorer-table[_ngcontent-%COMP%]{display:flex;flex-direction:column}.data-explorer-table[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:first-child{flex:1 1 auto}.imx-tab-card[_ngcontent-%COMP%]{margin:20px;flex:1 1 auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   .imx-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.data-explorer-bottom-button-row[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:flex-end;margin-top:15px}.data-explorer-bottom-button-row[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.data-explorer-bottom-button-row[_ngcontent-%COMP%]   .imx-spacer[_ngcontent-%COMP%]{flex:1 1 auto}.hidden[_ngcontent-%COMP%]{display:none}imx-selected-elements[_ngcontent-%COMP%]{margin-left:10px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataExplorerGroupsComponent, [{
            type: Component,
            args: [{ selector: 'imx-data-explorer-groups', template: "<mat-card *ngIf=\"!usedInSidesheet\" class=\"data-explorer data-explorer--groups\">\r\n  <div class=\"data-explorer-card-header\">\r\n    <div class=\"data-explorer-card-header-bg\">\r\n      <h3 translate>#LDS#Heading System Entitlements</h3>\r\n      <imx-help-contextual [contextId]=\"contextId\"></imx-help-contextual>\r\n    </div>\r\n  </div>\r\n  <ng-container *ngTemplateOutlet=\"table\"> </ng-container>\r\n</mat-card>\r\n<div *ngIf=\"!usedInSidesheet\" class=\"data-explorer-bottom-button-row\">\r\n  <ng-container *ngTemplateOutlet=\"actions\"> </ng-container>\r\n</div>\r\n\r\n<mat-card *ngIf=\"usedInSidesheet\" class=\"imx-tab-card\">\r\n  <ng-container *ngTemplateOutlet=\"table\"> </ng-container>\r\n</mat-card>\r\n<div *ngIf=\"usedInSidesheet && (unsAccountIdFilter ? false : true)\" eui-sidesheet-actions>\r\n  <ng-container *ngTemplateOutlet=\"actions\"> </ng-container>\r\n</div>\r\n\r\n<ng-template #table>\r\n  <imx-data-source-toolbar\r\n    #dst\r\n    [settings]=\"dstSettings\"\r\n    [options]=\"['search', 'sort', 'filter', 'filterTree', 'settings']\"\r\n    [hiddenFilters]=\"['namespace']\"\r\n    [busyService]=\"busyService\"\r\n    [searchBoxText]=\"'#LDS#Search' | translate\"\r\n    [itemStatus]=\"itemStatus\"\r\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n    (search)=\"onSearch($event)\"\r\n    (filterTreeSelectionChanged)=\"filterByTree($event)\"\r\n    (updateConfig)=\"updateConfig($event)\"\r\n    (deleteConfigById)=\"deleteConfigById($event)\"\r\n  >\r\n  </imx-data-source-toolbar>\r\n\r\n  <div class=\"imx-data-explorer-content\">\r\n    <div class=\"data-explorer-table\">\r\n      <imx-data-table\r\n        #dataTable\r\n        [dst]=\"dst\"\r\n        [showSelectionInfo]=\"false\"\r\n        [showSelectedItemsMenu]=\"false\"\r\n        (highlightedEntityChanged)=\"onGroupChanged($event)\"\r\n        detailViewVisible=\"false\"\r\n        [selectable]=\"unsAccountIdFilter ? false : true\"\r\n        (selectionChanged)=\"onGroupSelected($event)\"\r\n        mode=\"manual\"\r\n        data-imx-identifier=\"groups-tabledata-table\"\r\n      >\r\n        <imx-data-table-column [entityColumn]=\"entitySchemaUnsGroup?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n          <ng-template let-item>\r\n            <div data-imx-identifier=\"groups-tabledata-display\">{{ item.GetEntity().GetDisplay() }}</div>\r\n            <div subtitle data-imx-identifier=\"groups-tabledata-description\">{{ item.Description.Column.GetDisplayValue() }}</div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n        <imx-data-table-column align=\"center\" [entityColumn]=\"entitySchemaUnsGroup?.Columns.Requestable\"> </imx-data-table-column>\r\n        <imx-data-table-generic-column\r\n          *ngIf=\"entitySchemaUnsGroup?.Columns.XMarkedForDeletion\"\r\n          alignHeader=\"center\"\r\n          alignContent=\"center\"\r\n          [columnName]=\"entitySchemaUnsGroup?.Columns.XMarkedForDeletion.ColumnName\"\r\n        >\r\n          <ng-template let-item>\r\n            <div *ngIf=\"item.XMarkedForDeletion.value !== 0\">\r\n              <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n        <imx-data-table-generic-column *ngIf=\"unsAccountIdFilter\" alignHeader=\"center\" alignContent=\"center\" columnName=\"action\">\r\n          <ng-template let-item>\r\n            <button\r\n              mat-button\r\n              color=\"primary\"\r\n              [attr.data-imx-identifier]=\"'groups-table-button-view-assignment-analysis' + item.GetEntity().GetKeys().join('_')\"\r\n              [disabled]=\"!uidPerson\"\r\n              (click)=\"viewSource($event, item)\"\r\n            >\r\n              {{ '#LDS#View assignment analysis' | translate }}\r\n            </button>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n      </imx-data-table>\r\n      <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n    </div>\r\n  </div>\r\n</ng-template>\r\n\r\n<ng-template #actions>\r\n  <imx-selected-elements [selectedElements]=\"selectedGroupsForUpdate\" [isLoading]=\"busyService.isBusy\"></imx-selected-elements>\r\n  <div class=\"imx-spacer\"></div>\r\n  <button mat-stroked-button data-imx-identifier=\"groups-button-actions\" title=\"{{ '#LDS#Actions' | translate }}\" [matMenuTriggerFor]=\"actionsMenu\">\r\n    <eui-icon icon=\"ellipsisvertical\"></eui-icon>\r\n    {{ '#LDS#Actions' | translate }}\r\n  </button>\r\n  <mat-menu yPosition=\"above\" xPosition=\"before\" data-imx-identifier=\"attestations-actions-menu\" #actionsMenu=\"matMenu\">\r\n    <button mat-menu-item color=\"primary\" [disabled]=\"itemsAreRequestable\" (click)=\"bulkUpdateSelected(true)\">\r\n      <span translate>#LDS#Make requestable</span>\r\n    </button>\r\n    <button mat-menu-item color=\"primary\" [disabled]=\"itemsAreNotRequestable\" (click)=\"bulkUpdateSelected(false)\">\r\n      <span translate>#LDS#Make not requestable</span>\r\n    </button>\r\n    <button *ngIf=\"isAdmin\" [disabled]=\"selectedGroupsForUpdate.length === 0\" mat-menu-item (click)=\"bulkUpdateOwner()\" class=\"imx-right-button\">\r\n      <span translate>#LDS#Assign product owner</span>\r\n    </button>\r\n  </mat-menu>\r\n</ng-template>\r\n", styles: [":host{overflow:hidden}.data-explorer--groups>:nth-child(2){flex:0 0 auto}.imx-data-explorer-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.data-explorer-table{display:flex;flex-direction:column}.data-explorer-table>:first-child{flex:1 1 auto}.imx-tab-card{margin:20px;flex:1 1 auto}.eui-sidesheet-actions .imx-spacer{flex:1 1 auto}.data-explorer-bottom-button-row{display:flex;flex-direction:row;align-items:flex-end;margin-top:15px}.data-explorer-bottom-button-row .mat-stroked-button eui-icon{font-size:14px;margin-right:4px}.data-explorer-bottom-button-row .imx-spacer{flex:1 1 auto}.hidden{display:none}imx-selected-elements{margin-left:10px}\n"] }]
        }], function () { return [{ type: i1$3.ActivatedRoute }, { type: i1$1.EuiSidesheetService }, { type: i1$1.EuiLoadingService }, { type: i2.ClassloggerService }, { type: GroupsService }, { type: i1.ViewConfigService }, { type: DeHelperService }, { type: i7$1.TranslateService }, { type: i2.SnackBarService }, { type: i2.SettingsService }]; }, { unsAccountIdFilter: [{
                type: Input
            }], sidesheetWidth: [{
                type: Input
            }], applyIssuesFilter: [{
                type: Input
            }], issuesFilterMode: [{
                type: Input
            }], targetSystemData: [{
                type: Input
            }], isAdmin: [{
                type: Input
            }], uidPerson: [{
                type: Input
            }], usedInSidesheet: [{
                type: Input
            }], contextId: [{
                type: Input
            }], dataTable: [{
                type: ViewChild,
                args: ['dataTable', { static: false }]
            }] });
})();

function AccountSidesheetComponent_ng_template_3_imx_cdr_editor_4_Template(rf, ctx) {
    if (rf & 1) {
        const _r8 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-cdr-editor", 14);
        i0.ɵɵlistener("controlCreated", function AccountSidesheetComponent_ng_template_3_imx_cdr_editor_4_Template_imx_cdr_editor_controlCreated_0_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r7 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r7.formArray.push($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const cdr_r6 = ctx.$implicit;
        i0.ɵɵproperty("cdr", cdr_r6);
    }
}
function AccountSidesheetComponent_ng_template_3_div_5_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 17)(1, "span", 11);
        i0.ɵɵtext(2, "#LDS#The manager assigned to this user account differs from the manager assigned to the listed identity.");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵproperty("colored", true);
    }
}
function AccountSidesheetComponent_ng_template_3_div_5_eui_alert_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 17)(1, "span", 11);
        i0.ɵɵtext(2, "#LDS#There is no manager assigned to this user account.");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵproperty("colored", true);
    }
}
function AccountSidesheetComponent_ng_template_3_div_5_Template(rf, ctx) {
    if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtemplate(1, AccountSidesheetComponent_ng_template_3_div_5_eui_alert_1_Template, 3, 1, "eui-alert", 15);
        i0.ɵɵtemplate(2, AccountSidesheetComponent_ng_template_3_div_5_eui_alert_2_Template, 3, 1, "eui-alert", 15);
        i0.ɵɵelementStart(3, "mat-slide-toggle", 16);
        i0.ɵɵlistener("change", function AccountSidesheetComponent_ng_template_3_div_5_Template_mat_slide_toggle_change_3_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r11 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r11.syncToIdentityManager($event)); });
        i0.ɵɵelementStart(4, "span", 11);
        i0.ɵɵtext(5, "#LDS#Synchronize the user account's manager with the listed identity");
        i0.ɵɵelementEnd()()();
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext(2);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r5.initialAccountManagerValue && (!ctx_r5.identityManagerMatchesAccountManager || ctx_r5.unsavedSyncChanges));
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r5.initialAccountManagerValue);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("checked", ctx_r5.identityManagerMatchesAccountManager);
    }
}
function AccountSidesheetComponent_ng_template_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r14 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 3)(1, "div", 4)(2, "mat-card", 5)(3, "form", 6);
        i0.ɵɵtemplate(4, AccountSidesheetComponent_ng_template_3_imx_cdr_editor_4_Template, 1, 1, "imx-cdr-editor", 7);
        i0.ɵɵtemplate(5, AccountSidesheetComponent_ng_template_3_div_5_Template, 6, 3, "div", 8);
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(6, "div", 9)(7, "button", 10)(8, "span", 11);
        i0.ɵɵtext(9, "#LDS#Download report");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(10, "button", 12);
        i0.ɵɵlistener("click", function AccountSidesheetComponent_ng_template_3_Template_button_click_10_listener() { i0.ɵɵrestoreView(_r14); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.cancel()); });
        i0.ɵɵelementStart(11, "span", 11);
        i0.ɵɵtext(12, "#LDS#Cancel");
        i0.ɵɵelementEnd()();
        i0.ɵɵelementStart(13, "button", 13);
        i0.ɵɵlistener("click", function AccountSidesheetComponent_ng_template_3_Template_button_click_13_listener() { i0.ɵɵrestoreView(_r14); const ctx_r15 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r15.save()); });
        i0.ɵɵelementStart(14, "span", 11);
        i0.ɵɵtext(15, "#LDS#Save");
        i0.ɵɵelementEnd()()()();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("formGroup", ctx_r0.detailsFormGroup);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx_r0.cdrList);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", ctx_r0.accountManagerIsEditable && ctx_r0.linkedIdentitiesManager && (!ctx_r0.identityManagerMatchesAccountManager || ctx_r0.unsavedSyncChanges));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("euiDownload", ctx_r0.reportDownload);
        i0.ɵɵadvance(6);
        i0.ɵɵproperty("disabled", ctx_r0.detailsFormGroup.pristine || ctx_r0.detailsFormGroup.invalid);
    }
}
function AccountSidesheetComponent_ng_template_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 3)(1, "div", 4);
        i0.ɵɵelement(2, "imx-data-explorer-groups", 18);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("usedInSidesheet", true)("unsAccountIdFilter", ctx_r1.sidesheetData.unsAccountId)("uidPerson", ctx_r1.sidesheetData.uidPerson);
    }
}
function AccountSidesheetComponent_ng_template_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 19);
        i0.ɵɵelement(1, "imx-object-hyperview", 20);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r2 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("objectUid", ctx_r2.sidesheetData.unsAccountId);
    }
}
function AccountSidesheetComponent_ng_container_10_ng_template_3_ng_container_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainer(0);
    }
}
function AccountSidesheetComponent_ng_container_10_ng_template_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 3)(1, "div", 4);
        i0.ɵɵtemplate(2, AccountSidesheetComponent_ng_container_10_ng_template_3_ng_container_2_Template, 1, 0, "ng-container", 22);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const tab_r16 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngComponentOutlet", tab_r16.instance);
    }
}
function AccountSidesheetComponent_ng_container_10_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementContainerStart(0);
        i0.ɵɵelementStart(1, "mat-tab", 21);
        i0.ɵɵpipe(2, "translate");
        i0.ɵɵtemplate(3, AccountSidesheetComponent_ng_container_10_ng_template_3_Template, 3, 1, "ng-template", 1);
        i0.ɵɵelementEnd();
        i0.ɵɵelementContainerEnd();
    }
    if (rf & 2) {
        const tab_r16 = ctx.$implicit;
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("imxDataProvider", ctx_r3.parameters)("label", i0.ɵɵpipeBind1(2, 2, tab_r16.inputData.label));
    }
}
class AccountSidesheetComponent {
    constructor(formBuilder, sidesheetData, logger, busyService, snackbar, sidesheetRef, elementalUiConfigService, configService, identitiesService, accountsService, reports, tabService, cdrFactory) {
        var _a, _b;
        this.sidesheetData = sidesheetData;
        this.logger = logger;
        this.busyService = busyService;
        this.snackbar = snackbar;
        this.sidesheetRef = sidesheetRef;
        this.elementalUiConfigService = elementalUiConfigService;
        this.configService = configService;
        this.identitiesService = identitiesService;
        this.accountsService = accountsService;
        this.reports = reports;
        this.tabService = tabService;
        this.cdrFactory = cdrFactory;
        this.cdrList = [];
        this.unsavedSyncChanges = false;
        this.neverConnectFormControl = new UntypedFormControl();
        this.dynamicTabs = [];
        this.detailsFormGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
        this.parameters = {
            objecttable: (_a = sidesheetData.unsDbObjectKey) === null || _a === void 0 ? void 0 : _a.TableName,
            objectuid: (_b = sidesheetData.unsDbObjectKey) === null || _b === void 0 ? void 0 : _b.Keys.join(','),
        };
        this.reportDownload = Object.assign(Object.assign({}, this.elementalUiConfigService.Config.downloadOptions), { url: this.reports.accountsReport(30, this.selectedAccount.GetEntity().GetKeys()[0], this.sidesheetData.tableName) });
    }
    ngOnInit() {
        this.setup();
    }
    cancel() {
        this.sidesheetRef.close();
    }
    save() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.detailsFormGroup.valid) {
                this.logger.debug(this, `Saving identity change`);
                const overlayRef = this.busyService.show();
                try {
                    yield this.selectedAccount.GetEntity().Commit(true);
                    this.detailsFormGroup.markAsPristine();
                    this.snackbar.open({ key: '#LDS#The user account has been successfully saved.' });
                    this.sidesheetRef.close(true);
                }
                finally {
                    this.unsavedSyncChanges = false;
                    this.busyService.hide(overlayRef);
                }
            }
        });
    }
    get selectedAccount() {
        return this.sidesheetData.selectedAccount;
    }
    get formArray() {
        return this.detailsFormGroup.get('formArray');
    }
    get identityManagerMatchesAccountManager() {
        var _a, _b;
        let isMatch = false;
        const objectKeyManager = (_b = (_a = this.selectedAccount) === null || _a === void 0 ? void 0 : _a.objectKeyManagerColumn) === null || _b === void 0 ? void 0 : _b.GetValue();
        if (this.linkedIdentitiesManager && (objectKeyManager === null || objectKeyManager === void 0 ? void 0 : objectKeyManager.length)) {
            isMatch = objectKeyManager === this.linkedIdentitiesManager.ToXmlString();
        }
        return isMatch;
    }
    get accountManagerIsEditable() {
        var _a;
        return (_a = this.selectedAccount.objectKeyManagerColumn) === null || _a === void 0 ? void 0 : _a.GetMetadata().CanEdit();
    }
    syncToIdentityManager(event) {
        return __awaiter(this, void 0, void 0, function* () {
            const objectKeyManagerColumn = this.selectedAccount.objectKeyManagerColumn;
            if (objectKeyManagerColumn != null && event.checked) {
                yield objectKeyManagerColumn.PutValue(this.linkedIdentitiesManager.ToXmlString());
                this.detailsFormGroup.markAsDirty();
                this.unsavedSyncChanges = true;
            }
        });
    }
    setup() {
        return __awaiter(this, void 0, void 0, function* () {
            const cols = (yield this.configService.getConfig()).OwnershipConfig.EditableFields[this.parameters.objecttable];
            this.cdrList = this.cdrFactory.buildCdrFromColumnList(this.selectedAccount.GetEntity(), cols);
            this.dynamicTabs = (yield this.tabService.getFittingComponents('accountSidesheet', (ext) => ext.inputData.checkVisibility(this.parameters))).sort((tab1, tab2) => tab1.sortOrder - tab2.sortOrder);
            this.setupIdentityManagerSync();
        });
    }
    setupIdentityManagerSync() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            this.initialAccountManagerValue = (_a = this.selectedAccount.objectKeyManagerColumn) === null || _a === void 0 ? void 0 : _a.GetValue();
            const linkedIdentityId = (_b = this.selectedAccount.uidPersonColumn) === null || _b === void 0 ? void 0 : _b.GetValue();
            if (linkedIdentityId) {
                this.linkedIdentitiesManager = yield this.getLinkedIdentitiesManager(linkedIdentityId, this.sidesheetData.unsDbObjectKey.TableName);
            }
        });
    }
    getLinkedIdentitiesManager(linkedIdentityId, tableName) {
        return __awaiter(this, void 0, void 0, function* () {
            const identityData = yield this.identitiesService.getPerson(linkedIdentityId);
            if (identityData === null || identityData === void 0 ? void 0 : identityData.UID_PersonHead.value) {
                const managerAccountData = yield this.accountsService.getAccount({
                    TableName: tableName,
                    Keys: [identityData.UID_PersonHead.value],
                }, 'UID_Person');
                if (managerAccountData) {
                    return new DbObjectKey(tableName, managerAccountData.GetEntity().GetKeys());
                }
            }
            return undefined;
        });
    }
}
AccountSidesheetComponent.ɵfac = function AccountSidesheetComponent_Factory(t) { return new (t || AccountSidesheetComponent)(i0.ɵɵdirectiveInject(i1$2.UntypedFormBuilder), i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.SnackBarService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetRef), i0.ɵɵdirectiveInject(i2.ElementalUiConfigService), i0.ɵɵdirectiveInject(i1.ProjectConfigurationService), i0.ɵɵdirectiveInject(i1.IdentitiesService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(AccountsReportsService), i0.ɵɵdirectiveInject(i2.ExtService), i0.ɵɵdirectiveInject(i2.CdrFactoryService)); };
AccountSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AccountSidesheetComponent, selectors: [["imx-account-sidesheet"]], decls: 11, vars: 10, consts: [[3, "label"], ["matTabContent", ""], [4, "ngFor", "ngForOf"], ["eui-sidesheet-content", "", 1, "governance-sidesheet__tab-content"], [1, "governance-sidesheet__tab-content-body"], [1, "imx-tab-card"], [3, "formGroup"], [3, "cdr", "controlCreated", 4, "ngFor", "ngForOf"], [4, "ngIf"], ["eui-sidesheet-actions", ""], ["mat-stroked-button", "", "color", "primary", 1, "justify-start", 3, "euiDownload"], ["translate", ""], ["mat-button", "", 3, "click"], ["mat-flat-button", "", "color", "primary", 3, "disabled", "click"], [3, "cdr", "controlCreated"], ["type", "info", "condensed", "true", 3, "colored", 4, "ngIf"], [3, "checked", "change"], ["type", "info", "condensed", "true", 3, "colored"], ["sidesheetWidth", "55%", 3, "usedInSidesheet", "unsAccountIdFilter", "uidPerson"], ["eui-sidesheet-content", "", 1, "imx-hyperview-sidesheet"], ["objectType", "UNSAccount", 3, "objectUid"], [3, "imxDataProvider", "label"], [4, "ngComponentOutlet"]], template: function AccountSidesheetComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-tab-group")(1, "mat-tab", 0);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵtemplate(3, AccountSidesheetComponent_ng_template_3_Template, 16, 5, "ng-template", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-tab", 0);
            i0.ɵɵpipe(5, "translate");
            i0.ɵɵtemplate(6, AccountSidesheetComponent_ng_template_6_Template, 3, 3, "ng-template", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "mat-tab", 0);
            i0.ɵɵpipe(8, "translate");
            i0.ɵɵtemplate(9, AccountSidesheetComponent_ng_template_9_Template, 2, 1, "ng-template", 1);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(10, AccountSidesheetComponent_ng_container_10_Template, 4, 4, "ng-container", 2);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 4, "#LDS#Heading Main Data"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(5, 6, "#LDS#Memberships"));
            i0.ɵɵadvance(3);
            i0.ɵɵpropertyInterpolate("label", i0.ɵɵpipeBind1(8, 8, "#LDS#Heading Hyperview"));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngForOf", ctx.dynamicTabs);
        }
    }, dependencies: [i7.NgComponentOutlet, i7.NgForOf, i7.NgIf, i1$2.ɵNgNoValidate, i1$2.NgControlStatusGroup, DataExplorerGroupsComponent, i1$2.FormGroupDirective, i1$1.EuiAlertComponent, i1$1.EuiDownloadDirective, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i10$1.MatCard, i11$1.MatSlideToggle, i10$2.MatTabGroup, i10$2.MatTab, i10$2.MatTabContent, i2.CdrEditorComponent, i1.ObjectHyperviewComponent, i7$1.TranslateDirective, i2.DynamicTabDataProviderDirective, i7$1.TranslatePipe], styles: [".eui-sidesheet-content[_ngcontent-%COMP%]:not(.imx-hyperview-sidesheet){padding:0}.eui-sidesheet-content[_ngcontent-%COMP%]:not(.imx-hyperview-sidesheet)     .mat-tab-body-content{display:flex;flex-direction:column}.eui-sidesheet-actions[_ngcontent-%COMP%]   .justify-start[_ngcontent-%COMP%]{margin-right:auto}.eui-sidesheet-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-of-type):not(.justify-start){margin-right:10px}.governance-sidesheet__tab-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%]{flex:1 1 auto;overflow:auto;padding:0}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%]   .imx-tab-card[_ngcontent-%COMP%]{margin:20px}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:first-child{overflow:auto}.governance-sidesheet__tab-content[_ngcontent-%COMP%] > .governance-sidesheet__tab-content-body[_ngcontent-%COMP%] > .imx-ext[_ngcontent-%COMP%]{overflow:hidden}.imx-entitlements-card[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column}.mat-checkbox[_ngcontent-%COMP%]{display:flex;margin-bottom:15px}  .mat-tab-group{height:100%;flex-grow:1;overflow:auto}  .mat-tab-group .mat-tab-header{padding:0 32px;background-color:#fff}  .mat-tab-group   .mat-tab-body-wrapper{height:100%}  .mat-tab-group .imx-edit-fk-open-picker{display:none}.eui-dark-theme   [_nghost-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]     .mat-tab-group .mat-tab-header{background-color:#16191a}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountSidesheetComponent, [{
            type: Component,
            args: [{ selector: 'imx-account-sidesheet', template: "<mat-tab-group>\r\n  <mat-tab [label]=\"'#LDS#Heading Main Data' | translate\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n        <div class=\"governance-sidesheet__tab-content-body\">\r\n          <mat-card class=\"imx-tab-card\">\r\n            <form [formGroup]=\"detailsFormGroup\">\r\n              <imx-cdr-editor *ngFor=\"let cdr of cdrList\" [cdr]=\"cdr\" (controlCreated)=\"formArray.push($event)\"> </imx-cdr-editor>\r\n              <div *ngIf=\"accountManagerIsEditable && linkedIdentitiesManager && (!identityManagerMatchesAccountManager || unsavedSyncChanges)\">\r\n                <eui-alert type=\"info\" condensed=\"true\" [colored]=\"true\" *ngIf=\"initialAccountManagerValue && (!identityManagerMatchesAccountManager || unsavedSyncChanges)\">\r\n                  <span translate>#LDS#The manager assigned to this user account differs from the manager assigned to the listed identity.</span>\r\n                </eui-alert>\r\n                <eui-alert type=\"info\" condensed=\"true\" [colored]=\"true\" *ngIf=\"!initialAccountManagerValue\">\r\n                  <span translate>#LDS#There is no manager assigned to this user account.</span>\r\n                </eui-alert>\r\n                <mat-slide-toggle [checked]=\"identityManagerMatchesAccountManager\" (change)=\"syncToIdentityManager($event)\">\r\n                  <span translate>#LDS#Synchronize the user account's manager with the listed identity</span>\r\n                </mat-slide-toggle>\r\n              </div>\r\n            </form>\r\n          </mat-card>\r\n        </div>\r\n        <div eui-sidesheet-actions>\r\n          <button mat-stroked-button color=\"primary\" [euiDownload]=\"reportDownload\" class=\"justify-start\">\r\n            <span translate>#LDS#Download report</span>\r\n          </button>\r\n          <button mat-button (click)=\"cancel()\">\r\n            <span translate>#LDS#Cancel</span>\r\n          </button>\r\n          <button mat-flat-button color=\"primary\" (click)=\"save()\" [disabled]=\"detailsFormGroup.pristine || detailsFormGroup.invalid\">\r\n            <span translate>#LDS#Save</span>\r\n          </button>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab [label]=\"'#LDS#Memberships' | translate\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n        <div class=\"governance-sidesheet__tab-content-body\">\r\n          <imx-data-explorer-groups [usedInSidesheet]=\"true\" [unsAccountIdFilter]=\"sidesheetData.unsAccountId\" [uidPerson]=\"sidesheetData.uidPerson\" sidesheetWidth=\"55%\">\r\n          </imx-data-explorer-groups>\r\n        </div>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <mat-tab label=\"{{ '#LDS#Heading Hyperview' | translate }}\">\r\n    <ng-template matTabContent>\r\n      <div eui-sidesheet-content class=\"imx-hyperview-sidesheet\">\r\n        <imx-object-hyperview objectType=\"UNSAccount\" [objectUid]=\"sidesheetData.unsAccountId\"></imx-object-hyperview>\r\n      </div>\r\n    </ng-template>\r\n  </mat-tab>\r\n\r\n  <ng-container *ngFor=\"let tab of dynamicTabs\">\r\n    <mat-tab [imxDataProvider]=\"parameters\" [label]=\"tab.inputData.label | translate\">\r\n      <ng-template matTabContent>\r\n        <div eui-sidesheet-content class=\"governance-sidesheet__tab-content\">\r\n          <div class=\"governance-sidesheet__tab-content-body\">\r\n            <ng-container *ngComponentOutlet=\"tab.instance\"></ng-container>\r\n          </div>\r\n        </div>\r\n      </ng-template>\r\n    </mat-tab>\r\n  </ng-container>\r\n</mat-tab-group>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.eui-sidesheet-content:not(.imx-hyperview-sidesheet){padding:0}.eui-sidesheet-content:not(.imx-hyperview-sidesheet) ::ng-deep .mat-tab-body-content{display:flex;flex-direction:column}.eui-sidesheet-actions .justify-start{margin-right:auto}.eui-sidesheet-actions button:not(:last-of-type):not(.justify-start){margin-right:10px}.governance-sidesheet__tab-content{display:flex;flex-direction:column;overflow:hidden}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body{flex:1 1 auto;overflow:auto;padding:0}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body .imx-tab-card{margin:20px}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body>:first-child{overflow:auto}.governance-sidesheet__tab-content>.governance-sidesheet__tab-content-body>.imx-ext{overflow:hidden}.imx-entitlements-card{flex:1 1 auto;display:flex;flex-direction:column}.mat-checkbox{display:flex;margin-bottom:15px}::ng-deep .mat-tab-group{height:100%;flex-grow:1;overflow:auto}::ng-deep .mat-tab-group .mat-tab-header{padding:0 32px;background-color:#fff}::ng-deep .mat-tab-group ::ng-deep .mat-tab-body-wrapper{height:100%}::ng-deep .mat-tab-group .imx-edit-fk-open-picker{display:none}.eui-dark-theme :host ::ng-deep .mat-tab-group .mat-tab-header{background-color:#2f3233}.eui-contrast-theme :host ::ng-deep .mat-tab-group .mat-tab-header{background-color:#16191a}\n"] }]
        }], function () {
        return [{ type: i1$2.UntypedFormBuilder }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [EUI_SIDESHEET_DATA]
                    }] }, { type: i2.ClassloggerService }, { type: i1$1.EuiLoadingService }, { type: i2.SnackBarService }, { type: i1$1.EuiSidesheetRef }, { type: i2.ElementalUiConfigService }, { type: i1.ProjectConfigurationService }, { type: i1.IdentitiesService }, { type: AccountsService }, { type: AccountsReportsService }, { type: i2.ExtService }, { type: i2.CdrFactoryService }];
    }, null);
})();

function TargetSystemReportComponent_eui_alert_1_Template(rf, ctx) {
    if (rf & 1) {
        const _r3 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "eui-alert", 6);
        i0.ɵɵlistener("dismissed", function TargetSystemReportComponent_eui_alert_1_Template_eui_alert_dismissed_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onHelperDismissed()); });
        i0.ɵɵelementStart(1, "div", 7);
        i0.ɵɵtext(2, " #LDS#Select a target system. All user accounts of this target system will be included in the report. ");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵproperty("condensed", true)("colored", true)("dismissable", true);
    }
}
function TargetSystemReportComponent_imx_data_tree_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r6 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "imx-data-tree", 8, 9);
        i0.ɵɵlistener("nodeSelected", function TargetSystemReportComponent_imx_data_tree_3_Template_imx_data_tree_nodeSelected_0_listener($event) { i0.ɵɵrestoreView(_r6); const ctx_r5 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r5.onNodeSelected($event)); });
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵproperty("withSelectedNodeHighlight", true)("hideSelection", true)("withMultiSelect", false)("database", ctx_r1.database);
    }
}
class TargetSystemReportComponent {
    constructor(busyService, entityWrapper, accountsService, accountReport, elementalUiConfigService, http, injector, overlay) {
        this.busyService = busyService;
        this.entityWrapper = entityWrapper;
        this.accountsService = accountsService;
        this.accountReport = accountReport;
        this.elementalUiConfigService = elementalUiConfigService;
        this.http = http;
        this.injector = injector;
        this.overlay = overlay;
        this.showHelperAlert = true;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.database = new FilterTreeDatabase(this.entityWrapper, (parentkey) => __awaiter(this, void 0, void 0, function* () {
                return this.accountsService.getFilterTree({
                    parentkey,
                    container: undefined,
                    system: undefined,
                    filter: undefined
                });
            }), this.busyService);
        });
    }
    onHelperDismissed() {
        this.showHelperAlert = false;
    }
    onNodeSelected(entity) {
        this.selectedEntity = entity;
    }
    loadReport() {
        var _a, _b;
        let url;
        const val = (_b = (_a = this.selectedEntity) === null || _a === void 0 ? void 0 : _a.GetColumn('Filter')) === null || _b === void 0 ? void 0 : _b.GetValue();
        if (!val) {
            return;
        }
        const columnName = val.ColumnName;
        if (columnName === 'UID_UNSRoot') {
            url = this.accountReport.accountsByRootReport(30, val.Value1);
        }
        else if (columnName === 'UID_UNSContainer') {
            url = this.accountReport.accountsByContainerReport(30, val.Value1);
        }
        const directive = new EuiDownloadDirective(null, this.http, this.overlay, this.injector);
        if (directive && url !== '') {
            directive.downloadOptions = Object.assign(Object.assign({}, this.elementalUiConfigService.Config.downloadOptions), { url, fileName: `${this.selectedEntity.GetDisplay()}.pdf`, disableElement: false });
            directive.onClick();
        }
    }
}
TargetSystemReportComponent.ɵfac = function TargetSystemReportComponent_Factory(t) { return new (t || TargetSystemReportComponent)(i0.ɵɵdirectiveInject(i1$1.EuiLoadingService), i0.ɵɵdirectiveInject(i2.FilterTreeEntityWrapperService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(AccountsReportsService), i0.ɵɵdirectiveInject(i2.ElementalUiConfigService), i0.ɵɵdirectiveInject(i5.HttpClient), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i6.Overlay)); };
TargetSystemReportComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TargetSystemReportComponent, selectors: [["imx-target-system-report"]], decls: 8, vars: 6, consts: [["eui-sidesheet-content", ""], ["class", "imx-helper-alert", "type", "info", 3, "condensed", "colored", "dismissable", "dismissed", 4, "ngIf"], [1, "imx-content-card"], ["data-imx-identifier", "target-system-report-data-tree", 3, "withSelectedNodeHighlight", "hideSelection", "withMultiSelect", "database", "nodeSelected", 4, "ngIf"], ["eui-sidesheet-actions", ""], ["color", "primary", "mat-raised-button", "", 3, "disabled", "click"], ["type", "info", 1, "imx-helper-alert", 3, "condensed", "colored", "dismissable", "dismissed"], ["translate", ""], ["data-imx-identifier", "target-system-report-data-tree", 3, "withSelectedNodeHighlight", "hideSelection", "withMultiSelect", "database", "nodeSelected"], ["tree", ""]], template: function TargetSystemReportComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, TargetSystemReportComponent_eui_alert_1_Template, 3, 3, "eui-alert", 1);
            i0.ɵɵelementStart(2, "mat-card", 2);
            i0.ɵɵtemplate(3, TargetSystemReportComponent_imx_data_tree_3_Template, 2, 4, "imx-data-tree", 3);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(4, "div", 4)(5, "button", 5);
            i0.ɵɵlistener("click", function TargetSystemReportComponent_Template_button_click_5_listener() { return ctx.loadReport(); });
            i0.ɵɵtext(6);
            i0.ɵɵpipe(7, "translate");
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.showHelperAlert);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.database);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("disabled", ctx.selectedEntity == null);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(7, 4, "#LDS#Download report"), " ");
        }
    }, dependencies: [i7.NgIf, i1$1.EuiAlertComponent, i1$1.EuiSidesheetContentDirective, i1$1.EuiSidesheetActionsDirective, i8.MatButton, i10$1.MatCard, i7$1.TranslateDirective, i2.DataTreeComponent, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:hidden;display:flex}.eui-sidesheet-content[_ngcontent-%COMP%]{overflow:hidden;display:flex;flex-direction:column}.imx-content-card[_ngcontent-%COMP%]{margin-top:10px;flex:1 1 auto;overflow:auto}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TargetSystemReportComponent, [{
            type: Component,
            args: [{ selector: 'imx-target-system-report', template: "<div eui-sidesheet-content>\r\n  <eui-alert *ngIf=\"showHelperAlert\" class=\"imx-helper-alert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\"\r\n    [dismissable]=\"true\" (dismissed)=\"onHelperDismissed()\">\r\n    <div translate>\r\n      #LDS#Select a target system. All user accounts of this target system will be included in the report.\r\n    </div>\r\n  </eui-alert>\r\n  <mat-card class=\"imx-content-card\">\r\n    <imx-data-tree [withSelectedNodeHighlight]=\"true\" data-imx-identifier=\"target-system-report-data-tree\" #tree\r\n      [hideSelection]=\"true\" *ngIf=\"database\"\r\n      [withMultiSelect]=\"false\"\r\n      [database]=\"database\" (nodeSelected)=\"onNodeSelected($event)\">\r\n    </imx-data-tree>\r\n  </mat-card>\r\n</div>\r\n<div eui-sidesheet-actions >\r\n  <button [disabled]=\"selectedEntity == null\" color=\"primary\" mat-raised-button (click)=\"loadReport()\">\r\n    {{'#LDS#Download report' |translate}}\r\n  </button>\r\n</div>\r\n", styles: [":host{overflow:hidden;display:flex}.eui-sidesheet-content{overflow:hidden;display:flex;flex-direction:column}.imx-content-card{margin-top:10px;flex:1 1 auto;overflow:auto}\n"] }]
        }], function () { return [{ type: i1$1.EuiLoadingService }, { type: i2.FilterTreeEntityWrapperService }, { type: AccountsService }, { type: AccountsReportsService }, { type: i2.ElementalUiConfigService }, { type: i5.HttpClient }, { type: i0.Injector }, { type: i6.Overlay }]; }, null);
})();

const _c0$3 = ["tsSelect"];
const _c1$1 = ["containerSelect"];
function DataExplorerFiltersComponent_div_3_button_2_span_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "span", 19);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r6 = i0.ɵɵnextContext(3);
        i0.ɵɵproperty("matTooltip", ctx_r6.selectedTreeNodeFilterDisplay);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(ctx_r6.selectedTreeNodeFilterDisplay);
    }
}
function DataExplorerFiltersComponent_div_3_button_2_ng_template_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "span", 20);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r8 = i0.ɵɵnextContext(3);
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(ctx_r8.DataExplorerFilterTypes.Container);
    }
}
function DataExplorerFiltersComponent_div_3_button_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "button", 14)(1, "span", 15);
        i0.ɵɵtext(2, "#LDS#Filter by");
        i0.ɵɵelementEnd();
        i0.ɵɵtext(3, "\u00A0 ");
        i0.ɵɵtemplate(4, DataExplorerFiltersComponent_div_3_button_2_span_4_Template, 2, 2, "span", 16);
        i0.ɵɵtemplate(5, DataExplorerFiltersComponent_div_3_button_2_ng_template_5_Template, 2, 1, "ng-template", null, 17, i0.ɵɵtemplateRefExtractor);
        i0.ɵɵelement(7, "eui-icon", 18);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const _r7 = i0.ɵɵreference(6);
        const ctx_r4 = i0.ɵɵnextContext(2);
        const _r2 = i0.ɵɵreference(6);
        i0.ɵɵproperty("disabled", !ctx_r4.treeDbWrapper.selectionEnabled || !ctx_r4.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable)("matMenuTriggerFor", _r2);
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("ngIf", ctx_r4.selectedTreeNodeFilterDisplay.length)("ngIfElse", _r7);
    }
}
const _c2$1 = function (a0) { return { "container-search--hidden": a0 }; };
function DataExplorerFiltersComponent_div_3_Template(rf, ctx) {
    if (rf & 1) {
        const _r12 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 6);
        i0.ɵɵlistener("click", function DataExplorerFiltersComponent_div_3_Template_div_click_0_listener($event) { return $event.stopPropagation(); });
        i0.ɵɵpipe(1, "translate");
        i0.ɵɵtemplate(2, DataExplorerFiltersComponent_div_3_button_2_Template, 8, 4, "button", 7);
        i0.ɵɵelementStart(3, "span", 8)(4, "div", 9);
        i0.ɵɵlistener("click", function DataExplorerFiltersComponent_div_3_Template_div_click_4_listener($event) { return $event.stopPropagation(); });
        i0.ɵɵelementStart(5, "eui-select", 10, 11);
        i0.ɵɵlistener("searchFieldChange", function DataExplorerFiltersComponent_div_3_Template_eui_select_searchFieldChange_5_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r11 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r11.onSearchChange(ctx_r11.DataExplorerFilterTypes.Container, $event)); })("selectionChange", function DataExplorerFiltersComponent_div_3_Template_eui_select_selectionChange_5_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.setSelectedContainer($event)); })("optionsClear", function DataExplorerFiltersComponent_div_3_Template_eui_select_optionsClear_5_listener() { i0.ɵɵrestoreView(_r12); const ctx_r14 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r14.clearContainerFilterSelection(false)); });
        i0.ɵɵpipe(7, "translate");
        i0.ɵɵelementEnd()()();
        i0.ɵɵelementStart(8, "button", 12);
        i0.ɵɵlistener("click", function DataExplorerFiltersComponent_div_3_Template_button_click_8_listener() { i0.ɵɵrestoreView(_r12); const ctx_r15 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r15.toggleContainerSearch()); });
        i0.ɵɵpipe(9, "translate");
        i0.ɵɵelement(10, "eui-icon", 13);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r1 = i0.ɵɵnextContext();
        i0.ɵɵproperty("matTooltip", i0.ɵɵpipeBind1(1, 12, ctx_r1.containerFilterWrapperTooltip));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", !ctx_r1.containerSearchMode);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(18, _c2$1, !ctx_r1.containerSearchMode));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("disabled", !ctx_r1.treeDbWrapper.selectionEnabled || !ctx_r1.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable)("hideClearButton", true)("label", i0.ɵɵpipeBind1(7, 14, "#LDS#Select a container"))("filterFunction", ctx_r1.paramListFilter)("options", ctx_r1.containerSelectOptions)("isPending", ctx_r1.pendingAsyncApiCall);
        i0.ɵɵadvance(3);
        i0.ɵɵproperty("disabled", !ctx_r1.treeDbWrapper.selectionEnabled || !ctx_r1.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable)("matTooltip", i0.ɵɵpipeBind1(9, 16, ctx_r1.containerToggleTooltip));
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("icon", !ctx_r1.containerSearchMode && !ctx_r1.treeNodeSelected ? "search" : "close");
    }
}
function DataExplorerFiltersComponent_div_7_span_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "span", 15);
        i0.ɵɵtext(1, "#LDS#No filters available");
        i0.ɵɵelementEnd();
    }
}
function DataExplorerFiltersComponent_div_7_Template(rf, ctx) {
    if (rf & 1) {
        const _r18 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtemplate(1, DataExplorerFiltersComponent_div_7_span_1_Template, 2, 0, "span", 21);
        i0.ɵɵelementStart(2, "imx-data-tree", 22);
        i0.ɵɵlistener("nodeSelected", function DataExplorerFiltersComponent_div_7_Template_imx_data_tree_nodeSelected_2_listener($event) { i0.ɵɵrestoreView(_r18); const ctx_r17 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r17.onTreeNodeSelected($event)); });
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r3 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", !ctx_r3.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("database", ctx_r3.treeDbWrapper.entityTreeDatabase);
    }
}
var DataExplorerFilterTypes;
(function (DataExplorerFilterTypes) {
    DataExplorerFilterTypes["TargetSystem"] = "targetsystem";
    DataExplorerFilterTypes["Container"] = "container";
})(DataExplorerFilterTypes || (DataExplorerFilterTypes = {}));
class DataExplorerFiltersComponent {
    constructor(dataHelper) {
        this.dataHelper = dataHelper;
        this.targetSystemOptions = [];
        this.containerSelectOptions = [];
        this.DataExplorerFilterTypes = DataExplorerFilterTypes;
        this.pendingAsyncApiCall = false;
        this.containerSearchMode = false;
        this.treeNodeSelected = false;
        this.tsIssueMode = '';
        this.selectedFiltersChanged = new EventEmitter();
        this.skipSelectionEmitMode = false;
    }
    get selectedTreeNodeFilterDisplay() {
        let display = '';
        if (this.selectedContainerUid) {
            display = `Container: ${this.dstContainerFilterRef.selectedOption.Display}`;
        }
        return display;
    }
    get containerFilterWrapperTooltip() {
        var _a, _b;
        let display = '';
        if (!((_a = this.treeDbWrapper) === null || _a === void 0 ? void 0 : _a.selectionEnabled)) {
            display = '#LDS#Select a domain first';
        }
        else if (((_b = this.treeDbWrapper) === null || _b === void 0 ? void 0 : _b.selectionEnabled) && !this.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable) {
            display = '#LDS#No containers available';
        }
        return display;
    }
    get containerToggleTooltip() {
        var _a;
        let display = '';
        if (this.treeNodeSelected) {
            display = '#LDS#Clear';
        }
        else if (((_a = this.treeDbWrapper) === null || _a === void 0 ? void 0 : _a.selectionEnabled) && this.treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable) {
            display = '#LDS#Toggle search';
        }
        return display;
    }
    get showTsSyncStatus() {
        let show = false;
        if (this.selectedTsOption && this.selectedTsOption.value) {
            show = !this.selectedTsOption.hasData;
        }
        return show;
    }
    get showTsSyncAlert() {
        let show = false;
        if (this.selectedTsOption && this.selectedTsOption.value) {
            show = this.selectedTsOption.hasData && !this.selectedTsOption.hasSync;
        }
        return show;
    }
    ngOnInit() {
        if (this.targetSystemData) {
            this.setupTsSelectOptions(this.targetSystemData);
        }
        else {
            this.getTargetSystemOptions();
        }
    }
    targetSystemSelected(selected) {
        var _a;
        this.selectedTargetSystemUid = selected.value;
        this.updateDataSyncStateForTs(selected);
        if (this.treeDbWrapper) {
            this.treeDbWrapper.selectionEnabled = ((_a = this.selectedTargetSystemUid) === null || _a === void 0 ? void 0 : _a.length) > 0 ? true : false;
            this.treeDbWrapper.targetSystemFilterValue = this.selectedTargetSystemUid;
        }
        if (this.dst) {
            // First clear any previosuly selected dst selectedFilter
            this.clearTargetSystemFilterSelection(false);
            if (selected.value && selected.value.length > 0) {
                this.dstTargetSystemFilterRef = {
                    selectedOption: { Value: selected.value, Display: selected.display },
                    filter: { Name: DataExplorerFilterTypes.TargetSystem },
                    isCustom: true
                };
                this.dst.selectedFilters.push(this.dstTargetSystemFilterRef);
            }
        }
        if (!this.skipSelectionEmitMode) {
            // Trigger a new api call to reflect filter removal
            this.selectedFiltersChanged.emit(this.selectedTargetSystemUid);
        }
    }
    /**
     * Used to override the eui-select's default filtering
     * Filtering is provided through an async api call
     */
    paramListFilter() {
        return true;
    }
    onSearchChange(filterType, search) {
        return __awaiter(this, void 0, void 0, function* () {
            const method = filterType === DataExplorerFilterTypes.TargetSystem ? this.getTargetSystemOptions : this.getContainers;
            this.pendingAsyncApiCall = true;
            try {
                yield method.call(this, search);
            }
            finally {
                this.pendingAsyncApiCall = false;
            }
        });
    }
    clearTargetSystemFilterSelection(clearSelectControl) {
        if (clearSelectControl) {
            this.tsSelect.searchInput.clearSearch();
            this.tsSelect.clearSelectionsInside();
        }
        // Also clear container selection if a value is set
        if (this.selectedContainerUid) {
            // Don't emit a change to container un-select in this context because it
            // will be emitted as part of target system change anyway
            this.skipSelectionEmitMode = true;
            this.clearContainerFilterSelection(true);
            this.skipSelectionEmitMode = false;
        }
        this.clearDstSelectedFilter(this.dstTargetSystemFilterRef);
    }
    clearContainerFilterSelection(clearSelectControl) {
        if (this.containerSelect && clearSelectControl) {
            this.containerSelect.searchInput.clearSearch();
            this.containerSelect.clearSelectionsInside();
        }
        this.treeNodeSelected = false;
    }
    clearAllSelectedFilters() {
        this.skipSelectionEmitMode = true;
        this.clearContainerFilterSelection(true);
        this.clearTargetSystemFilterSelection(true);
        this.skipSelectionEmitMode = false;
        this.selectedFiltersChanged.emit();
    }
    /**
     * @ignore Used internally.
     * Is called when a value is selection on the optional filter tree structure
     * Updates and emits the new navigationState to include any filter query params.
     */
    onTreeNodeSelected(entity) {
        return __awaiter(this, void 0, void 0, function* () {
            this.treeNodeSelected = true;
            const selectedValue = entity.GetKeys()[0];
            // Set the selected value on the search control as well
            this.containerSelect.writeValue(selectedValue);
            this.setSelectedContainer({ value: selectedValue, display: entity.GetDisplay() });
        });
    }
    setSelectedContainer(selected) {
        this.selectedContainerUid = selected.value;
        if (this.dst) {
            // First clear any previosuly selected dst selectedFilter
            this.clearDstSelectedFilter(this.dstContainerFilterRef);
            if (selected.value && selected.value.length > 0) {
                this.dstContainerFilterRef = {
                    selectedOption: { Value: selected.value, Display: selected.display },
                    filter: { Name: DataExplorerFilterTypes.Container },
                    isCustom: true
                };
                this.dst.selectedFilters.push(this.dstContainerFilterRef);
            }
        }
        if (!this.skipSelectionEmitMode) {
            this.selectedFiltersChanged.emit(this.selectedContainerUid);
        }
    }
    toggleContainerSearch() {
        var _a, _b;
        if (this.treeNodeSelected) {
            this.clearContainerFilterSelection(true);
            return;
        }
        this.containerSearchMode = !this.containerSearchMode;
        if (this.containerSearchMode) {
            if ((_b = (_a = this.treeDbWrapper) === null || _a === void 0 ? void 0 : _a.entityTreeDatabase) === null || _b === void 0 ? void 0 : _b.topLevelEntities) {
                this.containerSelectOptions = this.treeDbWrapper.entityTreeDatabase.topLevelEntities.map(d => this.convertEntityToEuiSelectOption(d));
            }
            else {
                this.getContainers();
            }
        }
        else if (this.selectedContainerUid) {
            // If a value is set then clear it when toggling out of search mode
            this.clearContainerFilterSelection(true);
        }
    }
    /**
     * Responds to a custom filter (or all filters) being removed from outside of the context of
     * this component
     */
    onCustomFilterClearedExternally(sf) {
        setTimeout(() => {
            if (!sf) {
                // If no singular filter is supplied, then all have been cleared
                this.clearAllSelectedFilters();
            }
            else if (sf.filter.Name === DataExplorerFilterTypes.TargetSystem) {
                this.clearTargetSystemFilterSelection(true);
            }
            else if (sf.filter.Name === DataExplorerFilterTypes.Container) {
                this.clearContainerFilterSelection(true);
            }
        });
    }
    updateDataSyncStateForTs(selectedOption) {
        this.selectedTsOption = selectedOption;
        this.tsIssueMode = '';
        if (this.showTsSyncStatus) {
            if (!this.selectedTsOption.hasSync) {
                this.tsIssueMode = 'no-sync';
            }
            else if (!this.selectedTsOption.hasData) {
                this.tsIssueMode = 'no-data';
            }
        }
    }
    clearDstSelectedFilter(selectedFilterRef) {
        if (this.dst && selectedFilterRef) {
            // Remove the 'isCustom' property to avoid an event being triggered in dst code
            selectedFilterRef.isCustom = undefined;
            // Then make call to remove selected filter
            this.dst.removeSelectedFilter(selectedFilterRef.filter, false, selectedFilterRef.selectedOption.Value, selectedFilterRef);
        }
    }
    getTargetSystemOptions(search) {
        return __awaiter(this, void 0, void 0, function* () {
            const data = yield this.dataHelper.getAuthorityData(search, true);
            this.setupTsSelectOptions(data.authorities);
        });
    }
    getContainers(search) {
        return __awaiter(this, void 0, void 0, function* () {
            const navState = { PageSize: 1000, StartIndex: 0, ParentKey: '' };
            navState.search = search ? search : undefined;
            navState.system = this.selectedTargetSystemUid ? this.selectedTargetSystemUid : undefined;
            const data = yield this.dataHelper.getContainers(navState);
            this.containerSelectOptions = data === null || data === void 0 ? void 0 : data.Data.map(d => this.convertEntityToEuiSelectOption(d.GetEntity()));
        });
    }
    setupTsSelectOptions(targetSystems) {
        this.targetSystemOptions = targetSystems.map(d => this.convertTsToEuiSelectOption(d));
    }
    convertTsToEuiSelectOption(tEntity) {
        var _a, _b;
        const option = this.convertEntityToEuiSelectOption(tEntity.GetEntity());
        option.hasSync = (_a = tEntity.HasSync) === null || _a === void 0 ? void 0 : _a.value;
        option.hasData = (_b = tEntity.HasData) === null || _b === void 0 ? void 0 : _b.value;
        return option;
    }
    convertEntityToEuiSelectOption(entity) {
        return { display: entity.GetDisplay(), value: entity.GetKeys()[0] };
    }
}
DataExplorerFiltersComponent.ɵfac = function DataExplorerFiltersComponent_Factory(t) { return new (t || DataExplorerFiltersComponent)(i0.ɵɵdirectiveInject(DeHelperService)); };
DataExplorerFiltersComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataExplorerFiltersComponent, selectors: [["imx-target-system-filter"]], viewQuery: function DataExplorerFiltersComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$3, 5);
            i0.ɵɵviewQuery(_c1$1, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.tsSelect = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.containerSelect = _t.first);
        }
    }, inputs: { targetSystemData: "targetSystemData", dst: "dst", treeDbWrapper: "treeDbWrapper" }, outputs: { selectedFiltersChanged: "selectedFiltersChanged" }, decls: 8, vars: 8, consts: [[1, "imx-de-targetsystem-filter", 3, "label", "filterFunction", "options", "isPending", "searchFieldChange", "selectionChange", "optionsClear"], ["tsSelect", ""], ["class", "imx-de-container-tree-filter", 3, "matTooltip", "click", 4, "ngIf"], ["xPosition", "before", 1, "container-filter-menu"], ["containerFilterMenu", ""], [4, "ngIf"], [1, "imx-de-container-tree-filter", 3, "matTooltip", "click"], ["mat-button", "", "data-imx-identifier", "dst-button-filter", 3, "disabled", "matMenuTriggerFor", 4, "ngIf"], [3, "ngClass"], ["imx-data-source-toolbar-custom-filter-search", "", 3, "click"], [1, "container-search", 3, "disabled", "hideClearButton", "label", "filterFunction", "options", "isPending", "searchFieldChange", "selectionChange", "optionsClear"], ["containerSelect", ""], ["mat-button", "", "matSuffix", "", "mat-icon-button", "", 3, "disabled", "matTooltip", "click"], ["matSuffix", "", "size", "18px", 3, "icon"], ["mat-button", "", "data-imx-identifier", "dst-button-filter", 3, "disabled", "matMenuTriggerFor"], ["translate", ""], ["class", "tree-filter-name", 3, "matTooltip", 4, "ngIf", "ngIfElse"], ["noselection", ""], ["icon", "scrolldown", "size", "16px"], [1, "tree-filter-name", 3, "matTooltip"], [1, "tree-filter-name"], ["translate", "", 4, "ngIf"], [3, "database", "nodeSelected"]], template: function DataExplorerFiltersComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "eui-select", 0, 1);
            i0.ɵɵlistener("searchFieldChange", function DataExplorerFiltersComponent_Template_eui_select_searchFieldChange_0_listener($event) { return ctx.onSearchChange(ctx.DataExplorerFilterTypes.TargetSystem, $event); })("selectionChange", function DataExplorerFiltersComponent_Template_eui_select_selectionChange_0_listener($event) { return ctx.targetSystemSelected($event); })("optionsClear", function DataExplorerFiltersComponent_Template_eui_select_optionsClear_0_listener() { return ctx.clearTargetSystemFilterSelection(false); });
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(3, DataExplorerFiltersComponent_div_3_Template, 11, 20, "div", 2);
            i0.ɵɵelement(4, "mat-divider");
            i0.ɵɵelementStart(5, "mat-menu", 3, 4);
            i0.ɵɵtemplate(7, DataExplorerFiltersComponent_div_7_Template, 3, 2, "div", 5);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵproperty("label", i0.ɵɵpipeBind1(2, 6, "#LDS#Select a domain"))("filterFunction", ctx.paramListFilter)("options", ctx.targetSystemOptions)("isPending", ctx.pendingAsyncApiCall);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.treeDbWrapper);
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("ngIf", ctx.treeDbWrapper == null ? null : ctx.treeDbWrapper.entityTreeDatabase);
        }
    }, dependencies: [i7.NgClass, i7.NgIf, i1$1.EuiIconComponent, i1$1.EuiSelectComponent, i8.MatButton, i5$1.MatDivider, i6$1.MatSuffix, i11.MatMenu, i11.MatMenuTrigger, i8$1.MatTooltip, i7$1.TranslateDirective, i2.DataTreeComponent, i7$1.TranslatePipe], styles: [".imx-de-targetsystem-filter[_ngcontent-%COMP%]{margin-bottom:15px}.imx-de-container-tree-filter[_ngcontent-%COMP%]{display:flex;align-items:center;margin-bottom:15px}.imx-de-container-tree-filter[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{margin-left:4px}.imx-de-container-tree-filter[_ngcontent-%COMP%]   .tree-filter-name[_ngcontent-%COMP%]{text-transform:capitalize;max-width:140px;display:inline-block;overflow:hidden;text-overflow:ellipsis}.imx-de-container-tree-filter[_ngcontent-%COMP%]   .container-search--hidden[_ngcontent-%COMP%]{display:none}  .mat-menu-panel.container-filter-menu{min-width:250px;max-width:400px;max-height:600px;padding:0 10px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataExplorerFiltersComponent, [{
            type: Component,
            args: [{ selector: 'imx-target-system-filter', template: "<eui-select\r\n  [label]=\"'#LDS#Select a domain' | translate\"\r\n  (searchFieldChange)=\"onSearchChange(DataExplorerFilterTypes.TargetSystem, $event)\"\r\n  [filterFunction]=\"paramListFilter\"\r\n  (selectionChange)=\"targetSystemSelected($event)\"\r\n  (optionsClear)=\"clearTargetSystemFilterSelection(false)\"\r\n  [options]=\"targetSystemOptions\"\r\n  [isPending]=\"pendingAsyncApiCall\"\r\n  class=\"imx-de-targetsystem-filter\"\r\n  #tsSelect>\r\n</eui-select>\r\n\r\n<div class=\"imx-de-container-tree-filter\" *ngIf=\"treeDbWrapper\"\r\n(click)=\"$event.stopPropagation()\"\r\n[matTooltip]=\"containerFilterWrapperTooltip | translate\">\r\n\r\n  <button *ngIf=\"!containerSearchMode\" [disabled]=\"!treeDbWrapper.selectionEnabled || !treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable\"\r\n  mat-button [matMenuTriggerFor]=\"containerFilterMenu\" data-imx-identifier=\"dst-button-filter\">\r\n    <span translate>#LDS#Filter by</span>&nbsp;\r\n    <span *ngIf=\"selectedTreeNodeFilterDisplay.length; else noselection\" [matTooltip]=\"selectedTreeNodeFilterDisplay\" class=\"tree-filter-name\">{{selectedTreeNodeFilterDisplay}}</span>\r\n    <ng-template #noselection><span class=\"tree-filter-name\">{{DataExplorerFilterTypes.Container}}</span></ng-template>\r\n    <eui-icon icon=\"scrolldown\" size=\"16px\"></eui-icon>\r\n  </button>\r\n  <span [ngClass]=\"{'container-search--hidden': !containerSearchMode}\">\r\n    <div imx-data-source-toolbar-custom-filter-search (click)=\"$event.stopPropagation()\">\r\n      <eui-select\r\n        [disabled]=\"!treeDbWrapper.selectionEnabled || !treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable\"\r\n        [hideClearButton]=\"true\"\r\n        [label]=\"'#LDS#Select a container' | translate\"\r\n        (searchFieldChange)=\"onSearchChange(DataExplorerFilterTypes.Container, $event)\"\r\n        [filterFunction]=\"paramListFilter\"\r\n        (selectionChange)=\"setSelectedContainer($event)\"\r\n        (optionsClear)=\"clearContainerFilterSelection(false)\"\r\n        [options]=\"containerSelectOptions\"\r\n        [isPending]=\"pendingAsyncApiCall\"\r\n        class=\"container-search\"\r\n        #containerSelect>\r\n      </eui-select>\r\n    </div>\r\n  </span>\r\n  <button [disabled]=\"!treeDbWrapper.selectionEnabled || !treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable\"\r\n  [matTooltip]=\"containerToggleTooltip | translate\"\r\n  mat-button matSuffix mat-icon-button (click)=\"toggleContainerSearch()\">\r\n    <eui-icon matSuffix [icon]=\"!containerSearchMode && !treeNodeSelected ? 'search' : 'close' \" size=\"18px\"></eui-icon>\r\n  </button>\r\n</div>\r\n\r\n <mat-divider></mat-divider>\r\n\r\n\r\n<mat-menu #containerFilterMenu class=\"container-filter-menu\" xPosition=\"before\">\r\n  <div *ngIf=\"treeDbWrapper?.entityTreeDatabase\">\r\n    <span *ngIf=\"!treeDbWrapper.entityTreeDatabase.hasEntitiesAvailable\" translate>#LDS#No filters available</span>\r\n    <imx-data-tree [database]=\"treeDbWrapper.entityTreeDatabase\" (nodeSelected)=\"onTreeNodeSelected($event)\"></imx-data-tree>\r\n  </div>\r\n</mat-menu>\r\n", styles: [".imx-de-targetsystem-filter{margin-bottom:15px}.imx-de-container-tree-filter{display:flex;align-items:center;margin-bottom:15px}.imx-de-container-tree-filter .eui-icon{margin-left:4px}.imx-de-container-tree-filter .tree-filter-name{text-transform:capitalize;max-width:140px;display:inline-block;overflow:hidden;text-overflow:ellipsis}.imx-de-container-tree-filter .container-search--hidden{display:none}::ng-deep .mat-menu-panel.container-filter-menu{min-width:250px;max-width:400px;max-height:600px;padding:0 10px}\n"] }]
        }], function () { return [{ type: DeHelperService }]; }, { tsSelect: [{
                type: ViewChild,
                args: ['tsSelect', { static: false }]
            }], containerSelect: [{
                type: ViewChild,
                args: ['containerSelect', { static: false }]
            }], targetSystemData: [{
                type: Input
            }], dst: [{
                type: Input
            }], treeDbWrapper: [{
                type: Input
            }], selectedFiltersChanged: [{
                type: Output
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function DataExplorerNoDataComponent_div_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵelement(1, "eui-icon", 2);
        i0.ɵɵelementStart(2, "h2", 3);
        i0.ɵɵtext(3, "#LDS#Heading No Synchronization Configured");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "p", 3);
        i0.ɵɵtext(5, "#LDS#Please configure a synchronization using the Synchronization Editor.");
        i0.ɵɵelementEnd()();
    }
}
function DataExplorerNoDataComponent_div_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵelement(1, "eui-icon", 4);
        i0.ɵɵelementStart(2, "h2", 3);
        i0.ɵɵtext(3, "#LDS#Heading No Data Synchronized");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(4, "p", 3);
        i0.ɵɵtext(5, "#LDS#A synchronization has been configured in the Synchronization Editor, but not run yet.");
        i0.ɵɵelementEnd()();
    }
}
class DataExplorerNoDataComponent {
}
DataExplorerNoDataComponent.ɵfac = function DataExplorerNoDataComponent_Factory(t) { return new (t || DataExplorerNoDataComponent)(); };
DataExplorerNoDataComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataExplorerNoDataComponent, selectors: [["imx-data-explorer-no-data"]], inputs: { mode: "mode" }, decls: 3, vars: 2, consts: [[1, "data-explorer-sync-status"], [4, "ngIf"], ["icon", "sync"], ["translate", ""], ["icon", "database"]], template: function DataExplorerNoDataComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵtemplate(1, DataExplorerNoDataComponent_div_1_Template, 6, 0, "div", 1);
            i0.ɵɵtemplate(2, DataExplorerNoDataComponent_div_2_Template, 6, 0, "div", 1);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.mode === "no-sync");
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.mode === "no-data");
        }
    }, dependencies: [i7.NgIf, i1$1.EuiIconComponent, i7$1.TranslateDirective], styles: [".data-explorer-sync-status[_ngcontent-%COMP%]{height:100%}.data-explorer-sync-status[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 16px}.data-explorer-sync-status[_ngcontent-%COMP%]   .eui-icon[_ngcontent-%COMP%]{font-size:150px;color:#919799;margin-bottom:30px}.data-explorer-sync-status[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{font-size:32px;font-weight:400}.data-explorer-sync-status[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:18px;margin-top:10px;margin-bottom:75px;color:#919799}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataExplorerNoDataComponent, [{
            type: Component,
            args: [{ selector: 'imx-data-explorer-no-data', template: "<div class=\"data-explorer-sync-status\">\r\n  <div *ngIf=\"mode === 'no-sync'\">\r\n    <eui-icon icon=\"sync\"></eui-icon>\r\n    <h2 translate>#LDS#Heading No Synchronization Configured</h2>\r\n    <p translate>#LDS#Please configure a synchronization using the Synchronization Editor.</p>\r\n  </div>\r\n  <div *ngIf=\"mode === 'no-data'\">\r\n    <eui-icon icon=\"database\"></eui-icon>\r\n    <h2 translate>#LDS#Heading No Data Synchronized</h2>\r\n    <p translate>#LDS#A synchronization has been configured in the Synchronization Editor, but not run yet.</p>\r\n  </div>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.data-explorer-sync-status{height:100%}.data-explorer-sync-status>div{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 16px}.data-explorer-sync-status .eui-icon{font-size:150px;color:#919799;margin-bottom:30px}.data-explorer-sync-status h2{font-size:32px;font-weight:400}.data-explorer-sync-status p{font-size:18px;margin-top:10px;margin-bottom:75px;color:#919799}\n"] }]
        }], null, { mode: [{
                type: Input
            }] });
})();

const _c0$2 = ["dataExplorerFilters"];
function DataExplorerAccountsComponent_div_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 13)(1, "div", 14)(2, "h3", 15);
        i0.ɵɵtext(3, "#LDS#Heading User Accounts");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(4, "imx-help-contextual", 16);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(4);
        i0.ɵɵproperty("contextId", ctx_r0.contextId);
    }
}
function DataExplorerAccountsComponent_div_8_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵelement(1, "imx-data-explorer-no-data", 17);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        i0.ɵɵnextContext();
        const _r2 = i0.ɵɵreference(7);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("mode", _r2.tsIssueMode);
    }
}
function DataExplorerAccountsComponent_eui_alert_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "eui-alert", 18)(1, "span", 15);
        i0.ɵɵtext(2, "#LDS#There is currently no data synchronization configured for the selected domain.");
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        i0.ɵɵproperty("colored", true);
    }
}
function DataExplorerAccountsComponent_div_10_ng_template_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 27);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r10 = ctx.$implicit;
        i0.ɵɵstyleProp("max-width", "500px");
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r10.GetEntity().GetDisplay());
    }
}
function DataExplorerAccountsComponent_div_10_ng_template_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 27);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r11 = ctx.$implicit;
        i0.ɵɵstyleProp("max-width", "300px");
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r11.UID_Person.Column.GetDisplayValue());
    }
}
function DataExplorerAccountsComponent_div_10_ng_template_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(2, "div", 28);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r12 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r12.UID_UNSRoot.Column.GetDisplayValue());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r12.UID_DPRNameSpace.Column.GetDisplayValue());
    }
}
function DataExplorerAccountsComponent_div_10_ng_template_11_div_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div")(1, "eui-badge", 29);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const item_r13 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r13.XMarkedForDeletion.Column.GetDisplayValue());
    }
}
function DataExplorerAccountsComponent_div_10_ng_template_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, DataExplorerAccountsComponent_div_10_ng_template_11_div_0_Template, 3, 1, "div", 7);
    }
    if (rf & 2) {
        const item_r13 = ctx.$implicit;
        i0.ɵɵproperty("ngIf", item_r13.XMarkedForDeletion.value !== 0);
    }
}
function DataExplorerAccountsComponent_div_10_Template(rf, ctx) {
    if (rf & 1) {
        const _r17 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "div", 19)(1, "div", 20)(2, "imx-data-table", 21);
        i0.ɵɵlistener("highlightedEntityChanged", function DataExplorerAccountsComponent_div_10_Template_imx_data_table_highlightedEntityChanged_2_listener($event) { i0.ɵɵrestoreView(_r17); const ctx_r16 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r16.onAccountChanged($event)); });
        i0.ɵɵelementStart(3, "imx-data-table-column", 22);
        i0.ɵɵtemplate(4, DataExplorerAccountsComponent_div_10_ng_template_4_Template, 2, 3, "ng-template");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(5, "imx-data-table-column", 23);
        i0.ɵɵtemplate(6, DataExplorerAccountsComponent_div_10_ng_template_6_Template, 2, 3, "ng-template");
        i0.ɵɵelementEnd();
        i0.ɵɵelement(7, "imx-data-table-column", 24);
        i0.ɵɵelementStart(8, "imx-data-table-column", 24);
        i0.ɵɵtemplate(9, DataExplorerAccountsComponent_div_10_ng_template_9_Template, 4, 2, "ng-template");
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(10, "imx-data-table-generic-column", 25);
        i0.ɵɵtemplate(11, DataExplorerAccountsComponent_div_10_ng_template_11_Template, 1, 1, "ng-template");
        i0.ɵɵelementEnd()();
        i0.ɵɵelement(12, "imx-data-source-paginator", 26);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const ctx_r5 = i0.ɵɵnextContext();
        const _r1 = i0.ɵɵreference(3);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r1);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r5.entitySchemaUnsAccount == null ? null : ctx_r5.entitySchemaUnsAccount.Columns[ctx_r5.DisplayColumns.DISPLAY_PROPERTYNAME]);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx_r5.entitySchemaUnsAccount == null ? null : ctx_r5.entitySchemaUnsAccount.Columns.UID_Person);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("entityColumn", ctx_r5.entitySchemaUnsAccount == null ? null : ctx_r5.entitySchemaUnsAccount.Columns.AccountDisabled);
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("entityColumn", ctx_r5.entitySchemaUnsAccount == null ? null : ctx_r5.entitySchemaUnsAccount.Columns.UID_UNSRoot);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("columnName", ctx_r5.entitySchemaUnsAccount == null ? null : ctx_r5.entitySchemaUnsAccount.Columns.XMarkedForDeletion.ColumnName);
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("dst", _r1);
    }
}
const _c1 = function () { return ["search", "sort", "filter", "filterTree", "settings"]; };
const _c2 = function () { return ["namespace"]; };
class DataExplorerAccountsComponent {
    constructor(translateProvider, sideSheet, logger, accountsService, dataHelper, viewConfigService, settingsService) {
        this.translateProvider = translateProvider;
        this.sideSheet = sideSheet;
        this.logger = logger;
        this.accountsService = accountsService;
        this.dataHelper = dataHelper;
        this.viewConfigService = viewConfigService;
        this.settingsService = settingsService;
        this.applyIssuesFilter = false;
        this.filterOptions = [];
        this.DisplayColumns = DisplayColumns;
        this.busyService = new BusyService();
        this.contextId = HELP_CONTEXTUAL.DataExplorerAccounts;
        this.displayedColumns = [];
        this.viewConfigPath = 'targetsystem/uns/account';
        this.navigationState = { PageSize: settingsService.DefaultPageSize, StartIndex: 0 };
        this.entitySchemaUnsAccount = accountsService.accountSchema;
        this.authorityDataDeleted$ = this.dataHelper.authorityDataDeleted.subscribe(() => this.navigate());
        this.treeDbWrapper = new ContainerTreeDatabaseWrapper(this.busyService, dataHelper);
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            /** if you like to add columns, please check {@link AccountsExtComponent | Account Extension Component} as well */
            this.displayedColumns = [
                this.entitySchemaUnsAccount.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
                this.entitySchemaUnsAccount.Columns.UID_Person,
                this.entitySchemaUnsAccount.Columns.UID_UNSRoot,
                this.entitySchemaUnsAccount.Columns.AccountDisabled,
                this.entitySchemaUnsAccount.Columns.XMarkedForDeletion,
            ];
            const isBusy = this.busyService.beginBusy();
            try {
                this.dataModel = yield this.accountsService.getDataModel();
                this.filterOptions = this.dataModel.Filters;
                this.viewConfig = yield this.viewConfigService.getInitialDSTExtension(this.dataModel, this.viewConfigPath);
            }
            finally {
                isBusy.endBusy();
            }
            if (this.applyIssuesFilter && !this.issuesFilterMode) {
                const orphanedFilter = this.filterOptions.find((f) => {
                    return f.Name === 'orphaned';
                });
                if (orphanedFilter) {
                    orphanedFilter.InitialValue = '1';
                }
            }
            if (this.applyIssuesFilter && this.issuesFilterMode === 'manager') {
                const managerDiscrepencyFilter = this.filterOptions.find((f) => {
                    return f.Name === 'managerdiscrepancy';
                });
                if (managerDiscrepencyFilter) {
                    managerDiscrepencyFilter.InitialValue = '1';
                }
            }
            yield this.navigate(true);
        });
    }
    ngOnDestroy() {
        if (this.authorityDataDeleted$) {
            this.authorityDataDeleted$.unsubscribe();
        }
    }
    updateConfig(config) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.putViewConfig(config);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    deleteConfigById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.viewConfigService.deleteViewConfig(id);
            this.viewConfig = yield this.viewConfigService.getDSTExtensionChanges(this.viewConfigPath);
            this.dstSettings.viewConfig = this.viewConfig;
        });
    }
    /**
     * Occurs when the navigation state has changed - e.g. users clicks on the next page button.
     *
     */
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.navigate();
        });
    }
    onAccountChanged(unsAccount) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Selected UNS account changed`);
            this.logger.trace(this, `New UNS account selected`, unsAccount);
            let data;
            const isBusy = this.busyService.beginBusy();
            try {
                const unsDbObjectKey = DbObjectKey.FromXml(unsAccount.XObjectKey.value);
                data = {
                    unsAccountId: unsAccount.UID_UNSAccount.value,
                    unsDbObjectKey,
                    selectedAccount: yield this.accountsService.getAccountInteractive(unsDbObjectKey, 'UID_UNSAccount'),
                    uidPerson: unsAccount.UID_Person.value,
                    tableName: this.tableName,
                };
            }
            finally {
                isBusy.endBusy();
            }
            yield this.viewAccount(data);
        });
    }
    /**
     * Occurs when user triggers search.
     *
     * @param keywords Search keywords.
     */
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Searching for: ${keywords}`);
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.navigate();
        });
    }
    filterByTree(filters) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState.filter = filters;
            this.navigationState.StartIndex = 0;
            return this.navigate();
        });
    }
    openReportOptionsSidesheet() {
        return __awaiter(this, void 0, void 0, function* () {
            this.sideSheet.open(TargetSystemReportComponent, {
                title: yield this.translateProvider.get('#LDS#Heading Download Target System Report').toPromise(),
                icon: 'download',
                padding: '0px',
                width: 'max(400px, 40%)',
                testId: 'accounts-report-sidesheet',
            });
        });
    }
    navigate(isInitialLoad = false) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            const getParams = this.navigationState;
            try {
                this.logger.debug(this, `Retrieving accounts list`);
                this.logger.trace('Navigation settings', this.navigationState);
                const tsUid = this.dataExplorerFilters.selectedTargetSystemUid;
                const cUid = this.dataExplorerFilters.selectedContainerUid;
                getParams.system = tsUid ? tsUid : undefined;
                getParams.container = cUid ? cUid : undefined;
                const data = isInitialLoad ? { totalCount: 0, Data: [] } : yield this.accountsService.getAccounts(getParams);
                if (data) {
                    const exportMethod = this.accountsService.exportAccounts(this.navigationState);
                    exportMethod.initialColumns = this.displayedColumns.map((col) => col.ColumnName);
                    this.dstSettings = {
                        displayedColumns: this.displayedColumns,
                        dataSource: data,
                        entitySchema: this.entitySchemaUnsAccount,
                        navigationState: this.navigationState,
                        filters: this.filterOptions,
                        filterTree: isInitialLoad
                            ? undefined
                            : {
                                filterMethode: (parentkey) => __awaiter(this, void 0, void 0, function* () {
                                    return this.accountsService.getFilterTree({
                                        parentkey,
                                        container: getParams.container,
                                        system: getParams.system,
                                        filter: getParams.filter,
                                    });
                                }),
                                multiSelect: false,
                            },
                        dataModel: this.dataModel,
                        viewConfig: this.viewConfig,
                        exportMethod,
                    };
                    this.tableName = data.tableName;
                    this.logger.debug(this, `Head at ${((_a = data === null || data === void 0 ? void 0 : data.Data) === null || _a === void 0 ? void 0 : _a.length) + ((_b = this.navigationState) === null || _b === void 0 ? void 0 : _b.StartIndex)} of ${data === null || data === void 0 ? void 0 : data.totalCount} item(s)`);
                }
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
    viewAccount(data) {
        return __awaiter(this, void 0, void 0, function* () {
            this.logger.debug(this, `Viewing account`);
            this.logger.trace(this, `Account selected`, data.selectedAccount);
            const sidesheetRef = this.sideSheet.open(AccountSidesheetComponent, {
                title: yield this.translateProvider.get('#LDS#Heading Edit User Account').toPromise(),
                subTitle: data.selectedAccount.GetEntity().GetDisplay(),
                padding: '0px',
                width: 'max(600px, 60%)',
                icon: 'account',
                testId: 'edit-user-account-sidesheet',
                data,
            });
            sidesheetRef.afterClosed().subscribe((dataRefreshRequired) => {
                if (dataRefreshRequired) {
                    this.navigate();
                }
            });
        });
    }
}
DataExplorerAccountsComponent.ɵfac = function DataExplorerAccountsComponent_Factory(t) { return new (t || DataExplorerAccountsComponent)(i0.ɵɵdirectiveInject(i7$1.TranslateService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.ClassloggerService), i0.ɵɵdirectiveInject(AccountsService), i0.ɵɵdirectiveInject(DeHelperService), i0.ɵɵdirectiveInject(i1.ViewConfigService), i0.ɵɵdirectiveInject(i2.SettingsService)); };
DataExplorerAccountsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DataExplorerAccountsComponent, selectors: [["imx-data-explorer-accounts"]], viewQuery: function DataExplorerAccountsComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(_c0$2, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.dataExplorerFilters = _t.first);
        }
    }, inputs: { applyIssuesFilter: "applyIssuesFilter", issuesFilterMode: "issuesFilterMode", targetSystemData: "targetSystemData" }, decls: 16, vars: 19, consts: [[1, "data-explorer", "data-explorer--accounts"], ["class", "data-explorer-card-header", 4, "ngIf"], [3, "settings", "options", "hiddenFilters", "busyService", "searchBoxText", "navigationStateChanged", "filterTreeSelectionChanged", "search", "customSelectedFilterRemoved", "updateConfig", "deleteConfigById"], ["dst", ""], ["imx-data-source-toolbar-custom-filter", "", 3, "click"], [3, "targetSystemData", "dst", "treeDbWrapper", "selectedFiltersChanged"], ["dataExplorerFilters", ""], [4, "ngIf"], ["class", "sync-status-alert", "type", "info", "condensed", "true", 3, "colored", 4, "ngIf"], ["class", "imx-data-explorer-content", 4, "ngIf"], [1, "data-explorer-bottom-button-row"], ["mat-stroked-button", "", "data-imx-identifier", "accounts-button-show-report-for-targetsystem", 3, "click"], ["icon", "reports"], [1, "data-explorer-card-header"], [1, "data-explorer-card-header-bg"], ["translate", ""], [3, "contextId"], [3, "mode"], ["type", "info", "condensed", "true", 1, "sync-status-alert", 3, "colored"], [1, "imx-data-explorer-content"], [1, "data-explorer-table"], ["detailViewVisible", "false", "mode", "manual", 3, "dst", "highlightedEntityChanged"], ["width", "500px", 3, "entityColumn"], ["width", "300px", 3, "entityColumn"], [3, "entityColumn"], ["alignHeader", "center", "alignContent", "center", 3, "columnName"], [3, "dst"], [1, "imx-ellipse-column"], ["subtitle", ""], ["color", "gray"]], template: function DataExplorerAccountsComponent_Template(rf, ctx) {
        if (rf & 1) {
            const _r18 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "mat-card", 0);
            i0.ɵɵtemplate(1, DataExplorerAccountsComponent_div_1_Template, 5, 1, "div", 1);
            i0.ɵɵelementStart(2, "imx-data-source-toolbar", 2, 3);
            i0.ɵɵlistener("navigationStateChanged", function DataExplorerAccountsComponent_Template_imx_data_source_toolbar_navigationStateChanged_2_listener($event) { return ctx.onNavigationStateChanged($event); })("filterTreeSelectionChanged", function DataExplorerAccountsComponent_Template_imx_data_source_toolbar_filterTreeSelectionChanged_2_listener($event) { return ctx.filterByTree($event); })("search", function DataExplorerAccountsComponent_Template_imx_data_source_toolbar_search_2_listener($event) { return ctx.onSearch($event); })("customSelectedFilterRemoved", function DataExplorerAccountsComponent_Template_imx_data_source_toolbar_customSelectedFilterRemoved_2_listener($event) { i0.ɵɵrestoreView(_r18); const _r2 = i0.ɵɵreference(7); return i0.ɵɵresetView(_r2.onCustomFilterClearedExternally($event)); })("updateConfig", function DataExplorerAccountsComponent_Template_imx_data_source_toolbar_updateConfig_2_listener($event) { return ctx.updateConfig($event); })("deleteConfigById", function DataExplorerAccountsComponent_Template_imx_data_source_toolbar_deleteConfigById_2_listener($event) { return ctx.deleteConfigById($event); });
            i0.ɵɵpipe(4, "translate");
            i0.ɵɵelementStart(5, "div", 4);
            i0.ɵɵlistener("click", function DataExplorerAccountsComponent_Template_div_click_5_listener($event) { return $event.stopPropagation(); });
            i0.ɵɵelementStart(6, "imx-target-system-filter", 5, 6);
            i0.ɵɵlistener("selectedFiltersChanged", function DataExplorerAccountsComponent_Template_imx_target_system_filter_selectedFiltersChanged_6_listener() { return ctx.onNavigationStateChanged(); });
            i0.ɵɵelementEnd()()();
            i0.ɵɵtemplate(8, DataExplorerAccountsComponent_div_8_Template, 2, 1, "div", 7);
            i0.ɵɵtemplate(9, DataExplorerAccountsComponent_eui_alert_9_Template, 3, 1, "eui-alert", 8);
            i0.ɵɵtemplate(10, DataExplorerAccountsComponent_div_10_Template, 13, 7, "div", 9);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(11, "div", 10)(12, "button", 11);
            i0.ɵɵlistener("click", function DataExplorerAccountsComponent_Template_button_click_12_listener() { return ctx.openReportOptionsSidesheet(); });
            i0.ɵɵelement(13, "eui-icon", 12);
            i0.ɵɵtext(14);
            i0.ɵɵpipe(15, "translate");
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r1 = i0.ɵɵreference(3);
            const _r2 = i0.ɵɵreference(7);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !_r2.showTsSyncStatus);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(17, _c1))("hiddenFilters", i0.ɵɵpureFunction0(18, _c2))("busyService", ctx.busyService)("searchBoxText", i0.ɵɵpipeBind1(4, 13, "#LDS#Search"));
            i0.ɵɵadvance(4);
            i0.ɵɵproperty("targetSystemData", ctx.targetSystemData)("dst", _r1)("treeDbWrapper", ctx.treeDbWrapper);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", _r2.showTsSyncStatus);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", _r2.showTsSyncAlert);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", !_r2.showTsSyncStatus);
            i0.ɵɵadvance(4);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(15, 15, "#LDS#Download target system report"), " ");
        }
    }, dependencies: [DataExplorerFiltersComponent, DataExplorerNoDataComponent, i7.NgIf, i1$1.EuiAlertComponent, i1$1.EuiBadgeComponent, i1$1.EuiIconComponent, i8.MatButton, i10$1.MatCard, i7$1.TranslateDirective, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent, i2.HelpContextualComponent, i7$1.TranslatePipe], styles: [".data-explorer.data-explorer--accounts[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:nth-child(2){flex:0 0 auto}.data-explorer.data-explorer--accounts[_ngcontent-%COMP%]   .imx-data-explorer-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.eui-dark-theme   [_nghost-%COMP%]{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .data-explorer.data-explorer--accounts[_ngcontent-%COMP%]   .data-explorer-card-header[_ngcontent-%COMP%]   .data-explorer-card-header-bg[_ngcontent-%COMP%]{background-color:#016b91}div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}.imx-ellipse-column[_ngcontent-%COMP%]{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.data-explorer-bottom-button-row[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:flex-end;margin-top:15px;align-self:end}.data-explorer-bottom-button-row[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.hidden[_ngcontent-%COMP%]{display:none}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .data-explorer.data-explorer--accounts[_ngcontent-%COMP%]   .data-explorer-card-header[_ngcontent-%COMP%]   .data-explorer-card-header-bg[_ngcontent-%COMP%]{background-color:#000}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataExplorerAccountsComponent, [{
            type: Component,
            args: [{ selector: 'imx-data-explorer-accounts', template: "<mat-card class=\"data-explorer data-explorer--accounts\">\r\n  <div *ngIf=\"!dataExplorerFilters.showTsSyncStatus\" class=\"data-explorer-card-header\">\r\n    <div class=\"data-explorer-card-header-bg\">\r\n      <h3 translate>#LDS#Heading User Accounts</h3>\r\n      <imx-help-contextual [contextId]=\"contextId\"></imx-help-contextual>\r\n    </div>\r\n  </div>\r\n\r\n  <imx-data-source-toolbar\r\n    #dst\r\n    [settings]=\"dstSettings\"\r\n    [options]=\"['search', 'sort', 'filter', 'filterTree', 'settings']\"\r\n    [hiddenFilters]=\"['namespace']\"\r\n    [busyService]=\"busyService\"\r\n    [searchBoxText]=\"'#LDS#Search' | translate\"\r\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n    (filterTreeSelectionChanged)=\"filterByTree($event)\"\r\n    (search)=\"onSearch($event)\"\r\n    (customSelectedFilterRemoved)=\"dataExplorerFilters.onCustomFilterClearedExternally($event)\"\r\n    (updateConfig)=\"updateConfig($event)\"\r\n    (deleteConfigById)=\"deleteConfigById($event)\"\r\n  >\r\n    <div imx-data-source-toolbar-custom-filter (click)=\"$event.stopPropagation()\">\r\n      <imx-target-system-filter\r\n        #dataExplorerFilters\r\n        [targetSystemData]=\"targetSystemData\"\r\n        (selectedFiltersChanged)=\"onNavigationStateChanged()\"\r\n        [dst]=\"dst\"\r\n        [treeDbWrapper]=\"treeDbWrapper\"\r\n      ></imx-target-system-filter>\r\n    </div>\r\n  </imx-data-source-toolbar>\r\n\r\n  <div *ngIf=\"dataExplorerFilters.showTsSyncStatus\">\r\n    <imx-data-explorer-no-data [mode]=\"dataExplorerFilters.tsIssueMode\"></imx-data-explorer-no-data>\r\n  </div>\r\n\r\n  <eui-alert class=\"sync-status-alert\" type=\"info\" condensed=\"true\" [colored]=\"true\" *ngIf=\"dataExplorerFilters.showTsSyncAlert\">\r\n    <span translate>#LDS#There is currently no data synchronization configured for the selected domain.</span>\r\n  </eui-alert>\r\n\r\n  <div *ngIf=\"!dataExplorerFilters.showTsSyncStatus\" class=\"imx-data-explorer-content\">\r\n    <div class=\"data-explorer-table\">\r\n      <imx-data-table [dst]=\"dst\" (highlightedEntityChanged)=\"onAccountChanged($event)\" detailViewVisible=\"false\" mode=\"manual\">\r\n        <imx-data-table-column width=\"500px\" [entityColumn]=\"entitySchemaUnsAccount?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n          <ng-template let-item>\r\n            <div [style.max-width]=\"'500px'\" class=\"imx-ellipse-column\">{{ item.GetEntity().GetDisplay() }}</div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n        <imx-data-table-column width=\"300px\" [entityColumn]=\"entitySchemaUnsAccount?.Columns.UID_Person\">\r\n          <ng-template let-item>\r\n            <div [style.max-width]=\"'300px'\" class=\"imx-ellipse-column\">{{ item.UID_Person.Column.GetDisplayValue() }}</div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchemaUnsAccount?.Columns.AccountDisabled\"> </imx-data-table-column>\r\n        <imx-data-table-column [entityColumn]=\"entitySchemaUnsAccount?.Columns.UID_UNSRoot\">\r\n          <ng-template let-item>\r\n            <div>{{ item.UID_UNSRoot.Column.GetDisplayValue() }}</div>\r\n            <div subtitle>{{ item.UID_DPRNameSpace.Column.GetDisplayValue() }}</div>\r\n          </ng-template>\r\n        </imx-data-table-column>\r\n        <imx-data-table-generic-column alignHeader=\"center\" alignContent=\"center\" [columnName]=\"entitySchemaUnsAccount?.Columns.XMarkedForDeletion.ColumnName\">\r\n          <ng-template let-item>\r\n            <div *ngIf=\"item.XMarkedForDeletion.value !== 0\">\r\n              <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\r\n            </div>\r\n          </ng-template>\r\n        </imx-data-table-generic-column>\r\n      </imx-data-table>\r\n      <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n    </div>\r\n  </div>\r\n</mat-card>\r\n<div class=\"data-explorer-bottom-button-row\">\r\n  <button mat-stroked-button data-imx-identifier=\"accounts-button-show-report-for-targetsystem\" (click)=\"openReportOptionsSidesheet()\">\r\n    <eui-icon icon=\"reports\"></eui-icon>\r\n    {{ '#LDS#Download target system report' | translate }}\r\n  </button>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.data-explorer.data-explorer--accounts>:nth-child(2){flex:0 0 auto}.data-explorer.data-explorer--accounts .imx-data-explorer-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.eui-dark-theme :host{background-color:#2f3233}.eui-dark-theme :host .data-explorer.data-explorer--accounts .data-explorer-card-header .data-explorer-card-header-bg{background-color:#016b91}div[subtitle]{font-size:smaller;color:#919799}.imx-ellipse-column{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.data-explorer-bottom-button-row{display:flex;flex-direction:row;align-items:flex-end;margin-top:15px;align-self:end}.data-explorer-bottom-button-row .mat-stroked-button eui-icon{font-size:14px;margin-right:4px}.hidden{display:none}.eui-contrast-theme :host{background-color:#000}.eui-contrast-theme :host .data-explorer.data-explorer--accounts .data-explorer-card-header .data-explorer-card-header-bg{background-color:#000}\n"] }]
        }], function () { return [{ type: i7$1.TranslateService }, { type: i1$1.EuiSidesheetService }, { type: i2.ClassloggerService }, { type: AccountsService }, { type: DeHelperService }, { type: i1.ViewConfigService }, { type: i2.SettingsService }]; }, { applyIssuesFilter: [{
                type: Input
            }], issuesFilterMode: [{
                type: Input
            }], targetSystemData: [{
                type: Input
            }], dataExplorerFilters: [{
                type: ViewChild,
                args: ['dataExplorerFilters', { static: false }]
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class DataFiltersModule {
}
DataFiltersModule.ɵfac = function DataFiltersModule_Factory(t) { return new (t || DataFiltersModule)(); };
DataFiltersModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: DataFiltersModule });
DataFiltersModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        RouterModule,
        MatExpansionModule,
        MatIconModule,
        MatSidenavModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule,
        LdsReplaceModule,
        DataTreeModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DataFiltersModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        DataExplorerFiltersComponent
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        CdrModule,
                        RouterModule,
                        MatExpansionModule,
                        MatIconModule,
                        MatSidenavModule,
                        TranslateModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        LdsReplaceModule,
                        DataTreeModule
                    ],
                    providers: [],
                    exports: [
                        DataExplorerFiltersComponent
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(DataFiltersModule, { declarations: [DataExplorerFiltersComponent], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            CdrModule,
            RouterModule,
            MatExpansionModule,
            MatIconModule,
            MatSidenavModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule,
            LdsReplaceModule,
            DataTreeModule], exports: [DataExplorerFiltersComponent] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class NoDataModule {
}
NoDataModule.ɵfac = function NoDataModule_Factory(t) { return new (t || NoDataModule)(); };
NoDataModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: NoDataModule });
NoDataModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        EuiCoreModule,
        TranslateModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(NoDataModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        DataExplorerNoDataComponent
                    ],
                    exports: [
                        DataExplorerNoDataComponent
                    ],
                    imports: [
                        CommonModule,
                        EuiCoreModule,
                        TranslateModule
                    ]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(NoDataModule, { declarations: [DataExplorerNoDataComponent], imports: [CommonModule,
            EuiCoreModule,
            TranslateModule], exports: [DataExplorerNoDataComponent] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GroupMembershipsExtService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    get portalPersonGroupmembershipsSchema() {
        return this.apiService.typedClient.PortalPersonGroupmemberships.GetSchema();
    }
    getGroupMemberships(uid, parameters) {
        return this.apiService.typedClient.PortalPersonGroupmemberships.Get(uid, parameters);
    }
}
GroupMembershipsExtService.ɵfac = function GroupMembershipsExtService_Factory(t) { return new (t || GroupMembershipsExtService)(i0.ɵɵinject(TsbApiService)); };
GroupMembershipsExtService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GroupMembershipsExtService, factory: GroupMembershipsExtService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupMembershipsExtService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: TsbApiService }]; }, null);
})();

function GroupMembershipsExtComponent_ng_template_9_div_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 11);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r3 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", item_r3.GetEntity().GetDisplayLong(), " ");
    }
}
function GroupMembershipsExtComponent_ng_template_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 9);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵtemplate(2, GroupMembershipsExtComponent_ng_template_9_div_2_Template, 2, 1, "div", 10);
    }
    if (rf & 2) {
        const item_r3 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r3.GetEntity().GetDisplay());
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngIf", item_r3.GetEntity().GetDisplay() !== item_r3.GetEntity().GetDisplayLong());
    }
}
function GroupMembershipsExtComponent_imx_data_table_column_10_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "imx-data-table-column", 6);
    }
    if (rf & 2) {
        const displayColumn_r6 = ctx.$implicit;
        i0.ɵɵproperty("entityColumn", displayColumn_r6);
    }
}
const _c0$1 = function () { return ["search"]; };
class GroupMembershipsExtComponent {
    constructor(settingService, groupService, translate, sidesheet, dataProvider) {
        this.settingService = settingService;
        this.groupService = groupService;
        this.translate = translate;
        this.sidesheet = sidesheet;
        this.DisplayColumns = DisplayColumns;
        this.displayColumns = [];
        this.displayedColumnsWithDisplay = [];
        this.busyService = new BusyService();
        this.referrer = dataProvider === null || dataProvider === void 0 ? void 0 : dataProvider.data;
        this.navigationState = { PageSize: this.settingService.DefaultPageSize };
        this.entitySchema = groupService.portalPersonGroupmembershipsSchema;
        this.displayColumns = [
            this.entitySchema.Columns.XOrigin,
            this.entitySchema.Columns.XDateInserted,
            this.entitySchema.Columns.OrderState,
            this.entitySchema.Columns.ValidUntil,
        ];
        this.displayedColumnsWithDisplay = [...[this.entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]], ...this.displayColumns];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.getData();
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.getData();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.getData();
        });
    }
    onShowDetails(entity) {
        return __awaiter(this, void 0, void 0, function* () {
            const unsGroupId = DbObjectKey.FromXml(entity.ObjectKeyGroup.value);
            const data = {
                UID_Person: this.referrer.objectuid,
                Type: SourceDetectiveType.MembershipOfSystemEntitlement,
                UID: unsGroupId.Keys[0],
                TableName: unsGroupId.TableName,
            };
            this.sidesheet.open(SourceDetectiveSidesheetComponent, {
                title: yield this.translate.get('#LDS#Heading View Assignment Analysis').toPromise(),
                subTitle: entity.GetEntity().GetDisplay(),
                padding: '0px',
                width: '800px',
                disableClose: false,
                testId: 'group-membership-assingment-analysis',
                data,
            });
        });
    }
    getData() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const groupsPerIdentity = yield this.groupService.getGroupMemberships(this.referrer.objectuid, this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayedColumnsWithDisplay,
                    dataSource: groupsPerIdentity,
                    entitySchema: this.entitySchema,
                    navigationState: this.navigationState,
                };
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
}
GroupMembershipsExtComponent.ɵfac = function GroupMembershipsExtComponent_Factory(t) { return new (t || GroupMembershipsExtComponent)(i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(GroupMembershipsExtService), i0.ɵɵdirectiveInject(i7$1.TranslateService), i0.ɵɵdirectiveInject(i1$1.EuiSidesheetService), i0.ɵɵdirectiveInject(i2.DynamicTabDataProviderDirective)); };
GroupMembershipsExtComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GroupMembershipsExtComponent, selectors: [["ng-component"]], inputs: { referrer: "referrer" }, decls: 12, vars: 13, consts: [["condensed", "true", "type", "info", 1, "helper-alert", 3, "colored", "dismissable"], [1, "imx-memberships"], [3, "settings", "busyService", "options", "navigationStateChanged", "search"], ["dst", ""], [1, "imx-membership-table"], ["detailViewVisible", "false", "data-imx-identifier", "group-memberships-ext-table", "mode", "manual", 3, "dst", "highlightedEntityChanged"], [3, "entityColumn"], [3, "entityColumn", 4, "ngFor", "ngForOf"], [3, "dst"], ["data-imx-identifier", "group-memberships-ext-tabledata-display"], ["subtitle", "", 4, "ngIf"], ["subtitle", ""]], template: function GroupMembershipsExtComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "eui-alert", 0);
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "mat-card", 1)(4, "imx-data-source-toolbar", 2, 3);
            i0.ɵɵlistener("navigationStateChanged", function GroupMembershipsExtComponent_Template_imx_data_source_toolbar_navigationStateChanged_4_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function GroupMembershipsExtComponent_Template_imx_data_source_toolbar_search_4_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(6, "div", 4)(7, "imx-data-table", 5);
            i0.ɵɵlistener("highlightedEntityChanged", function GroupMembershipsExtComponent_Template_imx_data_table_highlightedEntityChanged_7_listener($event) { return ctx.onShowDetails($event); });
            i0.ɵɵelementStart(8, "imx-data-table-column", 6);
            i0.ɵɵtemplate(9, GroupMembershipsExtComponent_ng_template_9_Template, 3, 2, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(10, GroupMembershipsExtComponent_imx_data_table_column_10_Template, 1, 1, "imx-data-table-column", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(11, "imx-data-source-paginator", 8);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(5);
            i0.ɵɵproperty("colored", true)("dismissable", false);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 10, "#LDS#Here you can get an overview of the memberships of the identity. Additionally, you can view the assignment analysis for each membership."), "\n");
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("settings", ctx.dstSettings)("busyService", ctx.busyService)("options", i0.ɵɵpureFunction0(12, _c0$1));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchema.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngForOf", ctx.displayColumns);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i7.NgForOf, i7.NgIf, i1$1.EuiAlertComponent, i10$1.MatCard, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i7$1.TranslatePipe], styles: ["[_nghost-%COMP%]{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-memberships[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-membership-table[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;margin-top:20px}.helper-alert[_ngcontent-%COMP%]{margin:20px 2px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupMembershipsExtComponent, [{
            type: Component,
            args: [{ template: "<eui-alert class=\"helper-alert\" condensed=\"true\" [colored]=\"true\" type=\"info\" [dismissable]=\"false\">\r\n  {{ '#LDS#Here you can get an overview of the memberships of the identity. Additionally, you can view the assignment analysis for each membership.' | translate }}\r\n</eui-alert>\r\n<mat-card class=\"imx-memberships\">\r\n  <imx-data-source-toolbar\r\n    #dst\r\n    [settings]=\"dstSettings\"\r\n    [busyService]=\"busyService\"\r\n    [options]=\"['search']\"\r\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\"\r\n    (search)=\"onSearch($event)\"\r\n  ></imx-data-source-toolbar>\r\n\r\n  <div class=\"imx-membership-table\">\r\n    <imx-data-table [dst]=\"dst\" detailViewVisible=\"false\" data-imx-identifier=\"group-memberships-ext-table\" (highlightedEntityChanged)=\"onShowDetails($event)\" mode=\"manual\">\r\n      <imx-data-table-column [entityColumn]=\"entitySchema.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n        <ng-template let-item>\r\n          <div data-imx-identifier=\"group-memberships-ext-tabledata-display\">{{ item.GetEntity().GetDisplay() }}</div>\r\n          <div *ngIf=\"item.GetEntity().GetDisplay() !== item.GetEntity().GetDisplayLong()\" subtitle>\r\n            {{ item.GetEntity().GetDisplayLong() }}\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-column>\r\n      <imx-data-table-column *ngFor=\"let displayColumn of displayColumns\" [entityColumn]=\"displayColumn\"> </imx-data-table-column>\r\n    </imx-data-table>\r\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n  </div>\r\n</mat-card>\r\n", styles: [":host{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-memberships{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-membership-table{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;margin-top:20px}.helper-alert{margin:20px 2px}\n"] }]
        }], function () { return [{ type: i2.SettingsService }, { type: GroupMembershipsExtService }, { type: i7$1.TranslateService }, { type: i1$1.EuiSidesheetService }, { type: i2.DynamicTabDataProviderDirective }]; }, { referrer: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class GroupsModule {
}
GroupsModule.ɵfac = function GroupsModule_Factory(t) { return new (t || GroupsModule)(); };
GroupsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: GroupsModule });
GroupsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        ExtModule,
        CdrModule,
        RouterModule,
        ObjectHyperviewModule,
        OwnerControlModule,
        BusyIndicatorModule,
        ServiceItemsEditFormModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule,
        LdsReplaceModule,
        DataFiltersModule,
        NoDataModule,
        DataTreeModule,
        DynamicTabsModule,
        ObjectHistoryModule,
        IdentityRoleMembershipsModule,
        SelectedElementsModule,
        HelpContextualModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GroupsModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        DataExplorerGroupsComponent,
                        GroupSidesheetComponent,
                        GroupMembersComponent,
                        ChildSystemEntitlementsComponent,
                        ProductOwnerSidesheetComponent,
                        GroupMembershipsExtComponent,
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        ExtModule,
                        CdrModule,
                        RouterModule,
                        ObjectHyperviewModule,
                        OwnerControlModule,
                        BusyIndicatorModule,
                        ServiceItemsEditFormModule,
                        TranslateModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        LdsReplaceModule,
                        DataFiltersModule,
                        NoDataModule,
                        DataTreeModule,
                        DynamicTabsModule,
                        ObjectHistoryModule,
                        IdentityRoleMembershipsModule,
                        SelectedElementsModule,
                        HelpContextualModule
                    ],
                    exports: [DataExplorerGroupsComponent, ChildSystemEntitlementsComponent],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(GroupsModule, { declarations: [DataExplorerGroupsComponent,
            GroupSidesheetComponent,
            GroupMembersComponent,
            ChildSystemEntitlementsComponent,
            ProductOwnerSidesheetComponent,
            GroupMembershipsExtComponent], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            ExtModule,
            CdrModule,
            RouterModule,
            ObjectHyperviewModule,
            OwnerControlModule,
            BusyIndicatorModule,
            ServiceItemsEditFormModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule,
            LdsReplaceModule,
            DataFiltersModule,
            NoDataModule,
            DataTreeModule,
            DynamicTabsModule,
            ObjectHistoryModule,
            IdentityRoleMembershipsModule,
            SelectedElementsModule,
            HelpContextualModule], exports: [DataExplorerGroupsComponent, ChildSystemEntitlementsComponent] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountsExtService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    get portalPersonAccountsSchema() {
        return this.apiService.typedClient.PortalPersonAccounts.GetSchema();
    }
    getAccounts(uid, parameters) {
        return this.apiService.typedClient.PortalPersonAccounts.Get(uid, parameters);
    }
}
AccountsExtService.ɵfac = function AccountsExtService_Factory(t) { return new (t || AccountsExtService)(i0.ɵɵinject(TsbApiService)); };
AccountsExtService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: AccountsExtService, factory: AccountsExtService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsExtService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: TsbApiService }]; }, null);
})();

function AccountsExtComponent_ng_template_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 10);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r4 = ctx.$implicit;
        i0.ɵɵstyleProp("max-width", "500px");
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r4.GetEntity().GetDisplay());
    }
}
function AccountsExtComponent_ng_template_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div");
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵelementStart(2, "div", 11);
        i0.ɵɵtext(3);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const item_r5 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(item_r5.UID_UNSRoot.Column.GetDisplayValue());
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r5.UID_DPRNameSpace.Column.GetDisplayValue());
    }
}
function AccountsExtComponent_ng_template_11_div_0_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "div")(1, "eui-badge", 13);
        i0.ɵɵtext(2);
        i0.ɵɵelementEnd()();
    }
    if (rf & 2) {
        const item_r6 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate(item_r6.XMarkedForDeletion.Column.GetDisplayValue());
    }
}
function AccountsExtComponent_ng_template_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵtemplate(0, AccountsExtComponent_ng_template_11_div_0_Template, 3, 1, "div", 12);
    }
    if (rf & 2) {
        const item_r6 = ctx.$implicit;
        i0.ɵɵproperty("ngIf", item_r6.XMarkedForDeletion.value !== 0);
    }
}
const _c0 = function () { return ["search"]; };
class AccountsExtComponent {
    constructor(settingService, accountsService, dataProvider) {
        this.settingService = settingService;
        this.accountsService = accountsService;
        this.DisplayColumns = DisplayColumns;
        this.busyService = new BusyService();
        this.displayColumns = [];
        this.referrer = dataProvider === null || dataProvider === void 0 ? void 0 : dataProvider.data;
        this.navigationState = { PageSize: this.settingService.DefaultPageSize };
        this.entitySchemaAccount = accountsService.portalPersonAccountsSchema;
        /** if you like to add columns, please check {@link DataExplorerAccountsComponent | Accounts Component} as well */
        this.displayColumns = [
            this.entitySchemaAccount.Columns[DisplayColumns.DISPLAY_PROPERTYNAME],
            this.entitySchemaAccount.Columns.UID_UNSRoot,
            this.entitySchemaAccount.Columns.AccountDisabled,
            this.entitySchemaAccount.Columns.XMarkedForDeletion,
        ];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.getData();
        });
    }
    onNavigationStateChanged(newState) {
        return __awaiter(this, void 0, void 0, function* () {
            if (newState) {
                this.navigationState = newState;
            }
            yield this.getData();
        });
    }
    onSearch(keywords) {
        return __awaiter(this, void 0, void 0, function* () {
            this.navigationState.StartIndex = 0;
            this.navigationState.search = keywords;
            yield this.getData();
        });
    }
    getData() {
        return __awaiter(this, void 0, void 0, function* () {
            const isBusy = this.busyService.beginBusy();
            try {
                const groupsPerIdentity = yield this.accountsService.getAccounts(this.referrer.objectuid, this.navigationState);
                this.dstSettings = {
                    displayedColumns: this.displayColumns,
                    dataSource: groupsPerIdentity,
                    entitySchema: this.entitySchemaAccount,
                    navigationState: this.navigationState,
                };
            }
            finally {
                isBusy.endBusy();
            }
        });
    }
}
AccountsExtComponent.ɵfac = function AccountsExtComponent_Factory(t) { return new (t || AccountsExtComponent)(i0.ɵɵdirectiveInject(i2.SettingsService), i0.ɵɵdirectiveInject(AccountsExtService), i0.ɵɵdirectiveInject(i2.DynamicTabDataProviderDirective)); };
AccountsExtComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: AccountsExtComponent, selectors: [["ng-component"]], inputs: { referrer: "referrer" }, decls: 13, vars: 10, consts: [[1, "imx-memberships"], [3, "settings", "options", "busyService", "navigationStateChanged", "search"], ["dst", ""], [1, "imx-membership-table"], ["detailViewVisible", "false", "data-imx-identifier", "identity-memberships-table", "mode", "manual", 3, "dst"], ["width", "500px", 3, "entityColumn"], ["align", "center", 3, "entityColumn"], [3, "entityColumn"], ["alignHeader", "center", "alignContent", "center", 3, "columnName"], [3, "dst"], [1, "imx-ellipse-column"], ["subtitle", ""], [4, "ngIf"], ["color", "gray"]], template: function AccountsExtComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-card", 0)(1, "imx-data-source-toolbar", 1, 2);
            i0.ɵɵlistener("navigationStateChanged", function AccountsExtComponent_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { return ctx.onNavigationStateChanged($event); })("search", function AccountsExtComponent_Template_imx_data_source_toolbar_search_1_listener($event) { return ctx.onSearch($event); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 3)(4, "imx-data-table", 4)(5, "imx-data-table-column", 5);
            i0.ɵɵtemplate(6, AccountsExtComponent_ng_template_6_Template, 2, 3, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelement(7, "imx-data-table-column", 6);
            i0.ɵɵelementStart(8, "imx-data-table-column", 7);
            i0.ɵɵtemplate(9, AccountsExtComponent_ng_template_9_Template, 4, 2, "ng-template");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "imx-data-table-generic-column", 8);
            i0.ɵɵtemplate(11, AccountsExtComponent_ng_template_11_Template, 1, 1, "ng-template");
            i0.ɵɵelementEnd()();
            i0.ɵɵelement(12, "imx-data-source-paginator", 9);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            const _r0 = i0.ɵɵreference(2);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("settings", ctx.dstSettings)("options", i0.ɵɵpureFunction0(9, _c0))("busyService", ctx.busyService);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("dst", _r0);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAccount == null ? null : ctx.entitySchemaAccount.Columns[ctx.DisplayColumns.DISPLAY_PROPERTYNAME]);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAccount == null ? null : ctx.entitySchemaAccount.Columns.AccountDisabled);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("entityColumn", ctx.entitySchemaAccount == null ? null : ctx.entitySchemaAccount.Columns.UID_UNSRoot);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("columnName", ctx.entitySchemaAccount == null ? null : ctx.entitySchemaAccount.Columns.XMarkedForDeletion.ColumnName);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("dst", _r0);
        }
    }, dependencies: [i7.NgIf, i1$1.EuiBadgeComponent, i10$1.MatCard, i2.DataSourceToolbarComponent, i2.DataSourcePaginatorComponent, i2.DataTableComponent, i2.DataTableColumnComponent, i2.DataTableGenericColumnComponent], styles: [".data-explorer.data-explorer--accounts[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:nth-child(2){flex:0 0 auto}.data-explorer.data-explorer--accounts[_ngcontent-%COMP%]   .imx-data-explorer-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.eui-dark-theme   [_nghost-%COMP%]{background-color:#2f3233}.eui-dark-theme   [_nghost-%COMP%]   .data-explorer.data-explorer--accounts[_ngcontent-%COMP%]   .data-explorer-card-header[_ngcontent-%COMP%]   .data-explorer-card-header-bg[_ngcontent-%COMP%]{background-color:#016b91}div[subtitle][_ngcontent-%COMP%]{font-size:smaller;color:#919799}.imx-ellipse-column[_ngcontent-%COMP%]{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.data-explorer-bottom-button-row[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:flex-end;margin-top:15px;align-self:end}.data-explorer-bottom-button-row[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]   eui-icon[_ngcontent-%COMP%]{font-size:14px;margin-right:4px}.hidden[_ngcontent-%COMP%]{display:none}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}.eui-contrast-theme   [_nghost-%COMP%]   .data-explorer.data-explorer--accounts[_ngcontent-%COMP%]   .data-explorer-card-header[_ngcontent-%COMP%]   .data-explorer-card-header-bg[_ngcontent-%COMP%]{background-color:#000}", "[_nghost-%COMP%]{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-memberships[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-membership-table[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;margin-top:20px}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsExtComponent, [{
            type: Component,
            args: [{ template: "<mat-card class=\"imx-memberships\">\r\n  \r\n  <imx-data-source-toolbar #dst [settings]=\"dstSettings\" [options]=\"['search']\" [busyService]=\"busyService\"\r\n    (navigationStateChanged)=\"onNavigationStateChanged($event)\" (search)=\"onSearch($event)\">\r\n  </imx-data-source-toolbar>\r\n\r\n  <div class=\"imx-membership-table\">\r\n    <imx-data-table [dst]=\"dst\" detailViewVisible=\"false\" data-imx-identifier=\"identity-memberships-table\"\r\n      mode=\"manual\">\r\n      <imx-data-table-column width=\"500px\" [entityColumn]=\"entitySchemaAccount?.Columns[DisplayColumns.DISPLAY_PROPERTYNAME]\">\r\n        <ng-template let-item>\r\n          <div [style.max-width]=\"'500px'\" class=\"imx-ellipse-column\">{{item.GetEntity().GetDisplay()}}</div>\r\n        </ng-template>\r\n      </imx-data-table-column>\r\n      <imx-data-table-column align=\"center\"\r\n        [entityColumn]=\"entitySchemaAccount?.Columns.AccountDisabled\">\r\n      </imx-data-table-column>\r\n      <imx-data-table-column [entityColumn]=\"entitySchemaAccount?.Columns.UID_UNSRoot\">\r\n        <ng-template let-item>\r\n          <div>{{item.UID_UNSRoot.Column.GetDisplayValue()}}</div>\r\n          <div subtitle >{{item.UID_DPRNameSpace.Column.GetDisplayValue()}}</div>\r\n        </ng-template>\r\n      </imx-data-table-column>\r\n      <imx-data-table-generic-column alignHeader=\"center\" alignContent=\"center\"\r\n        [columnName]=\"entitySchemaAccount?.Columns.XMarkedForDeletion.ColumnName\">\r\n        <ng-template let-item>\r\n          <div *ngIf=\"item.XMarkedForDeletion.value !== 0\">\r\n            <eui-badge color=\"gray\">{{ item.XMarkedForDeletion.Column.GetDisplayValue() }}</eui-badge>\r\n          </div>\r\n        </ng-template>\r\n      </imx-data-table-generic-column>\r\n    </imx-data-table>\r\n    <imx-data-source-paginator [dst]=\"dst\"></imx-data-source-paginator>\r\n  </div>\r\n</mat-card>", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */.data-explorer.data-explorer--accounts>:nth-child(2){flex:0 0 auto}.data-explorer.data-explorer--accounts .imx-data-explorer-content{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.eui-dark-theme :host{background-color:#2f3233}.eui-dark-theme :host .data-explorer.data-explorer--accounts .data-explorer-card-header .data-explorer-card-header-bg{background-color:#016b91}div[subtitle]{font-size:smaller;color:#919799}.imx-ellipse-column{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.data-explorer-bottom-button-row{display:flex;flex-direction:row;align-items:flex-end;margin-top:15px;align-self:end}.data-explorer-bottom-button-row .mat-stroked-button eui-icon{font-size:14px;margin-right:4px}.hidden{display:none}.eui-contrast-theme :host{background-color:#000}.eui-contrast-theme :host .data-explorer.data-explorer--accounts .data-explorer-card-header .data-explorer-card-header-bg{background-color:#000}\n", "/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{overflow:hidden;display:flex;flex-direction:column;height:100%}.imx-memberships{flex:1 1 auto;display:flex;flex-direction:column;overflow:hidden}.imx-membership-table{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto;margin-top:20px}\n"] }]
        }], function () { return [{ type: i2.SettingsService }, { type: AccountsExtService }, { type: i2.DynamicTabDataProviderDirective }]; }, { referrer: [{
                type: Input
            }] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class AccountsModule {
}
AccountsModule.ɵfac = function AccountsModule_Factory(t) { return new (t || AccountsModule)(); };
AccountsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: AccountsModule });
AccountsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [DataFiltersModule,
        NoDataModule,
        CommonModule,
        FormsModule,
        GroupsModule,
        BusyIndicatorModule,
        ReactiveFormsModule,
        EuiCoreModule,
        EuiMaterialModule,
        CdrModule,
        RouterModule,
        MatExpansionModule,
        MatIconModule,
        MatSidenavModule,
        MatCardModule,
        MatButtonModule,
        ObjectHyperviewModule,
        TranslateModule,
        DataSourceToolbarModule,
        DataTableModule,
        LdsReplaceModule,
        DataTreeModule,
        ExtModule,
        DynamicTabsModule,
        HelpContextualModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(AccountsModule, [{
            type: NgModule,
            args: [{
                    declarations: [
                        DataExplorerAccountsComponent,
                        AccountSidesheetComponent,
                        AccountsExtComponent,
                        TargetSystemReportComponent
                    ],
                    imports: [
                        DataFiltersModule,
                        NoDataModule,
                        CommonModule,
                        FormsModule,
                        GroupsModule,
                        BusyIndicatorModule,
                        ReactiveFormsModule,
                        EuiCoreModule,
                        EuiMaterialModule,
                        CdrModule,
                        RouterModule,
                        MatExpansionModule,
                        MatIconModule,
                        MatSidenavModule,
                        MatCardModule,
                        MatButtonModule,
                        ObjectHyperviewModule,
                        TranslateModule,
                        DataSourceToolbarModule,
                        DataTableModule,
                        LdsReplaceModule,
                        DataTreeModule,
                        ExtModule,
                        DynamicTabsModule,
                        HelpContextualModule
                    ],
                    exports: [
                        DataExplorerAccountsComponent,
                        AccountsExtComponent
                    ],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(AccountsModule, { declarations: [DataExplorerAccountsComponent,
            AccountSidesheetComponent,
            AccountsExtComponent,
            TargetSystemReportComponent], imports: [DataFiltersModule,
            NoDataModule,
            CommonModule,
            FormsModule,
            GroupsModule,
            BusyIndicatorModule,
            ReactiveFormsModule,
            EuiCoreModule,
            EuiMaterialModule,
            CdrModule,
            RouterModule,
            MatExpansionModule,
            MatIconModule,
            MatSidenavModule,
            MatCardModule,
            MatButtonModule,
            ObjectHyperviewModule,
            TranslateModule,
            DataSourceToolbarModule,
            DataTableModule,
            LdsReplaceModule,
            DataTreeModule,
            ExtModule,
            DynamicTabsModule,
            HelpContextualModule], exports: [DataExplorerAccountsComponent,
            AccountsExtComponent] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function isTsbNameSpaceAdminBase(groups) {
    return groups.find(item => item.toUpperCase() === 'TSB_4_NAMESPACEADMIN_BASE') != null;
}

class TsbPermissionsService {
    constructor(userService) {
        this.userService = userService;
    }
    isTsbNameSpaceAdminBase() {
        return __awaiter(this, void 0, void 0, function* () {
            return isTsbNameSpaceAdminBase((yield this.userService.getGroups()).map(userGroupInfo => userGroupInfo.Name));
        });
    }
}
TsbPermissionsService.ɵfac = function TsbPermissionsService_Factory(t) { return new (t || TsbPermissionsService)(i0.ɵɵinject(i1.UserModelService)); };
TsbPermissionsService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TsbPermissionsService, factory: TsbPermissionsService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TsbPermissionsService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], function () { return [{ type: i1.UserModelService }]; }, null);
})();

class TsbNamespaceAdminGuardService {
    constructor(authentication, permissionService, appConfig, router) {
        this.authentication = authentication;
        this.permissionService = permissionService;
        this.appConfig = appConfig;
        this.router = router;
    }
    canActivate(route, _) {
        return new Observable((observer) => {
            this.onSessionResponse = this.authentication.onSessionResponse.subscribe((sessionState) => __awaiter(this, void 0, void 0, function* () {
                if (sessionState.IsLoggedIn) {
                    // TODO Later: Berechtigungen sind noch nicht genau genug, non-admin-Pages lassen sich im Moment immer ansteuern
                    const navigateToAdmin = route.url[0].path === 'admin';
                    const userIsAdmin = yield this.permissionService.isTsbNameSpaceAdminBase();
                    if (navigateToAdmin && !userIsAdmin) {
                        this.router.navigate([this.appConfig.Config.routeConfig.start], { queryParams: {} });
                    }
                    observer.next(!navigateToAdmin || userIsAdmin);
                    observer.complete();
                }
            }));
        });
    }
    ngOnDestroy() {
        if (this.onSessionResponse) {
            this.onSessionResponse.unsubscribe();
        }
    }
}
TsbNamespaceAdminGuardService.ɵfac = function TsbNamespaceAdminGuardService_Factory(t) { return new (t || TsbNamespaceAdminGuardService)(i0.ɵɵinject(i2.AuthenticationService), i0.ɵɵinject(TsbPermissionsService), i0.ɵɵinject(i2.AppConfigService), i0.ɵɵinject(i1$3.Router)); };
TsbNamespaceAdminGuardService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TsbNamespaceAdminGuardService, factory: TsbNamespaceAdminGuardService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TsbNamespaceAdminGuardService, [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], function () { return [{ type: i2.AuthenticationService }, { type: TsbPermissionsService }, { type: i2.AppConfigService }, { type: i1$3.Router }]; }, null);
})();

class ReportButtonExtComponent {
    constructor(elementalUiConfigService, service, http, injector, overlay) {
        this.elementalUiConfigService = elementalUiConfigService;
        this.service = service;
        this.http = http;
        this.injector = injector;
        this.overlay = overlay;
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            const url = this.service.accountsOwnedByManagedReport(30, this.referrer);
            this.downloadOptions = Object.assign(Object.assign({}, this.elementalUiConfigService.Config.downloadOptions), { url });
        });
    }
    viewReport() {
        const directive = new EuiDownloadDirective(null, this.http, this.overlay, this.injector);
        directive.downloadOptions = Object.assign(Object.assign({}, this.downloadOptions), { disableElement: false });
        directive.onClick();
    }
}
ReportButtonExtComponent.ɵfac = function ReportButtonExtComponent_Factory(t) { return new (t || ReportButtonExtComponent)(i0.ɵɵdirectiveInject(i2.ElementalUiConfigService), i0.ɵɵdirectiveInject(AccountsReportsService), i0.ɵɵdirectiveInject(i5.HttpClient), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i6.Overlay)); };
ReportButtonExtComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ReportButtonExtComponent, selectors: [["imx-report-button-ext"]], decls: 3, vars: 4, consts: [["mat-menu-item", "", "data-imx-identifier", "report-button-ext-menu-item", 3, "euiDownload"]], template: function ReportButtonExtComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵtext(1);
            i0.ɵɵpipe(2, "translate");
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵproperty("euiDownload", ctx.downloadOptions);
            i0.ɵɵadvance(1);
            i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 2, "#LDS#Download report on user accounts of identities you are directly responsible for"), "\n");
        }
    }, dependencies: [i11.MatMenuItem, i1$1.EuiDownloadDirective, i7$1.TranslatePipe] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonExtComponent, [{
            type: Component,
            args: [{ selector: 'imx-report-button-ext', template: "<button mat-menu-item data-imx-identifier=\"report-button-ext-menu-item\" [euiDownload]=\"downloadOptions\">\r\n  {{'#LDS#Download report on user accounts of identities you are directly responsible for' | translate}}\r\n</button>\r\n" }]
        }], function () { return [{ type: i2.ElementalUiConfigService }, { type: AccountsReportsService }, { type: i5.HttpClient }, { type: i0.Injector }, { type: i6.Overlay }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ReportButtonExtModule {
}
ReportButtonExtModule.ɵfac = function ReportButtonExtModule_Factory(t) { return new (t || ReportButtonExtModule)(); };
ReportButtonExtModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ReportButtonExtModule });
ReportButtonExtModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        MatMenuModule,
        EuiCoreModule,
        TranslateModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ReportButtonExtModule, [{
            type: NgModule,
            args: [{
                    declarations: [ReportButtonExtComponent],
                    imports: [
                        CommonModule,
                        MatMenuModule,
                        EuiCoreModule,
                        TranslateModule
                    ],
                    exports: [ReportButtonExtComponent]
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ReportButtonExtModule, { declarations: [ReportButtonExtComponent], imports: [CommonModule,
            MatMenuModule,
            EuiCoreModule,
            TranslateModule], exports: [ReportButtonExtComponent] });
})();

class InitService {
    constructor(router, dataExplorerRegistryService, entlTypeService, tsbApiService, dynamicMethodService, menuService, extService, cacheService, myResponsibilitiesRegistryService) {
        this.router = router;
        this.dataExplorerRegistryService = dataExplorerRegistryService;
        this.entlTypeService = entlTypeService;
        this.tsbApiService = tsbApiService;
        this.dynamicMethodService = dynamicMethodService;
        this.menuService = menuService;
        this.extService = extService;
        this.cacheService = cacheService;
        this.myResponsibilitiesRegistryService = myResponsibilitiesRegistryService;
    }
    onInit(routes) {
        return __awaiter(this, void 0, void 0, function* () {
            this.cachedUnsConfig = this.cacheService.buildCache(() => this.tsbApiService.client.portal_uns_config_get());
            this.extService.register('identityReportsManager', {
                instance: ReportButtonExtComponent,
                inputData: {
                    caption: '#LDS#Download report on user accounts of identities you are directly responsible for',
                },
            });
            this.extService.register('identityAssignment', {
                instance: AccountsExtComponent,
                inputData: {
                    id: 'userAccounts',
                    label: '#LDS#User accounts',
                    checkVisibility: (_) => __awaiter(this, void 0, void 0, function* () { return true; }),
                },
                sortOrder: 10,
            });
            this.extService.register('identityAssignment', {
                instance: GroupMembershipsExtComponent,
                inputData: {
                    id: 'groups',
                    label: '#LDS#System entitlements',
                    checkVisibility: (_) => __awaiter(this, void 0, void 0, function* () { return true; }),
                },
                sortOrder: 10,
            });
            this.addRoutes(routes);
            this.setupMenu();
            this.entlTypeService.Register(() => this.loadUnsTypes());
            this.dataExplorerRegistryService.registerFactory((preProps, features, projectConfig, groups) => {
                if (!preProps.includes('ITSHOP') || !isTsbNameSpaceAdminBase(groups)) {
                    return;
                }
                return {
                    instance: DataExplorerAccountsComponent,
                    sortOrder: 2,
                    name: 'accounts',
                    caption: '#LDS#User accounts',
                    icon: 'account',
                };
            }, (preProps, features, projectConfig, groups) => {
                if (!preProps.includes('ITSHOP') || !isTsbNameSpaceAdminBase(groups)) {
                    return;
                }
                return {
                    instance: DataExplorerGroupsComponent,
                    sortOrder: 3,
                    name: 'groups',
                    caption: '#LDS#System entitlements',
                    icon: 'usergroup',
                    contextId: HELP_CONTEXTUAL.DataExplorerGroups,
                };
            });
            this.entlTypeService.Register(() => __awaiter(this, void 0, void 0, function* () {
                return [
                    new RequestableEntitlementType('TSBAccountDef', this.tsbApiService.apiClient, 'UID_TSBAccountDef', this.dynamicMethodService),
                ];
            }));
            this.myResponsibilitiesRegistryService.registerFactory((preProps, features) => ({
                instance: DataExplorerGroupsComponent,
                sortOrder: 3,
                name: 'UNSGroup',
                caption: '#LDS#System entitlements',
                icon: 'usergroup',
                contextId: HELP_CONTEXTUAL.MyResponsibilitiesGroups,
            }));
        });
    }
    loadUnsTypes() {
        return __awaiter(this, void 0, void 0, function* () {
            const config = yield this.cachedUnsConfig.get();
            const types = [];
            for (const key of Object.keys(config.ShopAssign)) {
                types.push(new RequestableEntitlementType(key, this.tsbApiService.apiClient, config.ShopAssign[key].GroupColumnName, this.dynamicMethodService));
            }
            return types;
        });
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach((route) => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, __) => {
            if (!preProps.includes('ITSHOP')) {
                return null;
            }
            return {
                id: 'ROOT_Responsibilities',
                title: '#LDS#Responsibilities',
                sorting: '30',
                items: [
                    {
                        id: 'QER_Responsibilities_AssignOwnership',
                        route: 'claimgroup',
                        title: '#LDS#Menu Entry System entitlement ownership',
                        sorting: '30-20',
                    },
                ],
            };
        }, (preProps, features, projectConfig, groups) => {
            if (!preProps.includes('ITSHOP') || !isTsbNameSpaceAdminBase(groups)) {
                return null;
            }
            return {
                id: 'ROOT_Data',
                title: '#LDS#Data administration',
                sorting: '40',
                items: [
                    {
                        id: 'QER_DataExplorer',
                        navigationCommands: { commands: ['admin', 'dataexplorer'] },
                        title: '#LDS#Menu Entry Data Explorer',
                        sorting: '40-10',
                    },
                ],
            };
        });
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i1$3.Router), i0.ɵɵinject(i1.DataExplorerRegistryService), i0.ɵɵinject(i1.RequestableEntitlementTypeService), i0.ɵɵinject(TsbApiService), i0.ɵɵinject(i2.DynamicMethodService), i0.ɵɵinject(i2.MenuService), i0.ɵɵinject(i2.ExtService), i0.ɵɵinject(i2.CacheService), i0.ɵɵinject(i1.MyResponsibilitiesRegistryService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], function () { return [{ type: i1$3.Router }, { type: i1.DataExplorerRegistryService }, { type: i1.RequestableEntitlementTypeService }, { type: TsbApiService }, { type: i2.DynamicMethodService }, { type: i2.MenuService }, { type: i2.ExtService }, { type: i2.CacheService }, { type: i1.MyResponsibilitiesRegistryService }]; }, null);
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'claimgroup',
        component: ClaimGroupComponent,
        canActivate: [RouteGuardService],
        data: {
            contextId: HELP_CONTEXTUAL.ClaimGroup
        }
    },
    {
        path: 'resp/UNSGroup',
        component: DataExplorerGroupsComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService]
    }
];
class TsbConfigModule {
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 TSB loaded with claimgroup');
        this.initializer.onInit(routes);
        console.log('▶️ TSB initialized');
    }
}
TsbConfigModule.ɵfac = function TsbConfigModule_Factory(t) { return new (t || TsbConfigModule)(i0.ɵɵinject(InitService)); };
TsbConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: TsbConfigModule });
TsbConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [
        TsbNamespaceAdminGuardService
    ], imports: [AccountsModule,
        BusinessownerAddonTileModule,
        BusinessownerOverviewTileModule,
        CdrModule,
        CommonModule,
        GroupsModule,
        RouterModule.forChild(routes),
        MatIconModule,
        MatListModule,
        TileModule,
        TranslateModule,
        ReportButtonExtModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TsbConfigModule, [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        AccountsModule,
                        BusinessownerAddonTileModule,
                        BusinessownerOverviewTileModule,
                        CdrModule,
                        CommonModule,
                        GroupsModule,
                        RouterModule.forChild(routes),
                        MatIconModule,
                        MatListModule,
                        TileModule,
                        TranslateModule,
                        ReportButtonExtModule
                    ],
                    providers: [
                        TsbNamespaceAdminGuardService
                    ]
                }]
        }], function () { return [{ type: InitService }]; }, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(TsbConfigModule, { imports: [AccountsModule,
            BusinessownerAddonTileModule,
            BusinessownerOverviewTileModule,
            CdrModule,
            CommonModule,
            GroupsModule, i1$3.RouterModule, MatIconModule,
            MatListModule,
            TileModule,
            TranslateModule,
            ReportButtonExtModule] });
})();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
/*
 * Public API Surface of tsb
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AccountSidesheetComponent, AccountsExtComponent, AccountsModule, AccountsReportsService, AccountsService, ChildSystemEntitlementsComponent, ClaimGroupModule, DataExplorerAccountsComponent, DataExplorerFiltersComponent, DataExplorerGroupsComponent, DataExplorerNoDataComponent, DataFiltersModule, DeHelperService, GroupSidesheetComponent, GroupsModule, GroupsReportsService, GroupsService, NoDataModule, TsbApiService, TsbConfigModule };
//# sourceMappingURL=tsb.mjs.map
