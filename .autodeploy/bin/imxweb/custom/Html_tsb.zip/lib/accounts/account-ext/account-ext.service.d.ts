import { PortalPersonAccounts, portal_person_accounts_get_args } from 'imx-api-tsb';
import { EntitySchema, ExtendedTypedEntityCollection } from 'imx-qbm-dbts';
import { TsbApiService } from '../../tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class AccountsExtService {
    private readonly apiService;
    constructor(apiService: TsbApiService);
    get portalPersonAccountsSchema(): EntitySchema;
    getAccounts(uid: string, parameters?: portal_person_accounts_get_args): Promise<ExtendedTypedEntityCollection<PortalPersonAccounts, unknown>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountsExtService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountsExtService>;
}
