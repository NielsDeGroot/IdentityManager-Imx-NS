import { OnInit } from '@angular/core';
import { CollectionLoadParameters, DisplayColumns, EntitySchema } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings, DynamicTabDataProviderDirective, SettingsService, BusyService } from 'qbm';
import { AccountsExtService } from './account-ext.service';
import * as i0 from "@angular/core";
export declare class AccountsExtComponent implements OnInit {
    private readonly settingService;
    private readonly accountsService;
    referrer: {
        objecttable?: string;
        objectuid?: string;
        tablename?: string;
    };
    dstSettings: DataSourceToolbarSettings;
    readonly DisplayColumns: typeof DisplayColumns;
    entitySchemaAccount: EntitySchema;
    busyService: BusyService;
    private displayColumns;
    private navigationState;
    constructor(settingService: SettingsService, accountsService: AccountsExtService, dataProvider: DynamicTabDataProviderDirective);
    ngOnInit(): Promise<void>;
    onNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    onSearch(keywords: string): Promise<void>;
    private getData;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountsExtComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountsExtComponent, "ng-component", never, { "referrer": "referrer"; }, {}, never, never, false>;
}
