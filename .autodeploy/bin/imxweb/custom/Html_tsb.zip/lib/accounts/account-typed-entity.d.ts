import { IEntityColumn, TypedEntity } from 'imx-qbm-dbts';
export declare class AccountTypedEntity extends TypedEntity {
    readonly displayColumn: IEntityColumn;
    readonly isNeverConnectManualColumn: IEntityColumn;
    readonly objectKeyManagerColumn: IEntityColumn;
    readonly uidPersonColumn: IEntityColumn;
    readonly uidADSDomain: IEntityColumn;
}
