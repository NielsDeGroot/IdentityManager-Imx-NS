import { OnDestroy, OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { BusyService, ClassloggerService, DataSourceToolbarFilter, DataSourceToolbarSettings, SettingsService, SideNavigationComponent } from 'qbm';
import { ViewConfigService } from 'qer';
import { CollectionLoadParameters, DisplayColumns, EntitySchema, FilterData } from 'imx-qbm-dbts';
import { ViewConfigData } from 'imx-api-qer';
import { PortalTargetsystemUnsSystem, PortalTargetsystemUnsAccount } from 'imx-api-tsb';
import { ContainerTreeDatabaseWrapper } from '../container-list/container-tree-database-wrapper';
import { DataExplorerFiltersComponent } from '../data-filters/data-explorer-filters.component';
import { DeHelperService } from '../de-helper.service';
import { AccountsService } from './accounts.service';
import * as i0 from "@angular/core";
export declare class DataExplorerAccountsComponent implements OnInit, OnDestroy, SideNavigationComponent {
    translateProvider: TranslateService;
    private readonly sideSheet;
    private readonly logger;
    private readonly accountsService;
    private readonly dataHelper;
    private viewConfigService;
    readonly settingsService: SettingsService;
    applyIssuesFilter: boolean;
    issuesFilterMode: string;
    targetSystemData?: PortalTargetsystemUnsSystem[];
    dataExplorerFilters: DataExplorerFiltersComponent;
    /**
     * Settings needed by the DataSourceToolbarComponent
     */
    dstSettings: DataSourceToolbarSettings;
    /**
     * Page size, start index, search and filtering options etc.
     */
    navigationState: CollectionLoadParameters;
    filterOptions: DataSourceToolbarFilter[];
    treeDbWrapper: ContainerTreeDatabaseWrapper;
    readonly entitySchemaUnsAccount: EntitySchema;
    readonly DisplayColumns: typeof DisplayColumns;
    data: any;
    busyService: BusyService;
    contextId: "data-explorer-accounts";
    private displayedColumns;
    private authorityDataDeleted$;
    private tableName;
    private dataModel;
    private viewConfigPath;
    private viewConfig;
    constructor(translateProvider: TranslateService, sideSheet: EuiSidesheetService, logger: ClassloggerService, accountsService: AccountsService, dataHelper: DeHelperService, viewConfigService: ViewConfigService, settingsService: SettingsService);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    updateConfig(config: ViewConfigData): Promise<void>;
    deleteConfigById(id: string): Promise<void>;
    /**
     * Occurs when the navigation state has changed - e.g. users clicks on the next page button.
     *
     */
    onNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    onAccountChanged(unsAccount: PortalTargetsystemUnsAccount): Promise<void>;
    /**
     * Occurs when user triggers search.
     *
     * @param keywords Search keywords.
     */
    onSearch(keywords: string): Promise<void>;
    filterByTree(filters: FilterData[]): Promise<void>;
    openReportOptionsSidesheet(): Promise<void>;
    private navigate;
    private viewAccount;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataExplorerAccountsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataExplorerAccountsComponent, "imx-data-explorer-accounts", never, { "applyIssuesFilter": "applyIssuesFilter"; "issuesFilterMode": "issuesFilterMode"; "targetSystemData": "targetSystemData"; }, {}, never, never, false>;
}
