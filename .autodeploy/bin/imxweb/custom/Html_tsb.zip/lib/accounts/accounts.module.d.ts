import * as i0 from "@angular/core";
import * as i1 from "./accounts.component";
import * as i2 from "./account-sidesheet/account-sidesheet.component";
import * as i3 from "./account-ext/accounts-ext.component";
import * as i4 from "./target-system-report/target-system-report.component";
import * as i5 from "../data-filters/data-filters.module";
import * as i6 from "../no-data/no-data.module";
import * as i7 from "@angular/common";
import * as i8 from "@angular/forms";
import * as i9 from "../groups/groups.module";
import * as i10 from "qbm";
import * as i11 from "@elemental-ui/core";
import * as i12 from "@angular/router";
import * as i13 from "@angular/material/expansion";
import * as i14 from "@angular/material/icon";
import * as i15 from "@angular/material/sidenav";
import * as i16 from "@angular/material/card";
import * as i17 from "@angular/material/button";
import * as i18 from "qer";
import * as i19 from "@ngx-translate/core";
export declare class AccountsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountsModule, [typeof i1.DataExplorerAccountsComponent, typeof i2.AccountSidesheetComponent, typeof i3.AccountsExtComponent, typeof i4.TargetSystemReportComponent], [typeof i5.DataFiltersModule, typeof i6.NoDataModule, typeof i7.CommonModule, typeof i8.FormsModule, typeof i9.GroupsModule, typeof i10.BusyIndicatorModule, typeof i8.ReactiveFormsModule, typeof i11.EuiCoreModule, typeof i11.EuiMaterialModule, typeof i10.CdrModule, typeof i12.RouterModule, typeof i13.MatExpansionModule, typeof i14.MatIconModule, typeof i15.MatSidenavModule, typeof i16.MatCardModule, typeof i17.MatButtonModule, typeof i18.ObjectHyperviewModule, typeof i19.TranslateModule, typeof i10.DataSourceToolbarModule, typeof i10.DataTableModule, typeof i10.LdsReplaceModule, typeof i10.DataTreeModule, typeof i10.ExtModule, typeof i10.DynamicTabsModule, typeof i10.HelpContextualModule], [typeof i1.DataExplorerAccountsComponent, typeof i3.AccountsExtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountsModule>;
}
