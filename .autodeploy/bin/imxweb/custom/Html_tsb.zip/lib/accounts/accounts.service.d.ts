import { CollectionLoadParameters, TypedEntityCollectionData, DataModelFilter, EntitySchema, FilterTreeData, DataModel } from 'imx-qbm-dbts';
import { TsbApiService } from '../tsb-api-client.service';
import { PortalTargetsystemUnsAccount } from 'imx-api-tsb';
import { TargetSystemDynamicMethodService } from '../target-system/target-system-dynamic-method.service';
import { AccountTypedEntity } from './account-typed-entity';
import { DbObjectKeyBase } from '../target-system/db-object-key-wrapper.interface';
import { AcountsFilterTreeParameters as AccountsFilterTreeParameters } from './accounts.models';
import { DataSourceToolbarExportMethod } from 'qbm';
import * as i0 from "@angular/core";
export declare class AccountsService {
    private readonly tsbClient;
    private readonly dynamicMethod;
    private abortController;
    constructor(tsbClient: TsbApiService, dynamicMethod: TargetSystemDynamicMethodService);
    get accountSchema(): EntitySchema;
    /**
     * Gets a list of accounts.
     *
     * @param navigationState Page size, start index, search and filtering options etc,.
     *
     * @returns Wrapped list of Accounts.
     */
    getAccounts(navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemUnsAccount>>;
    exportAccounts(navigationState: CollectionLoadParameters): DataSourceToolbarExportMethod;
    getAccount(dbObjectKey: DbObjectKeyBase, columnName?: string): Promise<AccountTypedEntity>;
    getAccountInteractive(dbObjectKey: DbObjectKeyBase, columnName: string): Promise<AccountTypedEntity>;
    /** @deprecated Will be removed. Please load the data model first.*/
    getFilterOptions(): Promise<DataModelFilter[]>;
    getDataModel(): Promise<DataModel>;
    getFilterTree(parameter: AccountsFilterTreeParameters): Promise<FilterTreeData>;
    private abortCall;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountsService>;
}
