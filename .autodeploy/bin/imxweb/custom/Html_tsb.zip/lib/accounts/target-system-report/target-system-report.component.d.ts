import { Overlay } from '@angular/cdk/overlay';
import { HttpClient } from '@angular/common/http';
import { Injector, OnInit } from '@angular/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { IEntity } from 'imx-qbm-dbts';
import { FilterTreeEntityWrapperService, FilterTreeDatabase, ElementalUiConfigService } from 'qbm';
import { AccountsReportsService } from '../accounts-reports.service';
import { AccountsService } from '../accounts.service';
import * as i0 from "@angular/core";
export declare class TargetSystemReportComponent implements OnInit {
    private busyService;
    private readonly entityWrapper;
    private readonly accountsService;
    private readonly accountReport;
    private readonly elementalUiConfigService;
    private readonly http;
    private readonly injector;
    private readonly overlay;
    showHelperAlert: boolean;
    database: FilterTreeDatabase;
    selectedEntity: IEntity;
    constructor(busyService: EuiLoadingService, entityWrapper: FilterTreeEntityWrapperService, accountsService: AccountsService, accountReport: AccountsReportsService, elementalUiConfigService: ElementalUiConfigService, http: HttpClient, injector: Injector, overlay: Overlay);
    ngOnInit(): Promise<void>;
    onHelperDismissed(): void;
    onNodeSelected(entity: IEntity): void;
    loadReport(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TargetSystemReportComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TargetSystemReportComponent, "imx-target-system-report", never, {}, {}, never, never, false>;
}
