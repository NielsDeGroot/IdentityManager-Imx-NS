export declare function isTsbNameSpaceAdminBase(groups: string[]): boolean;
