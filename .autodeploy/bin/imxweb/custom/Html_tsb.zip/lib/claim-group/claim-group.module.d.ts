import * as i0 from "@angular/core";
import * as i1 from "./claim-group.component";
import * as i2 from "qbm";
import * as i3 from "@angular/common";
import * as i4 from "@elemental-ui/core";
import * as i5 from "@angular/forms";
import * as i6 from "@angular/material/button";
import * as i7 from "@angular/material/radio";
import * as i8 from "@angular/material/stepper";
import * as i9 from "@ngx-translate/core";
export declare class ClaimGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ClaimGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ClaimGroupModule, [typeof i1.ClaimGroupComponent], [typeof i2.CdrModule, typeof i3.CommonModule, typeof i4.EuiCoreModule, typeof i5.FormsModule, typeof i2.LdsReplaceModule, typeof i6.MatButtonModule, typeof i7.MatRadioModule, typeof i8.MatStepperModule, typeof i5.ReactiveFormsModule, typeof i9.TranslateModule, typeof i2.HelpContextualModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ClaimGroupModule>;
}
