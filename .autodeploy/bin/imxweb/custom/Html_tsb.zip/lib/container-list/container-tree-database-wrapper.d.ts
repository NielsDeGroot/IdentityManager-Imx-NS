import { BusyService, EntityTreeDatabase } from 'qbm';
import { DeHelperService } from '../de-helper.service';
export declare class ContainerTreeDatabaseWrapper {
    private readonly busyService;
    private readonly dataHelper;
    get targetSystemFilterValue(): string;
    set targetSystemFilterValue(value: string);
    selectionEnabled: boolean;
    entityTreeDatabase: EntityTreeDatabase;
    private system;
    constructor(busyService: BusyService, dataHelper: DeHelperService);
    private getEntities;
}
