import * as i0 from "@angular/core";
import * as i1 from "./data-explorer-filters.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "@elemental-ui/core";
import * as i5 from "qbm";
import * as i6 from "@angular/router";
import * as i7 from "@angular/material/expansion";
import * as i8 from "@angular/material/icon";
import * as i9 from "@angular/material/sidenav";
import * as i10 from "@ngx-translate/core";
export declare class DataFiltersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DataFiltersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DataFiltersModule, [typeof i1.DataExplorerFiltersComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i4.EuiCoreModule, typeof i4.EuiMaterialModule, typeof i5.CdrModule, typeof i6.RouterModule, typeof i7.MatExpansionModule, typeof i8.MatIconModule, typeof i9.MatSidenavModule, typeof i10.TranslateModule, typeof i5.DataSourceToolbarModule, typeof i5.DataTableModule, typeof i5.LdsReplaceModule, typeof i5.DataTreeModule], [typeof i1.DataExplorerFiltersComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DataFiltersModule>;
}
