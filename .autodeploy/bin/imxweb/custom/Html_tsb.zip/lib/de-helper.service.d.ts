import { CollectionLoadParameters, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { PortalTargetsystemUnsContainer, PortalTargetsystemUnsSystem } from 'imx-api-tsb';
import { Subject } from 'rxjs';
import { EuiLoadingService } from '@elemental-ui/core';
import { TsbApiService } from './tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class DeHelperService {
    private loader;
    private tsbClient;
    authorityDataDeleted: Subject<string>;
    constructor(loader: EuiLoadingService, tsbClient: TsbApiService);
    getAuthorityData(search?: string, skipLoader?: boolean): Promise<DataDeleteOptions>;
    getContainers(navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemUnsContainer>>;
    private handlePromiseLoader;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeHelperService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeHelperService>;
}
export interface DataDeleteOptions {
    authorities?: PortalTargetsystemUnsSystem[];
    hasAuthorities: boolean;
}
