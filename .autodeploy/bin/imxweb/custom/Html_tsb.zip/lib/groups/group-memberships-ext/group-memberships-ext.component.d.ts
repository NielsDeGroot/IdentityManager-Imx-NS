import { OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { CollectionLoadParameters, DisplayColumns, EntitySchema, IClientProperty } from 'imx-qbm-dbts';
import { BusyService, DataSourceToolbarSettings, DynamicTabDataProviderDirective, SettingsService } from 'qbm';
import { GroupMembershipsExtService } from './group-memberships-ext.service';
import { PortalPersonGroupmemberships } from 'imx-api-tsb';
import * as i0 from "@angular/core";
export declare class GroupMembershipsExtComponent implements OnInit {
    private readonly settingService;
    private readonly groupService;
    private readonly translate;
    private readonly sidesheet;
    referrer: {
        objecttable?: string;
        objectuid?: string;
        tablename?: string;
    };
    dstSettings: DataSourceToolbarSettings;
    readonly DisplayColumns: typeof DisplayColumns;
    entitySchema: EntitySchema;
    displayColumns: IClientProperty[];
    private displayedColumnsWithDisplay;
    private navigationState;
    busyService: BusyService;
    constructor(settingService: SettingsService, groupService: GroupMembershipsExtService, translate: TranslateService, sidesheet: EuiSidesheetService, dataProvider: DynamicTabDataProviderDirective);
    ngOnInit(): Promise<void>;
    onNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    onSearch(keywords: string): Promise<void>;
    onShowDetails(entity: PortalPersonGroupmemberships): Promise<void>;
    private getData;
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupMembershipsExtComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GroupMembershipsExtComponent, "ng-component", never, { "referrer": "referrer"; }, {}, never, never, false>;
}
