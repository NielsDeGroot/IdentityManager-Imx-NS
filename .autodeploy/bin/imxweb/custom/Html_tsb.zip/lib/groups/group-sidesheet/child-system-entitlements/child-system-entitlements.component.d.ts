import { OnInit } from '@angular/core';
import { EuiLoadingService } from '@elemental-ui/core';
import { PortalTargetsystemUnsGroupmembers } from 'imx-api-tsb';
import { CollectionLoadParameters, EntitySchema, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings, SettingsService } from 'qbm';
import { GroupsService } from '../../groups.service';
import * as i0 from "@angular/core";
export declare class ChildSystemEntitlementsComponent implements OnInit {
    private readonly busyService;
    private readonly settingsService;
    private readonly groupsService;
    groupId: string;
    isAdmin: boolean;
    groupsGroupMembershipData: TypedEntityCollectionData<PortalTargetsystemUnsGroupmembers>;
    groupsDstSettings: DataSourceToolbarSettings;
    navigationState: CollectionLoadParameters;
    readonly entitySchemaUnsGroupMemberships: EntitySchema;
    private groupDisplayedColumns;
    constructor(busyService: EuiLoadingService, settingsService: SettingsService, groupsService: GroupsService);
    ngOnInit(): Promise<void>;
    getData(newState?: CollectionLoadParameters): Promise<void>;
    private groupNavigate;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChildSystemEntitlementsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChildSystemEntitlementsComponent, "imx-child-system-entitlements", never, { "groupId": "groupId"; "isAdmin": "isAdmin"; }, {}, never, never, false>;
}
