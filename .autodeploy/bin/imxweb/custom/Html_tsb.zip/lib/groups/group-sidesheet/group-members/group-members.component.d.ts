import { OnInit } from '@angular/core';
import { UntypedFormControl } from '@angular/forms';
import { MatButtonToggleChange } from '@angular/material/button-toggle';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { PortalTargetsystemUnsDirectmembers, PortalTargetsystemUnsGroupServiceitem, PortalTargetsystemUnsNestedmembers } from 'imx-api-tsb';
import { CollectionLoadParameters, EntitySchema, TypedEntity, TypedEntityCollectionData } from 'imx-qbm-dbts';
import { ConfirmationService, DataSourceToolbarSettings, DataTableComponent, SettingsService, SnackBarService } from 'qbm';
import { DbObjectKeyBase } from '../../../target-system/db-object-key-wrapper.interface';
import { GroupsService } from '../../groups.service';
import { NewMembershipService } from './new-membership/new-membership.service';
import * as i0 from "@angular/core";
export declare class GroupMembersComponent implements OnInit {
    private readonly busyService;
    private readonly snackBarService;
    private readonly sidesheet;
    private readonly groupsService;
    private readonly confirmationService;
    private readonly membershipService;
    private readonly translate;
    private readonly settingsService;
    groupDirectMembershipData: TypedEntityCollectionData<PortalTargetsystemUnsDirectmembers>;
    groupNestedMembershipData: TypedEntityCollectionData<PortalTargetsystemUnsNestedmembers>;
    unsGroupDbObjectKey: DbObjectKeyBase;
    membersTable: DataTableComponent<any>;
    /**
     * Settings needed by the DataSourceToolbarComponent
     */
    dstSettings: DataSourceToolbarSettings;
    dstNestedGroupSettings: DataSourceToolbarSettings;
    /**
     * Page size, start index, search and filtering options etc.
     */
    navigationState: CollectionLoadParameters;
    nestedNavigationState: CollectionLoadParameters;
    viewDirectMemberships: UntypedFormControl;
    canViewInheritedMemberships: boolean;
    showUnsubscribeWarning: boolean;
    readonly entitySchemaGroupDirectMemberships: EntitySchema;
    readonly entitySchemaGroupNestedMemberships: EntitySchema;
    readonly itemStatus: {
        enabled: (item: PortalTargetsystemUnsDirectmembers) => boolean;
    };
    private displayedColumns;
    private nestedDisplayColumns;
    private selectedItems;
    private selectedMembershipView;
    private busyIndicator;
    private groupId;
    constructor(busyService: EuiLoadingService, snackBarService: SnackBarService, sidesheet: EuiSidesheetService, groupsService: GroupsService, confirmationService: ConfirmationService, membershipService: NewMembershipService, translate: TranslateService, settingsService: SettingsService);
    get membershipView(): 'direct' | 'nested';
    get isMobile(): boolean;
    ngOnInit(): Promise<void>;
    get selectedItemsCount(): number;
    onSelectionChanged(items: TypedEntity[]): void;
    canUnsubscribeSelected(): boolean;
    canDeleteSelected(): boolean;
    onToggleChanged(change: MatButtonToggleChange): Promise<void>;
    onDirectNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    onNestedNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    deleteMembers(): Promise<void>;
    requestMembership(serviceItem: PortalTargetsystemUnsGroupServiceitem): Promise<void>;
    onWarningDismissed(): void;
    unsubscribeMembership(): Promise<void>;
    onShowDetails(item: PortalTargetsystemUnsDirectmembers): Promise<void>;
    private navigateDirect;
    private navigateNested;
    private handleOpenLoader;
    private handleCloseLoader;
    LdsNotUnsubscribableHint: string;
    LdsDirectlyAssignedHint: string;
    LdsIndirectlyAssignedHint: string;
    LdsDirectlyAssigned: string;
    LdsIndirectlyAssigned: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupMembersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GroupMembersComponent, "imx-group-members", never, { "groupDirectMembershipData": "groupDirectMembershipData"; "groupNestedMembershipData": "groupNestedMembershipData"; "unsGroupDbObjectKey": "unsGroupDbObjectKey"; }, {}, never, never, false>;
}
