import { EuiLoadingService } from '@elemental-ui/core';
import { PortalTargetsystemUnsGroupServiceitem } from 'imx-api-tsb';
import { IForeignKeyInfo, TypedEntity, ValueStruct } from 'imx-qbm-dbts';
import { ShelfService, QerApiService, UserModelService } from 'qer';
import * as i0 from "@angular/core";
export declare class NewMembershipService {
    private readonly itShop;
    private readonly qerClient;
    private readonly busyService;
    private readonly userService;
    constructor(itShop: ShelfService, qerClient: QerApiService, busyService: EuiLoadingService, userService: UserModelService);
    requestMembership(members: ValueStruct<string>[], product: PortalTargetsystemUnsGroupServiceitem): Promise<boolean>;
    getFKRelation(): readonly IForeignKeyInfo[];
    unsubscribeMembership(item: TypedEntity): Promise<void>;
    private getServiceItemsForPersons;
    static ɵfac: i0.ɵɵFactoryDeclaration<NewMembershipService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NewMembershipService>;
}
