import { UntypedFormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { OnInit, OnDestroy } from '@angular/core';
import { CollectionLoadParameters, DisplayColumns, EntitySchema, FilterData } from 'imx-qbm-dbts';
import { ViewConfigData } from 'imx-api-qer';
import { PortalTargetsystemUnsGroup, PortalTargetsystemUnsSystem } from 'imx-api-tsb';
import { BusyService, ClassloggerService, DataSourceToolbarFilter, DataSourceToolbarSettings, DataTableComponent, SettingsService, SideNavigationComponent, SnackBarService, HelpContextualValues } from 'qbm';
import { ViewConfigService } from 'qer';
import { ContainerTreeDatabaseWrapper } from '../container-list/container-tree-database-wrapper';
import { DeHelperService } from '../de-helper.service';
import { GroupsService } from './groups.service';
import * as i0 from "@angular/core";
export declare class DataExplorerGroupsComponent implements OnInit, OnDestroy, SideNavigationComponent {
    private readonly route;
    private readonly sideSheet;
    private readonly busyServiceElemental;
    private readonly logger;
    private readonly groupsService;
    private viewConfigService;
    private readonly dataHelper;
    private readonly translate;
    private readonly snackbar;
    unsAccountIdFilter: string;
    sidesheetWidth: string;
    applyIssuesFilter: boolean;
    issuesFilterMode: string;
    targetSystemData?: PortalTargetsystemUnsSystem[];
    isAdmin: boolean;
    uidPerson: string;
    usedInSidesheet: boolean;
    contextId: HelpContextualValues;
    dataTable: DataTableComponent<PortalTargetsystemUnsGroup>;
    /**
     * Settings needed by the DataSourceToolbarComponent
     */
    dstSettings: DataSourceToolbarSettings;
    /**
     * Page size, start index, search and filtering options etc.
     */
    navigationState: CollectionLoadParameters;
    filterOptions: DataSourceToolbarFilter[];
    treeDbWrapper: ContainerTreeDatabaseWrapper;
    requestableBulkUpdateCtrl: UntypedFormControl;
    entitySchemaUnsGroup: EntitySchema;
    readonly DisplayColumns: typeof DisplayColumns;
    selectedGroupsForUpdate: PortalTargetsystemUnsGroup[];
    data: any;
    busyService: BusyService;
    private viewConfigPath;
    private viewConfig;
    readonly itemStatus: {
        enabled: (item: PortalTargetsystemUnsGroup) => boolean;
    };
    private displayedColumns;
    private authorityDataDeleted$;
    private dataModel;
    constructor(route: ActivatedRoute, sideSheet: EuiSidesheetService, busyServiceElemental: EuiLoadingService, logger: ClassloggerService, groupsService: GroupsService, viewConfigService: ViewConfigService, dataHelper: DeHelperService, translate: TranslateService, snackbar: SnackBarService, settingsService: SettingsService);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    updateConfig(config: ViewConfigData): Promise<void>;
    deleteConfigById(id: string): Promise<void>;
    get itemsAreNotRequestable(): boolean;
    get itemsAreRequestable(): boolean;
    /**
     * Occurs when the navigation state has changed - e.g. users clicks on the next page button.
     *
     */
    onNavigationStateChanged(newState?: CollectionLoadParameters): Promise<void>;
    onGroupChanged(group: PortalTargetsystemUnsGroup): Promise<void>;
    /**
     * Occurs when user triggers search.
     *
     * @param keywords Search keywords.
     */
    onSearch(keywords: string): Promise<void>;
    filterByTree(filters: FilterData[]): Promise<void>;
    onGroupSelected(selected: PortalTargetsystemUnsGroup[]): void;
    viewSource(event: Event, item: PortalTargetsystemUnsGroup): Promise<void>;
    bulkUpdateSelected(request: boolean): Promise<void>;
    bulkUpdateOwner(): Promise<void>;
    private updateOwnerForSelectedGroups;
    private updateSelectedGroups;
    private navigate;
    private viewGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataExplorerGroupsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataExplorerGroupsComponent, "imx-data-explorer-groups", never, { "unsAccountIdFilter": "unsAccountIdFilter"; "sidesheetWidth": "sidesheetWidth"; "applyIssuesFilter": "applyIssuesFilter"; "issuesFilterMode": "issuesFilterMode"; "targetSystemData": "targetSystemData"; "isAdmin": "isAdmin"; "uidPerson": "uidPerson"; "usedInSidesheet": "usedInSidesheet"; "contextId": "contextId"; }, {}, never, never, false>;
}
