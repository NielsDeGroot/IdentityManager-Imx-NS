import { CollectionLoadParameters } from 'imx-qbm-dbts';
import { PortalTargetsystemUnsGroupServiceitem } from 'imx-api-tsb';
import { GroupTypedEntity } from './group-typed-entity';
import { DbObjectKeyBase } from '../target-system/db-object-key-wrapper.interface';
export interface GetGroupsOptionalParameters extends CollectionLoadParameters {
    uid_unsaccount?: string;
    published?: string;
    withowner?: string;
    system?: string;
    container?: string;
}
export interface GroupSidesheetData {
    uidAccProduct: string;
    unsGroupDbObjectKey: DbObjectKeyBase;
    group: GroupTypedEntity;
    groupServiceItem: PortalTargetsystemUnsGroupServiceitem;
    isAdmin?: boolean;
}
export interface GroupsFilterTreeParameters {
    container: string;
    system: string;
    uid_unsaccount: string;
    parentkey: string;
}
