import { ClassloggerService, DataSourceToolbarExportMethod } from 'qbm';
import { CollectionLoadParameters, TypedEntityCollectionData, DataModelFilter, EntitySchema, FilterTreeData, DataModel } from 'imx-qbm-dbts';
import { PortalTargetsystemUnsGroup, PortalTargetsystemUnsGroupServiceitem, PortalTargetsystemUnsGroupmembers, EntityWriteDataBulk, PortalTargetsystemUnsDirectmembers, PortalTargetsystemUnsNestedmembers, PortalRespUnsgroup } from 'imx-api-tsb';
import { GroupsFilterTreeParameters, GetGroupsOptionalParameters } from './groups.models';
import { TsbApiService } from '../tsb-api-client.service';
import { GroupTypedEntity } from './group-typed-entity';
import { TargetSystemDynamicMethodService } from '../target-system/target-system-dynamic-method.service';
import { DbObjectKeyBase } from '../target-system/db-object-key-wrapper.interface';
import * as i0 from "@angular/core";
export declare class GroupsService {
    private readonly tsbClient;
    private readonly logger;
    private readonly dynamicMethod;
    private abortController;
    constructor(tsbClient: TsbApiService, logger: ClassloggerService, dynamicMethod: TargetSystemDynamicMethodService);
    unsGroupsSchema(isAdmin: boolean): EntitySchema;
    get UnsGroupMembersSchema(): EntitySchema;
    get UnsGroupDirectMembersSchema(): EntitySchema;
    get UnsGroupNestedMembersSchema(): EntitySchema;
    getFilterTree(options: GroupsFilterTreeParameters): Promise<FilterTreeData>;
    getGroups(navigationState: GetGroupsOptionalParameters): Promise<TypedEntityCollectionData<PortalTargetsystemUnsGroup>>;
    exportGroups(navigationState: GetGroupsOptionalParameters): DataSourceToolbarExportMethod;
    getGroupsResp(navigationState: GetGroupsOptionalParameters): Promise<TypedEntityCollectionData<PortalRespUnsgroup>>;
    exportGroupsResp(navigationState: GetGroupsOptionalParameters): DataSourceToolbarExportMethod;
    getGroupDetails(dbObjectKey: DbObjectKeyBase): Promise<GroupTypedEntity>;
    getGroupDetailsInteractive(dbObjectKey: DbObjectKeyBase, columnName: string): Promise<GroupTypedEntity>;
    getGroupServiceItem(key: string): Promise<PortalTargetsystemUnsGroupServiceitem>;
    bulkUpdateGroupServiceItems(updateData: EntityWriteDataBulk): Promise<void>;
    getGroupDirectMembers(groupId: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemUnsDirectmembers>>;
    getGroupNestedMembers(groupId: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemUnsNestedmembers>>;
    deleteGroupMembers(dbObjectKey: DbObjectKeyBase, uidAccountList: string[]): Promise<any[]>;
    getGroupsGroupMembers(groupId: string, navigationState: CollectionLoadParameters): Promise<TypedEntityCollectionData<PortalTargetsystemUnsGroupmembers>>;
    /** @deprecated Will be removed. Please load the data model first.*/
    getFilterOptions(forAdmin: boolean): Promise<DataModelFilter[]>;
    getDataModel(forAdmin: boolean): Promise<DataModel>;
    updateMultipleOwner(uidAccProducts: string[], uidPerson: {
        uidPerson?: string;
        uidRole?: string;
    }): Promise<string>;
    private abortCall;
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GroupsService>;
}
