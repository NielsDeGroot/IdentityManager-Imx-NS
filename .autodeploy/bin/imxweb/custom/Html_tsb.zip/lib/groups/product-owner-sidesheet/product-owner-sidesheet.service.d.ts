import { IEntity, IEntityColumn } from 'imx-qbm-dbts';
import { EntityService } from 'qbm';
import { TsbApiService } from '../../tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class ProductOwnerSidesheetService {
    private readonly entityService;
    private readonly api;
    constructor(entityService: EntityService, api: TsbApiService);
    buildOrgRulerColumn(ref: IEntity): IEntityColumn;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductOwnerSidesheetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductOwnerSidesheetService>;
}
