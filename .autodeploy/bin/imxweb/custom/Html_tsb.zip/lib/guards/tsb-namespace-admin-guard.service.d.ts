import { OnDestroy } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AppConfigService, AuthenticationService } from 'qbm';
import { TsbPermissionsService } from '../admin/tsb-permissions.service';
import * as i0 from "@angular/core";
export declare class TsbNamespaceAdminGuardService implements CanActivate, OnDestroy {
    private readonly authentication;
    private readonly permissionService;
    private readonly appConfig;
    private readonly router;
    private onSessionResponse;
    constructor(authentication: AuthenticationService, permissionService: TsbPermissionsService, appConfig: AppConfigService, router: Router);
    canActivate(route: ActivatedRouteSnapshot, _: RouterStateSnapshot): Observable<boolean>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TsbNamespaceAdminGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TsbNamespaceAdminGuardService>;
}
