import { Route, Router } from '@angular/router';
import { CacheService, DynamicMethodService, ExtService, MenuService } from 'qbm';
import { DataExplorerRegistryService, MyResponsibilitiesRegistryService, RequestableEntitlementTypeService } from 'qer';
import { TsbApiService } from './tsb-api-client.service';
import * as i0 from "@angular/core";
export declare class InitService {
    private readonly router;
    private readonly dataExplorerRegistryService;
    private readonly entlTypeService;
    private readonly tsbApiService;
    private readonly dynamicMethodService;
    private readonly menuService;
    private readonly extService;
    private readonly cacheService;
    private readonly myResponsibilitiesRegistryService;
    private cachedUnsConfig;
    constructor(router: Router, dataExplorerRegistryService: DataExplorerRegistryService, entlTypeService: RequestableEntitlementTypeService, tsbApiService: TsbApiService, dynamicMethodService: DynamicMethodService, menuService: MenuService, extService: ExtService, cacheService: CacheService, myResponsibilitiesRegistryService: MyResponsibilitiesRegistryService);
    onInit(routes: Route[]): Promise<void>;
    private loadUnsTypes;
    private addRoutes;
    private setupMenu;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InitService>;
}
