import { Injector, OnInit } from '@angular/core';
import { EuiDownloadOptions } from '@elemental-ui/core';
import { ElementalUiConfigService } from 'qbm';
import { AccountsReportsService } from '../accounts/accounts-reports.service';
import { HttpClient } from '@angular/common/http';
import { Overlay } from '@angular/cdk/overlay';
import * as i0 from "@angular/core";
export declare class ReportButtonExtComponent implements OnInit {
    private readonly elementalUiConfigService;
    private readonly service;
    private readonly http;
    private readonly injector;
    private readonly overlay;
    downloadOptions: EuiDownloadOptions;
    referrer: string;
    isAvailable: boolean;
    constructor(elementalUiConfigService: ElementalUiConfigService, service: AccountsReportsService, http: HttpClient, injector: Injector, overlay: Overlay);
    ngOnInit(): Promise<void>;
    viewReport(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReportButtonExtComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReportButtonExtComponent, "imx-report-button-ext", never, {}, {}, never, never, false>;
}
