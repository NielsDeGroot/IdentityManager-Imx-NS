import * as i0 from "@angular/core";
import * as i1 from "./report-button-ext.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/menu";
import * as i4 from "@elemental-ui/core";
import * as i5 from "@ngx-translate/core";
export declare class ReportButtonExtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReportButtonExtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReportButtonExtModule, [typeof i1.ReportButtonExtComponent], [typeof i2.CommonModule, typeof i3.MatMenuModule, typeof i4.EuiCoreModule, typeof i5.TranslateModule], [typeof i1.ReportButtonExtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReportButtonExtModule>;
}
