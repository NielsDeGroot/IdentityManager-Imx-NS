import { DbObjectKey } from 'imx-qbm-dbts';
export declare type DbObjectKeyBase = {
    TableName: string;
    Keys: ReadonlyArray<string>;
} | DbObjectKey;
export interface DbObjectKeyWrapper {
    dbObjectKey: DbObjectKeyBase;
    columnName?: string;
}
