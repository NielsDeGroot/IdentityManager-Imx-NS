import { InitService } from './init.service';
import * as i0 from "@angular/core";
import * as i1 from "./accounts/accounts.module";
import * as i2 from "qer";
import * as i3 from "qbm";
import * as i4 from "@angular/common";
import * as i5 from "./groups/groups.module";
import * as i6 from "@angular/router";
import * as i7 from "@angular/material/icon";
import * as i8 from "@angular/material/list";
import * as i9 from "@ngx-translate/core";
import * as i10 from "./report-button-ext/report-button-ext.module";
export declare class TsbConfigModule {
    private readonly initializer;
    constructor(initializer: InitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<TsbConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TsbConfigModule, never, [typeof i1.AccountsModule, typeof i2.BusinessownerAddonTileModule, typeof i2.BusinessownerOverviewTileModule, typeof i3.CdrModule, typeof i4.CommonModule, typeof i5.GroupsModule, typeof i6.RouterModule, typeof i7.MatIconModule, typeof i8.MatListModule, typeof i3.TileModule, typeof i9.TranslateModule, typeof i10.ReportButtonExtModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TsbConfigModule>;
}
