import * as i4$1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, Component, Inject, NgModule } from '@angular/core';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i1 from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import * as i4 from 'qbm';
import { DataSourceWrapper, DataSourceToolbarModule, DataTableModule, CdrModule, QbmModule, RouteGuardService } from 'qbm';
import * as i2 from '@elemental-ui/core';
import { EUI_SIDESHEET_DATA, EuiCoreModule, EuiMaterialModule } from '@elemental-ui/core';
import { LocalEntityColumn, DbObjectKey } from 'imx-qbm-dbts';
import { V2Client, TypedClient } from 'imx-api-uci';
import * as i5 from '@angular/material/button';
import * as i6 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class UciApiService {
    constructor(config, logger, translationProvider) {
        this.config = config;
        this.logger = logger;
        this.translationProvider = translationProvider;
        try {
            this.logger.debug(this, 'Initializing UCI API service');
            // Use schema loaded by QBM client
            const schemaProvider = config.client;
            this.c = new V2Client(this.config.apiClient, schemaProvider);
            this.tc = new TypedClient(this.c, this.translationProvider);
        }
        catch (e) {
            this.logger.error(this, e);
        }
    }
    get typedClient() {
        return this.tc;
    }
    get client() {
        return this.c;
    }
    get apiClient() {
        return this.config.apiClient;
    }
}
UciApiService.ɵfac = function UciApiService_Factory(t) { return new (t || UciApiService)(i0.ɵɵinject(i4.AppConfigService), i0.ɵɵinject(i4.ClassloggerService), i0.ɵɵinject(i4.ImxTranslationProviderService)); };
UciApiService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: UciApiService, factory: UciApiService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UciApiService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: i4.AppConfigService }, { type: i4.ClassloggerService }, { type: i4.ImxTranslationProviderService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ChangeSidesheetComponent_div_1_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const idx_r2 = i0.ɵɵnextContext().index;
    const ctx_r3 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate2("(", idx_r2 + 1, "/", ctx_r3.changeDetail.length, ")");
} }
function ChangeSidesheetComponent_div_1_eui_badge_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 10);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Successful"));
} }
function ChangeSidesheetComponent_div_1_eui_badge_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 11);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Pending"));
} }
function ChangeSidesheetComponent_div_1_eui_badge_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 12);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Failed"));
} }
function ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if creating the object in the cloud application was successful or failed."), " ");
} }
function ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if deleting the object in the cloud application was successful or failed."), " ");
} }
function ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, "#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if changing the object in the cloud application was successful or failed."), " ");
} }
function ChangeSidesheetComponent_div_1_eui_alert_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-alert", 13);
    i0.ɵɵtemplate(1, ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_1_Template, 3, 3, "ng-container", 3);
    i0.ɵɵtemplate(2, ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_2_Template, 3, 3, "ng-container", 3);
    i0.ɵɵtemplate(3, ChangeSidesheetComponent_div_1_eui_alert_9_ng_container_3_Template, 3, 3, "ng-container", 3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const cdetail_r1 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵproperty("condensed", true)("colored", true);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", cdetail_r1.Operation.value == "I");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", cdetail_r1.Operation.value == "D");
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", cdetail_r1.Operation.value == "U");
} }
function ChangeSidesheetComponent_div_1_div_12_Template(rf, ctx) { if (rf & 1) {
    const _r16 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 14)(1, "button", 15);
    i0.ɵɵlistener("click", function ChangeSidesheetComponent_div_1_div_12_Template_button_click_1_listener() { i0.ɵɵrestoreView(_r16); const cdetail_r1 = i0.ɵɵnextContext().$implicit; const ctx_r14 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r14.markAsDone(cdetail_r1)); });
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "translate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 16);
    i0.ɵɵlistener("click", function ChangeSidesheetComponent_div_1_div_12_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r16); const cdetail_r1 = i0.ɵɵnextContext().$implicit; const ctx_r17 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r17.markAsError(cdetail_r1)); });
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "translate");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 2, "#LDS#Mark as successful"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 4, "#LDS#Mark as failed"));
} }
const _c0$1 = function (a0, a1) { return [a0, a1]; };
function ChangeSidesheetComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "mat-card")(2, "h4", 2);
    i0.ɵɵtext(3);
    i0.ɵɵpipe(4, "translate");
    i0.ɵɵtemplate(5, ChangeSidesheetComponent_div_1_ng_container_5_Template, 2, 2, "ng-container", 3);
    i0.ɵɵtemplate(6, ChangeSidesheetComponent_div_1_eui_badge_6_Template, 3, 3, "eui-badge", 4);
    i0.ɵɵtemplate(7, ChangeSidesheetComponent_div_1_eui_badge_7_Template, 3, 3, "eui-badge", 5);
    i0.ɵɵtemplate(8, ChangeSidesheetComponent_div_1_eui_badge_8_Template, 3, 3, "eui-badge", 6);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(9, ChangeSidesheetComponent_div_1_eui_alert_9_Template, 4, 5, "eui-alert", 7);
    i0.ɵɵelement(10, "imx-property-viewer", 8)(11, "imx-property-viewer", 8);
    i0.ɵɵtemplate(12, ChangeSidesheetComponent_div_1_div_12_Template, 7, 6, "div", 9);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const cdetail_r1 = ctx.$implicit;
    const idx_r2 = ctx.index;
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(4, 9, "#LDS#Heading Requested Operation"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r0.changeDetail.length > 1);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", cdetail_r1.IsProcessed.value == 1);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", cdetail_r1.IsProcessed.value == 0);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", cdetail_r1.IsProcessed.value == 2);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r0.canMarkAsDone(cdetail_r1));
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("properties", i0.ɵɵpureFunction2(11, _c0$1, cdetail_r1.Operation.Column, cdetail_r1.CreationDate.Column));
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("properties", ctx_r0.changeProperties[idx_r2]);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", ctx_r0.canMarkAsDone(cdetail_r1));
} }
class ChangeSidesheetComponent {
    constructor(change, uciApi, sidesheetRef, confirmation) {
        this.uciApi = uciApi;
        this.sidesheetRef = sidesheetRef;
        this.confirmation = confirmation;
        this.changeDetail = [];
        this.manualChangeData = [];
        this.changeProperties = [];
        this.changeDetail = change.Data;
        this.manualChangeData = change.extendedData.Operations;
        // build entity columns from extended data
        this.changeProperties = this.manualChangeData.map((d) => {
            return d.map((c) => {
                const prop = new LocalEntityColumn(c.Property, null, null, {
                    Value: c.DiffValue,
                });
                return prop;
            });
        });
    }
    async markAsDone(detail) {
        if (await this.confirmation.confirm({
            Title: '#LDS#Heading Mark As Successful',
            Message: '#LDS#The provisioning process will be marked as successful. Are you sure you have made the requested change in the cloud application?'
        })) {
            await this.save(detail, true);
        }
        ;
    }
    async markAsError(detail) {
        if (await this.confirmation.confirm({
            Title: '#LDS#Heading Mark As Failed',
            Message: '#LDS#The provisioning process will be marked as failed. Are you sure you cannot make the requested change in the cloud application?'
        })) {
            await this.save(detail, false);
        }
        ;
    }
    canMarkAsDone(detail) {
        return detail.IsProcessed.value === 0;
    }
    async save(detail, success) {
        await this.uciApi.client.opsupport_uci_changes_post(detail.GetEntity().GetKeys()[0], { Success: success });
        this.sidesheetRef.close(true /* reload */);
    }
}
ChangeSidesheetComponent.ɵfac = function ChangeSidesheetComponent_Factory(t) { return new (t || ChangeSidesheetComponent)(i0.ɵɵdirectiveInject(EUI_SIDESHEET_DATA), i0.ɵɵdirectiveInject(UciApiService), i0.ɵɵdirectiveInject(i2.EuiSidesheetRef), i0.ɵɵdirectiveInject(i4.ConfirmationService)); };
ChangeSidesheetComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ChangeSidesheetComponent, selectors: [["ng-component"]], decls: 2, vars: 1, consts: [["eui-sidesheet-content", ""], [4, "ngFor", "ngForOf"], ["mat-card-title", ""], [4, "ngIf"], ["class", "state-badge", "color", "green", 4, "ngIf"], ["class", "state-badge", "color", "orange", 4, "ngIf"], ["class", "state-badge", "color", "red", 4, "ngIf"], ["class", "imx-helper-alert", "type", "info", 3, "condensed", "colored", 4, "ngIf"], [3, "properties"], ["class", "button-bar", 4, "ngIf"], ["color", "green", 1, "state-badge"], ["color", "orange", 1, "state-badge"], ["color", "red", 1, "state-badge"], ["type", "info", 1, "imx-helper-alert", 3, "condensed", "colored"], [1, "button-bar"], ["data-imx-identifier", "imx-changeview-markdone", "mat-raised-button", "", "color", "primary", 3, "click"], ["data-imx-identifier", "imx-changeview-markerror", "mat-raised-button", "", "color", "warn", 3, "click"]], template: function ChangeSidesheetComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0);
        i0.ɵɵtemplate(1, ChangeSidesheetComponent_div_1_Template, 13, 14, "div", 1);
        i0.ɵɵelementEnd();
    } if (rf & 2) {
        i0.ɵɵadvance(1);
        i0.ɵɵproperty("ngForOf", ctx.changeDetail);
    } }, dependencies: [i4$1.NgForOf, i4$1.NgIf, i2.EuiAlertComponent, i2.EuiBadgeComponent, i2.EuiSidesheetContentDirective, i5.MatButton, i6.MatCard, i6.MatCardTitle, i4.PropertyViewerComponent, i1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:auto;height:100%}.mat-card[_ngcontent-%COMP%]{margin-bottom:10px}.imx-helper-alert[_ngcontent-%COMP%]{margin:10px 0 20px auto;display:block}.state-badge[_ngcontent-%COMP%]{vertical-align:middle}.button-bar[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-child){margin-right:1em}.eui-dark-theme   [_nghost-%COMP%]{background-color:#2f3233}.eui-contrast-theme   [_nghost-%COMP%]{background-color:#000}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChangeSidesheetComponent, [{
        type: Component,
        args: [{ template: "<div eui-sidesheet-content>\r\n  <div *ngFor=\"let cdetail of changeDetail; let idx = index\">\r\n    <mat-card>\r\n      <h4 mat-card-title>\r\n        {{ '#LDS#Heading Requested Operation' | translate }}\r\n        <ng-container *ngIf=\"changeDetail.length > 1\">({{ idx + 1 }}/{{ changeDetail.length }})</ng-container>\r\n        <eui-badge class=\"state-badge\" *ngIf=\"cdetail.IsProcessed.value == 1\" color=\"green\">{{ '#LDS#Successful' | translate }}</eui-badge>\r\n        <eui-badge class=\"state-badge\" *ngIf=\"cdetail.IsProcessed.value == 0\" color=\"orange\">{{ '#LDS#Pending' | translate }}</eui-badge>\r\n        <eui-badge class=\"state-badge\" *ngIf=\"cdetail.IsProcessed.value == 2\" color=\"red\">{{ '#LDS#Failed' | translate }}</eui-badge>\r\n      </h4>\r\n\r\n      <eui-alert *ngIf=\"canMarkAsDone(cdetail)\" class=\"imx-helper-alert\" type=\"info\" [condensed]=\"true\" [colored]=\"true\">\r\n        <ng-container *ngIf=\"cdetail.Operation.value == 'I'\">\r\n          {{\r\n            '#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if creating the object in the cloud application was successful or failed.' | translate\r\n          }}\r\n        </ng-container>\r\n        <ng-container *ngIf=\"cdetail.Operation.value == 'D'\">\r\n          {{\r\n            '#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if deleting the object in the cloud application was successful or failed.' | translate\r\n          }}\r\n        </ng-container>\r\n        <ng-container *ngIf=\"cdetail.Operation.value == 'U'\">\r\n          {{\r\n            '#LDS#Here you can see the details of the provisioning process. Additionally, you can change the status of the provisioning process if changing the object in the cloud application was successful or failed.' | translate\r\n          }}\r\n        </ng-container>\r\n      </eui-alert>\r\n\r\n      <imx-property-viewer [properties]=\"[cdetail.Operation.Column, cdetail.CreationDate.Column]\"></imx-property-viewer>\r\n\r\n      <imx-property-viewer [properties]=\"changeProperties[idx]\"></imx-property-viewer>\r\n\r\n      <div class=\"button-bar\" *ngIf=\"canMarkAsDone(cdetail)\">\r\n        <button data-imx-identifier=\"imx-changeview-markdone\" mat-raised-button color=\"primary\" (click)=\"markAsDone(cdetail)\">{{ '#LDS#Mark as successful' | translate }}</button>\r\n        <button data-imx-identifier=\"imx-changeview-markerror\" mat-raised-button color=\"warn\" (click)=\"markAsError(cdetail)\">{{ '#LDS#Mark as failed' | translate }}</button>\r\n      </div>\r\n    </mat-card>\r\n  </div>\r\n</div>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:auto;height:100%}.mat-card{margin-bottom:10px}.imx-helper-alert{margin:10px 0 20px auto;display:block}.state-badge{vertical-align:middle}.button-bar button:not(:last-child){margin-right:1em}.eui-dark-theme :host{background-color:#2f3233}.eui-contrast-theme :host{background-color:#000}\n"] }]
    }], function () { return [{ type: undefined, decorators: [{
                type: Inject,
                args: [EUI_SIDESHEET_DATA]
            }] }, { type: UciApiService }, { type: i2.EuiSidesheetRef }, { type: i4.ConfirmationService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
function ChangeViewComponent_mat_card_4_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "div", 11);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const prod_r5 = ctx.$implicit;
    const ctx_r3 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(prod_r5.ObjectKeyElement.Column.GetDisplayValue());
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r3.getTableDisplay(prod_r5));
} }
function ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 15);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Successful"));
} }
function ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 16);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Pending"));
} }
function ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "eui-badge", 17);
    i0.ɵɵtext(1);
    i0.ɵɵpipe(2, "translate");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵadvance(1);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(2, 1, "#LDS#Failed"));
} }
function ChangeViewComponent_mat_card_4_ng_template_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_1_Template, 3, 3, "eui-badge", 12);
    i0.ɵɵtemplate(2, ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_2_Template, 3, 3, "eui-badge", 13);
    i0.ɵɵtemplate(3, ChangeViewComponent_mat_card_4_ng_template_8_eui_badge_3_Template, 3, 3, "eui-badge", 14);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const prod_r6 = ctx.$implicit;
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", prod_r6.IsProcessed.value == 1);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", prod_r6.IsProcessed.value == 0);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("ngIf", prod_r6.IsProcessed.value == 2);
} }
const _c0 = function () { return ["search", "filter"]; };
function ChangeViewComponent_mat_card_4_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "mat-card", 3)(1, "imx-data-source-toolbar", 4, 5);
    i0.ɵɵlistener("search", function ChangeViewComponent_mat_card_4_Template_imx_data_source_toolbar_search_1_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r10 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r10.getData({ search: $event })); })("navigationStateChanged", function ChangeViewComponent_mat_card_4_Template_imx_data_source_toolbar_navigationStateChanged_1_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r12 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r12.getData($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "imx-data-table", 6, 7);
    i0.ɵɵlistener("highlightedEntityChanged", function ChangeViewComponent_mat_card_4_Template_imx_data_table_highlightedEntityChanged_3_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r13 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r13.viewDetails($event)); });
    i0.ɵɵelementStart(5, "imx-data-table-generic-column", 8);
    i0.ɵɵtemplate(6, ChangeViewComponent_mat_card_4_ng_template_6_Template, 4, 2, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "imx-data-table-column", 9);
    i0.ɵɵtemplate(8, ChangeViewComponent_mat_card_4_ng_template_8_Template, 4, 3, "ng-template");
    i0.ɵɵelementEnd();
    i0.ɵɵelement(9, "imx-data-table-column", 9)(10, "imx-data-table-column", 9);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(11, "imx-data-source-paginator", 10);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const _r1 = i0.ɵɵreference(2);
    const ctx_r0 = i0.ɵɵnextContext();
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("options", i0.ɵɵpureFunction0(9, _c0))("settings", ctx_r0.dstSettings);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("dst", _r1)("detailViewVisible", false);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("columnLabel", ctx_r0.entitySchema.Columns.ObjectKeyElement.Display);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("entityColumn", ctx_r0.entitySchema.Columns.IsProcessed);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("entityColumn", ctx_r0.entitySchema.Columns.UID_UCIRoot);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("entityColumn", ctx_r0.entitySchema.Columns.XDateInserted);
    i0.ɵɵadvance(1);
    i0.ɵɵproperty("dst", _r1);
} }
class ChangeViewComponent {
    constructor(translator, uciApi, sidesheet, metadatasvc, busyService) {
        this.translator = translator;
        this.uciApi = uciApi;
        this.sidesheet = sidesheet;
        this.metadatasvc = metadatasvc;
        this.busyService = busyService;
        this.filterOptions = [];
        this.busyCounter = 0;
        this.entitySchema = this.uciApi.typedClient.OpsupportUciChanges.GetSchema();
    }
    async ngOnInit() {
        const dataModel = await this.getDataModel();
        this.filterOptions = dataModel.Filters;
        // set initial value for state =0 (only pending processes)
        const idx = this.filterOptions.findIndex((elem) => elem.Name === 'state');
        if (idx > -1) {
            this.filterOptions[idx].InitialValue = '0';
        }
        this.dstWrapper = new DataSourceWrapper((state, requestOpts, isInitial) => isInitial ? Promise.resolve({ totalCount: 0, Data: [] }) : this.uciApi.typedClient.OpsupportUciChanges.Get(state), [
            this.entitySchema.Columns.ObjectKeyElement,
            this.entitySchema.Columns.IsProcessed,
            this.entitySchema.Columns.UID_UCIRoot,
            this.entitySchema.Columns.XDateInserted,
        ], this.entitySchema, {
            dataModel: dataModel,
        });
        await this.getData({ state: '0' }, true);
    }
    async getData(newState, isInitialLoad = false) {
        this.handleOpenLoader();
        try {
            const s = await this.dstWrapper.getDstSettings(newState, undefined, isInitialLoad);
            for (var d of s.dataSource.Data) {
                const tableName = DbObjectKey.FromXml(d.GetEntity().GetColumn('ObjectKeyElement').GetValue()).TableName;
                await this.metadatasvc.updateNonExisting([tableName]);
            }
            this.dstSettings = s;
        }
        finally {
            this.handleCloseLoader();
        }
    }
    getTableDisplay(d) {
        const tableName = DbObjectKey.FromXml(d.GetEntity().GetColumn('ObjectKeyElement').GetValue()).TableName;
        return this.metadatasvc.tables[tableName].DisplaySingular;
    }
    async viewDetails(change) {
        this.handleOpenLoader();
        var details;
        try {
            const uidChange = change.GetEntity().GetKeys()[0];
            details = await this.uciApi.typedClient.OpsupportUciChangedetail.Get(uidChange);
        }
        finally {
            this.handleCloseLoader();
        }
        const result = await this.sidesheet
            .open(ChangeSidesheetComponent, {
            title: await this.translator.get('#LDS#Heading View Provisioning Process Details').toPromise(),
            subTitle: change.ObjectKeyElement.Column.GetDisplayValue(),
            padding: '0',
            width: '600px',
            testId: 'changeview-details-sidesheet',
            data: details,
        })
            .afterClosed()
            .toPromise();
        if (result) {
            this.getData();
        }
    }
    async getDataModel() {
        return this.uciApi.client.opsupport_uci_changes_datamodel_get();
    }
    handleOpenLoader() {
        this.busyCounter++;
        if (!this.busyIndicator) {
            this.busyIndicator = this.busyService.show();
        }
    }
    handleCloseLoader() {
        if (this.busyCounter > 0) {
            this.busyCounter--;
        }
        if (this.busyCounter === 0 && this.busyIndicator) {
            this.busyService.hide(this.busyIndicator);
            this.busyIndicator = undefined;
        }
    }
}
ChangeViewComponent.ɵfac = function ChangeViewComponent_Factory(t) { return new (t || ChangeViewComponent)(i0.ɵɵdirectiveInject(i1.TranslateService), i0.ɵɵdirectiveInject(UciApiService), i0.ɵɵdirectiveInject(i2.EuiSidesheetService), i0.ɵɵdirectiveInject(i4.MetadataService), i0.ɵɵdirectiveInject(i2.EuiLoadingService)); };
ChangeViewComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ChangeViewComponent, selectors: [["imx-change-view"]], decls: 5, vars: 4, consts: [[1, "imx-content-header"], [1, "mat-headline"], ["class", "imx-table-container", 4, "ngIf"], [1, "imx-table-container"], ["data-imx-identifier", "changeview-dst", 3, "options", "settings", "search", "navigationStateChanged"], ["dst", ""], ["mode", "manual", "noDataText", "#LDS#There are currently no pending provisioning processes.", "noDataText", "#LDS#There are currently no pending provisioning processes.", "data-imx-identifier", "changeview-datatable", 1, "imx-changeview-table", 3, "dst", "detailViewVisible", "highlightedEntityChanged"], ["dataTable", ""], ["columnName", "ObjectKeyElement", 3, "columnLabel"], [3, "entityColumn"], ["data-imx-identifier", "changeview-paginator", 3, "dst"], [1, "subtitle"], ["class", "state-badge", "color", "green", 4, "ngIf"], ["class", "state-badge", "color", "orange", 4, "ngIf"], ["class", "state-badge", "color", "red", 4, "ngIf"], ["color", "green", 1, "state-badge"], ["color", "orange", 1, "state-badge"], ["color", "red", 1, "state-badge"]], template: function ChangeViewComponent_Template(rf, ctx) { if (rf & 1) {
        i0.ɵɵelementStart(0, "div", 0)(1, "h2", 1);
        i0.ɵɵtext(2);
        i0.ɵɵpipe(3, "translate");
        i0.ɵɵelementEnd()();
        i0.ɵɵtemplate(4, ChangeViewComponent_mat_card_4_Template, 12, 10, "mat-card", 2);
    } if (rf & 2) {
        i0.ɵɵadvance(2);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(3, 2, "#LDS#Heading Pending Provisioning Processes"), " ");
        i0.ɵɵadvance(2);
        i0.ɵɵproperty("ngIf", ctx.dstWrapper && ctx.dstSettings);
    } }, dependencies: [i4$1.NgIf, i2.EuiBadgeComponent, i6.MatCard, i4.DataSourceToolbarComponent, i4.DataSourcePaginatorComponent, i4.DataTableComponent, i4.DataTableColumnComponent, i4.DataTableGenericColumnComponent, i1.TranslatePipe], styles: ["[_nghost-%COMP%]{display:flex;flex-direction:column;overflow:hidden;flex-grow:1}.imx-table-container[_ngcontent-%COMP%]{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}.subtitle[_ngcontent-%COMP%]{font-size:smaller;color:#919799;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.state-badge[_ngcontent-%COMP%]{vertical-align:middle}.imx-table-container[_ngcontent-%COMP%], .imx-table-card[_ngcontent-%COMP%]{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto;margin:2px}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChangeViewComponent, [{
        type: Component,
        args: [{ selector: 'imx-change-view', template: "<div class=\"imx-content-header\">\r\n  <h2 class=\"mat-headline\">\r\n    {{ '#LDS#Heading Pending Provisioning Processes' | translate }}\r\n  </h2>\r\n</div>\r\n\r\n<mat-card class=\"imx-table-container\" *ngIf=\"dstWrapper && dstSettings\">\r\n  <imx-data-source-toolbar\r\n    #dst\r\n    [options]=\"['search', 'filter']\"\r\n    [settings]=\"dstSettings\"\r\n    (search)=\"getData({ search: $event })\"\r\n    (navigationStateChanged)=\"getData($event)\"\r\n    data-imx-identifier=\"changeview-dst\"\r\n  >\r\n  </imx-data-source-toolbar>\r\n  <imx-data-table\r\n    #dataTable\r\n    [dst]=\"dst\"\r\n    class=\"imx-changeview-table\"\r\n    [detailViewVisible]=\"false\"\r\n    mode=\"manual\"\r\n    noDataText=\"#LDS#There are currently no pending provisioning processes.\"\r\n    (highlightedEntityChanged)=\"viewDetails($event)\"\r\n    noDataText=\"#LDS#There are currently no pending provisioning processes.\"\r\n    data-imx-identifier=\"changeview-datatable\"\r\n  >\r\n    <imx-data-table-generic-column columnName=\"ObjectKeyElement\" [columnLabel]=\"entitySchema.Columns.ObjectKeyElement.Display\">\r\n      <ng-template let-prod>\r\n        <div>{{ prod.ObjectKeyElement.Column.GetDisplayValue() }}</div>\r\n        <div class=\"subtitle\">{{ getTableDisplay(prod) }}</div>\r\n      </ng-template>\r\n    </imx-data-table-generic-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchema.Columns.IsProcessed\">\r\n      <ng-template let-prod>\r\n        <div>\r\n          <eui-badge class=\"state-badge\" *ngIf=\"prod.IsProcessed.value == 1\" color=\"green\">{{ '#LDS#Successful' | translate }}</eui-badge>\r\n          <eui-badge class=\"state-badge\" *ngIf=\"prod.IsProcessed.value == 0\" color=\"orange\">{{ '#LDS#Pending' | translate }}</eui-badge>\r\n          <eui-badge class=\"state-badge\" *ngIf=\"prod.IsProcessed.value == 2\" color=\"red\">{{ '#LDS#Failed' | translate }}</eui-badge>\r\n        </div>\r\n      </ng-template>\r\n    </imx-data-table-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchema.Columns.UID_UCIRoot\"> </imx-data-table-column>\r\n    <imx-data-table-column [entityColumn]=\"entitySchema.Columns.XDateInserted\"> </imx-data-table-column>\r\n  </imx-data-table>\r\n  <imx-data-source-paginator data-imx-identifier=\"changeview-paginator\" [dst]=\"dst\"> </imx-data-source-paginator>\r\n</mat-card>\r\n", styles: ["/**\n * @copyright One Identity 2022\n * @license All Rights Reserved\n */:host{display:flex;flex-direction:column;overflow:hidden;flex-grow:1}.imx-table-container{flex:1 1 auto;display:flex;flex-direction:column;overflow:auto}.subtitle{font-size:smaller;color:#919799;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.state-badge{vertical-align:middle}.imx-table-container,.imx-table-card{display:flex;flex-direction:column;overflow:hidden;height:inherit;flex:1 1 auto;margin:2px}\n"] }]
    }], function () { return [{ type: i1.TranslateService }, { type: UciApiService }, { type: i2.EuiSidesheetService }, { type: i4.MetadataService }, { type: i2.EuiLoadingService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class ChangeViewModule {
}
ChangeViewModule.ɵfac = function ChangeViewModule_Factory(t) { return new (t || ChangeViewModule)(); };
ChangeViewModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ChangeViewModule });
ChangeViewModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        EuiCoreModule,
        EuiMaterialModule,
        DataSourceToolbarModule,
        DataTableModule,
        MatCardModule,
        CdrModule,
        QbmModule,
        TranslateModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ChangeViewModule, [{
        type: NgModule,
        args: [{
                declarations: [
                    ChangeViewComponent,
                    ChangeSidesheetComponent
                ],
                imports: [
                    CommonModule,
                    EuiCoreModule,
                    EuiMaterialModule,
                    DataSourceToolbarModule,
                    DataTableModule,
                    MatCardModule,
                    CdrModule,
                    QbmModule,
                    TranslateModule
                ]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ChangeViewModule, { declarations: [ChangeViewComponent,
        ChangeSidesheetComponent], imports: [CommonModule,
        EuiCoreModule,
        EuiMaterialModule,
        DataSourceToolbarModule,
        DataTableModule,
        MatCardModule,
        CdrModule,
        QbmModule,
        TranslateModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
class InitService {
    constructor(router, menuService) {
        this.router = router;
        this.menuService = menuService;
        this.setupMenu();
    }
    onInit(routes) {
        this.addRoutes(routes);
    }
    addRoutes(routes) {
        const config = this.router.config;
        routes.forEach(route => {
            config.unshift(route);
        });
        this.router.resetConfig(config);
    }
    setupMenu() {
        this.menuService.addMenuFactories((preProps, groups) => {
            const items = [];
            if (groups.includes('UCI_4_CLOUD_OPERATOR')
                // || groups.includes('UCI_4_CLOUD_AUDITOR')
                || groups.includes('UCI_4_CLOUD_ADMINISTRATOR')) {
                items.push({
                    id: 'UCI_PendingOperations',
                    route: 'provisioning',
                    title: '#LDS#Menu Entry Pending provisioning processes',
                    sorting: '30-40',
                });
            }
            if (items.length === 0) {
                return null;
            }
            return {
                id: 'OpsWeb_ROOT_Synchronization',
                title: '#LDS#Synchronization',
                sorting: '30',
                items
            };
        });
    }
}
InitService.ɵfac = function InitService_Factory(t) { return new (t || InitService)(i0.ɵɵinject(i1$1.Router), i0.ɵɵinject(i4.MenuService)); };
InitService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: InitService, factory: InitService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(InitService, [{
        type: Injectable,
        args: [{ providedIn: 'root' }]
    }], function () { return [{ type: i1$1.Router }, { type: i4.MenuService }]; }, null); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
const routes = [
    {
        path: 'provisioning',
        component: ChangeViewComponent,
        canActivate: [RouteGuardService],
        resolve: [RouteGuardService]
    }
];
class UciConfigModule {
    constructor(initializer) {
        this.initializer = initializer;
        console.log('🔥 UCI loaded');
        this.initializer.onInit(routes);
        console.log('▶️ UCI initialized');
    }
}
UciConfigModule.ɵfac = function UciConfigModule_Factory(t) { return new (t || UciConfigModule)(i0.ɵɵinject(InitService)); };
UciConfigModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: UciConfigModule });
UciConfigModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        RouterModule.forChild(routes),
        ChangeViewModule,
        TranslateModule] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(UciConfigModule, [{
        type: NgModule,
        args: [{
                declarations: [],
                imports: [
                    CommonModule,
                    RouterModule.forChild(routes),
                    ChangeViewModule,
                    TranslateModule
                ]
            }]
    }], function () { return [{ type: InitService }]; }, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(UciConfigModule, { imports: [CommonModule, i1$1.RouterModule, ChangeViewModule,
        TranslateModule] }); })();

/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2023 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

/**
 * Generated bundle index. Do not edit.
 */

export { UciConfigModule };
//# sourceMappingURL=uci.mjs.map
