import { EuiSidesheetRef } from '@elemental-ui/core';
import { ManualChangeOperation, ManualChangeOperationData, OpsupportUciChangedetail } from 'imx-api-uci';
import { ExtendedTypedEntityCollection, IEntityColumn } from 'imx-qbm-dbts';
import { ConfirmationService } from 'qbm';
import { UciApiService } from '../uci-api-client.service';
import * as i0 from "@angular/core";
export declare class ChangeSidesheetComponent {
    private readonly uciApi;
    private readonly sidesheetRef;
    private readonly confirmation;
    changeDetail: OpsupportUciChangedetail[];
    manualChangeData: ManualChangeOperation[][];
    changeProperties: IEntityColumn[][];
    constructor(change: ExtendedTypedEntityCollection<OpsupportUciChangedetail, ManualChangeOperationData>, uciApi: UciApiService, sidesheetRef: EuiSidesheetRef, confirmation: ConfirmationService);
    markAsDone(detail: OpsupportUciChangedetail): Promise<void>;
    markAsError(detail: OpsupportUciChangedetail): Promise<void>;
    canMarkAsDone(detail: OpsupportUciChangedetail): boolean;
    private save;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChangeSidesheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChangeSidesheetComponent, "ng-component", never, {}, {}, never, never, false>;
}
