import { OnInit } from '@angular/core';
import { EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { OpsupportUciChanges } from 'imx-api-uci';
import { CollectionLoadParameters, DataModel, EntitySchema, TypedEntity } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings, DataSourceWrapper, MetadataService } from 'qbm';
import { UciApiService } from '../uci-api-client.service';
import { ChangeViewService } from './change-view.service';
import * as i0 from "@angular/core";
export declare class ChangeViewComponent implements OnInit {
    private readonly translator;
    private readonly uciApi;
    private readonly changeviewService;
    private readonly sidesheet;
    private readonly metadatasvc;
    dstWrapper: DataSourceWrapper<OpsupportUciChanges>;
    dstSettings: DataSourceToolbarSettings;
    selectedChange: OpsupportUciChanges;
    entitySchema: EntitySchema;
    private filterOptions;
    constructor(translator: TranslateService, uciApi: UciApiService, changeviewService: ChangeViewService, sidesheet: EuiSidesheetService, metadatasvc: MetadataService);
    ngOnInit(): Promise<void>;
    getData(newState?: CollectionLoadParameters & {
        state?: string;
    }, isInitialLoad?: boolean): Promise<void>;
    getTableDisplay(d: TypedEntity): string;
    viewDetails(change: OpsupportUciChanges): Promise<void>;
    getDataModel(): Promise<DataModel>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChangeViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChangeViewComponent, "imx-change-view", never, {}, {}, never, never, false>;
}
