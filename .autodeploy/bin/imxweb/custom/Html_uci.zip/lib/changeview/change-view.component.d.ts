import { OnInit } from '@angular/core';
import { EuiLoadingService, EuiSidesheetService } from '@elemental-ui/core';
import { TranslateService } from '@ngx-translate/core';
import { OpsupportUciChanges } from 'imx-api-uci';
import { CollectionLoadParameters, DataModel, EntitySchema, TypedEntity } from 'imx-qbm-dbts';
import { DataSourceToolbarSettings, DataSourceWrapper, MetadataService } from 'qbm';
import { UciApiService } from '../uci-api-client.service';
import * as i0 from "@angular/core";
export declare class ChangeViewComponent implements OnInit {
    private readonly translator;
    private readonly uciApi;
    private readonly sidesheet;
    private readonly metadatasvc;
    private readonly busyService;
    dstWrapper: DataSourceWrapper<OpsupportUciChanges>;
    dstSettings: DataSourceToolbarSettings;
    selectedChange: OpsupportUciChanges;
    entitySchema: EntitySchema;
    private filterOptions;
    private busyIndicator;
    private busyCounter;
    constructor(translator: TranslateService, uciApi: UciApiService, sidesheet: EuiSidesheetService, metadatasvc: MetadataService, busyService: EuiLoadingService);
    ngOnInit(): Promise<void>;
    getData(newState?: CollectionLoadParameters & {
        state?: string;
    }, isInitialLoad?: boolean): Promise<void>;
    getTableDisplay(d: TypedEntity): string;
    viewDetails(change: OpsupportUciChanges): Promise<void>;
    getDataModel(): Promise<DataModel>;
    private handleOpenLoader;
    private handleCloseLoader;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChangeViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChangeViewComponent, "imx-change-view", never, {}, {}, never, never, false>;
}
