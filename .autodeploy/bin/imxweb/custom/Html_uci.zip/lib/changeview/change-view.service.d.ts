import { EuiLoadingService } from "@elemental-ui/core";
import * as i0 from "@angular/core";
export declare class ChangeViewService {
    private readonly busyService;
    constructor(busyService: EuiLoadingService);
    private busyIndicator;
    handleOpenLoader(): void;
    handleCloseLoader(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChangeViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ChangeViewService>;
}
