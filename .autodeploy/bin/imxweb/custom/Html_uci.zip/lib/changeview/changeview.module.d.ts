import * as i0 from "@angular/core";
import * as i1 from "./change-view.component";
import * as i2 from "./change-sidesheet.component";
import * as i3 from "@angular/common";
import * as i4 from "@elemental-ui/core";
import * as i5 from "qbm";
import * as i6 from "@angular/material/card";
import * as i7 from "@ngx-translate/core";
export declare class ChangeViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChangeViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ChangeViewModule, [typeof i1.ChangeViewComponent, typeof i2.ChangeSidesheetComponent], [typeof i3.CommonModule, typeof i4.EuiCoreModule, typeof i4.EuiMaterialModule, typeof i5.DataSourceToolbarModule, typeof i5.DataTableModule, typeof i6.MatCardModule, typeof i5.CdrModule, typeof i5.QbmModule, typeof i7.TranslateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ChangeViewModule>;
}
